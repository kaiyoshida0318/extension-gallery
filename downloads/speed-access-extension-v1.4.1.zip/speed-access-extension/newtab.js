// ============================================
// Speed Access - Chrome Extension (GitHub版)
// ============================================

// ============================================
// 配布用の固定設定 (配布者がここを編集してから配布)
// ユーザーはPATだけ入力すればOK
// ============================================
const FIXED_CONFIG = {
  OWNER: 'kaiyoshida0318',                  // ← GitHubユーザー名 (配布者が事前に設定)
  REPO: 'speed-access-data',                // ← リポジトリ名 (配布者が事前に設定)
  FILE_PATH: 'shared-tabs.json',
  BRANCH: 'main'
};

// 実行時設定 (FIXED_CONFIG + ユーザー入力のPAT)
let GITHUB_CONFIG = {
  ...FIXED_CONFIG,
  TOKEN: ''
};
// 最終同期日時 (タブIDごと)
let lastSyncTimes = {};

const EXPORT_VERSION = 1;

// ============================================
// State
// ============================================
let state = {
  tabs: [],
  activeTabId: null
};

let currentEditingTile = null;
let pendingConfirmAction = null;
let pendingImportData = null;

// タイルドラッグ中の状態
let draggedTile = null;  // { tileId, sourceTabId }
let tabHoverTimer = null;  // タブホバーで切替するためのタイマー

// 画像キャッシュ (URL → Base64 dataURL)
const imageCache = new Map();
const cacheFetchingUrls = new Set();  // フェッチ中URL (重複防止)
let imageCacheLoaded = false;

// アプリログ (デバッグ用)
const APP_LOG = [];
const MAX_LOG_ENTRIES = 200;

function appLog(level, category, message, extra = null) {
  const entry = {
    time: new Date().toISOString(),
    level,        // 'info' | 'warn' | 'error' | 'debug'
    category,     // 'github' | 'sync' | 'image' | 'tab' | 'storage' | 'general'
    message: String(message),
    extra: extra ? (typeof extra === 'string' ? extra : JSON.stringify(extra).slice(0, 500)) : null
  };
  APP_LOG.push(entry);
  if (APP_LOG.length > MAX_LOG_ENTRIES) APP_LOG.shift();

  // コンソールにも出力
  const prefix = `[SpeedAccess/${category}]`;
  if (level === 'error') console.error(prefix, message, extra || '');
  else if (level === 'warn') console.warn(prefix, message, extra || '');
  else console.log(prefix, message, extra || '');
}

// レイアウト設定のデフォルト
const DEFAULT_LAYOUT = {
  columns: 0,   // 0 = 自動 (auto-fill)
  width: 160,
  height: 160,
  gap: 16,
  headerSpacing: 24
};
// 推奨レイアウト (ユーザーが見つけた使いやすい設定)
const RECOMMENDED_LAYOUT = {
  columns: 6,
  width: 260,
  height: 150,
  gap: 8,
  headerSpacing: 64
};
// 全タブのレイアウト設定 { [tabId]: layout }
let allLayouts = {};
// 現在表示中のレイアウト (アクティブタブの設定)
let layoutSettings = { ...DEFAULT_LAYOUT };

// ============================================
// Storage - 個人データ (chrome.storage.local)
// ============================================
const personalStorage = {
  async load() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessData'], (result) => {
        if (result.speedAccessData) {
          resolve(result.speedAccessData);
        } else {
          // 最初は空 (ユーザーが最初のタブを作る)
          resolve({
            tabs: [],
            activeTabId: null
          });
        }
      });
    });
  },

  async save(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessData: data }, resolve);
    });
  },

  async loadLayout() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLayouts', 'speedAccessLayout'], (result) => {
        // 新形式: タブごとのレイアウト
        if (result.speedAccessLayouts && typeof result.speedAccessLayouts === 'object') {
          resolve(result.speedAccessLayouts);
          return;
        }
        // 旧形式: 単一レイアウト (マイグレーション)
        if (result.speedAccessLayout) {
          const oldLayout = { ...DEFAULT_LAYOUT, ...result.speedAccessLayout };
          // 旧設定を全タブのデフォルトとして扱う
          resolve({ _default: oldLayout });
          return;
        }
        resolve({});
      });
    });
  },

  async saveLayout(allLayouts) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLayouts: allLayouts }, resolve);
    });
  },

  async loadImageCache() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessImageCache'], (result) => {
        resolve(result.speedAccessImageCache || {});
      });
    });
  },

  async saveImageCache(cacheObj) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessImageCache: cacheObj }, resolve);
    });
  },

  async loadSyncConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessSyncConfig'], (result) => {
        resolve(result.speedAccessSyncConfig || null);
      });
    });
  },

  async saveSyncConfig(config) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessSyncConfig: config }, resolve);
    });
  },

  async loadLastSyncTimes() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLastSyncTimes'], (result) => {
        resolve(result.speedAccessLastSyncTimes || {});
      });
    });
  },

  async saveLastSyncTimes(times) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLastSyncTimes: times }, resolve);
    });
  }
};

// ============================================
// Storage - 共有データ (GitHub API)
// ============================================
const sharedStorage = {
  // ファイルごとのSHAをキャッシュ (GitHubの更新にはSHAが必要)
  _fileSha: null,

  isConfigured() {
    return GITHUB_CONFIG.OWNER.trim().length > 0 &&
           GITHUB_CONFIG.REPO.trim().length > 0 &&
           GITHUB_CONFIG.TOKEN.trim().length > 0;
  },

  _apiUrl() {
    return `https://api.github.com/repos/${GITHUB_CONFIG.OWNER.trim()}/${GITHUB_CONFIG.REPO.trim()}/contents/${GITHUB_CONFIG.FILE_PATH.trim()}`;
  },

  _headers() {
    return {
      'Authorization': `Bearer ${GITHUB_CONFIG.TOKEN.trim()}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28'
    };
  },

  // UTF-8文字列をBase64に
  _encodeBase64(str) {
    // 日本語などマルチバイト文字対応
    return btoa(unescape(encodeURIComponent(str)));
  },

  _decodeBase64(str) {
    return decodeURIComponent(escape(atob(str.replace(/\n/g, ''))));
  },

  async fetchAll() {
    if (!this.isConfigured()) {
      appLog('warn', 'github', 'fetchAll skipped: not configured');
      throw new Error('GitHub連携の初期セットアップが完了していません。README.mdを確認してください。');
    }

    const url = `${this._apiUrl()}?ref=${GITHUB_CONFIG.BRANCH}&_=${Date.now()}`;
    appLog('debug', 'github', 'fetchAll: GET ' + url);
    const res = await fetch(url, {
      headers: this._headers(),
      cache: 'no-store'
    });

    if (res.status === 404) {
      // ファイルがまだ存在しない場合
      this._fileSha = null;
      appLog('info', 'github', 'fetchAll: file not found (404), returning empty');
      return {};
    }
    if (!res.ok) {
      const errText = await res.text();
      appLog('error', 'github', `fetchAll failed: ${res.status}`, errText.slice(0, 200));
      throw new Error(`GitHub API エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const fileData = await res.json();
    this._fileSha = fileData.sha;

    try {
      const content = this._decodeBase64(fileData.content);
      const parsed = JSON.parse(content) || {};
      const keys = Object.keys(parsed);
      appLog('info', 'github', `fetchAll success: ${keys.length} 個の共有タブを取得`, { codes: keys, sha: fileData.sha });
      return parsed;
    } catch (err) {
      appLog('error', 'github', 'fetchAll: JSON parse error', err.message);
      console.error('Parse error:', err);
      return {};
    }
  },

  async saveAll(allData) {
    if (!this.isConfigured()) {
      throw new Error('GitHub連携の初期セットアップが完了していません。');
    }

    // SHAがない場合は取得を試みる
    if (!this._fileSha) {
      try { await this.fetchAll(); } catch {}
    }

    const body = {
      message: `Update shared-tabs.json (${new Date().toISOString()})`,
      content: this._encodeBase64(JSON.stringify(allData, null, 2)),
      branch: GITHUB_CONFIG.BRANCH
    };

    if (this._fileSha) {
      body.sha = this._fileSha;
    }

    const codes = Object.keys(allData);
    appLog('debug', 'github', `saveAll: PUT (${codes.length} codes)`, { codes });

    const res = await fetch(this._apiUrl(), {
      method: 'PUT',
      headers: {
        ...this._headers(),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      const errText = await res.text();

      // SHAのコンフリクト (他のユーザーが先に書き込んだ) → リトライ
      if (res.status === 409 || errText.includes('does not match')) {
        appLog('warn', 'github', 'saveAll: SHA conflict, retrying');
        this._fileSha = null;
        await this.fetchAll();
        return this.saveAll(allData);
      }

      appLog('error', 'github', `saveAll failed: ${res.status}`, errText.slice(0, 200));
      throw new Error(`GitHub 保存エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const result = await res.json();
    this._fileSha = result.content?.sha || null;
    appLog('info', 'github', `saveAll success (${codes.length} codes)`, { sha: this._fileSha });
  },

  async getByCode(code) {
    const all = await this.fetchAll();
    return all[code] || null;
  },

  async saveByCode(code, tabData) {
    const all = await this.fetchAll();
    all[code] = tabData;
    appLog('info', 'github', `saveByCode: ${code}`, { name: tabData.name, tiles: tabData.tiles?.length });
    await this.saveAll(all);
  },

  async deleteByCode(code) {
    const all = await this.fetchAll();
    if (all[code]) {
      delete all[code];
      appLog('info', 'github', `deleteByCode: ${code}`);
      await this.saveAll(all);
    } else {
      appLog('warn', 'github', `deleteByCode: ${code} not found`);
    }
  },

  async renameByCode(code, newName) {
    const all = await this.fetchAll();
    if (all[code]) {
      const oldName = all[code].name;
      all[code].name = newName;
      appLog('info', 'github', `renameByCode: ${code}`, { from: oldName, to: newName });
      await this.saveAll(all);
    } else {
      appLog('warn', 'github', `renameByCode: ${code} not found`);
    }
  }
};

// ============================================
// Helpers
// ============================================
function getFaviconUrl(url) {
  try {
    const domain = new URL(url).hostname;
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
  } catch {
    return '';
  }
}

// ============================================
// 画像キャッシュ
// ============================================
async function loadImageCacheToMemory() {
  if (imageCacheLoaded) return;
  try {
    const stored = await personalStorage.loadImageCache();
    Object.entries(stored).forEach(([key, value]) => {
      imageCache.set(key, value);
    });
  } catch (err) {
    console.error('Failed to load image cache:', err);
  }
  imageCacheLoaded = true;
}

let saveCacheTimer = null;
function scheduleSaveImageCache() {
  if (saveCacheTimer) clearTimeout(saveCacheTimer);
  saveCacheTimer = setTimeout(async () => {
    saveCacheTimer = null;
    const obj = {};
    imageCache.forEach((value, key) => { obj[key] = value; });
    try {
      await personalStorage.saveImageCache(obj);
    } catch (err) {
      console.error('Failed to save image cache:', err);
    }
  }, 1000);
}

// 画像URLをBase64化してキャッシュ
async function fetchAndCacheImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;  // 既にdata:URLならそのまま
  if (imageCache.has(url)) return imageCache.get(url);
  if (cacheFetchingUrls.has(url)) return null;

  cacheFetchingUrls.add(url);
  try {
    const res = await fetch(url, { cache: 'force-cache' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();

    // 300KB以上の画像はキャッシュしない (容量保護)
    if (blob.size > 300 * 1024) {
      cacheFetchingUrls.delete(url);
      return null;
    }

    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    imageCache.set(url, dataUrl);
    scheduleSaveImageCache();
    return dataUrl;
  } catch (err) {
    return null;
  } finally {
    cacheFetchingUrls.delete(url);
  }
}

function getCachedImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;
  return imageCache.get(url) || null;
}

function getDisplayImageSrc(url) {
  if (!url) return '';
  const cached = getCachedImage(url);
  return cached || url;
}

// 表示中のタイル画像をバックグラウンドでプリフェッチ
function prefetchImages(urls) {
  const CONCURRENT = 4;
  const queue = [...new Set(urls)].filter(u =>
    u && !u.startsWith('data:') && !imageCache.has(u) && !cacheFetchingUrls.has(u)
  );

  let running = 0;
  function runNext() {
    while (running < CONCURRENT && queue.length > 0) {
      const url = queue.shift();
      running++;
      fetchAndCacheImage(url).finally(() => {
        running--;
        runNext();
      });
    }
  }
  runNext();
}

function normalizeUrl(url) {
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (!/^https?:\/\//i.test(trimmed)) {
    return 'https://' + trimmed;
  }
  return trimmed;
}

function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function showToast(message, isError = false, duration = 2500) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast' + (isError ? ' error' : '');
  toast.classList.remove('hidden');
  // 既存のタイマーがあればクリア
  if (toast._hideTimer) clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.add('hidden'), duration);
}

function formatDateForFile(d = new Date()) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// ============================================
// Layout settings
// ============================================
function getLayoutForTab(tabId) {
  if (allLayouts[tabId]) {
    return { ...DEFAULT_LAYOUT, ...allLayouts[tabId] };
  }
  // フォールバック: _default (旧形式マイグレーション用)
  if (allLayouts._default) {
    return { ...DEFAULT_LAYOUT, ...allLayouts._default };
  }
  return { ...DEFAULT_LAYOUT };
}

function applyLayoutSettings() {
  const root = document.documentElement;
  root.style.setProperty('--tile-gap', `${layoutSettings.gap}px`);
  root.style.setProperty('--tile-width', `${layoutSettings.width}px`);
  root.style.setProperty('--tile-height', `${layoutSettings.height}px`);
  root.style.setProperty('--header-spacing', `${layoutSettings.headerSpacing}px`);

  // 画面幅から実際に表示できる列数を計算
  const main = document.querySelector('.main');
  const mainPadding = 80; // 左右40pxずつ
  const availableWidth = (main ? main.clientWidth : window.innerWidth) - mainPadding;
  const tileWithGap = layoutSettings.width + layoutSettings.gap;
  const maxFitColumns = Math.max(1, Math.floor((availableWidth + layoutSettings.gap) / tileWithGap));

  // ユーザー設定列数 (0=自動なら maxFitColumns) と実際に入る列数の小さい方
  let actualColumns;
  if (layoutSettings.columns === 0) {
    actualColumns = maxFitColumns;
  } else {
    actualColumns = Math.min(layoutSettings.columns, maxFitColumns);
  }

  // タイル幅は固定。列数だけが画面幅で変動
  const gridTemplate = `repeat(${actualColumns}, ${layoutSettings.width}px)`;
  root.style.setProperty('--grid-template', gridTemplate);
  root.style.setProperty('--tile-columns', String(actualColumns));
}

// ウィンドウリサイズ時に再計算
let resizeTimer = null;
window.addEventListener('resize', () => {
  if (resizeTimer) clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    applyLayoutSettings();
  }, 50);
});

function loadLayoutForActiveTab() {
  layoutSettings = getLayoutForTab(state.activeTabId);
  applyLayoutSettings();
}

function showLayoutModal() {
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();

  // モーダルのタイトルに対象タブ名を表示
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const titleEl = document.querySelector('#layout-modal .modal-header h2');
  if (titleEl && activeTab) {
    titleEl.textContent = `レイアウト設定: ${activeTab.name}`;
  }

  document.getElementById('layout-modal').classList.remove('hidden');
}

function hideLayoutModal() {
  document.getElementById('layout-modal').classList.add('hidden');
}

// ============================================
// 同期設定モーダル (PATのみ入力)
// ============================================
function showSyncModal() {
  document.getElementById('sync-token').value = GITHUB_CONFIG.TOKEN || '';

  // 固定値表示の更新
  document.getElementById('sync-fixed-info').textContent = `${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;

  updateSyncStatus();
  document.getElementById('sync-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('sync-token').focus(), 50);
}

function hideSyncModal() {
  document.getElementById('sync-modal').classList.add('hidden');
}

// ============================================
// 共有タブの管理モーダル
// ============================================
function showManageSharedModal() {
  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }
  document.getElementById('manage-shared-modal').classList.remove('hidden');
  loadManageSharedList();
}

function hideManageSharedModal() {
  document.getElementById('manage-shared-modal').classList.add('hidden');
}

// ============================================
// ログビューア
// ============================================
function showLogModal() {
  document.getElementById('log-modal').classList.remove('hidden');
  renderLogs();
}

function hideLogModal() {
  document.getElementById('log-modal').classList.add('hidden');
}

function renderLogs() {
  const viewer = document.getElementById('log-viewer');
  const levelFilter = document.getElementById('log-filter-level').value;
  const categoryFilter = document.getElementById('log-filter-category').value;

  // フィルタ適用
  const levelOrder = { error: 0, warn: 1, info: 2, debug: 3 };
  const levelThreshold = levelFilter === 'all' ? 99 : levelOrder[levelFilter];

  const filtered = APP_LOG.filter(entry => {
    if (levelFilter !== 'all' && levelOrder[entry.level] > levelThreshold) return false;
    if (categoryFilter !== 'all' && entry.category !== categoryFilter) return false;
    return true;
  });

  document.getElementById('log-count').textContent = `${filtered.length} / ${APP_LOG.length} 件`;

  if (filtered.length === 0) {
    viewer.innerHTML = '<div class="log-empty">該当するログがありません</div>';
    return;
  }

  // 新しいログを上に表示
  const reversed = [...filtered].reverse();
  viewer.innerHTML = reversed.map(entry => {
    const t = entry.time.slice(11, 19);  // HH:MM:SS だけ
    const extra = entry.extra ? `<div class="log-entry-extra">${escapeHtml(entry.extra)}</div>` : '';
    return `
      <div class="log-entry ${entry.level}">
        <span class="log-entry-time">${t}</span>
        <span class="log-entry-level ${entry.level}">${entry.level}</span>
        <span class="log-entry-category">${escapeHtml(entry.category)}</span>
        <span class="log-entry-message">${escapeHtml(entry.message)}</span>
        ${extra}
      </div>
    `;
  }).join('');
}

function clearLogs() {
  if (!confirm('ログを全てクリアしますか？')) return;
  APP_LOG.length = 0;
  appLog('info', 'general', 'ログをクリアしました');
  renderLogs();
}

async function copyLogsToClipboard() {
  const text = APP_LOG.map(entry => {
    const t = entry.time;
    const extra = entry.extra ? ` ${entry.extra}` : '';
    return `[${t}] [${entry.level.toUpperCase()}] [${entry.category}] ${entry.message}${extra}`;
  }).join('\n');

  try {
    await navigator.clipboard.writeText(text);
    showToast(`${APP_LOG.length} 件のログをコピーしました`);
  } catch (err) {
    // フォールバック: テキストエリア経由でコピー
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast(`${APP_LOG.length} 件のログをコピーしました`);
  }
}

async function loadManageSharedList() {
  const listEl = document.getElementById('manage-shared-list');
  listEl.innerHTML = '<div class="shared-list-loading">読み込み中...</div>';

  appLog('info', 'tab', '共有タブ管理画面を開きました');

  try {
    const all = await sharedStorage.fetchAll();
    const codes = Object.keys(all);
    appLog('info', 'tab', `共有タブ管理: ${codes.length} 個のタブを表示`, { codes });

    if (codes.length === 0) {
      listEl.innerHTML = '<div class="shared-list-empty">共有タブがまだありません。</div>';
      return;
    }

    listEl.innerHTML = '';
    codes.forEach(code => {
      const data = all[code];
      const name = data.name || code;
      const tileCount = Array.isArray(data.tiles) ? data.tiles.length : 0;
      // 自分が今このタブを開いているか
      const isOpen = state.tabs.some(t => t.type === 'shared' && t.code === code);

      const item = document.createElement('div');
      item.className = 'manage-shared-item';
      item.innerHTML = `
        <div class="manage-shared-item-info">
          <span class="manage-shared-item-name">${escapeHtml(name)}${isOpen ? ' <span style="color:#1967d2;font-size:11px;">(使用中)</span>' : ''}</span>
          <span class="manage-shared-item-meta">${escapeHtml(code)} ・ ${tileCount} タイル</span>
        </div>
        <div class="manage-shared-item-actions">
          <button class="manage-shared-btn" data-action="rename">名称変更</button>
          <button class="manage-shared-btn danger" data-action="delete">削除</button>
        </div>
      `;

      item.querySelector('[data-action="rename"]').addEventListener('click', () => {
        renameSharedTab(code, name);
      });
      item.querySelector('[data-action="delete"]').addEventListener('click', () => {
        deleteSharedTab(code, name);
      });

      listEl.appendChild(item);
    });
  } catch (err) {
    listEl.innerHTML = `<div class="shared-list-empty">取得に失敗しました。<br>${escapeHtml(err.message)}</div>`;
  }
}

async function renameSharedTab(code, currentName) {
  const newName = prompt(`「${currentName}」の新しい名前を入力してください:`, currentName);
  if (newName === null) return;  // キャンセル
  const trimmed = newName.trim();
  if (!trimmed) {
    showToast('名前を入力してください', true);
    return;
  }
  if (trimmed === currentName) return;  // 変更なし

  try {
    await sharedStorage.renameByCode(code, trimmed);

    // 自分が開いているタブも更新
    const localTab = state.tabs.find(t => t.type === 'shared' && t.code === code);
    if (localTab) {
      localTab.name = trimmed;
      await personalStorage.save(state);
      render();
    }

    showToast('名称を変更しました (全メンバーに反映)');
    loadManageSharedList();  // 一覧を更新
  } catch (err) {
    showToast('名称変更に失敗: ' + err.message, true);
  }
}

function deleteSharedTab(code, name) {
  showConfirm(
    `共有タブ「${name}」を削除しますか？\n\n⚠️ GitHub上の共有データが削除され、全メンバーの画面からも消えます。この操作は取り消せません。`,
    async () => {
      try {
        await sharedStorage.deleteByCode(code);

        // 自分が開いているタブからも削除
        const localTab = state.tabs.find(t => t.type === 'shared' && t.code === code);
        if (localTab) {
          state.tabs = state.tabs.filter(t => t.id !== localTab.id);
          if (state.activeTabId === localTab.id) {
            state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
          }
          if (allLayouts[localTab.id]) {
            delete allLayouts[localTab.id];
            await personalStorage.saveLayout(allLayouts);
          }
          loadLayoutForActiveTab();
          await personalStorage.save(state);
          render();
        }

        showToast('共有タブを削除しました');
        loadManageSharedList();  // 一覧を更新
      } catch (err) {
        showToast('削除に失敗: ' + err.message, true);
      }
    }
  );
}

function updateSyncStatus() {
  const status = document.getElementById('sync-status');
  const statusVal = document.getElementById('sync-status-value');
  const lastTimeVal = document.getElementById('sync-last-time');

  if (sharedStorage.isConfigured()) {
    status.classList.remove('hidden');
    statusVal.textContent = '設定済み';
    statusVal.className = 'ok';
  } else {
    status.classList.remove('hidden');
    statusVal.textContent = '未設定';
    statusVal.className = 'ng';
  }

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared' && lastSyncTimes[activeTab.id]) {
    const date = new Date(lastSyncTimes[activeTab.id]);
    lastTimeVal.textContent = formatDateTime(date);
  } else if (activeTab && activeTab.type === 'shared') {
    lastTimeVal.textContent = '未同期';
  } else {
    lastTimeVal.textContent = '(共有タブを開いてください)';
  }
}

function formatDateTime(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${yyyy}/${mm}/${dd} ${hh}:${mi}`;
}

async function saveSyncSettings() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  GITHUB_CONFIG.TOKEN = token;

  // SHAキャッシュをリセット
  sharedStorage._fileSha = null;

  await personalStorage.saveSyncConfig({ TOKEN: token });

  hideSyncModal();
  showToast('Personal Access Token を保存しました');

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared') {
    await syncActiveSharedTab();
    renderTiles();
  }
}

async function testSyncConnection() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  const statusVal = document.getElementById('sync-status-value');
  document.getElementById('sync-status').classList.remove('hidden');
  statusVal.textContent = '接続中...';
  statusVal.className = '';

  try {
    const url = `https://api.github.com/repos/${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    if (res.ok) {
      statusVal.textContent = '✓ 接続成功';
      statusVal.className = 'ok';
      showToast('接続テストに成功しました');
    } else if (res.status === 401) {
      statusVal.textContent = '✕ トークンが無効';
      statusVal.className = 'ng';
      showToast('トークンが無効です (401)', true);
    } else if (res.status === 404) {
      statusVal.textContent = '✕ リポジトリが見つからない';
      statusVal.className = 'ng';
      showToast(`リポジトリ ${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO} にアクセスできません (404)`, true);
    } else {
      statusVal.textContent = `✕ エラー (${res.status})`;
      statusVal.className = 'ng';
      showToast(`接続エラー: ${res.status}`, true);
    }
  } catch (err) {
    statusVal.textContent = '✕ 接続失敗';
    statusVal.className = 'ng';
    showToast('接続失敗: ' + err.message, true);
  }
}

function updateLayoutValueLabels() {
  const cols = layoutSettings.columns;
  document.getElementById('columns-value').textContent = cols === 0 ? '自動' : `${cols}列`;
  document.getElementById('width-value').textContent = `${layoutSettings.width}px`;
  document.getElementById('height-value').textContent = `${layoutSettings.height}px`;
  document.getElementById('gap-value').textContent = `${layoutSettings.gap}px`;
  document.getElementById('header-spacing-value').textContent = `${layoutSettings.headerSpacing}px`;
}

async function updateLayoutFromSliders() {
  layoutSettings.columns = parseInt(document.getElementById('columns-slider').value, 10);
  layoutSettings.width = parseInt(document.getElementById('width-slider').value, 10);
  layoutSettings.height = parseInt(document.getElementById('height-slider').value, 10);
  layoutSettings.gap = parseInt(document.getElementById('gap-slider').value, 10);
  layoutSettings.headerSpacing = parseInt(document.getElementById('header-spacing-slider').value, 10);
  updateLayoutValueLabels();
  applyLayoutSettings();
  // アクティブタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
}

async function resetLayout() {
  layoutSettings = { ...DEFAULT_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブの設定を削除 (デフォルトに戻す)
  delete allLayouts[state.activeTabId];
  await personalStorage.saveLayout(allLayouts);
  showToast('このタブをデフォルトに戻しました');
}

async function applyRecommendedLayout() {
  layoutSettings = { ...RECOMMENDED_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
  showToast('推奨設定を適用しました');
}

async function applyLayoutToAllTabs() {
  // 現在のレイアウトを全タブに適用
  state.tabs.forEach(tab => {
    allLayouts[tab.id] = { ...layoutSettings };
  });
  await personalStorage.saveLayout(allLayouts);
  showToast('全タブに適用しました');
}

// ============================================
// Sync logic
// ============================================
async function syncActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  try {
    const remote = await sharedStorage.getByCode(activeTab.code);
    if (remote && Array.isArray(remote.tiles)) {
      activeTab.tiles = remote.tiles;
      if (remote.name) activeTab.name = remote.name;
      await personalStorage.save(state);
    }
    // 同期成功 → 時刻を記録
    lastSyncTimes[activeTab.id] = Date.now();
    await personalStorage.saveLastSyncTimes(lastSyncTimes);
  } catch (err) {
    console.error('Sync failed:', err);
    showToast('同期に失敗しました: ' + err.message, true);
  }
}

async function saveSharedTab(tab) {
  try {
    await sharedStorage.saveByCode(tab.code, {
      name: tab.name,
      tiles: tab.tiles
    });
    // 保存成功 → 時刻を記録
    lastSyncTimes[tab.id] = Date.now();
    personalStorage.saveLastSyncTimes(lastSyncTimes).catch(() => {});
  } catch (err) {
    console.error('Save shared failed:', err);
    showToast('共有データの保存に失敗: ' + err.message, true);
    throw err;
  }
}

async function saveActiveTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  await personalStorage.save(state);
  if (activeTab && activeTab.type === 'shared') {
    await saveSharedTab(activeTab);
  }
}

// ============================================
// Export / Import
// ============================================
function exportData() {
  const exportObj = {
    format: 'speed-access',
    version: EXPORT_VERSION,
    exportedAt: new Date().toISOString(),
    tabs: state.tabs.map(tab => ({
      id: tab.id,
      name: tab.name,
      type: tab.type,
      code: tab.code || null,
      tiles: tab.tiles.map(tile => ({
        title: tile.title,
        url: tile.url,
        image: tile.image || ''
      }))
    }))
  };

  const json = JSON.stringify(exportObj, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `speed-access-export-${formatDateForFile()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('エクスポートしました');
}

function parseImportData(raw) {
  if (!raw || typeof raw !== 'object') {
    throw new Error('無効なファイル形式です');
  }

  if (raw.format === 'speed-access' && Array.isArray(raw.tabs)) {
    return raw.tabs.map(tab => ({
      name: tab.name || 'タブ',
      type: tab.type === 'shared' ? 'shared' : 'personal',
      code: tab.code || null,
      tiles: (tab.tiles || []).map(t => ({
        title: t.title || '',
        url: t.url || '',
        image: t.image || ''
      })).filter(t => t.url)
    }));
  }

  if (Array.isArray(raw.dials)) {
    const groups = Array.isArray(raw.groups) ? raw.groups : [{ id: 0, title: 'Home' }];
    const groupMap = {};
    groups.forEach(g => {
      groupMap[g.id] = {
        name: g.title || 'タブ',
        type: 'personal',
        code: null,
        tiles: []
      };
    });

    const sortedDials = [...raw.dials].sort((a, b) => (a.position || 0) - (b.position || 0));

    sortedDials.forEach(dial => {
      const groupId = dial.idgroup !== undefined ? dial.idgroup : 0;
      if (!groupMap[groupId]) {
        groupMap[groupId] = { name: 'その他', type: 'personal', code: null, tiles: [] };
      }
      if (dial.url) {
        let title = dial.title || '';
        title = title.trim();
        const firstToken = title.split(/\s+/)[0];
        if (firstToken && firstToken.length > 0) {
          title = firstToken;
        }
        if (!title || title === '.') {
          try {
            title = new URL(dial.url).hostname.replace(/^www\./, '');
          } catch {
            title = 'リンク';
          }
        }

        groupMap[groupId].tiles.push({
          title,
          url: dial.url,
          image: dial.thumbnail || ''
        });
      }
    });

    const orderedGroups = groups
      .slice()
      .sort((a, b) => (a.position || 0) - (b.position || 0))
      .map(g => groupMap[g.id])
      .filter(Boolean);

    return orderedGroups;
  }

  throw new Error('対応していないファイル形式です');
}

function renderImportPreview(parsedTabs) {
  const container = document.getElementById('import-preview');
  const html = parsedTabs.map(tab => `
    <div class="import-preview-group">
      <div class="import-preview-group-title">
        <span>${escapeHtml(tab.name)}${tab.type === 'shared' ? ' <span class="tab-badge">共有</span>' : ''}</span>
        <span class="import-preview-group-count">${tab.tiles.length} タイル</span>
      </div>
      <div class="import-preview-items">
        ${tab.tiles.slice(0, 5).map(t => escapeHtml(t.title || t.url)).join(' / ')}
        ${tab.tiles.length > 5 ? ` <span style="color:#999">他 ${tab.tiles.length - 5} 件</span>` : ''}
      </div>
    </div>
  `).join('');
  container.innerHTML = html || '<div style="color:#999;font-size:12px;">インポート可能な項目がありません</div>';
}

async function handleImportFile(file) {
  console.log('[Import] ファイル読み込み開始:', file.name, file.size, 'bytes');
  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    console.log('[Import] JSON パース成功');
    const parsed = parseImportData(raw);
    console.log('[Import] データ変換成功:', parsed.length, '個のタブ');
    parsed.forEach((t, i) => {
      console.log(`  [${i}] "${t.name}" - ${t.tiles.length} タイル`);
    });

    pendingImportData = parsed;
    document.getElementById('import-preview-container').classList.remove('hidden');
    renderImportPreview(parsed);
    document.getElementById('import-execute').disabled = parsed.length === 0;
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('ファイルの読み込みに失敗: ' + err.message, true);
    pendingImportData = null;
    document.getElementById('import-preview-container').classList.add('hidden');
    document.getElementById('import-execute').disabled = true;
  }
}

async function executeImport() {
  if (!pendingImportData) return;

  const mode = document.querySelector('input[name="import-mode"]:checked').value;

  console.log('[Import] モード:', mode);
  console.log('[Import] インポート対象:', pendingImportData.length, '個のタブ');

  try {
    if (mode === 'replace') {
      // replaceモード: 全タブをクリア
      state.tabs = [];
    }

    let firstImportedTabId = null;
    let totalTilesAdded = 0;

    for (const importTab of pendingImportData) {
      const newTab = {
        id: generateId('tab'),
        name: importTab.name,
        type: importTab.type === 'shared' ? 'shared' : 'personal',
        tiles: importTab.tiles.map(t => ({
          id: generateId('tile'),
          title: t.title,
          url: t.url,
          image: t.image
        }))
      };

      if (importTab.type === 'shared' && importTab.code) {
        newTab.code = importTab.code;
      } else {
        newTab.type = 'personal';
        delete newTab.code;
      }

      state.tabs.push(newTab);
      totalTilesAdded += newTab.tiles.length;
      if (!firstImportedTabId) firstImportedTabId = newTab.id;
    }

    // インポートしたタブをアクティブに
    if (firstImportedTabId) {
      state.activeTabId = firstImportedTabId;
    }

    console.log('[Import] 完了:', totalTilesAdded, 'タイル追加');
    console.log('[Import] 保存前のstate:', {
      tabs: state.tabs.length,
      totalTiles: state.tabs.reduce((sum, t) => sum + t.tiles.length, 0),
      activeTabId: state.activeTabId
    });

    // chrome.storage.local の 5MB 制限対策: データサイズを確認
    const dataSize = JSON.stringify(state).length;
    console.log('[Import] データサイズ:', Math.round(dataSize / 1024), 'KB');

    if (dataSize > 4.5 * 1024 * 1024) {
      showToast('データが大きすぎます。画像URLを減らしてください', true);
      return;
    }

    await personalStorage.save(state);
    console.log('[Import] 保存完了');

    // 共有タブはリモートにも保存
    if (sharedStorage.isConfigured()) {
      for (const tab of state.tabs) {
        if (tab.type === 'shared' && tab.code) {
          try { await saveSharedTab(tab); } catch (err) {
            console.warn('[Import] 共有保存失敗:', err);
          }
        }
      }
    }

    hideImportModal();
    showToast(`${pendingImportData.length} 個のタブ / ${totalTilesAdded} 個のタイルをインポートしました`);
    pendingImportData = null;
    render();

    // インポートした全タイルの画像をバックグラウンドでキャッシュ
    const allUrls = [];
    state.tabs.forEach(tab => {
      tab.tiles.forEach(t => allUrls.push(t.image || getFaviconUrl(t.url)));
    });
    prefetchImages(allUrls);
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('インポートエラー: ' + err.message, true);
  }
}

// ============================================
// Rendering
// ============================================
function render() {
  const app = document.getElementById('app');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const isSharedTab = activeTab && activeTab.type === 'shared';

  app.innerHTML = `
    <header class="header">
      <div class="header-row">
        <div class="tabs-container" id="tabs-container"></div>
        <div class="header-actions">
          ${isSharedTab ? `
            <div class="shared-code-display" title="このタブの合言葉コード">🔗 共有: ${escapeHtml(activeTab.code)}</div>
            <div class="sync-btn-wrapper">
              <button class="sync-btn" id="sync-btn" title="同期メニュー">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="23 4 23 10 17 10"/>
                  <polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                </svg>
                同期
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-left:2px;">
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>
            </div>
          ` : ''}
          <button class="header-btn" id="settings-btn" title="設定">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
        </div>
      </div>
    </header>
    <main class="main">
      <div class="tiles-grid" id="tiles-grid"></div>
    </main>
  `;

  renderTabs();
  renderTiles();
  attachMainEvents();
  setupTabDropZones();
}

function renderTabs() {
  const container = document.getElementById('tabs-container');
  container.innerHTML = '';

  state.tabs.forEach((tab) => {
    const btn = document.createElement('div');
    btn.className = 'tab' + (tab.id === state.activeTabId ? ' active' : '');
    btn.dataset.tabId = tab.id;
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('draggable', 'true');

    const sharedLabel = tab.type === 'shared'
      ? '<span class="tab-shared-label">共有</span>'
      : '<span class="tab-shared-label placeholder">&nbsp;</span>';
    btn.innerHTML = `
      <div class="tab-content">
        ${sharedLabel}
        <span class="tab-name">${escapeHtml(tab.name)}</span>
      </div>
      <button class="tab-menu-btn" data-action="menu" type="button" aria-label="タブメニュー">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" pointer-events="none">
          <circle cx="12" cy="12" r="1"/>
          <circle cx="12" cy="5" r="1"/>
          <circle cx="12" cy="19" r="1"/>
        </svg>
      </button>
    `;

    btn.addEventListener('click', (e) => {
      const menuBtn = e.target.closest('[data-action="menu"]');
      if (menuBtn) {
        e.stopPropagation();
        e.preventDefault();
        showTabMenu(tab.id, menuBtn);
        return;
      }
      selectTab(tab.id);
    });

    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTabMenu(tab.id, btn);
    });

    // ドラッグ&ドロップ
    btn.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', tab.id);
      btn.classList.add('dragging');
    });

    btn.addEventListener('dragend', () => {
      btn.classList.remove('dragging');
      document.querySelectorAll('.tab').forEach(el => {
        el.classList.remove('drag-over-left', 'drag-over-right');
      });
    });

    btn.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置で左右どちらに挿入するか判定
      const rect = btn.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      btn.classList.remove('drag-over-left', 'drag-over-right');
      if (e.clientX < midpoint) {
        btn.classList.add('drag-over-left');
      } else {
        btn.classList.add('drag-over-right');
      }
    });

    btn.addEventListener('dragleave', () => {
      btn.classList.remove('drag-over-left', 'drag-over-right');
    });

    btn.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const insertRight = btn.classList.contains('drag-over-right');
      btn.classList.remove('drag-over-left', 'drag-over-right');

      const draggedId = e.dataTransfer.getData('text/plain');
      if (!draggedId || draggedId === tab.id) return;

      const draggedIndex = state.tabs.findIndex(t => t.id === draggedId);
      if (draggedIndex < 0) return;

      const [moved] = state.tabs.splice(draggedIndex, 1);

      let dropIndex = state.tabs.findIndex(t => t.id === tab.id);
      if (dropIndex < 0) {
        state.tabs.push(moved);
      } else {
        if (insertRight) dropIndex += 1;
        state.tabs.splice(dropIndex, 0, moved);
      }

      // タブバーだけ再描画 (タイルグリッドは変化なし)
      renderTabs();
      setupTabDropZones();

      // 保存はバックグラウンド
      personalStorage.save(state).catch(err => console.error('save failed:', err));
    });

    container.appendChild(btn);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tab-add-btn';
  addBtn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  `;
  addBtn.title = 'タブを追加';
  addBtn.addEventListener('click', showAddTabModal);
  container.appendChild(addBtn);
}

function renderTiles() {
  const grid = document.getElementById('tiles-grid');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);

  // タブが存在しない場合はウェルカム画面
  if (!activeTab) {
    grid.innerHTML = '';
    grid.classList.add('empty-grid');
    const welcome = document.createElement('div');
    welcome.className = 'welcome-screen';
    welcome.innerHTML = `
      <div class="welcome-icon">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="3" width="7" height="7"/>
          <rect x="14" y="3" width="7" height="7"/>
          <rect x="14" y="14" width="7" height="7"/>
          <rect x="3" y="14" width="7" height="7"/>
        </svg>
      </div>
      <h2>Speed Accessへようこそ</h2>
      <p>最初のタブを作成して始めましょう。<br>個人用/共有用を選べます。</p>
      <button class="btn-primary" id="welcome-create-tab">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="12" y1="5" x2="12" y2="19"/>
          <line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        タブを作成
      </button>
    `;
    grid.appendChild(welcome);
    document.getElementById('welcome-create-tab').addEventListener('click', showAddTabModal);
    return;
  }

  grid.classList.remove('empty-grid');
  grid.innerHTML = '';

  activeTab.tiles.forEach((tile) => {
    const tileEl = document.createElement('a');
    tileEl.className = 'tile';
    tileEl.href = tile.url;
    tileEl.dataset.tileId = tile.id;
    tileEl.setAttribute('draggable', 'true');

    // 画像URL: tile.image があればそれ、なければfavicon
    const primaryUrl = tile.image || getFaviconUrl(tile.url);
    const fallbackUrl = getFaviconUrl(tile.url);
    // キャッシュにあれば Base64 を表示、なければ元URL
    const displaySrc = getDisplayImageSrc(primaryUrl);
    const isFavicon = !tile.image;
    const initialClass = isFavicon ? 'favicon' : '';

    const imageHtml = `<img src="${escapeHtml(displaySrc)}" alt="" class="${initialClass}" data-original-url="${escapeHtml(primaryUrl)}" onerror="this.onerror=null;this.src='${escapeHtml(fallbackUrl)}';this.className='favicon';">`;

    tileEl.innerHTML = `
      ${imageHtml}
    `;

    tileEl.title = tile.title;

    tileEl.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTileMenu(tile, e.clientX, e.clientY);
    });

    // ドラッグ開始 - タイルIDと元タブIDを記録
    tileEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('application/x-tile-id', tile.id);
      e.dataTransfer.setData('application/x-source-tab-id', state.activeTabId);
      // fallback for Firefox/Safari
      e.dataTransfer.setData('text/plain', `tile:${tile.id}`);
      tileEl.classList.add('dragging');
      draggedTile = { tileId: tile.id, sourceTabId: state.activeTabId };
    });

    tileEl.addEventListener('dragend', () => {
      tileEl.classList.remove('dragging');
      document.querySelectorAll('.tile').forEach(el => {
        el.classList.remove('tile-drop-before', 'tile-drop-after');
      });
      document.querySelectorAll('.tile-add').forEach(el => {
        el.classList.remove('tile-drop-before');
      });
      draggedTile = null;
    });

    // ドロップ先としての動作
    tileEl.addEventListener('dragover', (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置でこのタイルの前/後ろに挿入するか判定
      const rect = tileEl.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
      if (e.clientX < midpoint) {
        tileEl.classList.add('tile-drop-before');
      } else {
        tileEl.classList.add('tile-drop-after');
      }
    });

    tileEl.addEventListener('dragleave', (e) => {
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
    });

    tileEl.addEventListener('drop', async (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.stopPropagation();

      const insertAfter = tileEl.classList.contains('tile-drop-after');
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');

      await handleTileDrop(draggedTile, state.activeTabId, tile.id, insertAfter);
    });

    grid.appendChild(tileEl);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tile-add';
  addBtn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
    <span>追加</span>
  `;
  addBtn.addEventListener('click', openAddTile);

  // 追加ボタンへのdrop = 末尾に配置
  addBtn.addEventListener('dragover', (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    addBtn.classList.add('tile-drop-before');
  });
  addBtn.addEventListener('dragleave', () => {
    addBtn.classList.remove('tile-drop-before');
  });
  addBtn.addEventListener('drop', async (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.stopPropagation();
    addBtn.classList.remove('tile-drop-before');
    // 末尾に配置 (anchorTileId = null を渡す)
    await handleTileDrop(draggedTile, state.activeTabId, null, true);
  });

  grid.appendChild(addBtn);

  if (activeTab.tiles.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = `
      <h3>まだタイルがありません</h3>
      <p>「+ 追加」から最初のリンクを登録しましょう</p>
    `;
    grid.insertBefore(empty, addBtn);
  }

  // 表示中タイルの画像をバックグラウンドでプリフェッチ
  if (imageCacheLoaded) {
    const urlsToPrefetch = activeTab.tiles.map(t => t.image || getFaviconUrl(t.url));
    prefetchImages(urlsToPrefetch);
  }
}

function attachMainEvents() {
  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showSyncMenu(syncBtn);
    });
  }

  const settingsBtn = document.getElementById('settings-btn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showSettingsMenu(settingsBtn);
    });
  }
}

// ============================================
// Settings menu
// ============================================
function showSyncMenu(btnEl) {
  // 既存メニューを閉じる
  document.querySelectorAll('.dropdown-menu, .tab-context-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.innerHTML = `
    <button data-action="push">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      反映 (アップロード)
    </button>
    <button data-action="pull">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      取得 (ダウンロード)
    </button>
  `;

  btnEl.parentElement.appendChild(menu);

  menu.querySelector('[data-action="push"]').addEventListener('click', async () => {
    menu.remove();
    await pushActiveSharedTab();
  });
  menu.querySelector('[data-action="pull"]').addEventListener('click', async () => {
    menu.remove();
    await pullActiveSharedTab();
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target) && !btnEl.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 10);
}

// 反映 (アップロード): ローカルの状態をGitHubに送信
async function pushActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) syncBtn.classList.add('syncing');

  try {
    await saveSharedTab(activeTab);
    showToast('反映しました (このタブの内容をGitHubに送信)');
  } catch (err) {
    // saveSharedTab内でtoast表示済み
  } finally {
    if (syncBtn) syncBtn.classList.remove('syncing');
  }
}

// 取得 (ダウンロード): GitHubから最新を取得してローカルに上書き
async function pullActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) syncBtn.classList.add('syncing');

  try {
    await syncActiveSharedTab();
    renderTiles();
    showToast('取得しました (GitHubから最新を読み込み)');
  } catch (err) {
    // 内部でtoast表示済み
  } finally {
    if (syncBtn) syncBtn.classList.remove('syncing');
  }
}

function showSettingsMenu(btnEl) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.innerHTML = `
    <button data-action="layout">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="7" height="7"/>
        <rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/>
        <rect x="3" y="14" width="7" height="7"/>
      </svg>
      レイアウト設定
    </button>
    <button data-action="sync-settings">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="23 4 23 10 17 10"/>
        <polyline points="1 20 1 14 7 14"/>
        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
      </svg>
      同期設定 (PAT)
    </button>
    <button data-action="manage-shared">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"/>
        <path d="M2 17l10 5 10-5"/>
        <path d="M2 12l10 5 10-5"/>
      </svg>
      共有タブの管理
    </button>
    <button data-action="logs">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
        <polyline points="10 9 9 9 8 9"/>
      </svg>
      ログ
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="export">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      全データをエクスポート
    </button>
    <button data-action="import">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      インポート
    </button>
  `;

  btnEl.parentElement.appendChild(menu);

  menu.querySelector('[data-action="layout"]').addEventListener('click', () => {
    menu.remove();
    showLayoutModal();
  });
  menu.querySelector('[data-action="sync-settings"]').addEventListener('click', () => {
    menu.remove();
    showSyncModal();
  });
  menu.querySelector('[data-action="manage-shared"]').addEventListener('click', () => {
    menu.remove();
    showManageSharedModal();
  });
  menu.querySelector('[data-action="logs"]').addEventListener('click', () => {
    menu.remove();
    showLogModal();
  });
  menu.querySelector('[data-action="export"]').addEventListener('click', () => {
    menu.remove();
    exportData();
  });
  menu.querySelector('[data-action="import"]').addEventListener('click', () => {
    menu.remove();
    showImportModal();
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 0);
}

// ============================================
// Tab operations
// ============================================
async function selectTab(tabId) {
  state.activeTabId = tabId;
  await personalStorage.save(state);
  // タブごとのレイアウトを適用
  loadLayoutForActiveTab();
  render();

  const activeTab = state.tabs.find(t => t.id === tabId);
  if (activeTab && activeTab.type === 'shared' && sharedStorage.isConfigured()) {
    await syncActiveSharedTab();
    renderTiles();
  }
}

// ============================================
// タイルのドラッグ&ドロップ処理
// ============================================
async function handleTileDrop(dragged, targetTabId, anchorTileId, insertAfter) {
  const sourceTab = state.tabs.find(t => t.id === dragged.sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const tileIndex = sourceTab.tiles.findIndex(t => t.id === dragged.tileId);
  if (tileIndex < 0) return;

  // ソースから取り出し
  const [tile] = sourceTab.tiles.splice(tileIndex, 1);

  // ターゲット側の挿入位置を決定
  let insertIndex;
  if (anchorTileId === null) {
    insertIndex = targetTab.tiles.length;
  } else {
    const anchorIndex = targetTab.tiles.findIndex(t => t.id === anchorTileId);
    if (anchorIndex < 0) {
      insertIndex = targetTab.tiles.length;
    } else {
      insertIndex = insertAfter ? anchorIndex + 1 : anchorIndex;
    }
  }

  targetTab.tiles.splice(insertIndex, 0, tile);

  // 画面はすぐ更新 (タイルグリッドのみ)
  renderTiles();

  // ストレージへの保存はバックグラウンドで (awaitしない)
  personalStorage.save(state).catch(err => console.error('save failed:', err));

  // 共有タブの場合もバックグラウンドで同期
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error('shared save failed:', err));
  }
  if (targetTab.id !== sourceTab.id && targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error('shared save failed:', err));
  }
}

// ============================================
// タブホバーでの自動切替 (ドラッグ中)
// ============================================
function setupTabDropZones() {
  document.querySelectorAll('.tab').forEach((tabEl) => {
    const tabId = tabEl.dataset.tabId;
    if (!tabId) return;

    tabEl.addEventListener('dragover', (e) => {
      // タイルのドラッグ中だけ反応
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      tabEl.classList.add('tile-drag-over-tab');

      // 既にアクティブなタブなら切替処理不要
      if (tabId === state.activeTabId) return;

      // タイマーが既に動いていれば何もしない
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) return;

      // 既存タイマーをクリア
      if (tabHoverTimer) clearTimeout(tabHoverTimer.timer);

      // 500ms 後にそのタブに切り替え
      const timer = setTimeout(() => {
        if (draggedTile) {
          selectTab(tabId);
        }
        tabHoverTimer = null;
      }, 500);
      tabHoverTimer = { tabId, timer };
    });

    tabEl.addEventListener('dragleave', () => {
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
    });

    tabEl.addEventListener('drop', (e) => {
      // タブ自体への drop は「そのタブに切り替え」のみ (タイルのドロップ先はグリッド)
      if (!draggedTile) return;
      e.preventDefault();
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
      // まだそのタブに切り替わってない場合は切替
      if (tabId !== state.activeTabId) {
        selectTab(tabId);
      }
    });
  });
}

function showTileMenu(tile, x, y) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="edit">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      編集
    </button>
    <button data-action="move">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="9 18 15 12 9 6"/>
      </svg>
      別タブへ移動
    </button>
    <button data-action="copy">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
      別タブへコピー
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      削除
    </button>
  `;

  document.body.appendChild(menu);

  // 画面外にはみ出さないように位置調整
  menu.style.position = 'fixed';
  const menuRect = menu.getBoundingClientRect();
  let left = x;
  let top = y;
  if (left + menuRect.width > window.innerWidth) left = window.innerWidth - menuRect.width - 8;
  if (top + menuRect.height > window.innerHeight) top = window.innerHeight - menuRect.height - 8;
  menu.style.top = `${top}px`;
  menu.style.left = `${left}px`;

  menu.querySelector('[data-action="edit"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    openEditTile(tile);
  });

  menu.querySelector('[data-action="move"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'move');
  });

  menu.querySelector('[data-action="copy"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'copy');
  });

  menu.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    confirmDeleteTile(tile);
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
        document.removeEventListener('contextmenu', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
    document.addEventListener('contextmenu', closeMenu);
  }, 10);
}

// タブ選択モーダル (移動/コピー用)
function showTabSelector(tile, action) {
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>${action === 'move' ? '移動先のタブを選択' : 'コピー先のタブを選択'}</h2>
        <button class="icon-btn" data-action="close">✕</button>
      </div>
      <div class="modal-body">
        <div class="tab-selector-list" id="tab-selector-list"></div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  const list = modal.querySelector('#tab-selector-list');
  const sourceTabId = state.activeTabId;

  state.tabs.forEach(tab => {
    // 移動の場合、現在のタブは選択肢から除外
    if (action === 'move' && tab.id === sourceTabId) return;

    const item = document.createElement('button');
    item.className = 'tab-selector-item';
    const sharedBadge = tab.type === 'shared' ? '<span class="tab-badge" style="margin-left:6px;">共有</span>' : '';
    const currentBadge = tab.id === sourceTabId ? '<span class="tab-badge" style="margin-left:6px;background:#fef3c7;color:#92400e;">現在</span>' : '';
    item.innerHTML = `
      <span>${escapeHtml(tab.name)}${sharedBadge}${currentBadge}</span>
      <span class="tab-selector-count">${tab.tiles.length} タイル</span>
    `;
    item.addEventListener('click', async () => {
      modal.remove();
      if (action === 'move') {
        await moveTile(tile, sourceTabId, tab.id);
      } else {
        await copyTile(tile, tab.id);
      }
    });
    list.appendChild(item);
  });

  if (list.children.length === 0) {
    list.innerHTML = '<div style="color:#999;padding:20px;text-align:center;font-size:13px;">他のタブがありません</div>';
  }

  modal.querySelector('[data-action="close"]').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

async function moveTile(tile, sourceTabId, targetTabId) {
  const sourceTab = state.tabs.find(t => t.id === sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const idx = sourceTab.tiles.findIndex(t => t.id === tile.id);
  if (idx < 0) return;

  const [moved] = sourceTab.tiles.splice(idx, 1);
  targetTab.tiles.push(moved);

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error(err));
  }
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へ移動しました`);
}

async function copyTile(tile, targetTabId) {
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!targetTab) return;

  const copy = {
    id: generateId('tile'),
    title: tile.title,
    url: tile.url,
    image: tile.image
  };
  targetTab.tiles.push(copy);

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へコピーしました`);
}

function showTabMenu(tabId, btnEl) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const convertAction = tab.type === 'shared' ? `
    <button data-action="convert-to-personal">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
      個人タブに変換
    </button>
  ` : `
    <button data-action="convert-to-shared">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="18" cy="5" r="3"/>
        <circle cx="6" cy="12" r="3"/>
        <circle cx="18" cy="19" r="3"/>
        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
      </svg>
      共有タブに変換
    </button>
  `;

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="rename">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      名前を変更
    </button>
    ${convertAction}
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      タブを削除
    </button>
  `;

  document.body.appendChild(menu);

  const rect = btnEl.getBoundingClientRect();
  menu.style.position = 'fixed';
  menu.style.top = `${rect.bottom + 4}px`;
  menu.style.left = `${rect.left}px`;

  menu.querySelector('[data-action="rename"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    startRenameTab(tabId);
  });

  const convertSharedBtn = menu.querySelector('[data-action="convert-to-shared"]');
  if (convertSharedBtn) {
    convertSharedBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      showConvertToSharedModal(tabId);
    });
  }

  const convertPersonalBtn = menu.querySelector('[data-action="convert-to-personal"]');
  if (convertPersonalBtn) {
    convertPersonalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmConvertToPersonal(tabId);
    });
  }

  const deleteBtn = menu.querySelector('[data-action="delete"]');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmDeleteTab(tabId);
    });
  }

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 10);
}

function startRenameTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const tabBtn = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
  if (!tabBtn) return;

  const nameSpan = tabBtn.querySelector('.tab-name');
  const originalName = tab.name;

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tab-name-input';
  input.value = originalName;
  nameSpan.replaceWith(input);
  input.focus();
  input.select();

  const finish = async (save) => {
    const newName = input.value.trim();
    if (save && newName && newName !== originalName) {
      tab.name = newName;
      await saveActiveTab();
      if (tab.type === 'shared' && tab.id !== state.activeTabId) {
        try { await saveSharedTab(tab); } catch {}
      }
    }
    render();
  };

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// ============================================
// タブの種類変換
// ============================================
function showConvertToSharedModal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }

  // 合言葉コードを入力させる (簡易プロンプト)
  const code = prompt(
    `「${tab.name}」を共有タブに変換します。\n\n合言葉コードを入力してください (3文字以上、半角英数字・ハイフン推奨):`,
    ''
  );

  if (code === null) return;  // キャンセル
  const trimmedCode = code.trim();
  if (!trimmedCode || trimmedCode.length < 3) {
    showToast('合言葉コードは3文字以上で入力してください', true);
    return;
  }

  (async () => {
    try {
      const remote = await sharedStorage.getByCode(trimmedCode);
      if (remote && Array.isArray(remote.tiles) && remote.tiles.length > 0) {
        const useExisting = confirm(
          `コード「${trimmedCode}」には既に ${remote.tiles.length} 個のタイルを持つ共有タブが存在します。\n\n「OK」で既存の共有タブに参加 (このタブの ${tab.tiles.length} 個のタイルは破棄)。\n「キャンセル」で中止。`
        );
        if (!useExisting) return;
        tab.tiles = remote.tiles;
        if (remote.name) tab.name = remote.name;
      }

      tab.type = 'shared';
      tab.code = trimmedCode;

      await personalStorage.save(state);
      await saveSharedTab(tab);

      render();
      showToast('共有タブに変換しました');
    } catch (err) {
      showToast('変換に失敗: ' + err.message, true);
    }
  })();
}

function restoreDefaultTabSaveHandler() {
  // モーダルを閉じたら、元の「新しいタブ」用のハンドラに戻す
  const saveBtn = document.getElementById('tab-save');
  saveBtn.textContent = '作成';
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
  newSaveBtn.addEventListener('click', handleAddTab);
}

function confirmConvertToPersonal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab || tab.type !== 'shared') return;

  showConfirm(
    `「${tab.name}」を個人タブに変換しますか？\n\nタブの内容(現在のタイル)はそのまま残り、このブラウザだけで編集・表示するようになります。\n\n※共有データ自体はGitHub上に残ります。他のメンバーには影響しません。`,
    async () => {
      tab.type = 'personal';
      delete tab.code;
      await personalStorage.save(state);
      render();
      showToast('個人タブに変換しました');
    }
  );
}

function confirmDeleteTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  showConfirm(
    `「${tab.name}」タブを削除しますか？${tab.type === 'shared' ? '\n※共有データは残ります(他の人の画面からは消えません)。' : '\n中のタイルも全て削除されます。'}`,
    async () => {
      state.tabs = state.tabs.filter(t => t.id !== tabId);
      if (state.activeTabId === tabId) {
        state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
      }
      // このタブのレイアウト設定も削除
      if (allLayouts[tabId]) {
        delete allLayouts[tabId];
        await personalStorage.saveLayout(allLayouts);
      }
      await personalStorage.save(state);
      loadLayoutForActiveTab();
      render();
      showToast('タブを削除しました');
    }
  );
}

// ============================================
// Add Tab Modal
// ============================================
let selectedSharedCode = null;  // 参加で選択中の共有コード

function showAddTabModal() {
  const modal = document.getElementById('tab-modal');
  document.getElementById('tab-name').value = '';
  document.getElementById('tab-code').value = '';
  document.getElementById('tab-shared-new-name').value = '';
  document.querySelector('input[name="tab-type"][value="personal"]').checked = true;
  document.querySelector('input[name="shared-mode"][value="join"]').checked = true;
  selectedSharedCode = null;

  // 表示状態を初期化 (個人用)
  updateTabModalVisibility();

  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();

  modal.classList.remove('hidden');
  setTimeout(() => document.getElementById('tab-name').focus(), 50);
}

// タブモーダルの表示切替 (個人/共有、参加/新規)
function updateTabModalVisibility() {
  const type = document.querySelector('input[name="tab-type"]:checked').value;
  const sharedMode = document.querySelector('input[name="shared-mode"]:checked')?.value || 'join';

  const nameGroup = document.getElementById('tab-name-group');
  const sharedModeGroup = document.getElementById('tab-shared-mode-group');
  const sharedListGroup = document.getElementById('tab-shared-list-group');
  const sharedNewGroup = document.getElementById('tab-shared-new-group');

  if (type === 'personal') {
    nameGroup.classList.remove('hidden');
    sharedModeGroup.classList.add('hidden');
    sharedListGroup.classList.add('hidden');
    sharedNewGroup.classList.add('hidden');
  } else {
    // 共有用
    nameGroup.classList.add('hidden');
    sharedModeGroup.classList.remove('hidden');

    if (sharedMode === 'join') {
      sharedListGroup.classList.remove('hidden');
      sharedNewGroup.classList.add('hidden');
      loadSharedListForModal();
    } else {
      sharedListGroup.classList.add('hidden');
      sharedNewGroup.classList.remove('hidden');
    }
  }
}

// GitHub から共有リストを取得してモーダルに表示
async function loadSharedListForModal() {
  const listEl = document.getElementById('tab-shared-list');

  if (!sharedStorage.isConfigured()) {
    listEl.innerHTML = '<div class="shared-list-empty">PATが未設定です。<br>歯車 → 同期設定 (PAT) から設定してください。</div>';
    return;
  }

  listEl.innerHTML = '<div class="shared-list-loading">読み込み中...</div>';

  try {
    const all = await sharedStorage.fetchAll();
    const codes = Object.keys(all);

    // 既に開いている共有タブのコードを除外
    const existingCodes = new Set(state.tabs.filter(t => t.type === 'shared').map(t => t.code));

    const available = codes.filter(code => !existingCodes.has(code));

    if (available.length === 0) {
      if (codes.length === 0) {
        listEl.innerHTML = '<div class="shared-list-empty">共有タブがまだありません。<br>「新規作成」から作ってください。</div>';
      } else {
        listEl.innerHTML = '<div class="shared-list-empty">参加できる共有タブはありません。<br>(すべて追加済みです)</div>';
      }
      return;
    }

    listEl.innerHTML = '';
    available.forEach(code => {
      const data = all[code];
      const name = data.name || code;
      const tileCount = Array.isArray(data.tiles) ? data.tiles.length : 0;

      const item = document.createElement('button');
      item.className = 'shared-list-item';
      item.dataset.code = code;
      item.innerHTML = `
        <div class="shared-list-item-info">
          <span class="shared-list-item-name">${escapeHtml(name)}</span>
          <span class="shared-list-item-meta">${escapeHtml(code)}</span>
        </div>
        <span class="shared-list-item-count">${tileCount} タイル</span>
      `;
      item.addEventListener('click', () => {
        // 選択状態を更新
        listEl.querySelectorAll('.shared-list-item').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        selectedSharedCode = code;
      });
      listEl.appendChild(item);
    });
  } catch (err) {
    listEl.innerHTML = `<div class="shared-list-empty">取得に失敗しました。<br>${escapeHtml(err.message)}</div>`;
  }
}

function hideAddTabModal() {
  document.getElementById('tab-modal').classList.add('hidden');
  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();
}

async function handleAddTab() {
  const type = document.querySelector('input[name="tab-type"]:checked').value;

  // ===== 個人タブ =====
  if (type === 'personal') {
    const name = document.getElementById('tab-name').value.trim();
    if (!name) {
      showToast('タブ名を入力してください', true);
      return;
    }
    const newTab = {
      id: generateId('tab'),
      name,
      type: 'personal',
      tiles: []
    };
    state.tabs.push(newTab);
    state.activeTabId = newTab.id;
    await personalStorage.save(state);
    hideAddTabModal();
    render();
    return;
  }

  // ===== 共有タブ =====
  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }

  const sharedMode = document.querySelector('input[name="shared-mode"]:checked').value;

  // --- 既存から参加 ---
  if (sharedMode === 'join') {
    if (!selectedSharedCode) {
      showToast('参加する共有タブを選んでください', true);
      return;
    }

    try {
      const remote = await sharedStorage.getByCode(selectedSharedCode);
      const newTab = {
        id: generateId('tab'),
        name: (remote && remote.name) ? remote.name : selectedSharedCode,
        type: 'shared',
        code: selectedSharedCode,
        tiles: (remote && Array.isArray(remote.tiles)) ? remote.tiles : []
      };
      state.tabs.push(newTab);
      state.activeTabId = newTab.id;
      lastSyncTimes[newTab.id] = Date.now();
      await personalStorage.save(state);
      await personalStorage.saveLastSyncTimes(lastSyncTimes);

      hideAddTabModal();
      render();
      showToast(`「${newTab.name}」に参加しました`);
    } catch (err) {
      showToast('共有データの取得に失敗: ' + err.message, true);
    }
    return;
  }

  // --- 新規作成 ---
  const name = document.getElementById('tab-shared-new-name').value.trim();
  const code = document.getElementById('tab-code').value.trim();

  if (!name) {
    showToast('タブ名を入力してください', true);
    return;
  }
  if (!code || code.length < 3) {
    showToast('合言葉コードは3文字以上で入力してください', true);
    return;
  }

  try {
    // 既存コードと衝突してないかチェック
    const existing = await sharedStorage.getByCode(code);
    if (existing) {
      showToast(`コード「${code}」は既に使われています。別のコードにするか、参加から選んでください`, true);
      return;
    }

    const newTab = {
      id: generateId('tab'),
      name,
      type: 'shared',
      code,
      tiles: []
    };
    state.tabs.push(newTab);
    state.activeTabId = newTab.id;
    await personalStorage.save(state);
    await saveSharedTab(newTab);

    hideAddTabModal();
    render();
    showToast(`共有タブ「${name}」を作成しました`);
  } catch (err) {
    showToast('共有タブの作成に失敗: ' + err.message, true);
  }
}

// ============================================
// Tile Modal
// ============================================
function openAddTile() {
  currentEditingTile = null;
  document.getElementById('tile-modal-title').textContent = '新しいタイル';
  document.getElementById('tile-title').value = '';
  document.getElementById('tile-url').value = '';
  document.getElementById('tile-image-url').value = '';
  setImagePreview('');
  document.getElementById('tile-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('tile-title').focus(), 50);
}

function openEditTile(tile) {
  currentEditingTile = tile;
  document.getElementById('tile-modal-title').textContent = 'タイルを編集';
  document.getElementById('tile-title').value = tile.title;
  document.getElementById('tile-url').value = tile.url;
  const image = tile.image || '';
  document.getElementById('tile-image-url').value = image.startsWith('data:') ? '' : image;
  setImagePreview(image);
  document.getElementById('tile-modal').classList.remove('hidden');
}

function hideTileModal() {
  document.getElementById('tile-modal').classList.add('hidden');
  currentEditingTile = null;
}

function setImagePreview(src) {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (src) {
    img.src = src;
    preview.classList.remove('hidden');
  } else {
    img.src = '';
    preview.classList.add('hidden');
  }
}

function getTileImageValue() {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (!preview.classList.contains('hidden') && img.src) {
    if (img.src.startsWith('data:')) return img.src;
  }
  const urlInput = document.getElementById('tile-image-url').value.trim();
  return urlInput;
}

async function handleSaveTile() {
  const title = document.getElementById('tile-title').value.trim();
  const rawUrl = document.getElementById('tile-url').value.trim();

  if (!title || !rawUrl) {
    showToast('タイトルとURLは必須です', true);
    return;
  }

  const url = normalizeUrl(rawUrl);
  const image = getTileImageValue();

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return;

  if (currentEditingTile) {
    const idx = activeTab.tiles.findIndex(t => t.id === currentEditingTile.id);
    if (idx >= 0) {
      activeTab.tiles[idx] = { ...activeTab.tiles[idx], title, url, image };
    }
  } else {
    activeTab.tiles.push({
      id: generateId('tile'),
      title,
      url,
      image
    });
  }

  try {
    await saveActiveTab();
    hideTileModal();
    renderTiles();
    // 追加・編集したタイルの画像を即キャッシュ (初回から高速表示)
    const primaryUrl = image || getFaviconUrl(url);
    fetchAndCacheImage(primaryUrl);
    if (image) {
      // tile.imageがある場合もfaviconを予備でキャッシュ
      fetchAndCacheImage(getFaviconUrl(url));
    }
  } catch (err) {
    hideTileModal();
    renderTiles();
  }
}

function confirmDeleteTile(tile) {
  showConfirm(`「${tile.title}」を削除しますか？`, async () => {
    const activeTab = state.tabs.find(t => t.id === state.activeTabId);
    if (!activeTab) return;
    activeTab.tiles = activeTab.tiles.filter(t => t.id !== tile.id);
    await saveActiveTab();
    renderTiles();
    showToast('削除しました');
  });
}

// ============================================
// Import Modal
// ============================================
function showImportModal() {
  pendingImportData = null;
  document.getElementById('import-preview-container').classList.add('hidden');
  document.getElementById('import-execute').disabled = true;
  document.getElementById('import-file').value = '';
  document.querySelector('input[name="import-mode"][value="merge"]').checked = true;
  document.getElementById('import-modal').classList.remove('hidden');
}

function hideImportModal() {
  document.getElementById('import-modal').classList.add('hidden');
  pendingImportData = null;
}

// ============================================
// Confirm dialog
// ============================================
function showConfirm(message, onOk) {
  document.getElementById('confirm-message').textContent = message;
  pendingConfirmAction = onOk;
  document.getElementById('confirm-modal').classList.remove('hidden');
}

function hideConfirm() {
  document.getElementById('confirm-modal').classList.add('hidden');
  pendingConfirmAction = null;
}

// ============================================
// Init
// ============================================
async function init() {
  appLog('info', 'general', `Speed Access v${chrome.runtime?.getManifest?.()?.version || '?'} 起動`);
  state = await personalStorage.load();
  allLayouts = await personalStorage.loadLayout();
  // 画像キャッシュをメモリに展開 (並列で開始、awaitして完了待ち)
  await loadImageCacheToMemory();

  // 保存されたPATをロード (OWNER/REPOは固定なので読まない)
  const savedConfig = await personalStorage.loadSyncConfig();
  if (savedConfig && savedConfig.TOKEN) {
    GITHUB_CONFIG.TOKEN = savedConfig.TOKEN;
  }
  lastSyncTimes = await personalStorage.loadLastSyncTimes();

  // 旧Homeタブがあれば、通常のタブとして扱う
  const oldHome = state.tabs.find(t => t.id === 'home');
  if (oldHome) {
    oldHome.id = generateId('tab');  // 新しいIDを付与
    // 既存のレイアウト設定を引き継ぐ
    if (allLayouts.home) {
      allLayouts[oldHome.id] = allLayouts.home;
      delete allLayouts.home;
      await personalStorage.saveLayout(allLayouts);
    }
    if (state.activeTabId === 'home') {
      state.activeTabId = oldHome.id;
    }
    await personalStorage.save(state);
  }

  // activeTabId の整合性チェック
  if (state.tabs.length > 0 && (!state.activeTabId || !state.tabs.find(t => t.id === state.activeTabId))) {
    state.activeTabId = state.tabs[0].id;
  }

  loadLayoutForActiveTab();
  render();

  // 全タブの全タイル画像をバックグラウンドでプリフェッチ (タブ切替時の高速化)
  setTimeout(() => {
    const allUrls = [];
    state.tabs.forEach(tab => {
      tab.tiles.forEach(t => {
        allUrls.push(t.image || getFaviconUrl(t.url));
      });
    });
    prefetchImages(allUrls);
  }, 500);

  // 起動時の自動取得: 全共有タブを並列で取得 (バックグラウンド)
  // - アクティブな共有タブは結果を即反映
  // - 非アクティブな共有タブは結果をstateに保存だけ
  // - エラーが出ても続行 (オフライン等)
  if (sharedStorage.isConfigured()) {
    silentAutoPullAllSharedTabs();
  }
}

// 起動時の自動取得 (静かに実行、トースト出さない)
async function silentAutoPullAllSharedTabs() {
  const sharedTabs = state.tabs.filter(t => t.type === 'shared' && t.code);
  if (sharedTabs.length === 0) return;

  appLog('info', 'sync', `自動取得開始: ${sharedTabs.length} 個の共有タブをチェック`);

  // まず一度fetchAllして「GitHubに存在するコード」のセットを作る
  // (個別にgetByCodeすると毎回API呼び出しになるため、まとめて1回で取得)
  let remoteAll = {};
  try {
    remoteAll = await sharedStorage.fetchAll();
  } catch (err) {
    appLog('warn', 'sync', '自動取得: fetchAll失敗 (オフライン等)', err.message);
    return;
  }
  const remoteCodes = new Set(Object.keys(remoteAll));

  // GitHubに存在しない共有タブを検出
  const missing = sharedTabs.filter(t => !remoteCodes.has(t.code));

  if (missing.length > 0) {
    const missingInfo = missing.map(t => ({ name: t.name, code: t.code }));
    appLog('warn', 'sync', `GitHub上に存在しない共有タブ: ${missing.length} 個`, missingInfo);
    // 画面にも警告 (まとめて1回だけ)
    const names = missing.map(t => `「${t.name}」`).join('、');
    setTimeout(() => {
      showToast(
        `⚠️ 共有タブ ${names} がGitHubに存在しません。\n反映ボタンで再登録、または個人タブに変換してください。`,
        true,
        8000
      );
    }, 1000);
  }

  // GitHubに存在するタブだけpullを適用
  let updatedCount = 0;
  sharedTabs.forEach(tab => {
    if (!remoteCodes.has(tab.code)) return;
    const remote = remoteAll[tab.code];
    if (remote && Array.isArray(remote.tiles)) {
      tab.tiles = remote.tiles;
      if (remote.name) tab.name = remote.name;
      lastSyncTimes[tab.id] = Date.now();
      updatedCount++;
      if (tab.id === state.activeTabId) {
        renderTiles();
      }
    }
  });

  appLog('info', 'sync', `自動取得完了: ${updatedCount} 個のタブを更新`);

  await personalStorage.save(state);
  await personalStorage.saveLastSyncTimes(lastSyncTimes);
}

// ============================================
// Event listeners
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('tile-modal-close').addEventListener('click', hideTileModal);
  document.getElementById('tile-cancel').addEventListener('click', hideTileModal);
  document.getElementById('tile-save').addEventListener('click', handleSaveTile);

  document.getElementById('tile-image-url').addEventListener('input', (e) => {
    setImagePreview(e.target.value.trim());
  });

  document.getElementById('tile-upload-btn').addEventListener('click', () => {
    document.getElementById('tile-image-file').click();
  });
  document.getElementById('tile-image-file').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      showToast('画像は500KB以下にしてください', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      document.getElementById('tile-image-url').value = '';
      setImagePreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  });

  document.getElementById('tile-image-remove').addEventListener('click', () => {
    document.getElementById('tile-image-url').value = '';
    document.getElementById('tile-image-file').value = '';
    setImagePreview('');
  });

  document.getElementById('tab-modal-close').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-cancel').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-save').addEventListener('click', handleAddTab);

  // タブ種類 (個人/共有) の切替
  document.querySelectorAll('input[name="tab-type"]').forEach(radio => {
    radio.addEventListener('change', updateTabModalVisibility);
  });
  // 共有モード (参加/新規) の切替
  document.querySelectorAll('input[name="shared-mode"]').forEach(radio => {
    radio.addEventListener('change', updateTabModalVisibility);
  });

  document.getElementById('import-modal-close').addEventListener('click', hideImportModal);
  document.getElementById('import-cancel').addEventListener('click', hideImportModal);
  document.getElementById('import-execute').addEventListener('click', executeImport);

  const dropZone = document.getElementById('import-drop-zone');
  const fileInput = document.getElementById('import-file');

  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) handleImportFile(file);
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const file = e.dataTransfer.files?.[0];
    if (file) handleImportFile(file);
  });

  document.getElementById('confirm-cancel').addEventListener('click', hideConfirm);
  document.getElementById('confirm-ok').addEventListener('click', () => {
    if (pendingConfirmAction) pendingConfirmAction();
    hideConfirm();
  });

  // Layout modal
  document.getElementById('layout-modal-close').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-done').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-reset').addEventListener('click', resetLayout);
  document.getElementById('layout-recommended').addEventListener('click', applyRecommendedLayout);
  document.getElementById('layout-apply-all').addEventListener('click', applyLayoutToAllTabs);

  // Sync modal
  document.getElementById('sync-modal-close').addEventListener('click', hideSyncModal);
  document.getElementById('sync-cancel').addEventListener('click', hideSyncModal);
  document.getElementById('sync-save').addEventListener('click', saveSyncSettings);
  document.getElementById('sync-test').addEventListener('click', testSyncConnection);

  // Manage shared modal
  document.getElementById('manage-shared-close').addEventListener('click', hideManageSharedModal);
  document.getElementById('manage-shared-done').addEventListener('click', hideManageSharedModal);
  document.getElementById('manage-shared-refresh').addEventListener('click', loadManageSharedList);

  // Log modal
  document.getElementById('log-modal-close').addEventListener('click', hideLogModal);
  document.getElementById('log-done').addEventListener('click', hideLogModal);
  document.getElementById('log-refresh').addEventListener('click', renderLogs);
  document.getElementById('log-clear').addEventListener('click', clearLogs);
  document.getElementById('log-copy').addEventListener('click', copyLogsToClipboard);
  document.getElementById('log-filter-level').addEventListener('change', renderLogs);
  document.getElementById('log-filter-category').addEventListener('change', renderLogs);

  document.getElementById('columns-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('width-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('height-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('gap-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('header-spacing-slider').addEventListener('input', updateLayoutFromSliders);

  document.getElementById('tile-title').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('tile-url').focus(); }
  });
  document.getElementById('tile-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleSaveTile(); }
  });
  document.getElementById('tab-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddTab(); }
  });
  document.getElementById('tab-code').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddTab(); }
  });
  document.getElementById('tab-shared-new-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('tab-code').focus(); }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      hideTileModal();
      hideAddTabModal();
      hideImportModal();
      hideLayoutModal();
      hideSyncModal();
      hideManageSharedModal();
      hideLogModal();
      hideConfirm();
    }
  });

  init();
});

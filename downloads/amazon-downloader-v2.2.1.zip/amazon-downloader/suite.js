// 最上部：共通の開始日/終了日 と「必要ページを開く」
const $ = (id) => document.getElementById(id);
function jstToday(off = 0) {
  return new Date(Date.now() + 9 * 3600 * 1000 + off * 86400000).toISOString().slice(0, 10);
}
const DATE_LOCK_KEY = 'amazon_dl_date_lock';

async function initTop() {
  const store = await chrome.storage.local.get([DATE_LOCK_KEY, 'sharedDates']);
  const lock = store[DATE_LOCK_KEY];
  const sd = store.sharedDates;
  let s, e;
  if (lock) {                       // 固定されていれば固定値を優先
    s = lock.startDate || jstToday(-1);
    e = lock.endDate || jstToday(-1);
  } else {                          // それ以外は前回値、なければ昨日
    s = sd && sd.start ? sd.start : jstToday(-1);
    e = sd && sd.end ? sd.end : jstToday(-1);
  }
  $('top-start').value = s;
  $('top-end').value = e;
  await chrome.storage.local.set({ sharedDates: { start: s, end: e } });
  updateDateLockUI(!!lock);
}

function setDateHint(msg, isError) {
  const el = $('date-hint'); if (!el) return;
  el.textContent = msg || '';
  el.style.color = isError ? '#a01010' : '#806000';
}

function updateDateLockUI(locked) {
  const badge = $('date-lock-badge'); if (badge) badge.style.display = locked ? 'inline-block' : 'none';
  ['top-start', 'top-end'].forEach((id) => {
    const el = $(id); if (!el) return;
    el.classList.toggle('date-locked', locked);
  });
  const sb = $('date-save');
  if (sb) { sb.textContent = locked ? '✅ 保存中(再保存で更新)' : '💾 日付を保存(固定)'; sb.classList.toggle('locked', locked); }
}

$('date-save').addEventListener('click', async () => {
  const startDate = $('top-start').value, endDate = $('top-end').value;
  if (!startDate && !endDate) { setDateHint('❌ 保存する日付を入力してください', true); return; }
  await chrome.storage.local.set({ [DATE_LOCK_KEY]: { startDate, endDate } });
  updateDateLockUI(true);
  setDateHint(`✅ 保存しました (${startDate || '(空)'} 〜 ${endDate || '(空)'})`);
});

$('date-clear').addEventListener('click', async () => {
  await chrome.storage.local.remove([DATE_LOCK_KEY]);
  updateDateLockUI(false);
  setDateHint('🔓 日付の固定を解除しました');
});
async function save() {
  const now = Date.now();
  const startDate = $('top-start').value, endDate = $('top-end').value;
  const patch = {
    sharedDates: { start: startDate, end: endDate },
    // 日付(月)を変えたら「取得済み」表示をリセット
    ads_status: { state: 'idle', ts: now },
    ship_status: { state: 'idle', ts: now }
  };
  // 固定中に日付を変えたら、固定値も追従して更新
  const store = await chrome.storage.local.get([DATE_LOCK_KEY]);
  if (store[DATE_LOCK_KEY]) patch[DATE_LOCK_KEY] = { startDate, endDate };
  chrome.storage.local.set(patch);
}
$('top-start').addEventListener('change', save);
$('top-end').addEventListener('change', save);

$('top-open').addEventListener('click', async () => {
  const urls = [
    'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
    'https://sellercentral-japan.amazon.com/orders-v3?page=1'
  ];
  for (const u of urls) { try { await chrome.tabs.create({ url: u, active: false }); } catch (_) {} }
  const b = $('top-open'); b.textContent = '✅ 開きました（各タブを一度表示してください）';
  setTimeout(() => (b.textContent = '🗂️ 必要ページを開く'), 2500);
});

initTop();

// ===== 保存先(File System Access API)の状態表示 =====
async function renderFs() {
  const st = await AMZ_FS.status();
  const nameEl = $('fs-name'), setBtn = $('fs-set');
  if (st.state === 'granted') {
    nameEl.textContent = st.name; nameEl.style.color = '#1a7f37';
    setBtn.textContent = '変更'; setBtn.style.background = '#888';
  } else if (st.state === 'none') {
    nameEl.textContent = '未設定（要設定）'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '設定'; setBtn.style.background = '#c25a00';
  } else {
    nameEl.textContent = (st.name || '') + '：要許可'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '許可'; setBtn.style.background = '#c25a00';
  }
}
$('fs-set').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
});
chrome.storage.onChanged.addListener((ch) => { if (ch.amz_fs_state) renderFs(); });
renderFs();

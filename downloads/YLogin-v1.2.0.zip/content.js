(() => {
  if (window.top !== window) return;

  if (window.__YLoginContent?.scan) {
    window.__YLoginContent.scan(true);
    return;
  }

  const POLL_INTERVAL_MS = 2000;
  const MAX_WAIT_MS = 90000;
  const LOOKBACK_MS = 10 * 60 * 1000;

  let polling = false;
  let statusBox = null;
  let statusText = null;
  let retryButton = null;
  let lastInput = null;

  const api = { scan, startPolling };
  window.__YLoginContent = api;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "YLOGIN_RETRY") {
      scan(true)
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
      return true;
    }
    return false;
  });

  const observer = new MutationObserver(() => scan(false));
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("pageshow", () => scan(false));
  setInterval(() => scan(false), 1500);
  scan(false);

  async function scan(force = false) {
    if (!isYahooLoginPage()) return;
    const input = findCodeInput();
    if (!input) return;

    ensureStatusBox();
    lastInput = input;

    if (force) {
      await startPolling(true);
      return;
    }

    if (polling || input.dataset.yloginAutoStarted === "1") return;
    input.dataset.yloginAutoStarted = "1";

    const response = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
    if (!response?.ok) {
      setStatus("YLoginの設定を確認できませんでした", "error");
      showRetry();
      return;
    }
    if (!response.settings.workerUrl || !response.settings.apiToken) {
      setStatus("拡張機能アイコンからWorkerを設定してください", "warning");
      showRetry();
      return;
    }
    if (response.settings.autoFill) {
      await startPolling(false);
    } else {
      setStatus("自動取得はオフです", "idle");
      showRetry();
    }
  }

  async function startPolling(force = false) {
    if (polling) return;
    if (!isYahooLoginPage()) return;

    const input = findCodeInput() || lastInput;
    if (!input) {
      ensureStatusBox();
      setStatus("確認コード入力欄が見つかりません", "error");
      showRetry();
      return;
    }

    polling = true;
    hideRetry();
    const startedAt = Date.now();
    setStatus(force ? "確認コードを再取得しています…" : "確認コードを待っています…", "loading");

    try {
      while (Date.now() - startedAt < MAX_WAIT_MS) {
        const currentInput = findCodeInput() || input;
        if (!currentInput || !isYahooLoginPage()) return;
        if (/^\d{6}$/.test(currentInput.value)) {
          setStatus("確認コードは入力済みです", "success");
          return;
        }

        const result = await chrome.runtime.sendMessage({
          type: "GET_CODE",
          notBefore: Date.now() - LOOKBACK_MS
        });

        if (result?.ok && result.found && /^\d{6}$/.test(result.code)) {
          setInputValue(currentInput, result.code);
          await chrome.runtime.sendMessage({
            type: "MARK_USED",
            receivedAt: result.receivedAt || new Date().toISOString()
          }).catch(() => {});
          setStatus("確認コードを入力しました。ログインを押してください。", "success");
          return;
        }

        if (result?.configMissing) {
          setStatus("拡張機能アイコンからWorkerを設定してください", "warning");
          showRetry();
          return;
        }
        if (result?.ok === false) {
          setStatus(result.error || "確認コードを取得できませんでした", "error");
          showRetry();
          return;
        }

        const scanned = result?.diagnostics?.scannedMessages;
        const total = result?.diagnostics?.mailboxMessages;
        if (Number.isFinite(scanned) && Number.isFinite(total)) {
          setStatus(`メールを確認中…（${scanned}/${total}件確認）`, "loading");
        }
        await sleep(POLL_INTERVAL_MS);
      }

      setStatus("有効な確認コードが見つかりません。再取得できます。", "warning");
      showRetry();
    } finally {
      polling = false;
    }
  }

  function findCodeInput() {
    const selectors = [
      'input[name="code"]',
      'input[autocomplete="one-time-code"]',
      'input[aria-label="確認コード"]',
      'input[placeholder="確認コード"]'
    ];
    return selectors
      .map((selector) => document.querySelector(selector))
      .find((element) => element instanceof HTMLInputElement && !element.disabled && element.type !== "hidden") || null;
  }

  function isYahooLoginPage() {
    return location.hostname === "login.yahoo.co.jp" && location.pathname.startsWith("/config/login");
  }

  function setInputValue(input, value) {
    const previous = input.value;
    const ownPrototype = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(ownPrototype, "value")?.set
      || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;

    input.focus();
    input.dispatchEvent(new InputEvent("beforeinput", {
      bubbles: true,
      cancelable: true,
      inputType: "insertText",
      data: value
    }));

    if (setter) setter.call(input, value);
    else input.value = value;

    // React系の入力監視がある場合にも変更を認識させる。
    if (input._valueTracker?.setValue) input._valueTracker.setValue(previous);

    input.setAttribute("value", value);
    input.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: value
    }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: value.slice(-1) }));
  }

  function ensureStatusBox() {
    if (statusBox?.isConnected) return;
    statusBox = document.createElement("div");
    statusBox.id = "ylogin-status-box";
    statusText = document.createElement("span");
    retryButton = document.createElement("button");
    retryButton.type = "button";
    retryButton.textContent = "再取得";
    retryButton.hidden = true;
    retryButton.addEventListener("click", () => startPolling(true));
    statusBox.append(statusText, retryButton);
    document.body.appendChild(statusBox);
  }

  function setStatus(text, state) {
    ensureStatusBox();
    statusText.textContent = text;
    statusBox.dataset.state = state;
  }

  function showRetry() {
    ensureStatusBox();
    retryButton.hidden = false;
  }

  function hideRetry() {
    ensureStatusBox();
    retryButton.hidden = true;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
})();

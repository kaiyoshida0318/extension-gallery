const DEFAULTS = {
  workerUrl: "",
  apiToken: "",
  autoFill: true
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) }));
  return true;
});

async function handleMessage(message, sender) {
  switch (message?.type) {
    case "GET_SETTINGS":
      return { ok: true, settings: await getSettings() };

    case "SAVE_SETTINGS":
      return saveSettings(message.settings);

    case "GET_CODE": {
      assertYahooSender(sender);
      return getCode(message.notBefore);
    }

    case "GET_CODE_TEST":
      return getCode(Date.now() - 10 * 60 * 1000);

    case "MARK_USED":
      assertYahooSender(sender);
      return markUsed(message.receivedAt);

    case "TEST_POP3":
      return callWorker("/api/test-pop3", "POST");

    case "STATUS":
      return callWorker("/api/status", "GET");

    default:
      return { ok: false, error: "不明な操作です" };
  }
}

async function getCode(requestedNotBefore) {
  const settings = await getSettings();
  const lastUsedMs = Date.parse(settings.lastUsedReceivedAt || "");
  const requestedMs = Number(requestedNotBefore || 0);
  const notBeforeMs = Math.max(
    Number.isFinite(requestedMs) ? requestedMs : Date.now() - 10 * 60 * 1000,
    Number.isFinite(lastUsedMs) ? lastUsedMs + 1000 : 0
  );
  return callWorker("/api/code", "POST", {
    notBefore: new Date(notBeforeMs).toISOString()
  });
}

async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
}

async function saveSettings(input) {
  const workerUrl = normalizeWorkerUrl(input?.workerUrl || "");
  const apiToken = String(input?.apiToken || "").trim();
  const autoFill = input?.autoFill !== false;

  if (!workerUrl) return { ok: false, error: "Worker URLを入力してください" };
  if (!apiToken) return { ok: false, error: "APIトークンを入力してください" };

  await chrome.storage.local.set({ workerUrl, apiToken, autoFill });
  return { ok: true, settings: { workerUrl, apiToken, autoFill } };
}

async function callWorker(path, method, bodyData = {}) {
  const settings = await getSettings();
  if (!settings.workerUrl || !settings.apiToken) {
    return { ok: false, configMissing: true, error: "拡張機能の設定が未完了です" };
  }

  const url = `${normalizeWorkerUrl(settings.workerUrl)}${path}`;
  const response = await fetch(url, {
    method,
    headers: {
      "Authorization": `Bearer ${settings.apiToken}`,
      "Content-Type": "application/json"
    },
    body: method === "POST" ? JSON.stringify(bodyData) : undefined,
    cache: "no-store",
    credentials: "omit"
  });

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(`Workerから不正な応答が返りました（HTTP ${response.status}）`);
  }

  if (!response.ok || data.ok === false) {
    return { ok: false, error: data.error || `Workerエラー（HTTP ${response.status}）` };
  }
  return data;
}

async function markUsed(receivedAt) {
  const parsed = new Date(receivedAt || "");
  if (Number.isNaN(parsed.getTime())) return { ok: false, error: "受信日時が不正です" };
  await chrome.storage.local.set({ lastUsedReceivedAt: parsed.toISOString() });
  return { ok: true };
}

function normalizeWorkerUrl(value) {
  const text = String(value).trim().replace(/\/+$/, "");
  if (!text) return "";
  let url;
  try {
    url = new URL(text);
  } catch {
    throw new Error("Worker URLの形式が正しくありません");
  }
  if (url.protocol !== "https:" || !url.hostname.endsWith(".workers.dev")) {
    throw new Error("https://～.workers.dev のURLを入力してください");
  }
  if (url.pathname !== "/" && url.pathname !== "") {
    throw new Error("Worker URLには /api/code などのパスを付けないでください");
  }
  return `${url.protocol}//${url.host}`;
}

function assertYahooSender(sender) {
  const url = sender?.tab?.url || sender?.url || "";
  if (!url.startsWith("https://login.yahoo.co.jp/config/login")) {
    throw new Error("Yahoo! JAPANの再認証画面以外からは実行できません");
  }
}

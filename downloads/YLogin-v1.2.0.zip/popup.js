const workerUrl = document.getElementById("workerUrl");
const apiToken = document.getElementById("apiToken");
const autoFill = document.getElementById("autoFill");
const status = document.getElementById("status");
const saveButton = document.getElementById("save");
const testButton = document.getElementById("test");
const codeTestButton = document.getElementById("codeTest");
const fillCurrentButton = document.getElementById("fillCurrent");
const buttons = [saveButton, testButton, codeTestButton, fillCurrentButton];

init();

async function init() {
  const result = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
  if (result?.ok) {
    workerUrl.value = result.settings.workerUrl || "";
    apiToken.value = result.settings.apiToken || "";
    autoFill.checked = result.settings.autoFill !== false;
  }
}

saveButton.addEventListener("click", async () => {
  setBusy(true);
  const result = await saveSettings();
  setBusy(false);
  showResult(result?.ok ? "設定を保存しました" : result?.error || "保存に失敗しました", result?.ok);
});

testButton.addEventListener("click", async () => {
  setBusy(true);
  const saved = await saveSettings();
  if (!saved?.ok) return finish(saved?.error || "設定を保存できませんでした", false);
  const result = await chrome.runtime.sendMessage({ type: "TEST_POP3" });
  if (result?.ok) finish(`接続成功（メール ${result.mailboxMessages}件）`, true);
  else finish(result?.error || "POP3接続に失敗しました", false);
});

codeTestButton.addEventListener("click", async () => {
  setBusy(true);
  const saved = await saveSettings();
  if (!saved?.ok) return finish(saved?.error || "設定を保存できませんでした", false);
  const result = await chrome.runtime.sendMessage({ type: "GET_CODE_TEST" });
  if (result?.ok && result.found) {
    finish(`取得成功：${result.code}（メール ${result.diagnostics?.mailboxMessages ?? "-"}件）`, true);
  } else if (result?.ok) {
    finish(`有効なコードなし（最新${result.diagnostics?.scannedMessages ?? "-"}件を確認）`, false);
  } else {
    finish(result?.error || "コード取得に失敗しました", false);
  }
});

fillCurrentButton.addEventListener("click", async () => {
  setBusy(true);
  const saved = await saveSettings();
  if (!saved?.ok) return finish(saved?.error || "設定を保存できませんでした", false);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !String(tab.url || "").startsWith("https://login.yahoo.co.jp/config/login")) {
    return finish("Yahoo! JAPANの確認コード画面を開いてください", false);
  }

  try {
    await chrome.tabs.sendMessage(tab.id, { type: "YLOGIN_RETRY" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await new Promise((resolve) => setTimeout(resolve, 150));
    await chrome.tabs.sendMessage(tab.id, { type: "YLOGIN_RETRY" });
  }
  finish("確認コードの取得を開始しました。画面右下を確認してください。", true);
});

async function saveSettings() {
  return chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    settings: {
      workerUrl: workerUrl.value,
      apiToken: apiToken.value,
      autoFill: autoFill.checked
    }
  });
}

function setBusy(busy) {
  for (const button of buttons) button.disabled = busy;
  status.textContent = busy ? "処理中…" : "";
  status.dataset.ok = "";
}

function finish(message, ok) {
  setBusy(false);
  showResult(message, ok);
}

function showResult(message, ok) {
  status.textContent = message;
  status.dataset.ok = ok ? "true" : "false";
}

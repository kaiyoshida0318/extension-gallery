const $ = (id) => document.getElementById(id);
const LABELS = { tx: 'FBA手数料・販売手数料・出荷数', ads: '広告費・広告売上', adsReport: '広告費・広告売上(レポート作成)', storage: '保管費', sales: '総売上' };
const DEFAULT_SUB = { tx: 'トランザクション', ads: 'キャンペーン', adsReport: '効果測定とレポートでCSVを作って取得', storage: '在庫保管手数料', sales: '売上ダッシュボード' };
const ORDER = ['tx', 'ads', 'storage', 'sales'];

const pad = (n) => String(n).padStart(2, '0');
// 2026/09/18 時点で 2025/07/15 あたりが境目だった = 約430日(約14か月)
const ADS_LIMIT_DAYS = 430;
function adsBoundary() {
  const now = new Date();
  const edge = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ADS_LIMIT_DAYS);
  const lastNg = new Date(edge.getFullYear(), edge.getMonth(), 1);      // この月以前はレポート作成
  const firstOk = new Date(edge.getFullYear(), edge.getMonth() + 1, 1); // この月以降は通常ボタン
  const jp = (d) => `${d.getFullYear()}年${d.getMonth() + 1}月`;
  return {
    edgeText: `${edge.getFullYear()}/${edge.getMonth() + 1}/${edge.getDate()}`,
    lastNgKey: `${lastNg.getFullYear()}-${pad(lastNg.getMonth() + 1)}`,
    lastNgText: jp(lastNg),
    firstOkText: jp(firstOk),
  };
}
const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;

function buildMonths() {
  const now = new Date();
  const opts = [];
  for (let i = 0; i < 48; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    opts.push([keyOf(d), `${d.getFullYear()}年${d.getMonth() + 1}月${i === 0 ? '(今月・途中)' : i === 1 ? '(先月)' : ''}`]);
  }
  for (const id of ['month', 'rFrom', 'rTo']) {
    const sel = $(id);
    for (const [v, t] of opts) {
      const o = document.createElement('option');
      o.value = v; o.textContent = t;
      sel.appendChild(o);
    }
  }
  // 範囲の初期値: 12か月前 〜 先月
  $('rFrom').value = opts[12][0];
  $('rTo').value = opts[1][0];
}

// 開始月〜終了月(古い順)
function monthsBetween(from, to) {
  const [fy, fm] = from.split('-').map(Number);
  const [ty, tm] = to.split('-').map(Number);
  const out = [];
  let y = fy, m = fm;
  for (let i = 0; i < 120; i++) {
    const key = `${y}-${pad(m)}`;
    out.push(key);
    if (y === ty && m === tm) break;
    m++; if (m > 12) { m = 1; y++; }
    if (y > ty || (y === ty && m > tm)) break;
  }
  return out;
}

function rangeKinds() {
  return [...document.querySelectorAll('.rrow.chips input:checked')].map((i) => i.value);
}

function renderRangeNote() {
  const from = $('rFrom').value, to = $('rTo').value;
  if (from > to) { $('rangeNote').textContent = '開始月が終了月より後になっています'; return; }
  const months = monthsBetween(from, to);
  const kinds = rangeKinds();
  const perMonth = kinds.length * 3;
  $('rangeNote').textContent = kinds.length
    ? `${months.length}か月 × ${kinds.length}種類 = ${months.length * kinds.length}件(目安 ${Math.round(months.length * perMonth)}分)。古い月から順に取得します`
    : '種類を1つ以上選んでください';
}

let shownMonth = null; // いま表示している月(離れたら結果をクリアする)

async function init() {
  buildMonths();
  const s = await chrome.storage.local.get(['amz_month']);
  const lastMonth = keyOf(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1));
  const saved = s.amz_month;
  $('month').value = saved && [...$('month').options].some((o) => o.value === saved) ? saved : lastMonth;
  shownMonth = currentMonth();
  renderRangeNote();
  await render();
}

// 月を切り替えたら、前に見ていた月の取得結果(マーカー)を消す。
// 実行中のジョブの月は消さない。
async function clearResults(month) {
  if (!month) return;
  const s = await chrome.storage.local.get(['amz_results', 'amz_job']);
  const job = s.amz_job || {};
  if (job.running && job.month === month) return;
  const all = s.amz_results || {};
  if (!all[month]) return;
  delete all[month];
  await chrome.storage.local.set({ amz_results: all });
}

function currentMonth() { return $('month').value; }

function step(delta) {
  const sel = $('month');
  const i = sel.selectedIndex - delta; // 選択肢は新しい順
  if (i >= 0 && i < sel.options.length) {
    sel.selectedIndex = i;
    sel.dispatchEvent(new Event('change'));
  }
}

async function render() {
  const s = await chrome.storage.local.get(['amz_results', 'amz_job', 'amz_logs']);
  const month = currentMonth();
  const res = (s.amz_results || {})[month] || {};
  const job = s.amz_job || {};
  const running = !!job.running;

  const b = adsBoundary();
  const oldMonth = month <= b.lastNgKey; // 選択中の月が境目より古い
  DEFAULT_SUB.adsReport = oldMonth
    ? `◀ 選択中の月(${Number(month.split('-')[0])}年${Number(month.split('-')[1])}月)はこちらを使ってください`
    : `${b.lastNgText}以前はこちら(境目 ${b.edgeText}ごろ)`;
  DEFAULT_SUB.ads = oldMonth
    ? `この月は取れない可能性あり(${b.firstOkText}以降が対象)`
    : 'キャンペーン';

  for (const btn of document.querySelectorAll('.kind')) {
    const k = btn.dataset.kind;
    const r = res[k];
    if (k === 'adsReport') btn.classList.toggle('hint', oldMonth);
    if (k === 'ads') btn.classList.toggle('hint', oldMonth);
    let st = r ? r.status : '';
    const isCurrent = running && job.month === month && job.current === k;
    if (isCurrent) st = 'running';
    else if (st === 'running') st = 'cancelled'; // 途中で拡張が止まった等の残骸
    btn.dataset.st = st;
    const sub = btn.querySelector('.s');
    if (!r) sub.textContent = DEFAULT_SUB[k];
    else if (st === 'running') sub.textContent = job.progress || '実行中…';
    else if (r.status === 'running') sub.textContent = '中断されました';
    else {
      const head = { ok: '取得済み', noData: 'データなし', notReady: '未確定', error: '失敗', cancelled: '中止' }[st] || '';
      sub.textContent = [head, r.message].filter(Boolean).join(':');
      sub.title = r.at ? new Date(r.at).toLocaleString('ja-JP') : '';
    }
    btn.disabled = running;
  }
  $('runAll').disabled = running;
  $('retry').disabled = running;

  $('job').classList.toggle('on', running);
  if (running) {
    const idx = (job.kinds || []).indexOf(job.current);
    const nMonths = (job.months || []).length;
    const monthPos = nMonths > 1 ? ` [${(job.monthIndex || 0) + 1}/${nMonths}か月]` : '';
    $('jobCur').textContent = `${job.month.replace('-', '年')}月${monthPos} ${job.current ? LABELS[job.current] : '準備中'}${idx >= 0 ? `(${idx + 1}/${job.kinds.length})` : ''}`;
    $('jobPg').textContent = job.cancel ? '中止待ち…' : (job.progress || '');
  }

  const box = $('logs');
  box.textContent = '';
  for (const l of (s.amz_logs || []).slice(0, 80)) {
    const div = document.createElement('div');
    div.className = l.level;
    const t = document.createElement('time');
    const d = new Date(l.at);
    t.textContent = `${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    div.append(t, document.createTextNode(l.text));
    box.appendChild(div);
  }
}

let fsState = { state: 'none' };
const FS_LABEL = { none: '未設定', granted: 'OK', prompt: '要許可', denied: '拒否' };

async function renderDest() {
  try { fsState = await AMZ_FS.status(); } catch (e) { fsState = { state: 'none' }; }
  $('destName').textContent = fsState.name || 'フォルダを選んでください';
  $('destState').textContent = FS_LABEL[fsState.state] || fsState.state;
  $('destState').className = 'st ' + fsState.state;
  $('destBtn').textContent = fsState.state === 'none' ? '設定' : fsState.state === 'granted' ? '変更' : '保存を許可';
  $('dest').classList.toggle('warn', fsState.state !== 'granted');
}

function openFolderPage() {
  chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
}

async function start(kinds) {
  await renderDest();
  if (fsState.state !== 'granted') { openFolderPage(); return; }
  const month = currentMonth();
  chrome.runtime.sendMessage({ type: 'amz_start', month, kinds }); // 応答は待たない
}

$('month').addEventListener('change', async () => {
  const left = shownMonth;
  shownMonth = currentMonth();
  if (left && left !== shownMonth) await clearResults(left);
  await chrome.storage.local.set({ amz_month: shownMonth });
  render();
});
$('prev').addEventListener('click', () => step(-1));
$('next').addEventListener('click', () => step(1));
$('runAll').addEventListener('click', () => start(ORDER));
for (const btn of document.querySelectorAll('.kind')) {
  btn.addEventListener('click', () => start([btn.dataset.kind]));
}
$('destBtn').addEventListener('click', openFolderPage);

for (const el of [$('rFrom'), $('rTo'), ...document.querySelectorAll('.rrow.chips input')]) {
  el.addEventListener('change', renderRangeNote);
}
$('runRange').addEventListener('click', async () => {
  const from = $('rFrom').value, to = $('rTo').value;
  const kinds = rangeKinds();
  if (from > to || !kinds.length) { renderRangeNote(); return; }
  await renderDest();
  if (fsState.state !== 'granted') { openFolderPage(); return; }
  const months = monthsBetween(from, to);
  chrome.runtime.sendMessage({ type: 'amz_start', months, kinds });
  $('rangeNote').textContent = `${months.length}か月を順番に取得します。ポップアップは閉じても続きます`;
});

// ───────── 説明モーダル
function renderHelpLimit() {
  const b = adsBoundary();
  $('helpLimit').textContent = `目安: 今日から約${ADS_LIMIT_DAYS}日(約14か月)前まで`;
  $('helpDetail').innerHTML =
    `境目はおよそ <b>${b.edgeText}</b> です。<br>` +
    `・${b.firstOkText} 以降 … 通常の「広告費・広告売上」でOK<br>` +
    `・${b.lastNgText} 以前 … このボタン(レポート作成)を使う<br>` +
    `境目の月は、まず通常ボタンを試して、ダメならこちらを押してください。`;
}
$('helpBtn').addEventListener('click', (e) => { e.stopPropagation(); renderHelpLimit(); $('help').classList.add('on'); });
$('helpClose').addEventListener('click', () => $('help').classList.remove('on'));
$('help').addEventListener('click', (e) => { if (e.target === $('help')) $('help').classList.remove('on'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('help').classList.remove('on'); });
$('stop').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'amz_cancel' }));
$('retry').addEventListener('click', async () => {
  const s = await chrome.storage.local.get(['amz_results']);
  const res = (s.amz_results || {})[currentMonth()] || {};
  const kinds = ORDER.filter((k) => !res[k] || ['error', 'notReady', 'cancelled', 'running'].includes(res[k].status));
  if (kinds.length) start(kinds);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.amz_results || changes.amz_job || changes.amz_logs)) render();
  if (area === 'local' && changes.amz_fs_state) renderDest();
});

renderDest();
init();

// NE Quick Access - popup（一覧取得 + ツールON/OFF）
const STORAGE_KEY_ENABLED = 'ne_quick_enabled';

// 一覧取得
document.getElementById('fetch').addEventListener('click', async () => {
  const st = document.getElementById('status');
  const show = (msg, cls) => { st.textContent = msg; st.className = `status show ${cls}`; };
  show('取得中...', 'ok');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.includes('next-engine.com')) {
      show('ネクストエンジンの受注管理画面で開いてください', 'err');
      return;
    }
    const res = await chrome.tabs.sendMessage(tab.id, { action: 'fetchAll' });
    if (!res || !res.ok) { show(res?.error || '取得に失敗しました', 'err'); return; }
    show(`取得完了: オリステ${res.orig.length}件 / 保存検索${res.save.length}件。受注管理画面の「⚙設定」から選択してください。`, 'ok');
  } catch (e) {
    show('受注管理画面を開いた状態で実行してください', 'err');
  }
});

// ツールON/OFFトグル
const toggle = document.getElementById('tool-toggle');

// 初期状態を読み込み
(async () => {
  const data = await chrome.storage.local.get([STORAGE_KEY_ENABLED]);
  toggle.checked = data[STORAGE_KEY_ENABLED] !== false; // 未設定ならON
})();

// 切り替え時に保存
toggle.addEventListener('change', async () => {
  await chrome.storage.local.set({ [STORAGE_KEY_ENABLED]: toggle.checked });
});

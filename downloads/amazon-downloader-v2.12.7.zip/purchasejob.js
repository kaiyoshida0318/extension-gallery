// ============================================================
// purchasejob.js  （background.js から importScripts。officialjob.js の findAdsTab / inTab / cleanH / offDays を使う）
// ④購入商品データ（日別・速報）を「上の期間」の1日ずつ、購入商品データ-YYYY-MMDD.csv で保存する（v2.12.0〜・仕様書 第2版）
//
//  ■ 速い道（ふだん）
//    Amazon側の予約レポート「Amacheck_購入商品データ_毎日」（毎朝6時JST・過去30日間・日付つき）の、一番新しい「完了」回を
//    ダウンロードして日ごとに切り分ける。直近30日（昨日まで）の日なら数秒で終わる。予約が無ければ作る（作成日の翌朝から動く）。
//  ■ 遅い道（予約で足りない日だけ）
//    初回・予約の今朝の回がまだ・30日より前の日（取り忘れ）は、その日の期間で1回限りのレポートをその場で作り、
//    完成を alarms で待って保存（3〜10分・ポップアップを閉じても進む・完了は通知）。保存後、そのレポートは削除。
//  ・行が0件の日も列名だけのファイルを出す（仕様書3）。月別（確定値）は別ツールの担当なのでここでは取らない。
// ============================================================
const PUR_JOB_KEY = 'purchase_job';
const PUR_ALARM = 'purchase_poll';
const PUR_LOG_KEY = 'purchase_logs';
const PUR_STATUS_KEY = 'purchase_status';
const PUR_TIMEOUT_MS = 30 * 60 * 1000;

async function purLog(text) {
  try {
    const s = await chrome.storage.local.get([PUR_LOG_KEY]);
    const logs = s[PUR_LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), msg: String(text) });
    if (logs.length > 1000) logs.splice(0, logs.length - 1000);
    await chrome.storage.local.set({ [PUR_LOG_KEY]: logs });
  } catch (_) {}
  try { chrome.runtime.sendMessage({ type: 'purchase-log', text: String(text) }).catch(() => {}); } catch (_) {}
}
async function purGetJob() { return (await chrome.storage.local.get(PUR_JOB_KEY))[PUR_JOB_KEY] || null; }
async function purSetJob(patch) {
  const cur = (await purGetJob()) || {};
  const job = { ...cur, ...patch, updatedAt: Date.now() };
  await chrome.storage.local.set({ [PUR_JOB_KEY]: job });
  return job;
}
async function purSetStatus(state) { await chrome.storage.local.set({ [PUR_STATUS_KEY]: { state, ts: Date.now() } }); }
const purJstDay = (offsetDays = 0, base = Date.now()) => new Date(base + 9 * 3600 * 1000 + offsetDays * 86400000).toISOString().slice(0, 10);
const purAddDays = (day, n) => { const [y, m, d] = day.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d) + n * 86400000).toISOString().slice(0, 10); };
const purYen = (n) => '¥' + Math.round(n).toLocaleString();
const purBusy = (job) => !!(job && (job.state === 'starting' || job.state === 'waiting'));

// 共通: 保存先・広告タブ・トークン
async function purPrepare() {
  const fs = await AMZ_FS.status();
  if (fs.state !== 'granted') throw new Error('保存先フォルダが未設定／要許可です。上部の「保存先」から設定してください');
  const tab = await findAdsTab();
  if (!tab) throw new Error('Amazon広告のタブが見つかりません。上部「必要ページを開く」で開いてから実行してください');
  const tr = await AMZ_TOKEN.ensureFresh(tab, (t) => purLog(t), { ddsOnly: true });
  if (!tr.tok) {
    // 新しいトークンを取れなくても、前に捕捉したものがあればそれで続ける（統合レポートAPIは古いトークンでも通ることが多い）
    const old = await AMZ_TOKEN.latest({ ddsOnly: true });
    if (old) {
      const h = cleanH(old.headers);
      const probe = await inTab(tab, PURCHASE.pageFindCfg, { headers: h, name: PURCHASE.SCHEDULE_NAME }).catch(() => null);
      if (probe && probe.ok) { await purLog('   新しいトークンは取れませんでしたが、前回のトークンで続けます'); return { tab, headers: h, moved: tr.moved }; }
    }
    if (tr.moved) await AMZ_TOKEN.restore(tab);
    throw new Error('トークンを取得できませんでした。Amazon広告のタブを一度表示（ログインを確認）してから、もう一度押してください');
  }
  return { tab, headers: cleanH(tr.tok.headers), moved: tr.moved };
}

async function purFetchCsv(cfgId, schedId) {
  const url = `https://advertising-japan.amazon.com/reporting/subscriptions/${encodeURIComponent(cfgId)}/download-report/${encodeURIComponent(schedId)}`;
  try {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const u8 = new Uint8Array(await res.arrayBuffer());
    return (u8[0] === 0x1f && u8[1] === 0x8b)
      ? await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text()
      : new TextDecoder('utf-8').decode(u8);
  } catch (e) { throw new Error(`ダウンロードに失敗しました（${e.message}）。Amazonの「レポート」画面から直接ダウンロードできます`); }
}

// レポートをダウンロード → 日ごとに分けて days の各日を保存（0件の日は列名だけ）
async function purSaveDays({ cfgId, schedId, days }) {
  const t = PURCHASE.transform(await purFetchCsv(cfgId, schedId));
  if (!t.ok) throw new Error(t.error);
  // 中身が空のレポート（期間内に1行も無い）を「0件の日」として保存しない（Amazon側にデータが無い期間を、取ったが0件と取り違えないため）
  const span = days.length === 1 ? days[0] : `${days[0]}〜${days[days.length - 1]}`;
  if (t.rawRows === 0 && days.length > 1)
    throw new Error(`Amazonから返ってきたレポートが空でした（${span}）。この期間は購入商品データが提供されていない可能性があります。ファイルは保存していません`);
  if (t.rawRows > 0 && t.datedRows === 0)
    throw new Error(`レポートの日付を読み取れませんでした（${span}）。ファイルは保存していません`);
  const saved = [];
  for (const day of days) {
    const rows = t.byDay[day] || [];
    const name = PURCHASE.fileName(day);
    await AMZ_FS.writeFile('', name, new TextEncoder().encode(PURCHASE.toCsv(rows)));
    const sum = rows.reduce((a, r) => a + (Number(r[8]) || 0), 0);
    const by = {}; for (const r of rows) { const k = r[0] + ' ' + (r[5] === '宣伝商品' ? '宣伝' : r[5]); by[k] = (by[k] || 0) + (Number(r[8]) || 0); }
    const detail = Object.keys(by).length ? '（' + Object.entries(by).sort().map(([k, v]) => `${k} ${purYen(v)}`).join(' / ') + '）' : '';
    await purLog(`  ✅ ${name}：${rows.length}行・売上${purYen(sum)}${rows.length ? '' : '（広告経由の購入なし）'}${detail}`);
    saved.push(day);
  }
  return saved;
}

// 予約レポートを確認（無ければ作成）。返り値 { cfgId, completed:{schedId, at, covers:[from,to]} | null }
async function purSchedule(tab, headers) {
  const f = await inTab(tab, PURCHASE.pageFindCfg, { headers, name: PURCHASE.SCHEDULE_NAME });
  if (!f || !f.ok) throw new Error('レポート一覧を取得できませんでした: ' + (f && f.error || '不明'));
  if (!f.cfg) {
    const exp = purJstDay(364);
    const c = await inTab(tab, PURCHASE.pageCreateCfg, { headers, account: PURCHASE.ACCOUNT, cfg: PURCHASE.config({
      name: PURCHASE.SCHEDULE_NAME, period: { reportConfigurationPresetPeriod: { preset: 'LAST_30_DAYS' } },
      scheduleType: 'RECURRING_DAILY', schedule: { recurringDailySchedule: { timeZone: 'ASIA_TOKYO', hourOfDay: 6, expirationDate: exp } } }) });
    if (!c || !c.ok) { await purLog('⚠ 毎日の予約レポートを作成できませんでした（今回はその場で作成します）: ' + (c && c.error || '不明')); return { cfgId: null, completed: null }; }
    await purLog(`📅 Amazonの「レポート」画面に毎日の予約「${PURCHASE.SCHEDULE_NAME}」を作成しました（毎朝6時・過去30日分・期限 ${exp}）。明日の朝からは数秒で取れます`);
    return { cfgId: c.cfgId, completed: null };
  }
  const runs = await inTab(tab, PURCHASE.pageRuns, { headers, cfgId: f.cfg.cfgId });
  if (!runs || !runs.ok || !runs.completed) return { cfgId: f.cfg.cfgId, completed: null };
  // 予約の実行日（JST）の前日までの30日分が入っている
  const runDay = purJstDay(0, Date.parse(runs.completed.at));
  return { cfgId: f.cfg.cfgId, completed: { ...runs.completed, covers: [purAddDays(runDay, -30), purAddDays(runDay, -1)] } };
}

// ---- 上の期間を1日ずつ ----
async function purchaseDays({ startDate, endDate }) {
  const yesterday = purJstDay(-1);
  const cur = await purGetJob();
  if (purBusy(cur)) {
    // すでに作成待ちのレポートがある。頼まれた日がすべてその中に入っていれば「作成中」として扱う（4種まとめてDLで✕にしない）
    const want = startDate && endDate && startDate <= endDate && startDate <= yesterday ? offDays(startDate, endDate < yesterday ? endDate : yesterday) : [];
    const have = new Set(cur.allDays || cur.days || []);
    if (want.length && want.every((d) => have.has(d))) return { ok: true, mode: 'pending', message: `Amazon側で作成中（${cur.label}）。完了は通知でお知らせします` };
    return { ok: false, error: `Amazon側で別の期間（${cur.label || ''}）を作成中です。完了の通知が来てから、もう一度押してください` };
  }
  if (!startDate || !endDate || startDate > endDate) return { ok: false, error: '期間が正しくありません' };
  if (startDate > yesterday) return { ok: false, error: `今日以降のデータはまだ取れません（取れるのは昨日 ${yesterday} まで）` };
  let end = endDate;
  if (end > yesterday) { end = yesterday; await purLog(`ℹ 終了日を昨日（${yesterday}）にしました（今日の分はまだ取れません）`); }
  const days = offDays(startDate, end);
  await purSetStatus('running');
  let prep;
  try { prep = await purPrepare(); } catch (e) { await purSetStatus('idle'); await purLog('❌ ' + e.message); return { ok: false, error: e.message }; }
  const { tab, headers, moved } = prep;
  try {
    await purLog(`🛒 購入商品データ ${startDate}〜${end}（${days.length}日分）`);
    const sch = await purSchedule(tab, headers);
    let rest = days;
    if (sch.completed) {
      const [from, to] = sch.completed.covers;
      const inside = days.filter((d) => d >= from && d <= to);
      if (inside.length) {
        await purLog(`⏬ 毎日の予約レポート（${from}〜${to}分）から ${inside.length}日分を保存します`);
        await purSaveDays({ cfgId: sch.cfgId, schedId: sch.completed.schedId, days: inside });
      }
      rest = days.filter((d) => d < from || d > to);
    }
    if (!rest.length) {
      await purSetStatus('done');
      await purLog(`🎉 ${days.length}日分を保存しました`);
      return { ok: true, mode: 'saved', days: days.length };
    }
    // 予約で足りない日 → その場で作る
    const s = rest[0], e = rest[rest.length - 1];
    const why = !sch.completed ? '予約レポートの完了した回がまだ無いため' : (e > sch.completed.covers[1] ? '予約レポートの今朝の回がまだ完了していないため' : '予約レポートの範囲（過去30日）より前のため');
    await purLog(`📝 ${rest.length}日分（${s}〜${e}）は${why}、Amazon側でその場で作成します`);
    return await purStartNowJob({ tab, headers, chunks: purChunks(rest), savedFirst: days.length - rest.length });
  } catch (err) {
    await purSetStatus('idle'); await purLog('❌ ' + err.message);
    return { ok: false, error: err.message };
  } finally {
    if (moved) await AMZ_TOKEN.restore(tab);
  }
}

// 1回のレポートで指定できる期間は最大121日（2026-10-26 実測。超えると INVALID_METRIC_COMBINATION）→ 120日ずつに分ける
const PUR_MAX_SPAN = 120;
function purChunks(days) {
  const out = [];
  for (const d of days) {
    const c = out[out.length - 1];
    if (c && c.days.length < PUR_MAX_SPAN && purAddDays(c.e, 1) === d) { c.e = d; c.days.push(d); }
    else out.push({ s: d, e: d, days: [d] });
  }
  return out;
}
const purSpanLabel = (s, e) => (s === e ? s : `${s}〜${e}`);

async function purCreateChunk(tab, headers, ch) {
  const label = purSpanLabel(ch.s, ch.e);
  const name = `amazon-downloader 購入商品データ ${label}`;
  const arg = { headers, account: PURCHASE.ACCOUNT, cfg: PURCHASE.config({
    name, period: { datePeriod: { startDate: ch.s, endDate: ch.e } }, scheduleType: 'NOW', schedule: { nowSchedule: { timeZone: 'ASIA_TOKYO' } } }) };
  const c = tab ? await inTab(tab, PURCHASE.pageCreateCfg, arg) : await PURCHASE.pageCreateCfg(arg);
  if (!c || !c.ok) {
    // 保持期間（約2年）より前を指定しても INVALID_METRIC_COMBINATION が返る（2026-10-26 実測）
    if (/INVALID_METRIC_COMBINATION/.test(c && c.error || '') && ch.s < purAddDays(purJstDay(), -720))
      throw new Error(`Amazonで取れるのは約2年前までです（2026-10-26時点で 2024-10-12 以降）。開始日を新しくしてください`);
    throw new Error('レポートを作成できませんでした: ' + (c && c.error || '不明'));
  }
  return { cfgId: c.cfgId, schedId: c.schedId, name, partLabel: label };
}

// 1回限りのレポートを作って、完成は alarms で待つ（120日を超える期間は順番に作る）
async function purStartNowJob({ tab, headers, chunks, savedFirst }) {
  const first = await purCreateChunk(tab, headers, chunks[0]);
  const allDays = chunks.flatMap((c) => c.days);
  const label = purSpanLabel(allDays[0], allDays[allDays.length - 1]);
  const part = chunks.length > 1 ? `（1/${chunks.length}）` : '';
  await purSetJob({ bulk: null, state: 'waiting', ...first, label, chunks, ci: 0, days: chunks[0].days, allDays, savedCount: 0,
    headers, startedAt: Date.now(), busy: 0, error: null, message: `Amazon側で作成中…（${first.partLabel}${part}）` });
  await purSetStatus('pending');
  if (chunks.length > 1) await purLog(`   1回で作れるのは最大約4か月なので、${chunks.length}回に分けて順番に作成します`);
  await purLog(`   「${first.name}」を作成しました${part}。完成まで数分かかります（ポップアップを閉じても進みます・完了は通知）`);
  chrome.alarms.create(PUR_ALARM, { periodInMinutes: 0.5 });
  return { ok: true, mode: 'pending', saved: savedFirst || 0, message: `Amazon側で作成中（${label}）。完了は通知でお知らせします` };
}

let purPolling = false;   // 同時に2つ動かない（起動時の再開とアラームが重なると二重保存になっていた）
async function purPollOnce() {
  if (purPolling) return;
  purPolling = true;
  try { await purPollOnceInner(); } finally { purPolling = false; }
}
async function purPollOnceInner() {
  const job = await purGetJob();
  if (!job || job.state !== 'waiting' || !job.cfgId) { chrome.alarms.clear(PUR_ALARM); return; }
  if (job.busy && Date.now() - job.busy < 120000) return;
  const fail = async (msg) => {
    chrome.alarms.clear(PUR_ALARM);
    await purSetJob({ state: 'error', busy: 0, headers: null, message: '❌ ' + msg });
    await purSetStatus('idle');
    await purLog('❌ ' + msg);
    const bulk = ((await purGetJob()) || {}).bulk;
    if (bulk) return purBulkNotify(bulk, false, msg);
    try { chrome.notifications.create('purchase-ng-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '購入商品データ：失敗', message: msg.slice(0, 120), priority: 2 }); } catch (_) {}
  };
  await purSetJob({ busy: Date.now() });
  try {
    // 状態確認（保存したトークン → だめなら最新の捕捉トークン）
    const poll = async (headers) => {
      let r = null;
      if (tab) { try { r = await inTab(tab, OFFICIAL.pagePoll, { headers, cfgId: job.cfgId }); } catch (_) { r = null; } }
      if (!r || !r.ok) r = await OFFICIAL.pagePoll({ headers, cfgId: job.cfgId });
      return r;
    };
    const tab = await findAdsTab();
    let headers = job.headers;
    let st = await poll(headers);
    if (!st || !st.ok) {
      const t = await AMZ_TOKEN.latest({ ddsOnly: true });
      if (t) { headers = cleanH(t.headers); st = await poll(headers); if (st && st.ok) await purSetJob({ headers }); job.headers = headers; }
    }
    const late = Date.now() - job.startedAt > PUR_TIMEOUT_MS;
    if (!st || !st.ok) {
      if (late) return fail(`「${job.name}」の状態を確認できませんでした。Amazonの「レポート」画面から確認してください`);
      await purSetJob({ busy: 0, message: 'Amazon側で作成中…（状態確認に失敗。再試行します）' }); return;
    }
    if (/FAIL|CANCEL/i.test(st.status || '')) return fail(`Amazon側で作成に失敗しました（${st.status} ${st.failure || ''}）`);
    if (st.status !== 'COMPLETED') {
      // 完成していれば何分たっていても保存する。未完成のまま30分を過ぎたら失敗扱い
      if (late) return fail(`「${job.name}」が30分以内に完成しませんでした。Amazonの「レポート」画面から確認してください`);
      const part = (job.chunks || []).length > 1 ? ` ${job.ci + 1}/${job.chunks.length}` : '';
      await purSetJob({ busy: 0, message: `Amazon側で作成中…（${job.partLabel || job.label}${part}・${Math.round((Date.now() - job.startedAt) / 60000)}分経過）` }); return;
    }
    chrome.alarms.clear(PUR_ALARM);
    await purSetJob({ message: 'ダウンロード中…' });
    let saved;
    const days = job.days || null;
    if (!days) return fail('前のバージョンで作成したレポートのため保存できませんでした。もう一度「購入商品データ」を押してください');
    try { saved = await purSaveDays({ cfgId: job.cfgId, schedId: st.schedId || job.schedId, days }); }
    catch (e) {
      // 中身が空・読めないレポートは残しても使い道がないので削除
      if (/空でした|読み取れませんでした/.test(e.message)) {
        try { const arg = { headers: job.headers, cfgId: job.cfgId, account: PURCHASE.ACCOUNT }; tab ? await inTab(tab, OFFICIAL.pageDelete, arg) : await OFFICIAL.pageDelete(arg); } catch (_) {}
      }
      return fail(e.message);
    }
    // 1回限りのレポートは削除（Amazonの「レポート」画面に溜めない）。毎日の予約は残す
    try {
      const arg = { headers: job.headers, cfgId: job.cfgId, account: PURCHASE.ACCOUNT };
      const d = tab ? await inTab(tab, OFFICIAL.pageDelete, arg) : await OFFICIAL.pageDelete(arg);
      if (!d || !d.ok) await purLog('   （Amazon側の1回限りレポートは残っています。不要なら「レポート」画面から削除できます）');
    } catch (_) {}
    const total = (job.savedCount || 0) + saved.length;
    const chunks = job.chunks || [];
    if (job.ci + 1 < chunks.length) {
      // 続きの期間を作成
      const next = chunks[job.ci + 1];
      let c;
      try { c = await purCreateChunk(tab, job.headers, next); } catch (e) { return fail(`${e.message}（${total}日分は保存済み）`); }
      await purSetJob({ ...c, ci: job.ci + 1, days: next.days, savedCount: total, startedAt: Date.now(), busy: 0,
        message: `Amazon側で作成中…（${c.partLabel} ${job.ci + 2}/${chunks.length}）` });
      await purLog(`   「${c.name}」を作成しました（${job.ci + 2}/${chunks.length}）`);
      chrome.alarms.create(PUR_ALARM, { periodInMinutes: 0.5 });
      return;
    }
    await purSetJob({ state: 'done', busy: 0, headers: null, message: `✅ ${job.label} の ${total}日分を保存` });
    await purSetStatus('done');
    await purLog(`🎉 ${job.label} の ${total}日分を保存しました`);
    const bulk = ((await purGetJob()) || {}).bulk;
    if (bulk) { await purBulkNotify(bulk, true); return; }
    try { chrome.notifications.create('purchase-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '購入商品データ：保存しました',
      message: `${job.label}（${total}日分）`, priority: 2 }, (id) => setTimeout(() => chrome.notifications.clear(id), 15000)); } catch (_) {}
  } catch (e) {
    await purSetJob({ busy: 0, message: '状態確認でエラー（再試行します）: ' + String(e && e.message || e) });
  }
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === PUR_ALARM) purPollOnce(); });

// ---- 4種まとめてDL の完了通知 ----
// 購入商品が「作成中」で終わった場合、4種まとめてDL の完了通知はポップアップでは出さず、ここ（作成完了時）で出す。
//   bulk = { range:'開始〜終了', ok: 購入以外の成功数, ngs:[...購入以外の失敗] }
async function purBulkNotify(bulk, purOk, purErr, cancelled) {
  const okN = (bulk.ok || 0) + (purOk ? 1 : 0);
  // ポップアップの4種まとめてDL表示（bulk_state）を最終状態にする
  try {
    const st = (await chrome.storage.local.get('bulk_state')).bulk_state;
    if (st && st.active && st.phase === 'waiting-purchase') {
      const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
      st.chips = st.chips || {};
      st.chips.pur = purOk ? { cls: 'ok', suffix: '✓' } : cancelled ? { cls: 'skip', suffix: '中止' } : { cls: 'ng', suffix: '✕' };
      const ngs = (bulk.ngs || []).concat(purOk ? [] : ['購入商品：' + String(purErr || '失敗')]);
      st.msg = okN === 4 ? `🎉 4種すべて完了しました（${esc(bulk.range || st.range || '')}）`
        : `⚠ 完了 ${okN}/4（${esc(bulk.range || st.range || '')}）<br>` + ngs.map((t) => '・' + esc(t)).join('<br>');
      st.active = false; st.finishedAt = Date.now(); st.ts = Date.now();
      await chrome.storage.local.set({ bulk_state: st });
    }
  } catch (_) {}
  const lines = [bulk.range || ''];
  for (const t of bulk.ngs || []) lines.push('・' + t);
  if (!purOk) lines.push('・購入商品：' + String(purErr || '失敗'));
  try {
    chrome.notifications.create('all-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png',
      title: '4種まとめてDL：' + (okN === 4 ? '完了' : `完了 ${okN}/4`), message: lines.join('\n').slice(0, 200), priority: 2 },
      (id) => setTimeout(() => chrome.notifications.clear(id), 15000));
  } catch (_) {}
}
// ポップアップ（suite.js）から：購入以外の結果を預かる。購入がもう終わっていればすぐ通知
async function purchaseBulkDone(bulk) {
  const job = await purGetJob();
  if (purBusy(job)) { await purSetJob({ bulk }); return { ok: true, deferred: true }; }
  await purBulkNotify(bulk, !!(job && job.state === 'done'), job && job.message);
  return { ok: true, deferred: false };
}

// 拡張の更新・再読み込みで alarms は消える（storage の作成待ちは残る）→ 起動のたびに待機を再開する（v2.12.4）
async function purResume() {
  try {
    const job = await purGetJob();
    if (!job || job.state !== 'waiting' || !job.cfgId) return;
    const a = await chrome.alarms.get(PUR_ALARM);
    if (!a) { chrome.alarms.create(PUR_ALARM, { periodInMinutes: 0.5 }); await purSetJob({ busy: 0 }); purPollOnce(); }
  } catch (_) {}
}
purResume();
chrome.runtime.onStartup.addListener(purResume);
chrome.runtime.onInstalled.addListener(purResume);

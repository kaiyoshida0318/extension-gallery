const fs = require('fs'), vm = require('vm');
const dir = process.argv[2];
let src = fs.readFileSync(dir + '/background.js', 'utf8')
  .replace("importScripts('fsstore.js');", '')
  .replace('const GRANT_WAIT_MS = 4 * 60 * 1000;', 'const GRANT_WAIT_MS = 7000;');
const logs = [], store = {}, tabs = [], notes = [], writes = [];
let state = 'prompt', polls = 0, grantAfter = 2;
const chrome = {
  runtime: { getURL: p => 'chrome-extension://abc/' + p, onMessage: { addListener() {} }, onInstalled: { addListener() {} } },
  storage: { local: {
    get: async ks => Object.fromEntries([].concat(ks).filter(k => k in store).map(k => [k, store[k]])),
    set: async o => Object.assign(store, o), remove: async ks => [].concat(ks).forEach(k => delete store[k]) } },
  tabs: { query: async () => tabs, create: async o => { const t = { id: tabs.length + 1, url: o.url, pinned: o.pinned, windowId: 1 }; tabs.push(t); return t; },
          update: async (id, o) => ({ id, ...o }), onRemoved: { addListener() {} } },
  windows: { update: async () => {} },
  notifications: { create: async (id, o) => notes.push(o.title), clear() {} },
};
const AMZ_FS = {
  status: async () => { if (state === 'prompt' && grantAfter >= 0 && ++polls > grantAfter) state = 'granted'; return { state, name: 'ゆかい屋' }; },
  writeFile: async (d, f) => { writes.push(d + '/' + f); return 'root/' + d + '/' + f; },
};
const ctx = { chrome, AMZ_FS, console, setTimeout, Date, Promise, Uint8Array, Math, JSON, String, Array, Object };
vm.createContext(ctx); vm.runInContext(src, ctx);
const origLog = ctx.appendBgLog; ctx.appendBgLog = async (c, t) => logs.push(`(${c}) ${t}`);
vm.runInContext('appendBgLog = globalThis.appendBgLog', ctx);
const p = { filename: 'rpp_item_reports_yukaiya_20261029.zip', day: '2026-10-29', kind: 'RPP', dataArr: [1,2,3] };
(async () => {
  console.log('--- case1: 途中で許可切れ → 2回目のポーリングで許可');
  let r = await ctx.handleSaveFile(p);
  console.log('result ok=', r.ok, 'writes=', writes.length, 'tabs=', tabs.map(t => t.url + (t.pinned ? ' [pinned]' : '')), 'notes=', notes);
  console.log('--- case2: 許可されない → タイムアウト、直後の保存は待たずに失敗');
  state = 'prompt'; grantAfter = -1; polls = 0; writes.length = 0; notes.length = 0;
  let t0 = Date.now(); r = await ctx.handleSaveFile(p); console.log('result1 ok=', r.ok, r.error, Math.round((Date.now()-t0)/1000)+'s');
  t0 = Date.now(); r = await ctx.handleSaveFile({ ...p, day: '2026-10-30' }); console.log('result2 ok=', r.ok, Math.round((Date.now()-t0)/1000)+'s', 'tabs=', tabs.length, 'notes=', notes);
  console.log('--- case3: 中止ボタン');
  vm.runInContext('grantGaveUpAt = 0', ctx); store.rms_cancel_flag = true;
  r = await ctx.handleSaveFile(p); console.log('result ok=', r.ok, r.error);
  console.log('--- logs'); logs.forEach(l => console.log(l));
})();

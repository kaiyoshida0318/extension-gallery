const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync(process.argv[2] + '/fsstore.js', 'utf8');
function mkRoot(behavior) {
  const files = {}; const log = [];
  let n = 0;
  const fileHandle = (name) => ({
    async createWritable() {
      n++; let buf = null;
      return { async write(d) { buf = d; }, async close() {
          const b = behavior(n);
          if (b === 'fail') throw Object.assign(new Error('locked'), { name: 'NoModificationAllowedError' });
          files[name] = b === 'short' ? new Uint8Array(0) : buf; },
        async abort() { log.push('abort'); } };
    },
    async getFile() { return { size: (files[name] || new Uint8Array(0)).byteLength }; },
  });
  const dir = {
    name: 'root',
    async queryPermission() { return 'granted'; },
    async getDirectoryHandle() { return dir; },
    async getFileHandle(name, { create }) { if (!(name in files)) { if (!create) throw new Error('nf'); files[name] = new Uint8Array(0); } return fileHandle(name); },
    async removeEntry(name) { delete files[name]; log.push('removed ' + name); },
  };
  return { dir, files, log, tries: () => n };
}
(async () => {
  for (const [label, beh] of [['常に成功', () => 'ok'], ['1回目だけ失敗', n => n === 1 ? 'fail' : 'ok'], ['ずっと失敗', () => 'fail'], ['サイズ不一致→成功', n => n === 1 ? 'short' : 'ok']]) {
    const r = mkRoot(beh);
    const ctx = { self: {}, indexedDB: null, setTimeout, Blob, TextEncoder, Uint8Array, Error, Promise };
    vm.createContext(ctx); vm.runInContext(src, ctx);
    const FS = ctx.self.AMZ_FS;
    // getRoot を差し替え
    vm.runInContext('', ctx);
    const patched = src.replace("async function getRoot() {", "async function getRoot() { return self.__root;");
    const ctx2 = { self: { __root: r.dir }, setTimeout, Blob, TextEncoder, Uint8Array, Error, Promise };
    vm.createContext(ctx2); vm.runInContext(patched, ctx2);
    let out;
    try { out = await ctx2.self.AMZ_FS.writeFile('ADcheck取り込み用', 'x.zip', new Uint8Array(597)); }
    catch (e) { out = 'ERROR: ' + e.message; }
    console.log(`[${label}] 試行${r.tries()}回 →`, out, '| 残ったファイル:', Object.fromEntries(Object.entries(r.files).map(([k, v]) => [k, v.byteLength])), r.log.join(','));
  }
})();

const fs = require('fs'), vm = require('vm');
let src = fs.readFileSync(process.argv[2] + '/background.js', 'utf8').replace("importScripts('fsstore.js');", '');
const calls = [];
const chrome = { runtime: { getURL: p => p, onMessage: { addListener() {} }, onInstalled: { addListener() {} } },
  storage: { local: { get: async () => ({}), set: async () => {}, remove: async () => {} } },
  tabs: { query: async () => [], onRemoved: { addListener() {} } }, notifications: { create() {} } };
const ctx = { chrome, AMZ_FS: {}, console, setTimeout, Date, Promise, Math, JSON, Map, Set, Object, Array, String };
vm.createContext(ctx); vm.runInContext(src, ctx);
vm.runInContext(`getOrCreateTab = async () => ({ id: 1 }); installOverlayOnTab = async () => {}; runOnTab = async (id, fn, p) => { globalThis.__last = { fn, p }; return { ok: true }; };`, ctx);
(async () => {
  const uiOpts = { periodType: 0, campaignType: '1', reportFilter: 1, rankType: 1, allUsers: true, newUsers: true, existingUsers: true, noOfClicks: true, adsalesBefore: true, cpc: true, h12: true, h720: true, gms: true, roas: true, cv: true, cvr: true, cpa: true };
  for (const [label, task] of [
    ['画面の設定あり(全KW)', { kind: 'rppKw', days: ['2025-02-24', '2025-02-25'], options: uiOpts, timeout: 30 }],
    ['設定なし=既定値(全KW)', { kind: 'rppKw', days: ['2025-02-24'] }],
    ['設定なし=既定値(全ての広告)', { kind: 'rppAll', days: ['2025-02-24'] }],
  ]) {
    await ctx.runRetryTask(task);
    const { fn, p } = ctx.__last;
    console.log(`[${label}] ${fn} timeout=${p.timeout ?? '-'} interval=${p.interval ?? '-'} options=${p.options ? 'あり(' + Object.keys(p.options).length + '項目, h720=' + p.options.h720 + ', h12=' + p.options.h12 + ', newUsers=' + p.options.newUsers + ')' : 'なし'}`);
  }
  console.log('既定値(全KW) と 画面の初期値 が一致:', JSON.stringify(ctx.defaultRppOptions('rppKw')) === JSON.stringify(uiOpts));
})();

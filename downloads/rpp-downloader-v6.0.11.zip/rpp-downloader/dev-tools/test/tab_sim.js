const fs = require('fs'), vm = require('vm');
let src = fs.readFileSync(process.argv[2] + '/background.js', 'utf8').replace("importScripts('fsstore.js');", '');
const logs = [], store = {}, notes = []; let removedCb = null; let execMode = 'hang';
const chrome = {
  runtime: { getURL: p => 'chrome-extension://abc/' + p, onMessage: { addListener() {} }, onInstalled: { addListener() {} } },
  storage: { local: { get: async ks => Object.fromEntries([].concat(ks).filter(k => k in store).map(k => [k, store[k]])), set: async o => Object.assign(store, o), remove: async ks => [].concat(ks).forEach(k => delete store[k]) } },
  tabs: { query: async () => [{ id: 7, url: 'https://datatool.rms.rakuten.co.jp/realtime/item', status: 'complete' }], create: async o => ({ id: 99 }), update: async () => {}, get: async id => ({ id, status: 'complete' }), onRemoved: { addListener(cb) { removedCb = cb; } } },
  windows: { update: async () => {} },
  scripting: { executeScript: async (o) => {
      if (o.files) return [];
      if (execMode === 'hang' && o.args?.[0] === 'itemSalesDownloader') return new Promise(() => {});
      if (execMode === 'reject' && o.args?.[0] === 'itemSalesDownloader') throw new Error('No tab with id: 7');
      return [{ result: null }]; } },
  notifications: { create: async (id, o) => notes.push(o.title), clear() {} },
};
const ctx = { chrome, AMZ_FS: {}, console, setTimeout, Date, Promise, Math, JSON, Map, Object, Array, String };
vm.createContext(ctx); vm.runInContext(src, ctx);
ctx.appendBgLog = async (c, t) => logs.push(`(${c}) ${t}`); vm.runInContext('appendBgLog = globalThis.appendBgLog', ctx);
(async () => {
  console.log('--- ケース1: 実行中にタブが閉じられる (executeScript が返ってこない)');
  store.rms_active_job = { jobId: 'j1', status: 'running', days: [] };
  ctx.handleItemSales({});
  await new Promise(r => setTimeout(r, 50));
  removedCb(7);
  await new Promise(r => setTimeout(r, 50));
  console.log('job.status =', store.rms_active_job.status, '| 通知 =', notes);
  console.log('--- ケース2: executeScript がエラーを返す');
  execMode = 'reject'; notes.length = 0; store.rms_active_job = { jobId: 'j2', status: 'running', days: [] };
  const r = await ctx.handleItemSales({});
  console.log('戻り値 =', JSON.stringify(r), '| job.status =', store.rms_active_job.status, '| 通知 =', notes);
  console.log('--- logs'); logs.forEach(l => console.log(l));
  process.exit(0);
})();

// v6.0.9 ログイン切れのシミュレーション
//   node dev-tools/test/login_sim.js <拡張のフォルダ>
// A. injected.js: 途中で HTTP 401 → その場で止まる / やり直さない / 残りの日が「失敗」で履歴に残る
// B. background.js: エラー画面のタブを使わず開き直す / エラー画面なら始めない / 連続ジョブの残りを履歴に残す / 通知とログイン画面
const fs = require('fs'), vm = require('vm');
const dir = process.argv[2];
const sleepReal = setTimeout;
let failures = 0;
const check = (label, cond, extra = '') => { console.log(`${cond ? '✅' : '❌'} ${label}${extra ? '  ' + extra : ''}`); if (!cond) failures++; };

// ---------------- A. injected.js ----------------
function makeInjectedCtx({ failFromDay, mode }) {
  const store = { rms_dl_logs: [], rms_dl_history: [] };
  const calls = { submit: 0, saved: [] };
  const res = (status, body, extra = {}) => ({
    status, ok: status >= 200 && status < 300, redirected: false, url: '',
    headers: { get: h => (h === 'Content-Disposition' ? `attachment; filename="x_yukaiya_20261112093000000.${extra.ext || 'zip'}"` : null) },
    json: async () => (typeof body === 'string' ? JSON.parse(body) : body),
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    blob: async () => ({ arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer, type: '' }),
    clone() { return this; },
  });
  const unauthorized = () => res(401, { errors: [{ message: '正常な処理ができませんでした。もう一度お試しください。' }] });
  let currentDay = null;
  let jobSeq = 100;
  const jobs = [];
  const fetch = async (url, opt = {}) => {
    const body = opt.body ? JSON.parse(opt.body) : null;
    const day = body?.startDate || body?.reportPayload?.startDate || currentDay;
    const expired = failFromDay && day && day >= failFromDay;
    const expiredAll = failFromDay === 'ALL';
    if (url.includes('/rpp/api/reports/downloadPerfFile')) { calls.submit++; return (expired || expiredAll) ? unauthorized() : res(200, 'csv', { ext: 'csv' }); }
    if (url.includes('/rpp/api/reports/downloadAsync')) {
      calls.submit++; currentDay = body.startDate;
      if (expired || expiredAll) return unauthorized();
      jobs.unshift({ id: ++jobSeq, status: 2, reportType: 13, startDate: body.startDate, requestDate: String(jobSeq) });
      return res(201, { status: 'SUCCESS' });
    }
    if (url.includes('/rpp/api/keywords/downloadAll')) { calls.submit++; return expiredAll ? unauthorized() : res(201, { status: 'SUCCESS' }); }
    if (url.includes('/rpp/api/download/list')) return res(200, { data: { userHistoryList: jobs } });
    if (url.includes('/rpp/api/download/report')) return res(200, 'zip');
    if (url.endsWith('/cpnadv/api/downloads') && opt.method === 'POST') {
      calls.submit++;
      const d = JSON.parse(opt.body).reportPayload.startDate;
      currentDay = d;
      if (failFromDay && d >= failFromDay) return unauthorized();
      jobs.unshift({ jobId: ++jobSeq, status: 300 });
      return res(201, { status: 'SUCCESS', data: { jobId: jobSeq } });
    }
    if (url.includes('/cpnadv/api/downloads?page=1')) return res(200, { data: { jobs } });
    if (url.includes('/cpnadv/api/downloads/report')) return res(200, 'zip');
    throw new Error('想定外のURL: ' + url);
  };
  const chrome = {
    storage: { local: {
      get: async ks => Object.fromEntries([].concat(ks).filter(k => k in store).map(k => [k, store[k]])),
      set: async o => Object.assign(store, o),
      remove: async ks => [].concat(ks).forEach(k => delete store[k]) } },
    runtime: {
      lastError: null,
      sendMessage(msg, cb) { if (msg.type === 'save-file') { calls.saved.push(msg.payload.filename); cb && cb({ ok: true }); } },
    },
  };
  const window = {};
  const fastTimeout = (fn, ms) => sleepReal(fn, Math.min(ms, 5));   // 待ち時間は短縮
  const ctx = {
    chrome, window, fetch, console, Date, Promise, Math, JSON, Array, Object, String, Number, Set, Map, Error, RegExp, URL, Uint8Array, Blob: class { constructor(p, o) { this.type = o?.type || ''; } async arrayBuffer() { return new Uint8Array([1]).buffer; } },
    setTimeout: fastTimeout, crypto: { randomUUID: () => 'uuid' },
    document: { cookie: 'XSRF-TOKEN=abc', createElement: () => ({ style: {}, appendChild() {}, querySelector: () => null }), body: { appendChild() {} }, getElementById: () => null },
    location: { href: 'https://ad.rms.rakuten.co.jp/rpp/reports', pathname: '/rpp/reports', search: '' },
  };
  ctx.self = ctx; ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(dir + '/injected.js', 'utf8'), ctx);
  vm.runInContext(fs.readFileSync(dir + '/injected.js', 'utf8'), ctx);   // 同じタブに2回読み込まれても壊れないこと
  ctx.installProgressOverlay = () => {};
  vm.runInContext('installProgressOverlay = globalThis.installProgressOverlay', ctx);
  return { ctx, store, calls };
}
const hist = (store, type) => store.rms_dl_history.filter(h => h.type === type);

async function partA() {
  console.log('\n===== A. injected.js =====');
  // A1: 全KW 5日分、3日目から 401
  {
    const { ctx, store, calls } = makeInjectedCtx({ failFromDay: '2026-11-03' });
    const r = await ctx.rppAsyncDownloader({ startDate: '2026-11-01', endDate: '2026-11-05', timeout: 5, options: {}, selectionType: 4, reportType: 3, panelPrefix: 'rppKw', reportName: '全キーワードレポート' });
    const h = hist(store, '② 全キーワードレポート');
    check('A1 全KW: 3日目の401で止まる', r.loginRequired === true && r.success === 2 && r.fail === 3, JSON.stringify({ ok: r.ok, success: r.success, fail: r.fail }));
    check('A1 全KW: 401のあと投入しない(4・5日目に進まない)', calls.submit === 3, `投入回数=${calls.submit}`);
    check('A1 全KW: 11/03〜05 が失敗として履歴に残る', ['2026-11-03', '2026-11-04', '2026-11-05'].every(d => h.some(x => x.day === d && x.ok === false)));
    check('A1 全KW: ジョブ表示は aborted', store.rms_active_job?.status === 'aborted');
  }
  // A2: クーポンKW別 4日分、2日目から 401 → やり直さない
  {
    const { ctx, store, calls } = makeInjectedCtx({ failFromDay: '2026-11-02' });
    ctx.location.href = 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports';
    const r = await ctx.cpnadvAsyncDownloader({ startDate: '2026-11-01', endDate: '2026-11-04', mode: 'keyword', interval: 0, timeout: 5 });
    const h = hist(store, '③ クーポンKW別');
    check('A2 クーポン: 2日目の401で止まる', r.loginRequired === true && r.success === 1 && r.fail === 3, JSON.stringify({ success: r.success, fail: r.fail }));
    check('A2 クーポン: 401を3回やり直さない', calls.submit === 2, `投入回数=${calls.submit}`);
    check('A2 クーポン: 残り3日が失敗で履歴に残る', h.filter(x => x.ok === false).length === 3);
  }
  // A3: ④ スナップショット (今回の症状) → 1回で止まる
  {
    const { ctx, store, calls } = makeInjectedCtx({ failFromDay: 'ALL' });
    const r = await ctx.rppKeywordSnapshotDownloader({ timeout: 5 });
    check('A3 ④: 401で止まる', r.loginRequired === true && r.ok === false, r.error);
    check('A3 ④: やり直さない(以前は3回)', calls.submit === 1, `投入回数=${calls.submit}`);
    const logs = store.rms_dl_logs.map(l => l.msg).join('\n');
    check('A3 ④: 楽天の応答本文もログに残る', /正常な処理ができませんでした/.test(logs));
  }
  // A4: 全ての広告、最初の日から 401
  {
    const { ctx, store, calls } = makeInjectedCtx({ failFromDay: 'ALL' });
    const r = await ctx.rppAllDownloader({ startDate: '2026-11-01', endDate: '2026-11-03', interval: 0, options: {} });
    check('A4 全ての広告: 1日目で止まる', r.loginRequired === true && r.success === 0 && r.fail === 3 && calls.submit === 1);
  }
  // A5: 401 が無ければ今まで通り
  {
    const { ctx, calls } = makeInjectedCtx({});
    const r = await ctx.rppAsyncDownloader({ startDate: '2026-11-01', endDate: '2026-11-03', timeout: 5, options: {}, selectionType: 3, reportType: 4, panelPrefix: 'rppItem', reportName: '全商品レポート' });
    check('A5 正常時: 3日とも保存', r.ok === true && r.success === 3 && calls.saved.length === 3);
  }
}

// ---------------- B. background.js ----------------
function makeBgCtx({ tabs: initTabs, navigateTo }) {
  const store = {}, notes = [], logs = [];
  let tabs = initTabs.map(t => ({ status: 'complete', windowId: 1, ...t }));
  let nextId = 900;
  const chrome = {
    runtime: { getURL: p => 'chrome-extension://abc/' + p, onMessage: { addListener() {} }, onInstalled: { addListener() {} } },
    storage: { local: {
      get: async ks => Object.fromEntries([].concat(ks).filter(k => k in store).map(k => [k, store[k]])),
      set: async o => Object.assign(store, o), remove: async ks => [].concat(ks).forEach(k => delete store[k]) } },
    tabs: {
      query: async () => tabs.map(t => ({ ...t })),
      get: async id => { const t = tabs.find(x => x.id === id); if (!t) throw new Error('No tab with id: ' + id); return { ...t }; },
      create: async o => { const t = { id: ++nextId, url: navigateTo(o.url), status: 'complete', windowId: 1, active: o.active }; tabs.push(t); return { ...t }; },
      update: async (id, o) => {
        const t = tabs.find(x => x.id === id);
        if (o.url) { t.status = 'loading'; const dest = navigateTo(o.url); sleepReal(() => { t.url = dest; t.status = 'complete'; }, 600); }
        if (o.active) t.active = true;
        return { ...t };
      },
      onRemoved: { addListener() {} },
    },
    windows: { update: async () => {} },
    notifications: { create: async (id, o) => notes.push(`${o.title} | ${o.message}`), clear() {} },
    scripting: { executeScript: async () => [{ result: { ok: true, success: 3, fail: 0 } }] },
  };
  const ctx = { chrome, AMZ_FS: { status: async () => ({ state: 'granted' }) }, console, setTimeout, Date, Promise, Math, JSON, String, Array, Object, Set, Map, Error };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(dir + '/background.js', 'utf8').replace("importScripts('fsstore.js');", ''), ctx);
  ctx.appendBgLog = async (c, t) => logs.push(`(${c}) ${t}`);
  vm.runInContext('appendBgLog = globalThis.appendBgLog; installOverlayOnTab = async () => {};', ctx);
  return { ctx, store, notes, logs, getTabs: () => tabs };
}

async function partB() {
  console.log('\n===== B. background.js =====');
  const expired = url => url.includes('glogin') ? url : url.replace(/\/(rpp|cpnadv)\/.*/, '/$1/system_error');
  const loggedIn = url => url;

  // B1: 今回の症状。エラー画面のタブが残っていて、ログインは切れたまま → 始めずに止まる、ログイン画面を開く
  {
    const { ctx, notes, logs, getTabs } = makeBgCtx({ tabs: [{ id: 1, url: 'https://ad.rms.rakuten.co.jp/rpp/system_error' }], navigateTo: expired });
    let injected = 0;
    ctx.chrome.scripting.executeScript = async () => { injected++; return [{ result: { ok: true } }]; };
    const r = await ctx.handleRppKwSnapshot({});
    check('B1 ④: ログイン切れで返す', r.loginRequired === true && r.next === '④ をもう一度押してください', JSON.stringify(r));
    check('B1 ④: 楽天のタブで取得を始めない', injected === 0, `executeScript=${injected}`);
    check('B1 ④: エラー画面のタブを開き直した(タブを増やさない)', logs.some(l => l.includes('開き直します')) && getTabs().filter(t => t.url.includes('ad.rms')).length === 1);
    check('B1 ④: 🔑 通知', notes.some(n => n.startsWith('🔑 楽天RMSのログインが切れています')), notes[0]);
    check('B1 ④: RMSのログイン画面を開いた', getTabs().some(t => t.url.includes('glogin.rms.rakuten.co.jp') && t.active));
  }
  // B2: ログインし直した後 → エラー画面のタブを開き直して、そのまま取得できる
  {
    const { ctx, notes, getTabs } = makeBgCtx({ tabs: [{ id: 1, url: 'https://ad.rms.rakuten.co.jp/rpp/system_error' }], navigateTo: loggedIn });
    const r = await ctx.handleRppKwSnapshot({});
    check('B2 ログイン後: 取得できる', r.ok === true, JSON.stringify(r));
    check('B2 ログイン後: タブは /rpp/items に開き直された', getTabs().find(t => t.id === 1).url.includes('/rpp/items'));
    check('B2 ログイン後: 🔑 通知は出ない', !notes.some(n => n.startsWith('🔑')));
  }
  // B3: ② の 2つ目 (全商品) の途中で401 → 全KW の日を「未取得」として履歴に残す、♻ を案内
  {
    const { ctx, store, notes } = makeBgCtx({ tabs: [{ id: 1, url: 'https://ad.rms.rakuten.co.jp/rpp/reports' }], navigateTo: loggedIn });
    let n = 0;
    ctx.chrome.scripting.executeScript = async (o) => {
      if (o.files) return [];
      n++;
      if (n === 1) return [{ result: { ok: true, success: 3, fail: 0 } }];
      return [{ result: { ok: false, loginRequired: true, success: 1, fail: 2, error: '楽天RMSのログインが切れています (HTTP 401)' } }];
    };
    const p = { startDate: '2026-11-01', endDate: '2026-11-03' };
    const r = await ctx.handleBulkRpp3({ rppAll: p, rppItem: p, rppKw: p });
    const kw = (store.rms_dl_history || []).filter(h => h.type === '② 全キーワードレポート');
    check('B3 ②: 3つ目(全KW)は実行しない', n === 2, `実行回数=${n}`);
    check('B3 ②: 全KW の3日分を未取得として履歴に残す', kw.length === 3 && kw.every(h => h.ok === false));
    check('B3 ②: ♻ を案内', r.loginRequired && /♻/.test(r.next), r.next);
    check('B3 ②: 完了マーカーを付けない', !store.rms_done_flags?.rpp);
    check('B3 ②: 通知は1回', notes.length === 1, notes.join(' / '));
  }
  // B4: ③ の最初から(タブがエラー画面で)止まった → 履歴に何も残さず、③ の押し直しを案内
  {
    const { ctx, store } = makeBgCtx({ tabs: [], navigateTo: expired });
    const r = await ctx.handleBulkCpn2({ startDate: '2026-11-01', endDate: '2026-11-03', interval: 3, timeout: 20 });
    check('B4 ③: 押し直しを案内', r.loginRequired && r.next === '③ をもう一度押してください', r.next);
    check('B4 ③: 履歴は増えない', !(store.rms_dl_history || []).length);
  }
  // B5: ♻ の途中でログイン切れ → 残りのタスクは実行しない
  {
    const { ctx } = makeBgCtx({ tabs: [{ id: 1, url: 'https://ad.rms.rakuten.co.jp/rpp/reports' }], navigateTo: loggedIn });
    let n = 0;
    ctx.chrome.scripting.executeScript = async (o) => { if (o.files) return []; n++; return [{ result: { ok: false, loginRequired: true, success: 0, fail: 2 } }]; };
    const r = await ctx.handleRetryFailed([
      { kind: 'rppKw', type: '② 全キーワードレポート', days: ['2026-11-01', '2026-11-02'] },
      { kind: 'rppItem', type: '② 全商品レポート', days: ['2026-11-01'] },
    ]);
    check('B5 ♻: 1件目で止まる', n === 1 && r.loginRequired === true, JSON.stringify(r));
  }
}

(async () => {
  await partA();
  await partB();
  console.log(failures === 0 ? '\n🎉 全部OK' : `\n❌ ${failures} 件NG`);
  process.exit(failures ? 1 : 0);
})();

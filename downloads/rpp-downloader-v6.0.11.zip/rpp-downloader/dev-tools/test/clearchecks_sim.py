# v6.0.11 「✓を外す」ボタン (仕様書のテスト項目) を popup.html で確かめる
#   python3 dev-tools/test/clearchecks_sim.py <拡張のフォルダ>
# 要: playwright, Google Chrome
import asyncio, json, sys, datetime
from playwright.async_api import async_playwright

EXT = sys.argv[1]
TODAY = datetime.date.today().isoformat()
YDAY = (datetime.date.today() - datetime.timedelta(days=1)).isoformat()

# chrome.storage.local のダミー (Promise とコールバックの両方、onChanged も発火)
STUB = r"""
(() => {
  const store = JSON.parse(window.__INIT_STORE__ || '{}');
  const listeners = [];
  const fire = (changes) => listeners.forEach(fn => fn(changes, 'local'));
  const pick = ks => { if (ks == null) return { ...store }; const o = {}; [].concat(ks).forEach(k => { if (k in store) o[k] = JSON.parse(JSON.stringify(store[k])); }); return o; };
  const local = {
    get(ks, cb) { const r = pick(ks); if (cb) { cb(r); return; } return Promise.resolve(r); },
    set(o, cb) { const ch = {}; for (const [k, v] of Object.entries(o)) { ch[k] = { oldValue: store[k], newValue: v }; store[k] = JSON.parse(JSON.stringify(v)); } fire(ch); if (cb) { cb(); return; } return Promise.resolve(); },
    remove(ks, cb) { const ch = {}; [].concat(ks).forEach(k => { if (k in store) { ch[k] = { oldValue: store[k] }; delete store[k]; } }); if (Object.keys(ch).length) fire(ch); if (cb) { cb(); return; } return Promise.resolve(); },
  };
  window.__store = store;
  window.chrome = {
    storage: { local, onChanged: { addListener: fn => listeners.push(fn) } },
    runtime: { sendMessage() {}, onMessage: { addListener() {} }, getURL: p => p, lastError: null, getManifest: () => ({ version: 'test' }) },
    tabs: { query: async () => [], create: async () => ({}) }, notifications: {}, permissions: { contains: async () => true },
  };
})();
"""

BASE = {
  'rms_done_flags': {'is': True, 'rpp': True, 'cpn': True},
  'rms_done_flags_snap': {'snap': TODAY},
  'rms_dl_history': [{'type': '② 全商品レポート', 'day': '2026-11-01', 'ok': False}],
  'rms_dl_logs': [{'t': 'x', 'cat': 'bulk', 'msg': '既存ログ'}],
  'rms_dl_date_lock': {'start': '2026-10-13', 'end': '2026-11-12'},
}
fails = 0
def check(label, cond, extra=''):
    global fails
    print(('✅ ' if cond else '❌ ') + label + (('  ' + str(extra)) if extra else ''))
    if not cond: fails += 1

async def open_popup(b, store):
    pg = await b.new_page(viewport={'width': 420, 'height': 900})
    errors = []
    pg.on('pageerror', lambda e: errors.append(str(e)))
    await pg.add_init_script('window.__INIT_STORE__ = ' + json.dumps(json.dumps(store)) + ';' + STUB)
    await pg.goto(f'file://{EXT}/popup.html')
    await pg.wait_for_timeout(500)
    return pg, errors

async def done(pg):
    return await pg.evaluate("""() => ({
      is: $('bulk-dl-is').classList.contains('done'), rpp: $('bulk-dl-rpp').classList.contains('done'),
      cpn: $('bulk-dl-cpn').classList.contains('done'), snap: $('bulk-dl-rppsnap').classList.contains('done') })""")

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])

        pg, errors = await open_popup(b, BASE)
        d = await done(pg)
        check('最初は ①②③④ すべて ✓', all(d.values()), d)
        await pg.screenshot(path='/tmp/cc_before.png', clip={'x': 0, 'y': 60, 'width': 420, 'height': 470})

        await pg.click('#clearChecksDated'); await pg.wait_for_timeout(200)
        d = await done(pg)
        check('期間指定の「✓を外す」→ ①②③ だけ消える', not d['is'] and not d['rpp'] and not d['cpn'], d)
        check('もう一方 (④) の ✓ は残っている', d['snap'])
        await pg.screenshot(path='/tmp/cc_after_dated.png', clip={'x': 0, 'y': 60, 'width': 420, 'height': 470})

        await pg.click('#clearChecksDated'); await pg.wait_for_timeout(200)
        check('✓ が無い状態で押してもエラーにならない', not errors, errors)

        # 取り直し (background の setDoneFlag が storage に書くのと同じ)
        await pg.evaluate("() => chrome.storage.local.set({ rms_done_flags: { is: true } })"); await pg.wait_for_timeout(200)
        d = await done(pg)
        check('押した後に取り直すと、また ✓ が付く', d['is'] and not d['rpp'], d)

        await pg.click('#clearChecksSnap'); await pg.wait_for_timeout(200)
        d = await done(pg)
        check('最新状態の「✓を外す」→ ④ だけ消える', not d['snap'] and d['is'], d)

        # 閉じて開き直す
        saved = await pg.evaluate('() => JSON.stringify(window.__store)')
        store = json.loads(saved)
        await pg.close()
        pg, errors = await open_popup(b, store)
        d = await done(pg)
        check('開き直しても、消えた ✓ は消えたまま', not d['snap'] and not d['rpp'] and d['is'], d)
        check('ファイル以外も残っている: 履歴', store.get('rms_dl_history') == BASE['rms_dl_history'])
        check('ファイル以外も残っている: 固定した日付', store.get('rms_dl_date_lock') == BASE['rms_dl_date_lock'])
        check('ファイル以外も残っている: ログ', any(l.get('msg') == '既存ログ' for l in store.get('rms_dl_logs', [])))
        await pg.close()

        # ④ は「今日取ったか」: 昨日の日付なら ✓ は出ない
        pg, errors = await open_popup(b, {'rms_done_flags_snap': {'snap': YDAY}, 'rms_done_flags': {'rpp': True}})
        d = await done(pg)
        check('④ が昨日の日付なら ✓ は出ない (日付が変わったら消える)', not d['snap'] and d['rpp'], d)
        await pg.close()

        # 旧形式 (v6.0.10 まで: rms_done_flags.snap = true) が残っていても ④ に ✓ は出ない
        pg, errors = await open_popup(b, {'rms_done_flags': {'snap': True, 'is': True}})
        d = await done(pg)
        check('旧形式の snap=true では ④ に ✓ が出ない', not d['snap'] and d['is'], d)

        # 日付入力を変えると ①②③ だけ消え、④ は残る
        await pg.evaluate(f"() => chrome.storage.local.set({{ rms_done_flags_snap: {{ snap: '{TODAY}' }} }})"); await pg.wait_for_timeout(200)
        await pg.fill('#bulk-start', '2026-10-01'); await pg.dispatch_event('#bulk-start', 'change'); await pg.wait_for_timeout(300)
        d = await done(pg)
        check('日付入力を変えると ①②③ だけ消え、④ は残る', not d['is'] and d['snap'], d)

        # popup の markDone('snap') は日付で入る
        await pg.evaluate("() => markDone('snap')"); await pg.wait_for_timeout(100)
        v = await pg.evaluate("() => window.__store.rms_done_flags_snap")
        check('markDone(snap) は実行日を入れる', v == {'snap': TODAY}, v)
        await pg.close()
        await b.close()
    print('\n🎉 全部OK' if not fails else f'\n❌ {fails} 件NG')
    sys.exit(1 if fails else 0)

asyncio.run(main())

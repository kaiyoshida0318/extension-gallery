const fs = require('fs'), vm = require('vm');
let src = fs.readFileSync(process.argv[2] + '/background.js', 'utf8').replace("importScripts('fsstore.js');", '');
const logs = [], store = {}, notes = []; let listener = null, removedCb = null;
let tabs = [{ id: 10, url: 'https://ad.rms.rakuten.co.jp/rpp/reports', status: 'complete' }];
let mode = {};  // funcName → 'closeTab' | 'ok'
const chrome = {
  runtime: { getURL: p => 'chrome-extension://abc/' + p, onMessage: { addListener(cb) { listener = cb; } }, onInstalled: { addListener() {} } },
  storage: { local: { get: async ks => Object.fromEntries([].concat(ks).filter(k => k in store).map(k => [k, store[k]])), set: async o => Object.assign(store, o), remove: async ks => [].concat(ks).forEach(k => delete store[k]) } },
  tabs: { query: async () => tabs, create: async o => { const t = { id: 100 + tabs.length, url: o.url, status: 'complete' }; tabs.push(t); return t; }, update: async () => {},
          get: async id => { const t = tabs.find(x => x.id === id); if (!t) throw new Error('No tab with id: ' + id); return t; }, onRemoved: { addListener(cb) { removedCb = cb; } } },
  windows: { update: async () => {} },
  scripting: { executeScript: async (o) => {
      if (o.files) return [];
      const fn = o.args?.[0]; const tabId = o.target.tabId;
      if (!fn || fn.startsWith('🛒')) return [];
      if (mode[fn] === 'closeTab') { mode[fn] = 'ok'; tabs = tabs.filter(t => t.id !== tabId); removedCb(tabId); throw new Error('Frame with ID 0 was removed.'); }
      await new Promise(r => setTimeout(r, 30));
      return [{ result: { ok: true, success: 30, fail: 0 } }]; } },
  notifications: { create: async (id, o) => notes.push(o.title + ' / ' + o.message), clear() {} },
};
const ctx = { chrome, AMZ_FS: {}, console, setTimeout, Date, Promise, Math, JSON, Map, Set, Object, Array, String };
vm.createContext(ctx); vm.runInContext(src, ctx);
ctx.appendBgLog = async (c, t) => logs.push(`(${c}) ${t}`); vm.runInContext('appendBgLog = globalThis.appendBgLog', ctx);
const send = (msg) => new Promise(res => { const keep = listener(msg, {}, res); if (!keep) {} });
(async () => {
  console.log('--- ケース1: ② の「全ての広告」中にタブ(ウィンドウ)が閉じられる');
  mode = { rppAllDownloader: 'closeTab' };
  const r1 = await send({ type: 'run-bulk-rpp3', payload: {} });
  const runs = logs.filter(l => /実行開始|実行しません|RPP3種 完了/.test(l)); runs.forEach(l => console.log('  ', l));
  logs.length = 0; notes.length = 0;
  console.log('--- ケース2: ② を実行中にもう一度 ② を押す');
  const p1 = send({ type: 'run-bulk-rpp3', payload: {} });
  const r2 = await send({ type: 'run-bulk-rpp3', payload: {} });
  console.log('   2回目の応答:', JSON.stringify(r2));
  await p1;
  console.log('--- ケース3: ② 終了後にもう一度 ② → 開始できる');
  const r3 = await send({ type: 'run-bulk-rpp3', payload: {} });
  console.log('   応答:', JSON.stringify(r3).slice(0, 60));
  console.log('--- ケース4: ② 実行中に ③ → 開始できる(別の種類) / ♻ → 断られる');
  const p4 = send({ type: 'run-bulk-rpp3', payload: {} });
  const r4 = await send({ type: 'run-retry-failed', tasks: [] });
  console.log('   ♻ の応答:', JSON.stringify(r4));
  await p4;
  process.exit(0);
})();

import os, re, sys, shutil, hashlib
src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
groups = {}
for fn in os.listdir(src):
    m = re.match(r'^(.*)_get(\d{8}-\d{4})(\.\w+)$', fn)
    key = m.group(1) + m.group(3)
    groups.setdefault(key, []).append((m.group(2), fn))
same = diff = 0
for key, v in groups.items():
    v.sort()
    keep = v[-1][1]
    shutil.copy2(os.path.join(src, keep), os.path.join(dst, keep))
    if len(v) > 1:
        a = open(os.path.join(src, v[0][1]), 'rb').read(); b = open(os.path.join(src, keep), 'rb').read()
        if a == b: same += 1
        else: diff += 1
print('残したファイル', len(os.listdir(dst)), '/ 重複していた日', same + diff, '(中身が同じ', same, '・違う', diff, ')')

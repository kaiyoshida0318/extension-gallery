import os, re, sys, zipfile, io, hashlib, datetime as dt
root = sys.argv[1]
days = [(dt.date(2026,10,12)+dt.timedelta(d)).strftime('%Y%m%d') for d in range(30)]
kinds = {
 'is':   (r'^(\d{8})_Item_SalesList', 'RPP'),
 'all':  (r'^rpp_reports_yukaiya_(\d{8})', 'RPP'),
 'item': (r'^rpp_item_reports_yukaiya_(\d{8})', 'RPP'),
 'kw':   (r'^rpp_keyword_reports_yukaiya_(\d{8})', 'RPP'),
 'cpi':  (r'^CouponAdvance_yukaiya_item_(\d{8})', 'CPA'),
 'cpk':  (r'^CouponAdvance_yukaiya_kw_(\d{8})', 'CPA'),
 'snap': (r'^rpp_item_keyword_yukaiya_(\d{8})', None),
}
def kind_of(fn):
    for k,(rx,_) in kinds.items():
        m = re.match(rx, fn)
        if m: return k, m.group(1)
    return None, None
def sha(p): return hashlib.sha1(open(p,'rb').read()).hexdigest()
issues = []
monthly = {}  # (k,day) -> path
for d in sorted(os.listdir(root)):
    p = os.path.join(root, d)
    if d == 'ADcheck取り込み用' or not os.path.isdir(p): continue
    ym, kd = d[:7], d[8:]
    for fn in os.listdir(p):
        k, day = kind_of(fn)
        if not k: issues.append(f'月別に不明なファイル: {d}/{fn}'); continue
        if '_get' in fn: issues.append(f'月別に_get付き: {d}/{fn}')
        if k == 'snap': issues.append(f'月別にスナップショット: {d}/{fn}')
        if kinds[k][1] != kd: issues.append(f'種別フォルダ違い: {d}/{fn}')
        if f'{day[:4]}-{day[4:6]}' != ym: issues.append(f'月フォルダ違い: {d}/{fn}')
        if (k,day) in monthly: issues.append(f'月別に重複: {fn}')
        monthly[(k,day)] = os.path.join(p, fn)
imp = {}
ap = os.path.join(root, 'ADcheck取り込み用')
for fn in os.listdir(ap):
    k, day = kind_of(fn)
    m = re.search(r'_get(\d{8}-\d{4})\.', fn)
    if not k or not m: issues.append(f'取り込み用に不明/_get無し: {fn}'); continue
    imp.setdefault((k,day), []).append((m.group(1), os.path.join(ap, fn)))
print('== 種類別の件数 (月別 / 取り込み用) ==')
for k in kinds:
    if k == 'snap': continue
    md = [d for d in days if (k,d) in monthly]; idd = [d for d in days if (k,d) in imp]
    miss_m = [d for d in days if (k,d) not in monthly]; miss_i = [d for d in days if (k,d) not in imp]
    print(f'{k:5} 月別 {len(md):2}/30  取り込み用 {len(idd):2}/30  欠け(月別): {",".join(x[4:] for x in miss_m) or "-"}  欠け(取込): {",".join(x[4:] for x in miss_i) or "-"}')
snaps = [x for x in imp if x[0]=='snap']; print('snap 取り込み用:', [ (s[1], [g for g,_ in imp[s]]) for s in snaps])
dups = {k:v for k,v in imp.items() if len(v)>1}
print('取り込み用で同じ日が複数:', len(dups)); [print('  ',k, [g for g,_ in v]) for k,v in sorted(dups.items())]
# content checks
print('== 中身チェック ==')
allfiles = list(monthly.values()) + [p for v in imp.values() for _,p in v]
for p in allfiles:
    b = open(p,'rb').read(); fn = os.path.basename(p)
    if len(b) == 0: issues.append(f'0バイト: {os.path.relpath(p, root)}'); continue
    if fn.endswith('.zip'):
        try:
            z = zipfile.ZipFile(io.BytesIO(b)); bad = z.testzip()
            if bad: issues.append(f'zip破損: {fn} ({bad})')
            names = z.namelist()
            if not names: issues.append(f'zip空: {fn}')
            for n in names:
                c = z.read(n)
                if fn.startswith('CouponAdvance'):
                    try: c.decode('utf-8-sig')
                    except UnicodeDecodeError: issues.append(f'zip内がUTF-8で読めない: {fn}/{n}')
                else:
                    if c.startswith(b'\xef\xbb\xbf'): issues.append(f'zip内CSVにBOM: {fn}/{n}')
                    try: c.decode('cp932')
                    except UnicodeDecodeError: issues.append(f'zip内がShift_JISで読めない: {fn}/{n}')
        except zipfile.BadZipFile: issues.append(f'zipとして開けない: {fn}')
    else:
        k,_ = kind_of(fn)
        if k == 'is':
            if not b.startswith(b'\xef\xbb\xbf'): issues.append(f'Item_SalesListにBOM無し: {fn}')
            try: b.decode('utf-8-sig')
            except UnicodeDecodeError: issues.append(f'Item_SalesListがUTF-8で読めない: {fn}')
        else:
            if b.startswith(b'\xef\xbb\xbf'): issues.append(f'CSVにBOM: {fn}')
            try: b.decode('cp932')
            except UnicodeDecodeError: issues.append(f'CSVがShift_JISで読めない: {fn}')
# monthly == latest import copy
neq = []
for key, mp in monthly.items():
    if key not in imp: issues.append(f'月別にあるが取り込み用に無い: {os.path.basename(mp)}'); continue
    latest = sorted(imp[key])[-1][1]
    if sha(mp) != sha(latest): neq.append((key, os.path.basename(latest), os.path.getsize(mp), os.path.getsize(latest)))
for key in imp:
    if key not in monthly and key[0] != 'snap': issues.append(f'取り込み用にあるが月別に無い: {key}')
print('月別と取り込み用(最新)の中身が違う:', len(neq)); [print('  ', x) for x in neq]
print('== 問題点 =='); [print(' -', i) for i in issues] or print(' なし')

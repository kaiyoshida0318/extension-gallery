import zipfile, sys, os
src, dst = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(src)
for i in z.infolist():
    n = i.filename
    if not (i.flag_bits & 0x800):
        try: n = n.encode('cp437').decode('cp932')
        except Exception: pass
    if '..' in n or n.startswith('/'): continue
    p = os.path.join(dst, n)
    if n.endswith('/'): os.makedirs(p, exist_ok=True); continue
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'wb') as f: f.write(z.read(i))

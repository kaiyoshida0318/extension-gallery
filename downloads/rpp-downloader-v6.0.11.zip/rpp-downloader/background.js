// ====== Service Worker (background) ======
// popupが閉じても動き続けて、ジョブを順次実行する
//
// v6.0.0: 保存方式を File System Access API (fsstore.js / AMZ_FS) に切り替え。
//   旧: chrome.downloads.download + onDeterminingFilename + Offscreen
//   新: AMZ_FS.writeFile() で保存先フォルダに直接書き込み
//       (1) 月別フォルダ(保管用、上書き)   YYYY-MM-{CPA|RPP}/{_get除去済み名}
//       (2) ADcheck取り込み用(全保存)      ADcheck取り込み用/{_get付きの名}

importScripts('fsstore.js');   // self.AMZ_FS を提供

const LOG_KEY = 'rms_dl_logs';
const HISTORY_KEY = 'rms_dl_history';

// 簡易DL履歴を chrome.storage.local に保存 (複数件まとめて可)
// v6.0.9: 件数の上限を injected.js の recordDailyHistory と同じ 200 に揃えた (以前は 50 で、呼ばれると切り詰めていた)
async function recordHistory(entries) {
  try {
    const arr = Array.isArray(entries) ? entries : [entries];
    const s = await chrome.storage.local.get([HISTORY_KEY]);
    const list = s[HISTORY_KEY] || [];
    const t = new Date().toISOString();
    for (const e of arr) list.unshift({ t, ...e });
    if (list.length > 200) list.length = 200;
    await chrome.storage.local.set({ [HISTORY_KEY]: list });
  } catch (_) {}
}

// ====== v6.0.9: 楽天RMSのログイン切れ ======
// ログインが切れると、楽天のページは /rpp/system_error などのエラー画面に、
// API は HTTP 401 になる。以前はエラー画面のタブをそのまま使い、401 を3回ずつやり直していた。
const RMS_LOGIN_URL = 'https://glogin.rms.rakuten.co.jp/';

function isRmsLoginOrErrorUrl(url) {
  return /system_error|login_error|glogin\.rms\.rakuten\.co\.jp/i.test(String(url || ''));
}

// 'YYYY-MM-DD' の範囲を日付の配列にする
function daysBetween(startDate, endDate) {
  const out = [];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate || '') || !/^\d{4}-\d{2}-\d{2}$/.test(endDate || '')) return out;
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) out.push(fmt(d));
  return out;
}

// 連続ジョブの途中でログインが切れたとき、まだ始めていない種類の日も「失敗」として履歴に残す。
// → ログインし直したあと「♻ 失敗分を再取得」1回で残りが全部取れる
async function recordSkippedDays(historyType, days, reason) {
  if (!days?.length) return;
  await recordHistory(days.map(day => ({ type: historyType, day, ok: false, error: reason })));
  await appendBgLog('bg', `  📝 ${historyType} の ${days.length}日分を「未取得」として履歴に記録 (♻ で再取得できます)`);
}

// ログイン切れの通知 + RMS のログイン画面を前面に出す。連続ジョブで何度も出ないよう 30秒に1回まで
let lastLoginNoticeAt = 0;
async function notifyLoginRequired(label, hint) {
  await markActiveJobAborted('楽天RMSのログイン切れ');
  if (Date.now() - lastLoginNoticeAt < 30 * 1000) return;
  lastLoginNoticeAt = Date.now();
  await notify(
    `🔑 楽天RMSのログインが切れています (${label})`,
    `RMSにログインし直してから、${hint}`,
    'error'
  );
  try {
    const tabs = await chrome.tabs.query({});
    const loginTab = tabs.find(t => /glogin\.rms\.rakuten\.co\.jp/i.test(t.url || ''));
    if (loginTab) {
      await chrome.tabs.update(loginTab.id, { active: true });
      if (loginTab.windowId != null) await chrome.windows.update(loginTab.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: RMS_LOGIN_URL, active: true });
    }
    await appendBgLog('bg', `🔑 RMSのログイン画面を開きました: ${RMS_LOGIN_URL}`);
  } catch (e) {
    await appendBgLog('bg', `⚠ RMSのログイン画面を開けませんでした: ${e.message}`);
  }
}

async function appendBgLog(category, text, extra = null) {
  // 直列化(レース防止)
  appendBgLog._chain = (appendBgLog._chain || Promise.resolve()).then(async () => {
    try {
      const stored = await chrome.storage.local.get([LOG_KEY]);
      const logs = stored[LOG_KEY] || [];
      logs.push({
        t: new Date().toISOString(),
        cat: category,
        msg: String(text),
        extra: extra
      });
      if (logs.length > 2000) logs.splice(0, logs.length - 2000);
      await chrome.storage.local.set({ [LOG_KEY]: logs });
    } catch (_) {}
  });
  return appendBgLog._chain;
}

// 完了マーカー(popup UI用)を chrome.storage.local に書き込む。
// popup が閉じていても background が最後まで動けば反映される。
// v6.0.11: ④ (snap) は「今日取ったか」なので別キー rms_done_flags_snap に実行日 (YYYY-MM-DD) を入れる。
//   ①②③ は今まで通り rms_done_flags に true。popup.js の markDone と同じ書き方
async function setDoneFlag(kind) {
  try {
    const snap = (kind === 'snap');
    const key = snap ? 'rms_done_flags_snap' : 'rms_done_flags';
    const s = await chrome.storage.local.get([key]);
    const flags = s[key] || {};
    if (snap) {
      const d = new Date();
      flags[kind] = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    } else {
      flags[kind] = true;
    }
    await chrome.storage.local.set({ [key]: flags });
  } catch (_) {}
}

// 該当URLのタブを探す。無ければensureUrlで新規作成
// v6.0.9: 楽天のエラー画面 (/rpp/system_error 等) になっているタブは使わない。
//   以前は URL に 'ad.rms.rakuten.co.jp/rpp' を含めばエラー画面のタブでも使っていたため、
//   ログインし直しても古いエラー画面のタブで 401 になり続けた。
//   エラー画面のタブがあれば、新しいタブを増やさずにそのタブを正しいページへ開き直す。
async function getOrCreateTab(urlMatch, ensureUrl) {
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(t => t.url && t.url.includes(urlMatch) && !isRmsLoginOrErrorUrl(t.url));
  if (tab) return tab;
  const area = urlMatch.split('/').slice(0, 2).join('/');   // 例: 'ad.rms.rakuten.co.jp/cpnadv'
  const errTab = tabs.find(t => t.url && t.url.includes(area) && isRmsLoginOrErrorUrl(t.url));
  if (errTab) {
    await appendBgLog('bg', `楽天のエラー画面になっているタブ(tabId=${errTab.id})を開き直します: ${errTab.url} → ${ensureUrl}`);
    tab = await chrome.tabs.update(errTab.id, { url: ensureUrl });
  } else {
    await appendBgLog('bg', `タブが見つからないので新規オープン: ${ensureUrl}`);
    tab = await chrome.tabs.create({ url: ensureUrl, active: false });
  }
  const start = Date.now();
  // 開き直したタブは、直後だとまだ前のページ(エラー画面)のまま 'complete' に見えることがあるので、
  // 読み込みが始まったのを見てから(または3秒たってから)完了とみなす
  let sawLoading = !errTab;
  while ((Date.now() - start) < 15000) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'loading') sawLoading = true;
      if (t2.status === 'complete' && (sawLoading || Date.now() - start > 3000)) return t2;
    } catch (_) {
      const refreshed = (await chrome.tabs.query({})).find(t => t.url && t.url.includes(urlMatch));
      if (refreshed) return refreshed;
    }
  }
  return tab;
}

// ====== 取得中のタブが閉じられたときの検知 (v6.0.4) ======
// 取得処理は楽天のタブの中で動いている。そのタブが閉じられると処理ごと消えるが、
// 以前は何も記録されず、popup は「実行中 2/30」のまま止まって見えていた。
// → 実行中のタブを覚えておき、閉じられたら即座にジョブを中断扱いにして通知する。
const JOB_LABELS = {
  itemSalesDownloader: '① 商品別売上',
  rppAllDownloader: '② 全ての広告',
  rppAsyncDownloader: '② 全商品 / 全KWレポート',
  cpnadvAsyncDownloader: '③ クーポン広告',
  rppKeywordSnapshotDownloader: '④ 登録済みKW全件DL',
};
const runningTabs = new Map();   // tabId → 表示名
const closedTabs = new Set();    // 取得中に閉じられたタブ (v6.0.6: 連続ジョブの残りも止めるため)

chrome.tabs.onRemoved.addListener((tabId) => {
  if (!runningTabs.has(tabId)) return;
  const label = runningTabs.get(tabId);
  runningTabs.delete(tabId);
  closedTabs.add(tabId);
  onJobTabClosed(tabId, label);
});

async function onJobTabClosed(tabId, label) {
  await appendBgLog('bg', `❌ 取得中の楽天のタブ(tabId=${tabId})が閉じられたため「${label}」を中断しました`);
  await markActiveJobAborted('取得中のタブが閉じられた');
  await notify(
    `❌ ${label} が中断されました`,
    '取得中の楽天のタブが閉じられました。もう一度ボタンを押して取り直してください(保存済みの日は上書きされるだけです)',
    'error'
  );
}

// popup に「実行中」のまま残らないよう、進行中ジョブを中断状態にする
async function markActiveJobAborted(reason) {
  try {
    const s = await chrome.storage.local.get(['rms_active_job']);
    const job = s.rms_active_job;
    if (job && job.status === 'running') {
      job.status = 'aborted';
      job.abortReason = reason;
      job.endedAt = new Date().toISOString();
      await chrome.storage.local.set({ rms_active_job: job });
    }
  } catch (_) {}
}

// v6.0.5: 拡張の更新・再読み込みのとき、実行中だったジョブは必ず止まっている
// (楽天のタブの中の処理は拡張の再読み込みで切り離される)。popup に「実行中」が残らないよう片付ける
chrome.runtime.onInstalled.addListener(async () => {
  const s = await chrome.storage.local.get(['rms_active_job']);
  if (s.rms_active_job?.status === 'running') {
    await markActiveJobAborted('拡張の更新・再読み込みで中断');
    await appendBgLog('bg', '🧹 拡張の更新・再読み込みのため、実行中だったジョブを中断扱いにしました');
  }
  await chrome.storage.local.remove(['rms_cancel_flag']);
});

// タブに injected.js を読み込み、指定の関数を呼び出す
// v6.0.4: 実行中のタブを runningTabs に登録。タブが閉じられる等で失敗したら例外にせず {ok:false} を返す
async function runOnTab(tabId, funcName, params) {
  // v6.0.9: タブが楽天のエラー画面・ログイン画面なら、取得を始めずに「ログイン切れ」で返す
  try {
    const t = await chrome.tabs.get(tabId);
    if (isRmsLoginOrErrorUrl(t.url)) {
      await appendBgLog('bg', `🔑 楽天のタブ(tabId=${tabId})がエラー画面です: ${t.url} → ログインが切れているので「${JOB_LABELS[funcName] || funcName}」を始めません`);
      return { ok: false, loginRequired: true, success: 0, fail: 0, error: `楽天RMSのログインが切れています (タブが ${t.url} になっている)` };
    }
  } catch (_) { /* タブが無い場合は下の runOnTabInner が失敗として返す */ }
  runningTabs.set(tabId, JOB_LABELS[funcName] || funcName);
  try {
    return await runOnTabInner(tabId, funcName, params);
  } catch (e) {
    await appendBgLog('bg', `❌ タブ(tabId=${tabId})で ${funcName} を実行できませんでした: ${e.message}`);
    await markActiveJobAborted(e.message);
    let tabGone = closedTabs.has(tabId);
    if (!tabGone) { try { await chrome.tabs.get(tabId); } catch (_) { tabGone = true; } }
    return { ok: false, tabClosed: tabGone, error: `タブで実行できませんでした(タブが閉じられた可能性): ${e.message}` };
  } finally {
    runningTabs.delete(tabId);
  }
}

async function runOnTabInner(tabId, funcName, params) {
  // ① injected.js を注入(関数定義がpage contextに入る)
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['injected.js']
  });
  // ② 注入された関数を名前で呼び出す
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (funcName, params) => {
      const fn = (typeof globalThis[funcName] === 'function')
        ? globalThis[funcName]
        : (typeof self[funcName] === 'function' ? self[funcName] : null);
      if (!fn) return { ok: false, error: `関数が未注入: ${funcName}` };
      try {
        return await fn(params);
      } catch (e) {
        return { ok: false, error: e.message, stack: e.stack };
      }
    },
    args: [funcName, params]
  });
  return results?.[0]?.result;
}

// オーバーレイ準備
async function installOverlayOnTab(tabId, title) {
  // v6.0.4: 取得は このタブの中で動くので、閉じないよう表示に明記する
  title = `${title} (このタブは閉じないでください)`;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['injected.js']
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (title) => {
        if (typeof installProgressOverlay === 'function') installProgressOverlay(title);
      },
      args: [title]
    });
  } catch (e) {
    // 表示が出せないだけなら続行。タブが無い場合は直後の runOnTab が {ok:false} を返す
    await appendBgLog('bg', `⚠ 進捗表示を出せませんでした(tabId=${tabId}): ${e.message}`);
  }
}

// ====== 保存先の書き込み許可を保つための「保存先タブ」 (v6.0.1) ======
// Chrome は「拡張のページ(タブ)が全部閉じてから約5秒後」に File System Access の
// 書き込み許可を取り消す (granted → prompt)。Service Worker は「開いているページ」に
// 数えられないので、取得中は folder.html をピン留めタブで開いておく必要がある。
// (v6.0.0 では folder.html に「このタブは閉じてOK」と出していたため、
//  取得の途中でタブを閉じると5秒後から全部「要許可」で保存スキップになっていた)
const FOLDER_PAGE_URL = chrome.runtime.getURL('folder.html');

async function findFolderTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => (t.url || t.pendingUrl || '').startsWith(FOLDER_PAGE_URL)) || null;
}

// 保存先タブが無ければピン留めで開く。focus=true なら前面に出す
async function ensureFolderTab({ focus = false } = {}) {
  try {
    let tab = await findFolderTab();
    if (!tab) {
      tab = await chrome.tabs.create({ url: FOLDER_PAGE_URL, active: focus, pinned: true });
      await appendBgLog('fs', `📌 保存先タブをピン留めで開きました (tabId=${tab.id})`);
    } else if (focus) {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId != null) {
        try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
      }
    }
    return tab;
  } catch (e) {
    await appendBgLog('fs', `⚠ 保存先タブを開けません: ${e.message}`);
    return null;
  }
}

// 取得の途中で許可が切れたとき、ユーザーが「🔑 許可」を押すのを待つ。
// 待っている間はジョブが一時停止する (injected 側は save-file の応答を待っている)。
// Service Worker の1イベントの上限(約5分)に掛からないよう、待つのは最大4分。
const GRANT_WAIT_MS = 4 * 60 * 1000;
let grantWaiter = null;          // 同時に複数の保存が待っても通知は1回にする
let grantGaveUpAt = 0;           // 待ちがタイムアウトした時刻。直後の保存は待たずに失敗させる

async function waitForGrant() {
  // 直前にタイムアウトしたばかりなら(ユーザー不在)、毎日分4分ずつ待たないように即失敗
  if (grantGaveUpAt && (Date.now() - grantGaveUpAt) < 30 * 60 * 1000) {
    return { state: 'timeout' };
  }
  if (!grantWaiter) {
    grantWaiter = (async () => {
      await appendBgLog('fs', `⏸ 保存先の書き込み許可が切れました → 一時停止。保存先タブで「🔑 許可」を押すと続きから再開します (最大${GRANT_WAIT_MS / 60000}分待機)`);
      await notify(
        '⏸ 保存先の許可が切れました(一時停止中)',
        '前面に出たタブの「🔑 このフォルダへの保存を許可」を押すと、続きから自動で再開します',
        'warning'
      );
      await ensureFolderTab({ focus: true });
      const start = Date.now();
      while ((Date.now() - start) < GRANT_WAIT_MS) {
        await new Promise(r => setTimeout(r, 2000));
        const c = await chrome.storage.local.get(['rms_cancel_flag']);
        if (c.rms_cancel_flag) return { state: 'cancelled' };
        let st;
        try { st = await AMZ_FS.status(); } catch (_) { continue; }
        if (st.state === 'granted') {
          grantGaveUpAt = 0;
          await appendBgLog('fs', `▶ 許可されたので再開します (${Math.round((Date.now() - start) / 1000)}秒待機)`);
          return st;
        }
        if (st.state === 'none') return st;
      }
      grantGaveUpAt = Date.now();
      await appendBgLog('fs', `❌ ${GRANT_WAIT_MS / 60000}分待っても許可されなかったので、以降の保存はスキップします`);
      await notify('❌ 保存先の許可待ちがタイムアウト', '保存できなかった日は「♻ 失敗分を再取得」で取り直せます', 'error');
      return { state: 'timeout' };
    })().finally(() => { grantWaiter = null; });
  }
  return grantWaiter;
}

// ====== 二重起動の防止 (v6.0.6) ======
// 実行中の取得 (msg.type → 開始時刻)。Service Worker が生きている間だけ有効
// (取得中は Service Worker は止まらない)。
const activeRuns = new Map();
const RUN_LABELS = {
  'run-itemsales': '① 商品別売上',
  'run-bulk-rpp3': '② RPP 3種',
  'run-bulk-cpn2': '③ クーポン広告 2種',
  'run-cpn': '③ クーポン広告',
  'run-rpp-kw-snapshot': '④ 登録済みKW全件DL',
  'run-retry-failed': '♻ 失敗分の再取得',
};
function busyReason(type) {
  // 同じ取得が動いている
  if (activeRuns.has(type)) return `${RUN_LABELS[type] || type} はすでに実行中です。終わるまで待つか「⏹ 中止」を押してください`;
  // ♻ 再取得は何かが動いている間は始めない (同じ日を取り合うため)。逆も同じ
  if (type === 'run-retry-failed' && activeRuns.size > 0) {
    return `ほかの取得 (${[...activeRuns.keys()].map(k => RUN_LABELS[k] || k).join('・')}) が実行中です。終わってから再取得してください`;
  }
  if (activeRuns.has('run-retry-failed')) return '♻ 失敗分の再取得が実行中です。終わってから始めてください';
  // ③ の単発と連続も同じクーポン広告なので同時に動かさない
  if ((type === 'run-cpn' && activeRuns.has('run-bulk-cpn2')) || (type === 'run-bulk-cpn2' && activeRuns.has('run-cpn'))) {
    return '③ クーポン広告はすでに実行中です';
  }
  return null;
}

// ====== メッセージリスナー ======
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // v6.0.6: 同じ取得がすでに動いているときは、2本目を始めない (二重保存を防ぐ)
  if (typeof msg?.type === 'string' && msg.type.startsWith('run-')) {
    const busy = busyReason(msg.type);
    if (busy) {
      appendBgLog('bg', `⛔ ${RUN_LABELS[msg.type] || msg.type} は開始しませんでした: ${busy}`);
      notify('⛔ 取得を開始しませんでした', busy, 'warning');
      try { sendResponse({ ok: false, busy: true, error: busy }); } catch (_) {}
      return false;
    }
    activeRuns.set(msg.type, Date.now());
    const origSend = sendResponse;
    sendResponse = (res) => { activeRuns.delete(msg.type); try { origSend(res); } catch (_) {} };
    // 取得ジョブ開始時: 保存先タブ(ピン留め)を確保して、途中で許可が切れないようにする
    grantGaveUpAt = 0;
    ensureFolderTab();
  }
  if (msg?.type === 'fs-status') {
    // popup 側が保存先の状態を知るために問い合わせてくる
    AMZ_FS.status().then(st => {
      try { sendResponse({ ok: true, state: st.state, name: st.name || null }); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-bulk-rpp3') {
    // 即座にtrueを返してSWを生かしておく
    handleBulkRpp3(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;  // 非同期レスポンス
  }
  if (msg?.type === 'run-itemsales') {
    handleItemSales(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-cpn') {
    handleCpn(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-bulk-cpn2') {
    handleBulkCpn2(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-retry-failed') {
    handleRetryFailed(msg.tasks || []).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-rpp-kw-snapshot') {
    handleRppKwSnapshot(msg.payload || {}).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'save-file') {
    handleSaveFile(msg.payload || {}).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  return false;
});

// ====== 完了通知(Chromeデスクトップ通知) ======
// title: 短いヘッダー(例: '✅ ① 商品別売上 完了')
// message: 詳細(例: '成功 30 / 失敗 0 (23秒)')
// kind: 'success' | 'error' | 'warning'  アイコン・色分け用
async function notify(title, message, kind = 'success') {
  try {
    // 通知が無効化されていたら呼ばない
    const s = await chrome.storage.local.get(['rms_notify_enabled']);
    if (s.rms_notify_enabled === false) return;
    const id = `rms-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    await chrome.notifications.create(id, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title,
      message: message || '',
      priority: kind === 'error' ? 2 : 1,
      silent: false
    });
    // 一定時間後に自動クリア(通常は手動クリアされるがPCがスリープ時対策)
    setTimeout(() => {
      try { chrome.notifications.clear(id); } catch (_) {}
    }, 60000);
  } catch (e) {
    await appendBgLog('notify', `⚠ 通知失敗: ${e.message}`);
  }
}

// 「成功N / 失敗M / データなしX」の形式で結果サマリーを生成
// r.success  = 保存できた日数、r.fail = 取得失敗した日数、r.noData = データなしの日数
function summarizeResult(r) {
  if (!r) return '結果不明';
  if (r.ok && (r.success != null || r.fail != null || r.noData != null)) {
    const parts = [];
    if (r.success != null) parts.push(`保存成功 ${r.success}`);
    if (r.fail    != null && r.fail > 0)    parts.push(`失敗 ${r.fail}`);
    if (r.noData  != null && r.noData > 0)  parts.push(`データなし ${r.noData}`);
    return parts.join(' / ');
  }
  if (r.ok) return '完了';
  return `失敗: ${r.error || '不明'}`;
}

// ====== ファイル保存ハンドラ (File System Access API 版) ======
// payload: {
//   filename:   'rpp_reports_yukaiya_20261011.csv',   // データの日付入り、元のファイル名(_get は含まない)
//   day:        '2026-10-11',                          // データの日付(YYYY-MM-DD)
//   kind:       'CPA' | 'RPP',                         // 月別フォルダ種別
//   mimeType:   'application/zip' | 'text/csv' 等       // 参考情報(FS API は使わない)
//   dataArr:    Array.from(new Uint8Array(...))        // ファイルの中身(構造化クローン対応)
//   isSnapshot: true なら月別フォルダには書かない(取り込み用のみ。rpp_item_keyword_*.csv)
// }
// 保存先:
//   (1) 月別フォルダ(保管用、上書き)   : {保存先}/YYYY-MM-{CPA|RPP}/{filename}
//   (2) ADcheck取り込み用(全保存)      : {保存先}/ADcheck取り込み用/{basename}_get{YYYYMMDD-HHMM}.{ext}
//
// バイト列は受け取ったままで書く。文字コード変換・BOM付加・zip展開は一切しない
// (楽天CSV は Shift_JIS、ADcheck 側がそのまま読む)。
// ========================================================
async function handleSaveFile(payload) {
  const { filename, day, kind, isSnapshot, dataArr } = payload || {};
  if (!filename || !dataArr) {
    return { ok: false, error: 'filename/dataArr が未指定' };
  }

  // 書き込み先が granted か事前確認。popup 側のボタン押下時にチェックしているが、
  // 長時間ジョブの途中で Chrome 再起動等が起きた場合に備えてここでも確認する。
  let fsStatus;
  try { fsStatus = await AMZ_FS.status(); }
  catch (e) { return { ok: false, error: `fs status 取得失敗: ${e.message}` }; }
  // 途中で許可が切れた (prompt/denied) → 一時停止してユーザーの「🔑 許可」を待つ (v6.0.1)
  if (fsStatus.state === 'prompt' || fsStatus.state === 'denied') {
    const st2 = await waitForGrant();
    if (st2.state === 'granted') fsStatus = st2;
    else fsStatus = { state: st2.state };
  }
  if (fsStatus.state !== 'granted') {
    await appendBgLog('save', `❌ 保存先フォルダが ${fsStatus.state} → 保存スキップ: ${filename}`);
    const why = fsStatus.state === 'timeout'   ? '保存先フォルダの許可待ちがタイムアウトしました'
              : fsStatus.state === 'cancelled' ? '中止されました'
              : `保存先フォルダが未設定/要許可(state=${fsStatus.state})`;
    return { ok: false, error: `${why}。保存先タブで許可してから「♻ 失敗分を再取得」してください` };
  }

  // Uint8Array に戻す(構造化クローンで Array.from された)
  const bytes = new Uint8Array(dataArr);

  const results = { saved: [], failed: [] };

  // ─ (1) 月別フォルダ保存(スナップショットは対象外) ─
  // snapshot は day=null で送られてくるので isSnapshot か day/kind が無ければスキップ。
  if (!isSnapshot && day && kind) {
    const ym = day.slice(0, 7);                    // '2026-10-11' → '2026-10'
    const subdir = `${ym}-${kind}`;                // '2026-10-RPP' 等
    // 月別フォルダ用: _getYYYYMMDD-HHMM を除去した名前にする
    const monthName = stripGetSuffix(filename);
    try {
      const path = await AMZ_FS.writeFile(subdir, monthName, bytes);
      results.saved.push({ to: '月別', path });
      await appendBgLog('save', `✅ 月別保存: ${path}`);
    } catch (e) {
      results.failed.push({ to: '月別', subdir, filename: monthName, error: e.message });
      await appendBgLog('save', `❌ 月別保存失敗: ${subdir}/${monthName}: ${e.message}`);
    }
  }

  // ─ (2) ADcheck取り込み用保存(全ファイル。スナップショット含む) ─
  // 取得日時付きの名前にする(既に filename に _get... が入っていればそれを使う、無ければ付ける)
  const importName = /_get\d{8}-\d{4}/.test(filename)
    ? filename
    : insertGetSuffix(filename, formatGetTimestamp(new Date()));
  try {
    const path = await AMZ_FS.writeFile('ADcheck取り込み用', importName, bytes);
    results.saved.push({ to: '取り込み用', path });
    await appendBgLog('save', `✅ 取り込み用保存: ${path}`);
  } catch (e) {
    results.failed.push({ to: '取り込み用', subdir: 'ADcheck取り込み用', filename: importName, error: e.message });
    await appendBgLog('save', `❌ 取り込み用保存失敗: ADcheck取り込み用/${importName}: ${e.message}`);
  }

  // v6.0.2: どちらか一方でも失敗したら、その日は失敗扱いにする。
  // (以前は月別だけ成功すると ✅ になり、取り込み用に 0バイトのファイルが残っても気づけなかった)
  // 失敗扱いにすれば「♻ 失敗分を再取得」で両方とも書き直される(月別は上書き)。
  if (results.failed.length > 0) {
    const where = results.failed.map(f => f.to).join('・');
    return { ok: false, error: `保存に失敗(${where}): ${results.failed[0].error}`, detail: results };
  }
  return { ok: true, saved: results.saved.length, failed: results.failed.length, detail: results };
}

// ファイル名から _getYYYYMMDD-HHMM を除去する
// 'rpp_item_reports_yukaiya_20261012_get20261111-1209.zip' → 'rpp_item_reports_yukaiya_20261012.zip'
// '20261012_Item_SalesList_get20261111-1205.csv' → '20261012_Item_SalesList.csv'
// 既に _get が付いていない名前はそのまま返す
function stripGetSuffix(filename) {
  return filename.replace(/_get\d{8}-\d{4}/, '');
}

// YYYYMMDD-HHMM (24時間表記、JST=ローカル時刻)
function formatGetTimestamp(d) {
  const Y = d.getFullYear();
  const M = String(d.getMonth() + 1).padStart(2, '0');
  const D = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${Y}${M}${D}-${h}${m}`;
}

// ファイル名の拡張子前に _getTS を挿入
// 'foo.zip' + '20261110-1849' → 'foo_get20261110-1849.zip'
function insertGetSuffix(filename, ts) {
  const dotIdx = filename.lastIndexOf('.');
  if (dotIdx < 0) return `${filename}_get${ts}`;
  return `${filename.slice(0, dotIdx)}_get${ts}${filename.slice(dotIdx)}`;
}

// ====== ハンドラ: 商品別売上 ======
async function handleItemSales(payload) {
  await appendBgLog('bg', `▶ 商品別売上 開始`);
  const tab = await getOrCreateTab('datatool.rms.rakuten.co.jp/realtime/item', 'https://datatool.rms.rakuten.co.jp/realtime/item');
  if (!tab) {
    await appendBgLog('bg', `❌ 商品別売上タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  タブID=${tab.id}`);
  await installOverlayOnTab(tab.id, '🛒 商品別売上 ダウンロード中');
  const r = await runOnTab(tab.id, 'itemSalesDownloader', payload);
  await appendBgLog('bg', `${r?.ok ? '✅' : '❌'} 商品別売上 完了: ${JSON.stringify(r)}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (r?.loginRequired) {
    // v6.0.9: 始める前に止まった(エラー画面)なら履歴に日が無いので、ボタンの押し直しを案内する
    const next = (r.success || r.fail) ? '「♻ 失敗分を再取得」を押してください' : '① をもう一度押してください';
    await notifyLoginRequired('① 商品別売上', next);
    return { ...r, next };
  }
  await setDoneFlag('is');
  await notify(
    r?.ok ? '✅ ① 商品別売上 完了' : '❌ ① 商品別売上 失敗',
    summarizeResult(r),
    r?.ok ? 'success' : 'error'
  );
  return r;
}

// v6.0.9: 連続ジョブ (②③) が i 番目でログイン切れになったときの履歴の後始末。
// i 番目の途中で止まった場合、その種類の残りの日は injected.js が「失敗」として履歴に残している。
// ここでは、まだ始めていない種類の日も「失敗」として残し、♻ 1回で残りが全部取れるようにする。
// 1つ目の種類が始まる前に止まった(タブがエラー画面だった)ときは何も残っていないので、ボタンの押し直しを案内する。
async function recordLoginSkips(jobs, i, r) {
  const startedCurrent = Boolean(r?.success || r?.fail);
  if (i === 0 && !startedCurrent) {
    return { retryHint: '{button} をもう一度押してください' };
  }
  const reason = 'ログイン切れで中断(未取得)';
  for (let k = startedCurrent ? i + 1 : i; k < jobs.length; k++) {
    const p = jobs[k].params || {};
    const days = (Array.isArray(p.daysOverride) && p.daysOverride.length) ? p.daysOverride : daysBetween(p.startDate, p.endDate);
    await recordSkippedDays(jobs[k].historyType, days, reason);
  }
  return { retryHint: '「♻ 失敗分を再取得」を押してください(残りの日だけ取れます)' };
}

// ====== ハンドラ: RPP 3種連続 ======
async function handleBulkRpp3(payload) {
  await appendBgLog('bg', `▶ RPP3種 開始`);
  const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
  if (!tab) {
    await appendBgLog('bg', `❌ RPPタブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  RPPタブID=${tab.id}`);

  // 3ジョブの仕様
  const jobs = [
    { name: '全ての広告', historyType: '② 全ての広告', funcName: 'rppAllDownloader', params: payload.rppAll, overlayTitle: '🛒 全ての広告 ダウンロード中' },
    { name: '全商品レポート', historyType: '② 全商品レポート', funcName: 'rppAsyncDownloader', params: payload.rppItem, overlayTitle: '🛒 全商品レポート ダウンロード中' },
    { name: '全キーワードレポート', historyType: '② 全キーワードレポート', funcName: 'rppAsyncDownloader', params: payload.rppKw, overlayTitle: '🛒 全キーワードレポート ダウンロード中' }
  ];

  let ok = 0, ng = 0;
  let login = null;   // v6.0.9: ログイン切れで止まったら { retryHint }
  for (let i = 0; i < jobs.length; i++) {
    // 中止フラグチェック(連続ジョブの途中で止められるよう)
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りのRPP3種ジョブをスキップ`);
      ng += (jobs.length - i);
      break;
    }
    const job = jobs[i];
    await appendBgLog('bg', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      // タブが消滅していたら再取得
      let curTab;
      try { curTab = await chrome.tabs.get(tab.id); } catch (_) { curTab = null; }
      if (!curTab) {
        await appendBgLog('bg', `  タブ消滅 → 再取得`);
        const re = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
        if (!re) throw new Error('タブ再取得失敗');
        tab.id = re.id;
      }
      await installOverlayOnTab(tab.id, job.overlayTitle);
      const r = await runOnTab(tab.id, job.funcName, job.params);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        ok++;
        await appendBgLog('bg', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ng++;
        await appendBgLog('bg', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
        // v6.0.6: 取得中のタブが閉じられた(ウィンドウを閉じた等)ときは、残りの手順に進まない。
        // 以前は新しいタブを開いて続きを走らせていたため、ユーザーがやり直すと2本同時に動いていた。
        if (r?.tabClosed) {
          ng += (jobs.length - i - 1);
          await appendBgLog('bg', `  ⏹ 取得中のタブが閉じられたので、残り ${jobs.length - i - 1} 種類も実行しません`);
          break;
        }
        if (r?.loginRequired) {
          ng += (jobs.length - i - 1);
          await appendBgLog('bg', `  🔑 楽天RMSのログインが切れたので、残り ${jobs.length - i - 1} 種類も実行しません`);
          login = await recordLoginSkips(jobs, i, r);
          break;
        }
      }
    } catch (e) {
      ng++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 RPP3種 完了: 成功 ${ok} / 失敗 ${ng}`);
  // 中止フラグはここでクリア(次のジョブに引き継がない)
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (login) {
    const next = login.retryHint.replace('{button}', '②');
    await notifyLoginRequired('② RPP 3種', next);
    return { ok: false, loginRequired: true, success: ok, fail: ng, error: '楽天RMSのログインが切れています', next };
  }
  await setDoneFlag('rpp');
  await notify(
    ng === 0 ? '✅ ② RPP 3種 完了' : '⚠ ② RPP 3種 一部失敗',
    `サブジョブ 成功 ${ok} / 失敗 ${ng}`,
    ng === 0 ? 'success' : 'warning'
  );
  return { ok: true, success: ok, fail: ng };
}

// ====== ハンドラ: クーポン広告(cpnadv) ======
async function handleCpn(payload) {
  await appendBgLog('bg', `▶ クーポン広告 開始 (mode=${payload?.mode})`);
  const tab = await getOrCreateTab(
    'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
    'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
  );
  if (!tab) {
    await appendBgLog('bg', `❌ クーポン広告タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  タブID=${tab.id}`);
  const overlayTitle = payload?.mode === 'keyword'
    ? '🛒 クーポン広告 全KWレポート ダウンロード中'
    : '🛒 クーポン広告 商品別レポート ダウンロード中';
  await installOverlayOnTab(tab.id, overlayTitle);
  const r = await runOnTab(tab.id, 'cpnadvAsyncDownloader', payload);
  await appendBgLog('bg', `${r?.ok ? '✅' : '❌'} クーポン広告 完了: ${JSON.stringify(r)}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (r?.loginRequired) {
    const next = (r.success || r.fail) ? '「♻ 失敗分を再取得」を押してください' : 'もう一度実行してください';
    await notifyLoginRequired('③ クーポン広告', next);
    return { ...r, next };
  }
  return r;
}

// ====== ハンドラ: クーポン広告 2種連続 (商品別 → KW別) ======
async function handleBulkCpn2(payload) {
  await appendBgLog('bg', `▶ クーポン2種 開始`);
  const tab = await getOrCreateTab(
    'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
    'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
  );
  if (!tab) {
    await appendBgLog('bg', `❌ クーポン広告タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  クーポンタブID=${tab.id}`);

  const jobs = [
    {
      name: 'クーポン広告 商品別',
      historyType: '③ クーポン商品別',
      params: { ...payload, mode: 'item' },
      overlayTitle: '🛒 クーポン広告 商品別レポート ダウンロード中'
    },
    {
      name: 'クーポン広告 KW別(全件)',
      historyType: '③ クーポンKW別',
      params: { ...payload, mode: 'keyword' },
      overlayTitle: '🛒 クーポン広告 全KWレポート ダウンロード中'
    }
  ];

  let ok = 0, ng = 0;
  let login = null;   // v6.0.9
  for (let i = 0; i < jobs.length; i++) {
    // 中止フラグチェック
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りのクーポン広告ジョブをスキップ`);
      ng += (jobs.length - i);
      break;
    }
    const job = jobs[i];
    await appendBgLog('bg', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      let curTab;
      try { curTab = await chrome.tabs.get(tab.id); } catch (_) { curTab = null; }
      if (!curTab) {
        await appendBgLog('bg', `  タブ消滅 → 再取得`);
        const re = await getOrCreateTab(
          'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
          'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
        );
        if (!re) throw new Error('タブ再取得失敗');
        tab.id = re.id;
      }
      await installOverlayOnTab(tab.id, job.overlayTitle);
      const r = await runOnTab(tab.id, 'cpnadvAsyncDownloader', job.params);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        ok++;
        await appendBgLog('bg', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ng++;
        await appendBgLog('bg', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
        // v6.0.6: 取得中のタブが閉じられた(ウィンドウを閉じた等)ときは、残りの手順に進まない。
        // 以前は新しいタブを開いて続きを走らせていたため、ユーザーがやり直すと2本同時に動いていた。
        if (r?.tabClosed) {
          ng += (jobs.length - i - 1);
          await appendBgLog('bg', `  ⏹ 取得中のタブが閉じられたので、残り ${jobs.length - i - 1} 種類も実行しません`);
          break;
        }
        if (r?.loginRequired) {
          ng += (jobs.length - i - 1);
          await appendBgLog('bg', `  🔑 楽天RMSのログインが切れたので、残り ${jobs.length - i - 1} 種類も実行しません`);
          login = await recordLoginSkips(jobs, i, r);
          break;
        }
      }
    } catch (e) {
      ng++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 クーポン2種 完了: 成功 ${ok} / 失敗 ${ng}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (login) {
    const next = login.retryHint.replace('{button}', '③');
    await notifyLoginRequired('③ クーポン広告 2種', next);
    return { ok: false, loginRequired: true, success: ok, fail: ng, error: '楽天RMSのログインが切れています', next };
  }
  await setDoneFlag('cpn');
  await notify(
    ng === 0 ? '✅ ③ クーポン広告 2種 完了' : '⚠ ③ クーポン広告 2種 一部失敗',
    `サブジョブ 成功 ${ok} / 失敗 ${ng}`,
    ng === 0 ? 'success' : 'warning'
  );
  return { ok: true, success: ok, fail: ng };
}

// ====== ハンドラ: 失敗分の再取得 ======
// tasks: [{ kind: 'rppAll', type: '② 全ての広告', days: ['2026-06-15', ...] }, ...]
async function handleRetryFailed(tasks) {
  await appendBgLog('bg', `▶ ♻ 失敗分の再取得 開始 (${tasks.length}タスク)`);
  let okTasks = 0, ngTasks = 0;
  let loginStopped = false;   // v6.0.9

  for (let i = 0; i < tasks.length; i++) {
    // 中止フラグチェック
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りの再取得タスクをスキップ`);
      ngTasks += (tasks.length - i);
      break;
    }
    const task = tasks[i];
    await appendBgLog('bg', `[${i + 1}/${tasks.length}] ${task.type} 失敗分再取得 (${task.days.length}日)${task.options ? ' 検索条件=画面の設定' : (['rppAll','rppItem','rppKw'].includes(task.kind) ? ' 検索条件=既定値' : '')}`);
    const t0 = Date.now();
    try {
      const result = await runRetryTask(task);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (result?.ok || result?.success > 0) {
        okTasks++;
        await appendBgLog('bg', `  ✅ ${task.type} 完了 (${dt}秒, 成功=${result.success ?? '-'} 失敗=${result.fail ?? '-'})`);
      } else {
        ngTasks++;
        await appendBgLog('bg', `  ❌ ${task.type} 失敗 (${dt}秒): ${result?.error || '不明'}`);
        if (result?.tabClosed) {
          ngTasks += (tasks.length - i - 1);
          await appendBgLog('bg', `  ⏹ 取得中のタブが閉じられたので、残り ${tasks.length - i - 1} 件の再取得も実行しません`);
          break;
        }
        // v6.0.9: ログイン切れ。残りのタスクの日は履歴上まだ「失敗」のままなので、次の ♻ で取れる
        if (result?.loginRequired) {
          ngTasks += (tasks.length - i - 1);
          await appendBgLog('bg', `  🔑 楽天RMSのログインが切れたので、残り ${tasks.length - i - 1} 件の再取得も実行しません`);
          loginStopped = true;
          break;
        }
      }
    } catch (e) {
      ngTasks++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${task.type} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 失敗分再取得 完了: 成功タスク ${okTasks} / 失敗タスク ${ngTasks}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (loginStopped) {
    const next = 'もう一度「♻ 失敗分を再取得」を押してください';
    await notifyLoginRequired('♻ 失敗分の再取得', next);
    return { ok: false, loginRequired: true, okTasks, ngTasks, error: '楽天RMSのログインが切れています', next };
  }
  await notify(
    ngTasks === 0 ? '✅ ♻ 失敗分の再取得 完了' : '⚠ ♻ 失敗分の再取得 一部失敗',
    `タスク 成功 ${okTasks} / 失敗 ${ngTasks}`,
    ngTasks === 0 ? 'success' : 'warning'
  );
  return { ok: true, okTasks, ngTasks };
}

// 1つの再取得タスクを kind に応じた downloader で実行
// v6.0.8: ② の検索条件(options)の既定値。popup の「既定値に戻す」と同じ内容。
// 再取得タスクに options が無いとき(古い popup から来たとき)の保険。
function defaultRppOptions(kind) {
  const all = kind === 'rppAll';
  return {
    periodType: 0, campaignType: '1', reportFilter: 1, rankType: 1,
    allUsers: true, newUsers: !all, existingUsers: !all,
    noOfClicks: true, adsalesBefore: true, cpc: true,
    h12: !all, h720: true, gms: true, roas: true, cv: true, cvr: true, cpa: true
  };
}

async function runRetryTask(task) {
  const days = task.days;
  if (!Array.isArray(days) || days.length === 0) return { ok: false, error: '日付リストが空' };
  const startDate = days[0];
  const endDate = days[days.length - 1];

  if (task.kind === 'itemSales') {
    const tab = await getOrCreateTab('datatool.rms.rakuten.co.jp/realtime/item', 'https://datatool.rms.rakuten.co.jp/realtime/item');
    if (!tab) throw new Error('datatoolタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ① 商品別売上 失敗分再取得');
    return await runOnTab(tab.id, 'itemSalesDownloader', {
      startDate, endDate, period: 'daily', device: 'all', tax: 'incl', interval: 3, daysOverride: days
    });
  }
  if (task.kind === 'rppAll') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全ての広告 失敗分再取得');
    return await runOnTab(tab.id, 'rppAllDownloader', {
      startDate, endDate, interval: task.interval || 3,
      options: task.options || defaultRppOptions('rppAll'), daysOverride: days
    });
  }
  if (task.kind === 'rppItem') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全商品レポート 失敗分再取得');
    return await runOnTab(tab.id, 'rppAsyncDownloader', {
      startDate, endDate, timeout: task.timeout || 30, selectionType: 3, reportType: 4,
      options: task.options || defaultRppOptions('rppItem'),
      panelPrefix: 'rppItem', reportName: '全商品レポート', daysOverride: days
    });
  }
  if (task.kind === 'rppKw') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全KWレポート 失敗分再取得');
    return await runOnTab(tab.id, 'rppAsyncDownloader', {
      startDate, endDate, timeout: task.timeout || 30, selectionType: 4, reportType: 3,
      options: task.options || defaultRppOptions('rppKw'),
      panelPrefix: 'rppKw', reportName: '全キーワードレポート', daysOverride: days
    });
  }
  if (task.kind === 'cpnItem') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/cpnadv/performance_reports', 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports');
    if (!tab) throw new Error('cpnadvタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ③ クーポン商品別 失敗分再取得');
    return await runOnTab(tab.id, 'cpnadvAsyncDownloader', {
      startDate, endDate, mode: 'item', interval: 3, timeout: 30, daysOverride: days
    });
  }
  if (task.kind === 'cpnKw') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/cpnadv/performance_reports', 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports');
    if (!tab) throw new Error('cpnadvタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ③ クーポンKW別 失敗分再取得');
    return await runOnTab(tab.id, 'cpnadvAsyncDownloader', {
      startDate, endDate, mode: 'keyword', interval: 3, timeout: 30, daysOverride: days
    });
  }
  return { ok: false, error: `未知のkind: ${task.kind}` };
}

// ====== ハンドラ: ④ 登録済みKW全件DL(スナップショット) ======
async function handleRppKwSnapshot(payload) {
  await appendBgLog('bg', `▶ ④ 登録済みKW全件DL(スナップショット) 開始`);
  const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/items?sort_by=-client_update_datetime');
  if (!tab) return { ok: false, error: 'RPPタブ取得失敗' };
  await appendBgLog('bg', `  RPPタブID=${tab.id}`);
  await installOverlayOnTab(tab.id, '🛒 ④ 登録済みKW全件DL');
  const r = await runOnTab(tab.id, 'rppKeywordSnapshotDownloader', {
    timeout: payload?.timeout || 60
  });
  await appendBgLog('bg', `${r?.ok ? '✅' : '❌'} 登録済みKW全件DL 完了: ${JSON.stringify(r)}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  if (r?.loginRequired) {
    const next = '④ をもう一度押してください';
    await notifyLoginRequired('④ 登録済みKW全件', next);
    return { ...r, next };
  }
  await setDoneFlag('snap');
  await notify(
    r?.ok ? '✅ ④ 登録済みKW全件 完了' : '❌ ④ 登録済みKW全件 失敗',
    r?.ok ? '(スナップショット1件取得)' : (r?.error || '不明なエラー'),
    r?.ok ? 'success' : 'error'
  );
  return r;
}

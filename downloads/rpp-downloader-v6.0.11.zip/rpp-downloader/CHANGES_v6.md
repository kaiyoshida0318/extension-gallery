# RMS一括ダウンローダー v6.0.11 変更点 (2026-11-13)

仕様書「取得済みチェックを外すボタン(他ツールへの流用)」(Yahoo一括ダウンローダー v2.1.2 の実装) に合わせて作り直した。

## 変更
- **popup.html**
  - v6.0.10 の「✓ をすべて外す」(④の下の全幅ボタン) を撤去 (どこの ✓ が消えるか分からないため)
  - セクションごとに、見出し行の右端に枠線だけの小さな「✓を外す」ボタン (`.mini-clear`) を置いた
    - 📅 期間指定DL → `#clearChecksDated` (①②③ だけ外す)
    - ⚡ 最新状態DL(日付と無関係) → `#clearChecksSnap` (④ だけ外す)。④ のセクションには見出しが無かったので新設
  - 見出しを `.section-head` (flex) で囲む。文字色は見出しと同じ #7a5000、枠線は `currentColor`
- **popup.js**
  - ✓ をセクションごとのキーで持つ
    | キー | 対象 | 値 | ✓ が消える条件 |
    |---|---|---|---|
    | `rms_done_flags` | ①②③ 期間指定 | `true` | 日付入力を変えたとき / 「✓を外す」 |
    | `rms_done_flags_snap` | ④ 最新状態 | 実行日 `YYYY-MM-DD` | 日付が変わったとき / 「✓を外す」 |
  - ④ は「今日取ったか」を表すので日付で持つ。以前は `true` だったので翌日以降も ✓ が残っていた (仕様書で触れているバグと同じ)
  - 日付入力を変えたときに外れるのは ①②③ だけになった (以前は ④ も外れていた)
  - `clearChecks(keys)`: `chrome.storage.local.remove` → `renderDoneFlags()` で再描画。ファイル・ログ・履歴・固定した日付には触らない
  - 旧形式 (`rms_done_flags.snap = true`) は読まない (更新した日だけ ④ の ✓ が一度消える)
- **background.js**: `setDoneFlag('snap')` が `rms_done_flags_snap` に実行日を書くようにした (①②③ は今まで通り)
- **dev-tools/test/clearchecks_sim.py**: 仕様書のテスト項目を popup.html で確かめる (14項目)
- 複数ショップ: ゆかい屋と KAIRY は Chrome プロファイルを分けていて storage も別なので、キーにショップ名は入れていない
- **manifest.json**: 6.0.10 → 6.0.11

---

# RMS一括ダウンローダー v6.0.10 変更点 (2026-11-13)

## 変更
- **popup.html / popup.js**: ④ の下に「✓ をすべて外す」ボタンを追加。①〜④ のボタンについた完了の ✓ (`rms_done_flags`) をまとめて外す。
  取得したファイルや ♻ 用の履歴 (`rms_dl_history`) には触らない。日付を変えたときに外れる動きは今まで通り
- **icons/icon16・48・128.png**: アイコンの文字を「DL」→「楽」に変更。色 (緑 #1e7a3a)・角丸はそのまま。フォントは Noto Sans CJK JP Black
- **manifest.json**: 6.0.9 → 6.0.10

## 確認したこと (コード変更なし)
- KAIRY の ③ クーポンKW別が 31日すべて「対象データなし ⚪」になる件 (2026-11-13)
  - 商品別CSVではクーポン獲得が毎日ある (例: 10/13 33件・825円、10/14 43件・1,075円)
  - しかし楽天RMSの画面で 2026/10/14 の「全キーワードレポート」を手動で作っても「対象データがありません」だった
  - → 楽天側にKW別のデータが無いだけで、拡張の判定は正しい。KAIRY ではKW別が毎日 ⚪ になるのが普通
  - 楽天の画面では「完了 / 対象データがありません」と出るが、API のジョブ一覧では status=500 になる

---

# RMS一括ダウンローダー v6.0.9 変更点 (2026-11-12)

## 症状
①②③ を 16:42 に終えたあと、18:17 に ④ 登録済みKW全件DL を押すと
`投入失敗 HTTP 401 応答: {"errors":[{"message":"正常な処理ができませんでした。もう一度お試しください。"}]}` で3回とも失敗。
「🔗 一括オープン」してから押し直しても同じだった。

## 原因 (ログで確定)
- 楽天RMSのログインが切れていた (楽天のタブが `/rpp/system_error`、メインメニューが `?act=app_login_error`)。拡張の不具合ではない
- ただし拡張側にも問題が2つあった
  1. 401 (ログイン切れ) でも3回ずつやり直していた。②③ なら日ごとに3回ずつ失敗を積み上げる
  2. `getOrCreateTab` が URL に `ad.rms.rakuten.co.jp/rpp` を含むタブを探すので、エラー画面 (`/rpp/system_error`) のタブもそのまま使っていた。
     一括オープンで新しいタブを開いても、古いエラー画面のタブが先に見つかって 401 になり続けた

## 変更
- **injected.js**
  - `checkLoginResponse(res)`: 応答が HTTP 401、またはエラー画面・ログイン画面 (`system_error` / `login_error` / `glogin.rms.rakuten.co.jp`) に転送されていたら `LOGIN_REQUIRED:` の例外にする。
    投入・ポーリング・ZIP取得の各 fetch に追加 (①②③④ すべて)
  - ログイン切れなら **やり直さずにその場で止める** (`abortJobForLogin`)。今の日と、まだ取っていない日を「失敗」として履歴に残す
    → ログインし直したあと「♻ 失敗分を再取得」で残りの日だけ取れる (取り込み用に同じ日が2つ入らない)
  - 戻り値に `loginRequired: true`。ジョブ表示は `aborted`
  - ④ は 401 で即終了 (以前は3回)
- **background.js**
  - `getOrCreateTab`: エラー画面のタブは使わない。エラー画面のタブがあれば新しいタブを増やさず、そのタブを正しいページへ開き直す
  - `runOnTab`: タブがエラー画面・ログイン画面なら取得を始めずに `loginRequired` を返す
  - ②③ の連続ジョブ: ログイン切れで残りの種類を実行しない。途中で止まったときは、まだ始めていない種類の日も「未取得」として履歴に残す (`recordLoginSkips`)
  - ♻ 再取得: ログイン切れで残りのタスクを実行しない (残りは履歴上まだ失敗のままなので、次の ♻ で取れる)
  - `notifyLoginRequired`: 「🔑 楽天RMSのログインが切れています」通知 + RMS のログイン画面 (`https://glogin.rms.rakuten.co.jp/`) を前面に開く。30秒に1回まで
  - 次にやることを応答の `next` で返す: 1つ目が始まる前に止まった → 「(同じボタン) をもう一度」/ 途中で止まった → 「♻ 失敗分を再取得」/ ④ → 「④ をもう一度」
  - `recordHistory` (未使用だった) を複数件対応にし、上限を injected.js と同じ 200 件に揃えた (以前は 50 件で切り詰めていた)
- **popup.js**: `loginRequired` の応答のとき「✅ 完了」ではなく「🔑 楽天RMSのログインが切れています。ログインし直してから、(次にやること)」を表示し、完了マーカーも付けない
- **dev-tools/test/login_sim.js**: ログイン切れのシミュレーション (27項目)
- **manifest.json**: 6.0.8 → 6.0.9

## 運用
- 🔑 の通知が出たら、開いた RMS のログイン画面でログインし直し、通知・popup に出ている「次にやること」をする
- エラー画面のタブは閉じなくてよい (次に取得するときに拡張が開き直す)

---

# RMS一括ダウンローダー v6.0.8 変更点 (2026-11-12)

## 症状
「♻ 失敗分を再取得」で ② 全キーワードレポート (2025-02-24, 02-25) を取り直すと、2日とも即座に
`downloadAsync失敗 HTTP 400 応答: {"errors":[{"message":"検索条件に誤りがあります。"}]}` で失敗した。
(v6.0.3 で応答本文をログに出すようにしたので理由が分かった)

## 原因
`runRetryTask` (background.js) が ② (全ての広告 / 全商品 / 全KW) を再取得するとき、検索条件 `options`
(集計単位・新規/既存・12時間/720時間・各列の ON/OFF など) を渡していなかった。
通常実行は popup の `collectRppOptions()` の値を送っているが、再取得は日付と selectionType だけを送っていたため、楽天が 400 で断っていた。
→ ② の ♻ 再取得は、これまで一度も成功しない状態だった (2026-11-11 16:03 の全KW 10/16・10/17 の再取得失敗も同じ原因)

## 変更
- **popup.js**: ♻ 再取得のタスクに、通常実行と同じ `options` (画面の設定) を付ける。全商品/全KW は timeout も画面の値 (最低30秒)、全ての広告は interval も画面の値
- **background.js**: `runRetryTask` で `task.options` を渡す。無い場合は `defaultRppOptions(kind)` (画面の「既定値に戻す」と同じ内容) で補う。再取得の開始ログに「検索条件=画面の設定 / 既定値」を出す
- **manifest.json**: 6.0.7 → 6.0.8

## 未解決
- 2026-11-11 15:45 の通常実行で 全KW 10/16・10/17 が HTTP 400 になった件は、通常実行 (options あり) なので今回の原因とは別。
  当時は応答本文を記録していなかったため理由は不明。v6.0.3 以降なら再発時にログに理由が残る

---

# RMS一括ダウンローダー v6.0.7 変更点 (2026-11-11)

## 変更
- 「📅 前日〜30日前を自動セット」→「📅 前日〜31日前を自動セット」(31日分)
- **理由**: RPP の720時間の売上は「クリック日」に計上され、その日の最後のクリックから720時間 (30日) 後まで増え続ける。
  D日の数字が出そろうのは D+31日以降。30日前まで取る運用だと、各日を最後に取るのが D+30日 (出そろう1日前) になり、
  720時間分が出そろった数字を一度も取れていなかった。31日前まで取れば、一番古い日は出そろった数字で月別フォルダに上書きされる
- ボタンの id (`bulk-preset-30days`) は互換のためそのまま
- **manifest.json**: 6.0.6 → 6.0.7

## 影響
- 毎日の取得が 30日分 → 31日分 (②③ が1日分ずつ長くなる)
- 取り込み用フォルダの件数も1日分増える

---

# RMS一括ダウンローダー v6.0.6 変更点 (2026-11-11)

## 症状
取り込み用フォルダに、同じ日のファイルが2つずつ入った (103日分)。② と ③ がそれぞれ2本同時に動いていた。

## 原因 (ログで確定)
- ② の「全ての広告」の途中 (16日分保存後) でユーザーがウィンドウを閉じた。v6.0.4 の検知で「全ての広告」は中断されたが、
  `handleBulkRpp3` はそのまま次の「全商品」「全KW」に進み、新しいタブを開いて続きを実行した
- ユーザーがウィンドウを開き直して ② を押し直したので、残っていた ② と新しい ② が並行して動いた
- ③ も同じ (17:25:59 にタブが閉じられ「商品別」は中断、「KW別」は新しいタブで続行 → 17:26:55 に ③ を押し直し)

## 変更
- **background.js**
  - `runOnTab`: 取得中に閉じられたタブを `closedTabs` に記録し、結果に `tabClosed: true` を付ける
  - `handleBulkRpp3` / `handleBulkCpn2` / `handleRetryFailed`: `tabClosed` なら残りの手順を実行せずに終了
  - 二重起動の防止: 同じ種類の取得 (`run-*`) が実行中なら2本目は開始せず `{busy:true}` を返して通知。
    ♻ 再取得は他の取得の実行中には始めない (逆も同じ)。③ の単発と連続も同時には動かさない (`activeRuns`, `busyReason`)
- **popup.js**: `busy` の応答のとき「✅ 完了」ではなく「⛔ (理由)」を表示し、完了マーカーも付けない
- **manifest.json**: 6.0.5 → 6.0.6

---

# RMS一括ダウンローダー v6.0.5 変更点 (2026-11-11)

## 症状
v6.0.4 に更新したあとも、前回止まった「① 商品別売上 2/30」が popup に残り、「⏹ 中止」を押すと「⏳ 中止中…」のまま固まった。

## 原因
- 進行中ジョブの表示 (`rms_active_job`) は chrome.storage.local にあり、拡張を更新・再読み込みしても消えない
- 中止ボタンは「中止フラグ」を立てて、動いている処理が気づくのを待つだけ。処理はすでに止まっているので、誰も気づかず「中止中」のまま

## 変更
- **injected.js**: ジョブに最終更新時刻 `updatedAt` を記録 (開始・各日の更新・終了時)
- **popup.js**: 中止を押したのに 90秒以上ジョブの更新が無ければ、止まっているとみなして表示を片付ける (`cleanupStaleCancelledJob`)。
  popup を開いた時と、開いている間 15秒ごとに確認。中止を押した時刻 `rms_cancel_at` を記録
- **background.js**: `chrome.runtime.onInstalled` (拡張の更新・再読み込み) で、実行中のジョブを中断扱いにして中止フラグを消す
- **manifest.json**: 6.0.4 → 6.0.5

---

# RMS一括ダウンローダー v6.0.4 変更点 (2026-11-11)

## 症状
① 商品別売上が「2/30 完了」のまま約1時間止まって見えた (16:07〜17:01)。エラーも通知も出なかった。

## 原因 (ログで確定)
- 16:07:12 に 2日目を保存した直後、取得処理が動いていた datatool のタブ (tabId=919538462) が閉じられた
  (16:07:24 の「一括オープン」時点でタブ一覧から消えており、新しい datatool タブ 919538510 が作られている)
- 取得処理は楽天のタブの中で動くので、タブと一緒に消えた。background は何も記録せず、popup は最後の状態 (実行中 2/30) を表示し続けた

## 変更
- **background.js**
  - `runOnTab`: 実行中のタブを `runningTabs` に登録。`chrome.tabs.onRemoved` で閉じられたのを検知したら、ログ・ジョブ中断 (`rms_active_job.status='aborted'`)・デスクトップ通知
  - `runOnTab` 内の失敗 (タブが無い等) は例外にせず `{ok:false}` を返す → 各ハンドラが「❌ 失敗」として通知する
  - `installOverlayOnTab`: 楽天のタブの進捗表示に「(このタブは閉じないでください)」を追記。表示に失敗しても続行
  - 商品別売上・スナップショットの完了ログが失敗時も ✅ になっていたのを修正
- **manifest.json**: 6.0.3 → 6.0.4

## 注意
- 処理されなかった日は ♻ 失敗分を再取得 の対象にならない (履歴に残らないため)。中断されたら同じボタンをもう一度押す

---

# RMS一括ダウンローダー v6.0.3 変更点 (2026-11-11)

## 症状
②全キーワードレポートの 2026-10-16 と 10-17 だけ `downloadAsync失敗 HTTP 400` で失敗。♻ 再取得でも同じ。
同じ日の 14:58 の取得では成功していた。ほかの日・ほかのレポートは成功。

## 原因
楽天の `POST /rpp/api/reports/downloadAsync` がジョブの受付を HTTP 400 で拒否している。拡張は応答本文を記録していなかったため、理由は不明。

## 変更
- **injected.js**: `httpError(res, label)` を追加。HTTPエラーのとき楽天の応答本文の先頭200文字をエラーメッセージに含める
  (全ての広告 / downloadAsync / ZIP取得)。次に 400 が出たら、ログに楽天側の理由が残る
- **manifest.json**: 6.0.2 → 6.0.3

## 補足 (v6.0.2 の件)
0バイトファイルの原因はログで確定: 取り込み用への書き込みの close で
`InvalidStateError: ... the state had changed since it was read from disk` (同期ソフトがファイルを触ったと思われる)。v6.0.2 のやり直し処理で対応済み。

---

# RMS一括ダウンローダー v6.0.2 変更点 (2026-11-11)

## 症状
取り込み用フォルダに 0バイトの zip が1件残っていた
(`ADcheck取り込み用/CouponAdvance_yukaiya_kw_20261027_get20261111-1514.zip`)。
月別フォルダの同じ日のファイル (597バイト) は正常で、取得結果も ✅ になっていた。

## 原因
- `fsstore.js` の `writeFile` は、先に空のファイルを作ってから書き込む。書き込みや close が失敗すると、その空ファイルが残っていた
  (Dropbox などの同期ソフトが一瞬ファイルを掴むと起こりうる)
- `handleSaveFile` は、月別と取り込み用の**両方が**失敗したときだけ失敗を返していた。片方だけ失敗しても ✅ になり、♻ 再取得の対象にもならなかった

## 変更
- **fsstore.js** `writeFile`: 失敗したら最大3回やり直す (0.5秒→1秒の間隔)。書いた後にサイズを確認し、違えばやり直す。3回とも失敗したら、今回新しく作ったファイルを消して空ファイルを残さない
- **background.js** `handleSaveFile`: どちらか一方でも失敗したら、その日を失敗扱いにする (♻ 失敗分を再取得で両方書き直される)
- **manifest.json**: 6.0.1 → 6.0.2

---

# RMS一括ダウンローダー v6.0.1 変更点 (2026-11-11)

## 症状
取得の途中 (例: ②全商品レポートの 10/29 以降) から、すべての日が
`保存先フォルダが未設定/要許可(state=prompt)` で保存スキップになった。Chrome の再起動はしていない。

## 原因
Chrome は File System Access の書き込み許可を「その拡張のページ(タブ)が全部閉じてから約5秒後」に取り消す
(granted → prompt)。Service Worker は「開いているページ」に数えられない。
v6.0.0 は folder.html に「このタブは閉じてOKです」と表示していたため、取得中にタブを閉じると5秒後に許可が切れていた。
ログ上も 05:19:38 (UTC) の保存成功から 05:19:44 の失敗まで6秒で切り替わっている。

## 変更
- **background.js**
  - `ensureFolderTab()`: `run-*` メッセージ (①〜④・♻) を受けたら、folder.html が無ければピン留め・非アクティブで開く
  - `waitForGrant()`: 保存時に `prompt` / `denied` なら即失敗せず **一時停止**。デスクトップ通知を出し、保存先タブを前面に出して
    「🔑 許可」を待つ (2秒ごとに確認、最大4分)。許可されたらその日の保存から続行
  - 4分待っても許可されなければ以降30分は待たずに失敗 (ユーザー不在時に1日4分ずつ待たないため)。⏹中止でも待ちを抜ける
- **popup.js**: `openFolderPage()` は既存タブがあれば前面に出すだけ (重複して開かない)。新規はピン留め。
  「🔗 必要なページを一括オープン」で保存先タブもピン留めで開く
- **folder.html / folder.js**: 「取得中はこのタブを閉じないでください」の注意書きを追加。「閉じてOK」の文言を削除。タブ名を `📌 RMS保存先(取得中は閉じない)` に
- **manifest.json**: 6.0.0 → 6.0.1

## 運用
- 保存先タブ (ピン留め) は開いたままにする。閉じてしまったら取得が止まって通知が出るので「🔑 許可」を押す
- 4分以内に押せなかった日は失敗扱いになるので「♻ 失敗分を再取得」

---

# RMS一括ダウンローダー v6.0.0 変更点

## 変更の目的
取得したレポートを Chrome の「ダウンロード」を通さず、ユーザーが一度選んだフォルダへ拡張機能が **直接書き込む** 方式に切り替えた。
File System Access API (showDirectoryPicker) ベース。amazon-downloader v2.12.15 の fsstore.js / folder.html / folder.js の仕組みを流用。

## 保存方式

### 書き込み先 (2か所)
1. **月別フォルダ (保管用、上書き)**: `{保存先}/YYYY-MM-{CPA|RPP}/{filename}`
   - `filename` は `_getYYYYMMDD-HHMM` を外したもの
   - 同名があれば上書き → 1日=種類ごとに常に最新の1ファイル
   - スナップショット (`rpp_item_keyword_*.csv`) は月別に書かない
2. **ADcheck取り込み用 (全保存)**: `{保存先}/ADcheck取り込み用/{basename}_get{YYYYMMDD-HHMM}.{ext}`
   - 取得日時サフィックスで事実上一意
   - 中身は ADcheck に取り込んだ後、ユーザーが手動で空にする想定

### 月別フォルダの振り分け (ファイル名 → 行き先)
| ファイル名 prefix | 月別フォルダ |
|---|---|
| `CouponAdvance_*_item_*` | `YYYY-MM-CPA/` |
| `CouponAdvance_*_kw_*` | `YYYY-MM-CPA/` |
| `rpp_reports_*` | `YYYY-MM-RPP/` |
| `rpp_item_reports_*` | `YYYY-MM-RPP/` |
| `rpp_keyword_reports_*` | `YYYY-MM-RPP/` |
| `YYYYMMDD_Item_SalesList.csv` | `YYYY-MM-RPP/` |
| `rpp_item_keyword_*` (snapshot) | **月別には書かない** |

振り分けは `handleSaveFile` に渡される `kind: 'CPA' | 'RPP'` と `day: 'YYYY-MM-DD'` で決定 (各 downloader が設定済み)。

## 追加ファイル
- **fsstore.js**: `self.AMZ_FS` で `status() / setRoot() / writeFile() / requestPermission()` を提供。
  - DB名: `rakuten_fetch_fs` (amazon-downloader とは分離)
- **folder.html / folder.js**: 保存先フォルダ設定ページ
  - ピッカーID: `rakuten-fetch-data`
  - 「保存先フォルダを選ぶ」「このフォルダへの保存を許可」の2ボタン
  - 他の画面(popup)に状態変化を知らせるため `chrome.storage.local` の `rms_fs_state` / `rms_fs_name` を書き込む

## 削除ファイル
- **offscreen.html / offscreen.js**: chrome.downloads.download で使っていた blob URL 生成用。不要になった。

## 変更ファイル

### manifest.json (v5.14.3 → v6.0.0)
- `permissions` から `"downloads"`, `"offscreen"` を削除
- `permissions` に残したもの: `activeTab`, `scripting`, `tabs`, `storage`, `notifications`
- `web_accessible_resources` に `folder.html` を追加

### background.js
- 先頭に `importScripts('fsstore.js')` を追加
- `onDeterminingFilename` リスナ、`pendingSaves` Map、`ensureOffscreen()`, `makeBlobUrlViaOffscreen()` を削除
- **`handleSaveFile()` を全面書き換え**:
  1. 事前に `AMZ_FS.status()` を確認、granted でなければ即エラー返す
  2. `new Uint8Array(dataArr)` でバイト列復元 (変換・BOM追加は一切しない)
  3. 月別フォルダに `AMZ_FS.writeFile(subdir, stripGetSuffix(filename), bytes)` (snapshot以外)
  4. ADcheck取り込み用に `AMZ_FS.writeFile('ADcheck取り込み用', insertGetSuffix(filename, ts), bytes)` (全ファイル)
- 新しい `fs-status` メッセージハンドラ: popup からの状態問い合わせに応答
- `summarizeResult()` に `noData` 件数の表示を追加

### injected.js
- `saveViaBackground` のコメントを更新 (offscreen → fsstore)
- **downloader 本体は無変更**: filename / day / kind / isSnapshot / dataArr / mimeType を background に送る形は既に正しい

### popup.html
- 上部の `.setup-hint` (Chrome DL設定の案内) を **保存先フォルダ ステータス行** `.fs-row` に差し替え
- `#fs-name` (フォルダ名表示) と `#fs-set-btn` (設定/変更/許可ボタン) を追加
- 未設定/要許可時に警告バナー `#fs-hint` を表示
- 対応するCSSを追加

### popup.js
- 保存先状態 (`granted` / `prompt` / `denied` / `none`) の表示と購読
- `refreshFsStatus()`: background に `fs-status` メッセージを送って最新状態を取得、UI反映
- `ensureFsGranted()`: ①②③④ ボタン押下時の事前チェック。granted でなければ folder.html を自動で開いて中断
- `window.focus` イベントで再確認 (Chrome再起動後の prompt 検出)
- 旧「Chrome DL設定ヒント」関連の `SETUP_HINT_HIDDEN_KEY` / `hide-setup-hint` ハンドラを削除

## 動作フロー (1ファイル保存)
```
injected.js (downloader)
  ↓ blob 完成
  saveViaBackground(blob, {filename, day, kind, isSnapshot})
  ↓ chrome.runtime.sendMessage({type:'save-file', payload:{filename, day, kind, isSnapshot, dataArr}})
  ↓
background.js handleSaveFile
  ↓ AMZ_FS.status() 確認 → granted
  ↓ new Uint8Array(dataArr) でバイト列復元
  ├→ AMZ_FS.writeFile('2026-10-RPP', 'rpp_reports_yukaiya_20261012.csv', bytes)   # 月別、上書き
  └→ AMZ_FS.writeFile('ADcheck取り込み用', 'rpp_reports_yukaiya_20261012_get20261111-1340.csv', bytes)   # 取り込み用、日時付き
```

## 初回セットアップ手順 (ユーザー向け)
1. 拡張を再読み込み (chrome://extensions/ でリロード)
2. 拡張アイコンをクリック → popup が開く
3. 上部の「保存先: 未設定」の行の「設定」ボタンを押す → folder.html が新しいタブで開く
4. 「📂 保存先フォルダを選ぶ」ボタン → OSのフォルダ選択ダイアログ
   - 例: `ダウンロード/楽天データ保管` フォルダを事前に作っておき、それを選ぶ
   - 「ダウンロード」直下、デスクトップ、システムフォルダはChromeが選ばせないことがある
5. Chromeの書き込み許可ダイアログで「許可」をクリック
6. popup に戻ると「保存先: 楽天データ保管」が緑色で表示される
7. 以降は①〜④のボタンを押すだけで保存先に直接書き込まれる

## Chrome再起動後の対応
- 書き込み許可が `prompt` に戻ることがある
- popup を開くと「保存先: 要許可」の黄色警告が出る
- 「許可」ボタンを押すと folder.html が開く → 「🔑 このフォルダへの保存を許可」をクリック (フォルダを選び直す必要はない)

## テスト観点 (仕様書より)
1. ✅ 保存先を選び、30日分を取得 → 月別フォルダが2つの月×CPA/RPP で4つでき、各日付のファイルが入っている
2. ✅ 月別フォルダのファイル名に `_get` が付いていない。スナップショットが月別フォルダに入っていない
3. ✅ ADcheck取り込み用 に、取得日時付きの全ファイル (スナップショット含む) が入っている
4. ✅ 翌日にもう一度取得 → 月別フォルダは同じ日付のファイルが上書きされ、数が増えない。ADcheck取り込み用 は前回分が残ったまま、新しい分が増える
5. ✅ 保存したファイルが元のファイルと同じ中身 (zip が開ける、CSV が文字化けしない) — バイト列をそのまま書いているので保証
6. ✅ 「ダウンロード」フォルダに同じファイルが保存されていない — chrome.downloads 完全廃止
7. ✅ Chrome を再起動したあと、取得ボタン → 要許可の案内 → 許可を押すと保存できる

## 既知の制限 / 注意点
- **`chrome.notifications` は継続**: 完了時のデスクトップ通知は今まで通り
- **noData カウントの通知表示**: 現状の各 downloader の戻り値は `{success, fail}` までで `noData` は含まれていないので、通知サマリに「データなし N」は出ない。履歴(popup内)には従来通り ⚪ で表示される
- **ADcheck取り込み用の自動掃除なし**: 休日を挟むと溜まる。ADcheck 取り込み後にユーザーが手で空にする前提
- **DB名 `rakuten_fetch_fs`**: 他の拡張とは完全分離。拡張を一度削除して入れ直すと保存先設定も消えるので再度設定が必要

// ========== 共通ユーティリティ ==========
const $ = id => document.getElementById(id);

// ========== 完了マーカー(①②③④のDLボタン用) ==========
// v6.0.11: 仕様書「取得済みチェックを外すボタン」に合わせて、✓ をセクションごとのキーで持つ。
//   rms_done_flags      ①②③ 期間指定  値 true          消える条件: 日付入力を変えたとき / 「✓を外す」
//   rms_done_flags_snap ④ 最新状態     値 実行日 YYYY-MM-DD  消える条件: 日付が変わったとき / 「✓を外す」
// ④ は「今日取ったか」なので日付で持つ (true だと翌日以降も ✓ が残り続ける)。
// ショップごとに Chrome プロファイルを分けているので、キーにショップ名は入れない。
const DONE_KEY = 'rms_done_flags';
const DONE_SNAP_KEY = 'rms_done_flags_snap';
const DONE_BUTTON_MAP = {        // ①②③ (期間指定)
  is: 'bulk-dl-is',
  rpp: 'bulk-dl-rpp',
  cpn: 'bulk-dl-cpn'
};
const DONE_SNAP_BUTTON_MAP = {   // ④ (最新状態)
  snap: 'bulk-dl-rppsnap'
};

// 端末の日付 (日本時間) を YYYY-MM-DD で
function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ✓ の表示は毎回 storage から読み直す
async function renderDoneFlags() {
  let flags = {}, snapFlags = {};
  try {
    const s = await chrome.storage.local.get([DONE_KEY, DONE_SNAP_KEY]);
    flags = s[DONE_KEY] || {};
    snapFlags = s[DONE_SNAP_KEY] || {};
  } catch (_) {}
  for (const [kind, btnId] of Object.entries(DONE_BUTTON_MAP)) {
    $(btnId)?.classList.toggle('done', !!flags[kind]);
  }
  for (const [kind, btnId] of Object.entries(DONE_SNAP_BUTTON_MAP)) {
    $(btnId)?.classList.toggle('done', snapFlags[kind] === todayIso());
  }
}

// ✓ を付ける (background の setDoneFlag と同じ書き方)
async function markDone(kind) {
  const snap = kind in DONE_SNAP_BUTTON_MAP;
  const key = snap ? DONE_SNAP_KEY : DONE_KEY;
  try {
    const s = await chrome.storage.local.get([key]);
    const flags = s[key] || {};
    flags[kind] = snap ? todayIso() : true;
    await chrome.storage.local.set({ [key]: flags });
  } catch (_) {}
  await renderDoneFlags();
}

// 「✓を外す」: 該当セクションのキーを消して再描画するだけ。
// ダウンロード済みファイル・ログ・履歴 (♻ の対象)・固定した日付には触らない
function clearChecks(keys) {
  return new Promise(resolve => {
    chrome.storage.local.remove(keys, () => {
      void chrome.runtime.lastError;
      renderDoneFlags().then(resolve);
    });
  });
}

// 日付入力を変えたら ①②③ の ✓ だけ外す (④ は日付と無関係なので残す)
async function resetDoneFlags() {
  await clearChecks([DONE_KEY]);
}

// popup 起動時に反映
renderDoneFlags();

$('clearChecksDated')?.addEventListener('click', () => {
  clearChecks([DONE_KEY]);
  appendLog('bulk', '🔘 ✓を外す (①②③ 期間指定)');
});
$('clearChecksSnap')?.addEventListener('click', () => {
  clearChecks([DONE_SNAP_KEY]);
  appendLog('bulk', '🔘 ✓を外す (④ 最新状態)');
});

// background 側で完了時に flag を書き込むので、その変化を購読してリアルタイム反映
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes[DONE_KEY] || changes[DONE_SNAP_KEY])) {
    renderDoneFlags();
  }
});

// ========== ログ記録システム ==========
// chrome.storage.local に蓄積、コピー時に整形して出力
const LOG_KEY = 'rms_dl_logs';
const LOG_MAX = 2000;  // 最大件数

async function appendLog(category, text, extra = null) {
  // 直列化: 同時に複数の appendLog が走るとchrome.storage.local.setの
  // 上書き合戦でログが消えるので、Promise チェーンで順番に処理する
  appendLog._chain = (appendLog._chain || Promise.resolve()).then(async () => {
    try {
      const stored = await chrome.storage.local.get([LOG_KEY]);
      const logs = stored[LOG_KEY] || [];
      logs.push({
        t: new Date().toISOString(),
        cat: category,
        msg: String(text),
        extra: extra
      });
      if (logs.length > LOG_MAX) logs.splice(0, logs.length - LOG_MAX);
      await chrome.storage.local.set({ [LOG_KEY]: logs });
      updateLogCount(logs.length);
    } catch (_) { /* logging失敗は致命にしない */ }
  });
  return appendLog._chain;
}

async function getLogCount() {
  const s = await chrome.storage.local.get([LOG_KEY]);
  return (s[LOG_KEY] || []).length;
}

function updateLogCount(n) {
  const el = document.getElementById('log-count');
  if (el) el.textContent = `ログ ${n}件`;
}

async function clearLogs() {
  await chrome.storage.local.remove([LOG_KEY]);
  updateLogCount(0);
}

// ========== DL履歴(簡易表示) ==========
const HISTORY_KEY = 'rms_dl_history';

function fmtHistoryTime(iso) {
  // "2026-06-29T01:13:48.123Z" → "06/29 10:13" (JST)
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  const M = String(d.getMonth() + 1).padStart(2, '0');
  const D = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${M}/${D} ${h}:${m}`;
}

function renderHistoryList(list) {
  const el = document.getElementById('dl-history-list');
  if (!el) return;
  if (!list || list.length === 0) {
    el.innerHTML = '<span class="empty">(まだ実行履歴がありません)</span>';
    return;
  }
  el.innerHTML = list.slice(0, 30).map(h => {
    const time = fmtHistoryTime(h.t);
    // 日別フォーマット(新) と ジョブまとめ(旧) 両方サポート
    let range;
    if (h.day) {
      range = h.day;  // 1日単位
    } else if (h.startDate && h.endDate) {
      range = (h.startDate === h.endDate) ? h.startDate : `${h.startDate}〜${h.endDate}`;
    } else {
      range = '';
    }
    let result;
    if (h.ok === 'noData') {
      result = `<span class="result nodata">⚪ 対象データなし</span>`;
    } else if (h.ok === 'notReady') {
      result = `<span class="result notready">⏰ 集計未完了(あとで再取得)</span>`;
    } else if (h.ok) {
      // 日別: rows(件数)があれば表示、なければ✅のみ
      if (h.rows != null) {
        result = `<span class="result">✅ ${h.rows}件</span>`;
      } else if (h.success != null || h.fail != null) {
        // 旧フォーマット
        result = `<span class="result">✅ 成功${h.success ?? '-'}/失敗${h.fail ?? '-'}</span>`;
      } else {
        result = `<span class="result">✅</span>`;
      }
    } else {
      result = `<span class="result">❌ ${h.error || '失敗'}</span>`;
    }
    const klass = (h.ok === 'noData') ? 'nodata' : (h.ok === 'notReady') ? 'notready' : (h.ok ? 'ok' : 'ng');
    return `<div class="dl-history-item ${klass}">
      <span class="time">[${time}]</span>${h.type || '?'} ${range} → ${result}
    </div>`;
  }).join('');
}

async function refreshHistory() {
  try {
    const s = await chrome.storage.local.get([HISTORY_KEY]);
    renderHistoryList(s[HISTORY_KEY] || []);
  } catch (_) {
    renderHistoryList([]);
  }
}

// 起動時に表示
(async () => { await refreshHistory(); })();

// 履歴が変わったら自動更新(他のpopupセッションやbackgroundからの追加に反応)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[HISTORY_KEY]) {
    renderHistoryList(changes[HISTORY_KEY].newValue || []);
  }
});

// 履歴クリアボタン
document.getElementById('bulk-clearhistory')?.addEventListener('click', async () => {
  if (!confirm('DL履歴をクリアしますか?')) return;
  await chrome.storage.local.remove([HISTORY_KEY]);
  renderHistoryList([]);
});

// ========== 失敗分を再取得 ==========
// type ラベル → background に渡す kind の対応表
const TYPE_TO_KIND = {
  '① 商品別売上': 'itemSales',
  '② 全ての広告': 'rppAll',
  '② 全商品レポート': 'rppItem',
  '② 全キーワードレポート': 'rppKw',
  '③ クーポン商品別': 'cpnItem',
  '③ クーポンKW別': 'cpnKw'
};

// 履歴を「(type, day) ごとに最新だけ」採用し、ok===false のものだけ集める
function aggregateFailures(historyList) {
  const latest = new Map();  // key: type+day, value: entry
  // 履歴は新しい順なので、初出のものが最新
  for (const e of historyList) {
    if (!e.day || !e.type) continue;
    const key = `${e.type}__${e.day}`;
    if (!latest.has(key)) latest.set(key, e);
  }
  // タイプ別に集計
  const grouped = {};
  for (const e of latest.values()) {
    if (e.ok === true || e.ok === 'noData') continue;  // 成功・データなしはスキップ
    const kind = TYPE_TO_KIND[e.type];
    if (!kind) continue;  // 知らないtypeは無視
    if (!grouped[kind]) grouped[kind] = { type: e.type, days: [] };
    grouped[kind].days.push(e.day);
  }
  // 各タイプの日付を昇順ソート
  for (const k of Object.keys(grouped)) {
    grouped[k].days.sort();
  }
  return grouped;  // { rppAll: { type: '② 全ての広告', days: [...] }, ... }
}

document.getElementById('bulk-retry-failed')?.addEventListener('click', async () => {
  // 進行中ジョブの有無をチェック
  if (!(await checkOngoingJobBeforeStart())) return;
  if (!(await ensureFsGranted())) return;

  // 履歴から失敗エントリを集計
  const s = await chrome.storage.local.get([HISTORY_KEY]);
  const list = s[HISTORY_KEY] || [];
  const grouped = aggregateFailures(list);
  const kinds = Object.keys(grouped);

  if (kinds.length === 0) {
    alert('再取得できる失敗エントリはありません。\n\n履歴枠の ❌ になっているもののみが対象です。\n(既に再取得して成功したものは対象外)');
    return;
  }

  // 確認ダイアログ
  const total = kinds.reduce((sum, k) => sum + grouped[k].days.length, 0);
  let summary = `合計 ${total}件 を再取得します:\n\n`;
  for (const k of kinds) {
    const g = grouped[k];
    summary += `・${g.type}: ${g.days.length}日\n  ${g.days.join(', ')}\n`;
  }
  summary += `\n再取得を開始しますか?`;
  if (!confirm(summary)) return;

  appendLog('bulk', `🔘 ♻失敗分を再取得 ボタン押下: 合計${total}件`);

  // タスクリスト作成
  // v6.0.8: ② の再取得にも、通常実行と同じ検索条件(options)を渡す。
  // 以前は options を渡しておらず、楽天が「検索条件に誤りがあります」(HTTP 400) で断っていた。
  const RPP_KINDS = ['rppAll', 'rppItem', 'rppKw'];
  const tasks = kinds.map(kind => {
    const t = { kind, type: grouped[kind].type, days: grouped[kind].days };
    if (RPP_KINDS.includes(kind)) {
      t.options = collectRppOptions(kind);
      if (kind === 'rppAll') t.interval = parseFloat($('rppAll-interval')?.value) || 3;
      else t.timeout = Math.max(30, parseInt($(`${kind}-timeout`)?.value, 10) || 0);  // 再取得は最低30秒待つ
    }
    return t;
  });

  // UIをdisable
  $('bulk-retry-failed').disabled = true;
  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-dl-cpn').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;

  chrome.runtime.sendMessage({ type: 'run-retry-failed', tasks }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ 再取得応答エラー: ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `♻ 再取得完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.busy) setBulkHint(`⛔ ${response.error}`, true);
      else if (response?.loginRequired) setBulkHint(loginHintText(response), true);
    }
    $('bulk-retry-failed').disabled = false;
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-dl-cpn').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
  });

  setBulkHint(`♻ ${total}件の再取得をbackgroundで実行中…(popup閉じてもOK)`);
});

// ========== 進行中ジョブの表示 + 中止ボタン ==========
const ACTIVE_JOB_KEY = 'rms_active_job';

function renderActiveJob(job) {
  const box = document.getElementById('active-job-box');
  if (!box) return;
  // ジョブが無い or 完了/中止済みなら隠す
  if (!job || job.status !== 'running') {
    box.style.display = 'none';
    return;
  }
  box.style.display = 'block';

  const first = job.days[0]?.day;
  const last = job.days[job.days.length - 1]?.day;
  const range = (first && last && first !== last) ? `${first}〜${last}` : (first || '');
  document.getElementById('active-job-title').textContent = `${job.type} ${range}`;

  // マス目: ✅成功 / ❌失敗 / ⚪データなし / ⏰集計未完了 / ⏳処理中 / ⬜待機
  const okCount = job.days.filter(d => d.status === 'ok').length;
  const ngCount = job.days.filter(d => d.status === 'ng').length;
  const ndCount = job.days.filter(d => d.status === 'noData').length;
  const nrCount = job.days.filter(d => d.status === 'notReady').length;
  const total = job.days.length;
  const cells = job.days.map(d => {
    let mark = '⬜', klass = 'pending';
    if (d.status === 'ok') { mark = '✅'; klass = 'ok'; }
    else if (d.status === 'ng') { mark = '❌'; klass = 'ng'; }
    else if (d.status === 'noData') { mark = '⚪'; klass = 'nodata'; }
    else if (d.status === 'notReady') { mark = '⏰'; klass = 'notready'; }
    else if (d.status === 'processing') { mark = '⏳'; klass = 'processing'; }
    return `<span class="cell ${klass}" title="${d.day}: ${d.status}">${mark}</span>`;
  }).join('');
  document.getElementById('active-job-cells').innerHTML = cells;

  const statsParts = [`${okCount + ngCount + ndCount + nrCount}/${total} 完了`, `成功${okCount}`];
  if (ngCount > 0) statsParts.push(`失敗${ngCount}`);
  if (ndCount > 0) statsParts.push(`データなし${ndCount}`);
  if (nrCount > 0) statsParts.push(`集計未完了${nrCount}`);
  document.getElementById('active-job-stats').textContent = statsParts.join(' / ');

  // 中止ボタンの状態
  const cancelBtn = document.getElementById('cancel-job-btn');
  cancelBtn.disabled = false;
  cancelBtn.textContent = '⏹ 中止';
  cancelBtn.onclick = async () => {
    if (!confirm(`「${job.type}」を中止しますか?\n(現在処理中の日付は完了まで継続します)`)) return;
    await chrome.storage.local.set({ rms_cancel_flag: job.jobId, rms_cancel_at: Date.now() });
    cancelBtn.disabled = true;
    cancelBtn.textContent = '⏳ 中止中…';
    appendLog('bulk', `⏹ ユーザーが中止ボタンを押下 (jobId=${job.jobId})`);
  };
}

// v6.0.5: 「中止」を押したのに反応が無いジョブは、すでに止まっている(タブが閉じられた・拡張の再読み込み等)。
// 中止を押してから一定時間、ジョブの更新が無ければ表示を片付ける。
// (1日分の処理は長くても1分程度。余裕を見て 90秒)
const STALE_CANCEL_MS = 90 * 1000;

async function cleanupStaleCancelledJob(job) {
  if (!job || job.status !== 'running') return job;
  const s = await chrome.storage.local.get(['rms_cancel_flag', 'rms_cancel_at']);
  if (s.rms_cancel_flag !== job.jobId && s.rms_cancel_flag !== 'all') return job;
  const cancelAt = s.rms_cancel_at || 0;
  const lastUpdate = job.updatedAt || Date.parse(job.startedAt) || 0;   // 旧版のジョブには updatedAt が無い
  const now = Date.now();
  // 中止を押した後に更新が無く、押してから(または最後の更新から) 90秒以上たっていれば止まっている
  const noProgressSinceCancel = lastUpdate <= cancelAt || !cancelAt;
  if (noProgressSinceCancel && now - Math.max(cancelAt, lastUpdate) >= STALE_CANCEL_MS) {
    job.status = 'aborted';
    job.abortReason = '中止を押したが応答なし(すでに止まっていた)';
    job.endedAt = new Date().toISOString();
    await chrome.storage.local.set({ [ACTIVE_JOB_KEY]: job });
    await chrome.storage.local.remove(['rms_cancel_flag', 'rms_cancel_at']);
    appendLog('bulk', `🧹 応答の無いジョブを片付けました (「${job.type}」は既に止まっていました)`);
  }
  return job;
}

async function refreshActiveJob() {
  try {
    const s = await chrome.storage.local.get([ACTIVE_JOB_KEY]);
    const job = await cleanupStaleCancelledJob(s[ACTIVE_JOB_KEY] || null);
    renderActiveJob(job);
  } catch (_) {}
}
// popup を開いている間は 15秒ごとに確認(中止中のまま固まらないように)
setInterval(() => { refreshActiveJob(); }, 15 * 1000);
(async () => { await refreshActiveJob(); })();

// active_jobの変化を購読してリアルタイム更新
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[ACTIVE_JOB_KEY]) {
    renderActiveJob(changes[ACTIVE_JOB_KEY].newValue || null);
  }
});

// ページコンテキストから飛んでくるログメッセージを受信して保存
// (popup側でリスナー登録。ただしpopupが閉じてるとリスナーが居なくなるので、
//  page context内のlog()関数はchrome.storage.localへ直接書く方式も併用する)
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type === 'rms-log') {
    appendLog(msg.panel || 'page', msg.text, { progress: msg.progress, tabId: sender?.tab?.id });
  } else if (msg?.type === 'rms-log-detail') {
    // API呼び出しなど詳細ログ用
    appendLog(msg.cat || 'detail', msg.text, msg.extra);
  }
});

// 拡張内部のconsole.error/warnも記録(popup側で発生したもの)
const _origConsoleError = console.error;
console.error = function (...args) {
  try { appendLog('error', args.map(a => {
    if (a instanceof Error) return `${a.name}: ${a.message}\n${a.stack || ''}`;
    if (typeof a === 'object') return JSON.stringify(a);
    return String(a);
  }).join(' ')); } catch (_) {}
  _origConsoleError.apply(console, args);
};
const _origConsoleWarn = console.warn;
console.warn = function (...args) {
  try { appendLog('warn', args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')); } catch (_) {}
  _origConsoleWarn.apply(console, args);
};

// 起動時に件数表示を更新
(async () => { updateLogCount(await getLogCount()); })();

function setStatus(panelPrefix, msg, append = true) {
  const el = $(`${panelPrefix}-status`);
  if (!el) return;  // 対応する個別タブが無い(④など)場合は何もしない
  if (append) el.textContent += '\n' + msg;
  else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(panelPrefix, pct) {
  const el = $(`${panelPrefix}-progress`);
  if (!el) return;  // 対応する個別タブが無い(④など)場合は何もしない
  el.style.width = pct + '%';
}

// ========== ログをコピー / クリア ==========
async function buildLogReport() {
  const stored = await chrome.storage.local.get([LOG_KEY]);
  const logs = stored[LOG_KEY] || [];
  const manifest = chrome.runtime.getManifest();

  // タブ情報も収集
  let tabsInfo = 'タブ取得失敗';
  try {
    const tabs = await chrome.tabs.query({});
    const relevant = tabs.filter(t => t.url && (t.url.includes('rakuten.co.jp')));
    tabsInfo = relevant.map(t => `  [${t.id}] ${t.active ? '*' : ' '} ${t.url?.slice(0, 100)}`).join('\n') || '  (該当タブなし)';
  } catch (_) {}

  // 現在の入力状況
  const inputs = {
    'bulk-start': $('bulk-start')?.value,
    'bulk-end': $('bulk-end')?.value,
    'is-period': $('is-period')?.value,
    'is-device': $('is-device')?.value,
    'is-tax': $('is-tax')?.value,
    'is-interval': $('is-interval')?.value,
    'rppAll-interval': $('rppAll-interval')?.value,
    'rppItem-timeout': $('rppItem-timeout')?.value,
    'rppKw-timeout': $('rppKw-timeout')?.value
  };

  const header = `=== RMS一括ダウンローダー ログレポート ===
出力日時: ${new Date().toISOString()}
拡張: ${manifest.name} v${manifest.version}
UA: ${navigator.userAgent}

[Rakuten関連タブ]
${tabsInfo}

[現在のUI設定]
${Object.entries(inputs).map(([k, v]) => `  ${k}: ${v ?? '(空)'}`).join('\n')}

[ログ: ${logs.length}件]
`;
  const body = logs.map(l => {
    const time = l.t.replace('T', ' ').replace(/\.\d{3}Z$/, '');
    let line = `[${time}] (${l.cat}) ${l.msg}`;
    if (l.extra && Object.keys(l.extra).length) {
      line += ` | ${JSON.stringify(l.extra)}`;
    }
    return line;
  }).join('\n');

  return header + body + '\n=== ログレポート終わり ===';
}

$('bulk-copylog')?.addEventListener('click', async () => {
  const btn = $('bulk-copylog');
  try {
    const report = await buildLogReport();
    await navigator.clipboard.writeText(report);
    btn.textContent = '✅ コピーしました';
    btn.classList.add('copied');
    setTimeout(() => {
      btn.textContent = '📋 ログをコピー';
      btn.classList.remove('copied');
    }, 2000);
  } catch (e) {
    // fallback: textareaに入れて手動コピー
    try {
      const report = await buildLogReport();
      const ta = document.createElement('textarea');
      ta.value = report;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      btn.textContent = '✅ コピー(fallback)';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = '📋 ログをコピー';
        btn.classList.remove('copied');
      }, 2000);
    } catch (e2) {
      btn.textContent = '❌ コピー失敗';
      _origConsoleError('log copy failed', e2);
    }
  }
});

$('bulk-clearlog')?.addEventListener('click', async () => {
  if (!confirm('すべてのログを消去します。よろしいですか?')) return;
  await clearLogs();
  const btn = $('bulk-clearlog');
  btn.textContent = '✅ クリア完了';
  setTimeout(() => { btn.textContent = '🗑️ ログをクリア'; }, 1500);
});

// タブ切替
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $(`panel-${tab.dataset.panel}`).classList.add('active');
  });
});

// 初期日付: 保存された日付があれば復元、無ければ開始日=空欄/終了日=昨日
const DATE_LOCK_KEY = 'rms_dl_date_lock';
const fmtDate = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

async function loadSavedDates() {
  try {
    const s = await chrome.storage.local.get([DATE_LOCK_KEY]);
    return s[DATE_LOCK_KEY] || null; // {startDate, endDate} or null
  } catch (_) { return null; }
}

async function applyInitialDates() {
  const t = new Date();
  const y = new Date(t); y.setDate(y.getDate() - 1);
  const yesterday = fmtDate(y);

  const saved = await loadSavedDates();
  const initStart = saved?.startDate || '';
  const initEnd   = saved?.endDate   || yesterday;

  ['bulk-end', 'rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end', 'cpn-end'].forEach(id => {
    const el = $(id); if (el) el.value = initEnd;
  });
  ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start', 'cpn-start'].forEach(id => {
    const el = $(id); if (el) el.value = initStart;
  });

  // ロック表示更新
  updateDateLockUI(!!saved);
  refreshEmptyHighlight();
}

function updateDateLockUI(locked) {
  const badge = $('date-lock-badge');
  if (badge) badge.style.display = locked ? 'inline-block' : 'none';
  ['bulk-start', 'bulk-end'].forEach(id => {
    const el = $(id);
    if (!el) return;
    if (locked) el.classList.add('date-locked');
    else el.classList.remove('date-locked');
  });
  const saveBtn = $('bulk-savedate');
  if (saveBtn) {
    if (locked) {
      saveBtn.textContent = '✅ 保存中(再保存で更新)';
      saveBtn.classList.add('locked');
    } else {
      saveBtn.textContent = '💾 日付を保存(固定)';
      saveBtn.classList.remove('locked');
    }
  }
}

// 起動時に実行(awaitできないので即時呼び出し)
applyInitialDates();

// 開始日が空かどうかで背景色を切り替える
const START_DATE_IDS = ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start', 'cpn-start'];
function refreshEmptyHighlight() {
  START_DATE_IDS.forEach(id => {
    const el = $(id);
    if (!el) return;
    if (el.value) el.classList.remove('empty-required');
    else el.classList.add('empty-required');
  });
}
// 初期表示で適用
refreshEmptyHighlight();
// 各開始日inputが変更されたら再判定
START_DATE_IDS.forEach(id => {
  const el = $(id);
  if (el) {
    el.addEventListener('input', refreshEmptyHighlight);
    el.addEventListener('change', refreshEmptyHighlight);
  }
});

// 上部の一括期間を変更したら、下の各タブの日付も同期(空欄の時は同期しない)
function syncBulkDatesToTabs() {
  const s = $('bulk-start').value;
  const e = $('bulk-end').value;
  if (s) ['rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start', 'cpn-start'].forEach(id => { const el=$(id); if(el) el.value = s; });
  if (e) ['rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end', 'cpn-end'].forEach(id => { const el=$(id); if(el) el.value = e; });
  refreshEmptyHighlight();
}
$('bulk-start').addEventListener('change', () => { syncBulkDatesToTabs(); resetDoneFlags(); });
$('bulk-end').addEventListener('change', () => { syncBulkDatesToTabs(); resetDoneFlags(); });

// ========== 日付保存(固定) / 解除 ==========
$('bulk-savedate')?.addEventListener('click', async () => {
  const startDate = $('bulk-start').value;
  const endDate = $('bulk-end').value;
  if (!startDate && !endDate) {
    setBulkHint('❌ 保存する日付を入力してください', true);
    return;
  }
  try {
    await chrome.storage.local.set({
      [DATE_LOCK_KEY]: { startDate, endDate }
    });
    updateDateLockUI(true);
    setBulkHint(`✅ 保存しました (${startDate || '(空)'} 〜 ${endDate || '(空)'})`);
    appendLog('lock', `日付保存: ${startDate} 〜 ${endDate}`);
  } catch (e) {
    setBulkHint(`❌ 保存失敗: ${e.message}`, true);
  }
});

$('bulk-cleardate')?.addEventListener('click', async () => {
  try {
    await chrome.storage.local.remove([DATE_LOCK_KEY]);
    updateDateLockUI(false);
    setBulkHint('🔓 日付の固定を解除しました');
    appendLog('lock', `日付固定を解除`);
  } catch (e) {
    setBulkHint(`❌ 解除失敗: ${e.message}`, true);
  }
});

// 一括ヒント表示
function setBulkHint(msg, isError = false) {
  const el = $('bulk-hint');
  el.textContent = msg;
  el.style.color = isError ? '#a01010' : '#806000';
}

// v6.0.9: 楽天RMSのログイン切れで止まったときの表示 (完了マーカーは付けない)
function loginHintText(response) {
  return `🔑 楽天RMSのログインが切れています。ログインし直してから、${response?.next || 'もう一度実行してください'}`;
}

// ========== 📅 前日〜31日前を自動セット ==========
// v6.0.7: 30日前 → 31日前 に変更。
// RPP の 720時間の売上は「クリック日」に計上され、その日の最後のクリックから720時間(30日)後まで増え続ける。
// D日の数字が出そろうのは D+31日 以降なので、毎日 31日前まで取り直せば、
// 一番古い日は「出そろった数字」で月別フォルダに上書きされる。(30日前までだと常に1日分足りなかった)
// ※ボタンの id (bulk-preset-30days) は互換のため変えない
const PRESET_DAYS_BACK = 31;
$('bulk-preset-30days')?.addEventListener('click', () => {
  const today = new Date();
  const end = new Date(today); end.setDate(end.getDate() - 1);                       // 昨日
  const start = new Date(today); start.setDate(start.getDate() - PRESET_DAYS_BACK);  // 31日前
  $('bulk-start').value = fmtDate(start);
  $('bulk-end').value = fmtDate(end);
  syncBulkDatesToTabs();
  setBulkHint(`📅 期間セット: ${fmtDate(start)} 〜 ${fmtDate(end)} (${PRESET_DAYS_BACK}日分)`);
  appendLog('preset', `前日〜${PRESET_DAYS_BACK}日前を自動セット: ${fmtDate(start)} 〜 ${fmtDate(end)}`);
});

// ========== 完了通知 ON/OFF 切替 ==========
const NOTIFY_ENABLED_KEY = 'rms_notify_enabled';
(async () => {
  try {
    const s = await chrome.storage.local.get([NOTIFY_ENABLED_KEY]);
    const el = $('notify-enabled');
    if (!el) return;
    // 初回(未設定)は true 扱い
    el.checked = s[NOTIFY_ENABLED_KEY] !== false;
  } catch (_) {}
})();
$('notify-enabled')?.addEventListener('change', async (e) => {
  const enabled = !!e.target.checked;
  try {
    await chrome.storage.local.set({ [NOTIFY_ENABLED_KEY]: enabled });
    appendLog('notify', `🔔 デスクトップ通知: ${enabled ? 'ON' : 'OFF'}`);
  } catch (_) {}
});

// ========== 保存先フォルダ ステータス行 ==========
// fsstore.js の AMZ_FS を background 経由で問い合わせ、ステータスを表示する。
// 未設定 / 要許可なら folder.html を開く。
const FS_STATE_KEY = 'rms_fs_state';    // folder.js が書き込むキー
const FS_NAME_KEY  = 'rms_fs_name';

// 現在の fs 状態をキャッシュ(ボタン押下時のバリデーションで使う)
let __fsCurrentState = { state: 'none', name: null };

// 保存先タブ(folder.html)を開く。既にあればそれを前面に出す(重複して開かない)。
// v6.0.1: ピン留めで開く。このタブが全部閉じると約5秒後に書き込み許可が切れるため、
//         取得中は開いたままにしておく。
const FOLDER_PAGE_URL = chrome.runtime.getURL('folder.html');

async function findFolderTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(t => (t.url || t.pendingUrl || '').startsWith(FOLDER_PAGE_URL)) || null;
}

async function openFolderPage({ active = true } = {}) {
  try {
    const found = await findFolderTab();
    if (found) {
      if (active) await chrome.tabs.update(found.id, { active: true });
      return found;
    }
    return await chrome.tabs.create({ url: FOLDER_PAGE_URL, active, pinned: true });
  } catch (e) {
    appendLog('fs', `⚠ folder.html を開けません: ${e.message}`);
    return null;
  }
}

function applyFsRow(state, name) {
  __fsCurrentState = { state, name: name || null };
  const row = $('fs-row');
  const nameEl = $('fs-name');
  const btn = $('fs-set-btn');
  const hint = $('fs-hint');
  if (!row || !nameEl || !btn) return;

  row.classList.remove('granted', 'warn', 'none');
  if (state === 'granted') {
    row.classList.add('granted');
    nameEl.textContent = name || '(名前不明)';
    nameEl.title = name || '';
    btn.textContent = '変更';
    if (hint) hint.style.display = 'none';
  } else if (state === 'none') {
    row.classList.add('none');
    nameEl.textContent = '未設定(クリックで設定)';
    nameEl.title = '';
    btn.textContent = '設定';
    if (hint) hint.style.display = 'block';
  } else {
    // 'prompt' or 'denied'
    row.classList.add('warn');
    nameEl.textContent = `${name || '(保存先)'}:要許可`;
    nameEl.title = name || '';
    btn.textContent = '許可';
    if (hint) hint.style.display = 'block';
  }
}

async function refreshFsStatus() {
  // background 経由で問い合わせ(SWで AMZ_FS.status() を呼ぶ)
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'fs-status' }, (resp) => {
        if (chrome.runtime.lastError || !resp?.ok) {
          applyFsRow('none', null);
          resolve({ state: 'none' });
          return;
        }
        applyFsRow(resp.state, resp.name);
        resolve({ state: resp.state, name: resp.name });
      });
    } catch (_) {
      applyFsRow('none', null);
      resolve({ state: 'none' });
    }
  });
}

// 初期表示
refreshFsStatus();

// 「設定/変更/許可」ボタン
$('fs-set-btn')?.addEventListener('click', () => {
  openFolderPage();
});

// folder.js が storage に書き込むので、変化を購読してリアルタイム反映
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[FS_STATE_KEY] || changes[FS_NAME_KEY]) {
    // folder.js は state と name を同時に書き込む想定だが、片方だけ来ることもあるので再問い合わせ
    refreshFsStatus();
  }
});

// popup を開くたびに最新を取る(Chrome再起動後に prompt になっているケースを検出)
window.addEventListener('focus', () => { refreshFsStatus(); });

// ========== ボタン押下時の事前チェック ==========
// granted でなければ folder.html を開き、false を返す(DL開始しない)
async function ensureFsGranted() {
  const st = await refreshFsStatus();
  if (st.state === 'granted') return true;
  const msg = st.state === 'none'
    ? '保存先フォルダがまだ設定されていません。設定ページを開きます。'
    : '保存先フォルダの書き込み許可が切れています(Chrome再起動後など)。設定ページを開くので「許可」を押してください。';
  setBulkHint(`❌ ${msg}`, true);
  appendLog('fs', `❌ 事前チェック失敗(state=${st.state}) → folder.html を開く`);
  openFolderPage();
  return false;
}

// ========== 一括: 必要なページを開く ==========
const REQUIRED_URLS = [
  { url: 'https://datatool.rms.rakuten.co.jp/realtime/item', match: 'datatool.rms.rakuten.co.jp/realtime/item' },
  { url: 'https://ad.rms.rakuten.co.jp/rpp/reports', match: 'ad.rms.rakuten.co.jp/rpp/reports' },
  { url: 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports', match: 'ad.rms.rakuten.co.jp/cpnadv/performance_reports' }
];

$('bulk-open').addEventListener('click', async () => {
  $('bulk-open').disabled = true;
  setBulkHint('🔍 既存タブを確認中…');
  appendLog('bulk', `🔘 一括オープン押下`);
  try {
    const tabs = await chrome.tabs.query({});
    appendLog('bulk', `現在のタブ数: ${tabs.length}`);

    // 楽天関連タブを全てログに出力(デバッグ用)
    const rakutenTabs = tabs.filter(t => t.url && t.url.includes('rakuten'));
    appendLog('bulk', `楽天関連タブ ${rakutenTabs.length}件:`);
    for (const t of rakutenTabs) {
      appendLog('bulk', `  [${t.id}] ${t.url?.slice(0, 100)}`);
    }

    let opened = 0, existing = 0, errored = 0;
    const results = [];

    for (let i = 0; i < REQUIRED_URLS.length; i++) {
      const u = REQUIRED_URLS[i];
      setBulkHint(`🔄 [${i + 1}/${REQUIRED_URLS.length}] ${u.match.slice(0, 40)}…`);
      try {
        const found = tabs.find(t => t.url && t.url.includes(u.match));
        if (found) {
          existing++;
          appendLog('bulk', `  ☑ 既存タブあり: ${u.match} → tabId=${found.id}`);
          results.push(`☑ ${shortLabel(u.match)}`);
        } else {
          appendLog('bulk', `  ➕ 新規オープン試行: ${u.url}`);
          const newTab = await chrome.tabs.create({ url: u.url, active: false });
          appendLog('bulk', `    → 作成成功 tabId=${newTab?.id ?? '?'}`);
          opened++;
          results.push(`➕ ${shortLabel(u.match)}`);
        }
      } catch (perUrlErr) {
        errored++;
        appendLog('bulk', `  ❌ ${u.url} で失敗: ${perUrlErr.message}`);
        results.push(`❌ ${shortLabel(u.match)}`);
      }
      // ループ間に小休止(Chromeのタブ作成連打対策)
      if (i < REQUIRED_URLS.length - 1) await new Promise(r => setTimeout(r, 300));
    }
    // v6.0.1: 保存先タブもピン留めで開いておく(取得中に書き込み許可が切れないように)
    try {
      const hadFolderTab = !!(await findFolderTab());
      await openFolderPage({ active: false });
      results.push(hadFolderTab ? '☑ 保存先' : '📌 保存先');
      appendLog('bulk', hadFolderTab ? '  ☑ 保存先タブあり' : '  📌 保存先タブをピン留めで開きました');
    } catch (e) {
      appendLog('bulk', `  ⚠ 保存先タブを開けません: ${e.message}`);
    }
    appendLog('bulk', `一括オープン完了: 既存${existing} 新規${opened} 失敗${errored}`);
    setBulkHint(`✅ 既存${existing}/新規${opened}${errored ? `/失敗${errored}` : ''}  ${results.join(' ')}`);
  } catch (e) {
    appendLog('bulk', `❌ 一括オープン全体エラー: ${e.message}`);
    setBulkHint(`❌ エラー: ${e.message}`, true);
  } finally {
    $('bulk-open').disabled = false;
  }
});

// URLマッチ文字列を短い表示名に
function shortLabel(match) {
  if (match.includes('datatool')) return '商品別売上';
  if (match.includes('cpnadv')) return 'クーポン広告';
  if (match.includes('rpp')) return 'RPP';
  return match.slice(0, 20);
}

// ========== 一括: 4種類まとめてダウンロード ==========
// ========== 日付バリデーション共通ヘルパー ==========
function validateBulkDates() {
  const startDate = $('bulk-start').value;
  const endDate = $('bulk-end').value;
  if (!startDate) { setBulkHint('❌ 開始日を入力してください', true); return null; }
  if (!endDate) { setBulkHint('❌ 終了日を入力してください', true); return null; }
  if (startDate > endDate) { setBulkHint('❌ 開始日が終了日より後になっています', true); return null; }
  syncBulkDatesToTabs();
  return { startDate, endDate };
}

// 進行中ジョブがあるか確認。あれば確認ダイアログ → falseで中止
async function checkOngoingJobBeforeStart() {
  try {
    const s = await chrome.storage.local.get(['rms_active_job']);
    const job = s.rms_active_job;
    if (job && job.status === 'running') {
      const done = job.days.filter(d => d.status === 'ok' || d.status === 'ng').length;
      const total = job.days.length;
      const proceed = confirm(
        `⚠ 進行中のジョブがあります:\n\n` +
        `「${job.type}」 ${done}/${total} 完了\n\n` +
        `新しいジョブを開始すると2つが同時に走り、` +
        `同じファイルが重複してDLされる可能性があります。\n\n` +
        `本当に新規ジョブを開始しますか?\n\n` +
        `(中止したい場合は「キャンセル」を押し、進行中のジョブの「⏹ 中止」ボタンを使ってください)`
      );
      return proceed;
    }
  } catch (_) {}
  return true;
}

// ========== 該当URLのタブを探す(無ければ新規) ==========
async function getOrCreateJobTab(job) {
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(t => t.url && t.url.includes(job.urlMatch));
  if (tab) return tab;
  appendLog('bulk', `  ⚠ ${job.name}用のタブが見つかりません。新規オープンします: ${job.ensureUrl}`);
  tab = await chrome.tabs.create({ url: job.ensureUrl, active: false });
  const start = Date.now();
  while ((Date.now() - start) < 15000) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete') return t2;
    } catch (_) {
      const refreshed = (await chrome.tabs.query({})).find(t => t.url && t.url.includes(job.urlMatch));
      if (refreshed) return refreshed;
    }
  }
  return tab;
}

// ========== ジョブ実行共通ヘルパー ==========
// jobs配列を順次実行する。タブをアクティブにしない(ポップアップが閉じるのを防ぐ)
async function runJobsSequentially(jobs, label) {
  let okCount = 0, ngCount = 0;
  appendLog('bulk', `${label} 開始 (${jobs.length}種類)`);

  for (let i = 0; i < jobs.length; i++) {
    const job = jobs[i];
    setBulkHint(`▶ [${i + 1}/${jobs.length}] ${job.name} を実行中…`);
    appendLog('bulk', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      const targetTab = await getOrCreateJobTab(job);
      if (!targetTab || targetTab.id == null) {
        throw new Error(`タブを取得できませんでした (urlMatch=${job.urlMatch})`);
      }
      const tabId = targetTab.id;
      appendLog('bulk', `  タブID=${tabId} url=${targetTab.url?.slice(0, 80)}`);

      await chrome.scripting.executeScript({
        target: { tabId },
        func: installProgressOverlay,
        args: [job.overlayTitle]
      });
      const r = (await chrome.scripting.executeScript({
        target: { tabId },
        func: job.fn,
        args: job.args
      }))[0].result;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        okCount++;
        appendLog('bulk', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ngCount++;
        appendLog('bulk', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
        console.warn(`[${job.name}]`, r?.error);
      }
    } catch (e) {
      ngCount++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      appendLog('bulk', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}\n${e.stack || ''}`);
      console.error(`[${job.name}]`, e);
    }
    // ★ジョブ間のsleepを削除。
    // sleep中のsetTimeoutコールバックはpopupのmicrotask queueに依存するため、
    // popupが閉じた瞬間にawaitが消えて後続ジョブが実行されない可能性がある。
    // 連続実行で隙を作らない方が安定する。
  }
  appendLog('bulk', `${label} 完了: 成功 ${okCount} / 失敗 ${ngCount}`);
  setBulkHint(`🎉 ${label}完了: 成功 ${okCount} / 失敗 ${ngCount}`);
  return { okCount, ngCount };
}

// ========== ① 商品別売上ボタン ==========
$('bulk-dl-is').addEventListener('click', async () => {
  appendLog('bulk', `🔘 ①商品別売上 ボタン押下`);
  const dates = validateBulkDates();
  if (!dates) return;
  if (!(await checkOngoingJobBeforeStart())) return;
  if (!(await ensureFsGranted())) return;
  const { startDate, endDate } = dates;

  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-dl-cpn').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;
  $('bulk-open').disabled = true;
  setBulkHint('🚀 商品別売上をbackgroundで実行中…');

  const payload = {
    startDate, endDate,
    period: $('is-period').value || 'daily',
    device: $('is-device').value || 'all',
    tax: $('is-tax').value || 'incl',
    filter: ($('is-filter').value || '').trim(),
    filterBy: $('is-filterBy').value || 'all',
    interval: parseFloat($('is-interval').value) || 3
  };

  // backgroundに依頼。fire-and-forget(popup閉じても継続)
  chrome.runtime.sendMessage({ type: 'run-itemsales', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `① 完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.busy) { setBulkHint(`⛔ ${response.error}`, true); }
      else if (response?.loginRequired) { setBulkHint(loginHintText(response), true); }
      else { setBulkHint(`✅ 商品別売上 完了`); markDone('is'); }
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-dl-cpn').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
    $('bulk-open').disabled = false;
  });

  appendLog('bulk', `→ backgroundへ依頼送信完了 (popup閉じても継続します)`);
  setBulkHint(`✅ background処理開始。popup閉じてもOKです`);
});

// ========== ② RPP 3種 連続ボタン ==========
$('bulk-dl-rpp').addEventListener('click', async () => {
  appendLog('bulk', `🔘 ②RPP3種 ボタン押下`);
  const dates = validateBulkDates();
  if (!dates) return;
  if (!(await checkOngoingJobBeforeStart())) return;
  if (!(await ensureFsGranted())) return;
  const { startDate, endDate } = dates;

  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-dl-cpn').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;
  $('bulk-open').disabled = true;

  const payload = {
    rppAll: {
      startDate, endDate,
      interval: parseFloat($('rppAll-interval').value) || 3,
      options: collectRppOptions('rppAll')
    },
    rppItem: {
      startDate, endDate,
      timeout: parseInt($('rppItem-timeout').value, 10) || 10,
      options: collectRppOptions('rppItem'),
      selectionType: 3, reportType: 4,
      panelPrefix: 'rppItem', reportName: '全商品レポート'
    },
    rppKw: {
      startDate, endDate,
      timeout: parseInt($('rppKw-timeout').value, 10) || 10,
      options: collectRppOptions('rppKw'),
      selectionType: 4, reportType: 3,
      panelPrefix: 'rppKw', reportName: '全キーワードレポート'
    }
  };

  // backgroundに依頼。popup閉じても継続するのでfire-and-forgetで返答待たなくてもOK
  chrome.runtime.sendMessage({ type: 'run-bulk-rpp3', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `② 完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.busy) { setBulkHint(`⛔ ${response.error}`, true); }
      else if (response?.loginRequired) { setBulkHint(loginHintText(response), true); }
      else { setBulkHint(`✅ RPP3種 完了`); markDone('rpp'); }
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-dl-cpn').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
    $('bulk-open').disabled = false;
  });

  appendLog('bulk', `→ backgroundへ依頼送信完了 (popup閉じても継続します)`);
  setBulkHint(`✅ background処理開始。popup閉じてもOKです`);
});

// ========== ③ クーポン広告 2種(商品別 + KW別) 連続ボタン ==========
$('bulk-dl-cpn').addEventListener('click', async () => {
  appendLog('bulk', `🔘 ③クーポン2種 ボタン押下`);
  const dates = validateBulkDates();
  if (!dates) return;
  if (!(await checkOngoingJobBeforeStart())) return;
  if (!(await ensureFsGranted())) return;
  const { startDate, endDate } = dates;

  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-dl-cpn').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;
  $('bulk-open').disabled = true;

  // クーポン広告の設定値はクーポンタブから取る(なければデフォルト)
  const interval = parseFloat($('cpn-interval')?.value) || 3;
  const timeout = parseInt($('cpn-timeout')?.value, 10) || 20;

  const payload = { startDate, endDate, interval, timeout };

  chrome.runtime.sendMessage({ type: 'run-bulk-cpn2', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `③ 完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.busy) { setBulkHint(`⛔ ${response.error}`, true); }
      else if (response?.loginRequired) { setBulkHint(loginHintText(response), true); }
      else { setBulkHint(`✅ クーポン2種 完了`); markDone('cpn'); }
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-dl-cpn').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
    $('bulk-open').disabled = false;
  });

  appendLog('bulk', `→ backgroundへ依頼送信完了 (popup閉じても継続します)`);
  setBulkHint(`✅ background処理開始。popup閉じてもOKです`);
});

// リアルタイムログ受信(どのパネルから来たかをmsg.panelで判定)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'rms-log') {
    setStatus(msg.panel, msg.text);
    if (typeof msg.progress === 'number') setProgress(msg.panel, msg.progress);
  }
});

// ========== 全ての広告(RPP) ==========

// フォーム値を集める(prefixで使い回す: rppAll / rppItem / rppKw)
function collectRppOptions(prefix) {
  const getRadio = name => document.querySelector(`input[name="${name}"]:checked`)?.value;
  const getCb = id => $(id)?.checked;
  return {
    periodType: parseInt(getRadio(`${prefix}-periodType`) || '0', 10),
    campaignType: getRadio(`${prefix}-campaignType`) || '1',
    reportFilter: parseInt(getRadio(`${prefix}-reportFilter`) || '1', 10),
    rankType: 1,
    allUsers: getCb(`${prefix}-allUsers`),
    newUsers: getCb(`${prefix}-newUsers`),
    existingUsers: getCb(`${prefix}-existingUsers`),
    noOfClicks: getCb(`${prefix}-noOfClicks`),
    adsalesBefore: getCb(`${prefix}-adsalesBefore`),
    cpc: getCb(`${prefix}-cpc`),
    h12: getCb(`${prefix}-h12`),
    h720: getCb(`${prefix}-h720`),
    gms: getCb(`${prefix}-gms`),
    roas: getCb(`${prefix}-roas`),
    cv: getCb(`${prefix}-cv`),
    cvr: getCb(`${prefix}-cvr`),
    cpa: getCb(`${prefix}-cpa`)
  };
}

// 既定値に戻す処理(prefixで使い回す)
// allCheckedAll: 「全ての広告」は新規・既存OFFが初期値。商品別/キーワード別は全てONが画像の状態
function resetRppForm(prefix, opts = { userAllOn: false, h12On: false }) {
  const setRadio = (name, value) => {
    const el = document.querySelector(`input[name="${name}"][value="${value}"]`);
    if (el) el.checked = true;
  };
  setRadio(`${prefix}-periodType`, '0');
  setRadio(`${prefix}-campaignType`, '1');
  setRadio(`${prefix}-reportFilter`, '1');
  const cbMap = {
    [`${prefix}-allUsers`]: true,
    [`${prefix}-newUsers`]: opts.userAllOn,
    [`${prefix}-existingUsers`]: opts.userAllOn,
    [`${prefix}-noOfClicks`]: true,
    [`${prefix}-adsalesBefore`]: true,
    [`${prefix}-cpc`]: true,
    [`${prefix}-h12`]: opts.h12On,
    [`${prefix}-h720`]: true,
    [`${prefix}-gms`]: true,
    [`${prefix}-roas`]: true,
    [`${prefix}-cv`]: true,
    [`${prefix}-cvr`]: true,
    [`${prefix}-cpa`]: true
  };
  for (const [id, val] of Object.entries(cbMap)) {
    const el = $(id);
    if (el) el.checked = val;
  }
}

// 既定値に戻すボタン(全ての広告)
$('rppAll-reset').addEventListener('click', () => {
  resetRppForm('rppAll', { userAllOn: false, h12On: false });
});

// 既定値に戻すボタン(商品別 / キーワード別)
$('rppItem-reset').addEventListener('click', () => {
  resetRppForm('rppItem', { userAllOn: true, h12On: true });
});
$('rppKw-reset').addEventListener('click', () => {
  resetRppForm('rppKw', { userAllOn: true, h12On: true });
});

// 全ての広告 ボタン
$('rppAll-run').addEventListener('click', async () => {
  const startDate = $('rppAll-start').value;
  const endDate = $('rppAll-end').value;
  const interval = parseFloat($('rppAll-interval').value) || 1;

  if (!startDate) { setStatus('rppAll', '❌ 開始日を入力してください', false); return; }
  if (!endDate) { setStatus('rppAll', '❌ 終了日を入力してください', false); return; }
  if (startDate > endDate) { setStatus('rppAll', '❌ 開始日が終了日より後になっています', false); return; }

  // RPPタブを「URL一致」で探す(アクティブでなくてもOK)
  const allTabs = await chrome.tabs.query({});
  const tab = allTabs.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
  if (!tab) {
    setStatus('rppAll', '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
  }

  const options = collectRppOptions('rppAll');

  $('rppAll-run').disabled = true;
  setStatus('rppAll', '🚀 開始…', false);
  setProgress('rppAll', 0);

  try {
    // ページにオーバーレイ進捗ウィンドウを設置
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 全ての広告 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: rppAllDownloader,
      args: [{ startDate, endDate, interval, options }]
    }))[0].result;
    if (r?.ok) setStatus('rppAll', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('rppAll', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('rppAll', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('rppAll-run').disabled = false;
  }
});

// ========== 商品別売上 ボタン ==========
$('is-run').addEventListener('click', async () => {
  const params = {
    startDate: $('is-start').value,
    endDate: $('is-end').value,
    period: $('is-period').value,
    device: $('is-device').value,
    tax: $('is-tax').value,
    filter: $('is-filter').value.trim(),
    filterBy: $('is-filterBy').value,
    interval: parseFloat($('is-interval').value) || 2
  };

  if (!params.startDate) { setStatus('is', '❌ 開始日を入力してください', false); return; }
  if (!params.endDate) { setStatus('is', '❌ 終了日を入力してください', false); return; }
  if (params.startDate > params.endDate) { setStatus('is', '❌ 開始日が終了日より後になっています', false); return; }

  // 商品別売上タブをURL一致で探す
  const allTabsIs = await chrome.tabs.query({});
  const tab = allTabsIs.find(t => t.url && t.url.includes('datatool.rms.rakuten.co.jp/realtime/item'));
  if (!tab) {
    setStatus('is', '❌ 商品別売上ページ(datatool.rms.rakuten.co.jp/realtime/item)を開いてください', false); return;
  }

  $('is-run').disabled = true;
  setStatus('is', '🚀 開始…', false);
  setProgress('is', 0);

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 商品別売上 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: itemSalesDownloader,
      args: [params]
    }))[0].result;
    if (r?.ok) setStatus('is', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('is', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('is', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('is-run').disabled = false;
  }
});

// ========== 商品別 / キーワード別(RPP 非同期レポート) 共通ハンドラ ==========
// reportType: 4 = 全商品レポート, 3 = 全キーワードレポート
// selectionType: 3 = 商品別, 4 = キーワード別
function registerRppAsyncHandler(prefix, selectionType, reportType, reportName, buttonLabelWhenDone) {
  $(`${prefix}-run`).addEventListener('click', async () => {
    const startDate = $(`${prefix}-start`).value;
    const endDate = $(`${prefix}-end`).value;
    const timeout = parseInt($(`${prefix}-timeout`).value, 10) || 120;

    if (!startDate) { setStatus(prefix, '❌ 開始日を入力してください', false); return; }
    if (!endDate) { setStatus(prefix, '❌ 終了日を入力してください', false); return; }
    if (startDate > endDate) { setStatus(prefix, '❌ 開始日が終了日より後になっています', false); return; }

    // RPPタブをURL一致で探す
    const allTabsRpp = await chrome.tabs.query({});
    const tab = allTabsRpp.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
    if (!tab) {
      setStatus(prefix, '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
    }

    const options = collectRppOptions(prefix);

    $(`${prefix}-run`).disabled = true;
    setStatus(prefix, `🚀 ${reportName} 開始…`, false);
    setProgress(prefix, 0);

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: installProgressOverlay,
        args: [`🛒 ${reportName} ダウンロード中`]
      });

      const r = (await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: rppAsyncDownloader,
        args: [{ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix: prefix, reportName }]
      }))[0].result;
      if (r?.ok) setStatus(prefix, `\n✅ ${r.filename || '完了'}`);
      else setStatus(prefix, `\n❌ ${r?.error || '不明なエラー'}`);
    } catch (e) {
      setStatus(prefix, `\n❌ 実行エラー: ${e.message}`);
    } finally {
      $(`${prefix}-run`).disabled = false;
    }
  });
}

registerRppAsyncHandler('rppItem', 3, 4, '全商品レポート');
registerRppAsyncHandler('rppKw', 4, 3, '全キーワードレポート');


// ========== クーポン広告(cpnadv) 個別タブのボタン ==========
$('cpn-run')?.addEventListener('click', async () => {
  const startDate = $('cpn-start').value;
  const endDate = $('cpn-end').value;
  const mode = document.querySelector('input[name="cpn-mode"]:checked')?.value || 'item';
  const interval = parseFloat($('cpn-interval').value) || 3;
  const timeout = parseInt($('cpn-timeout').value, 10) || 20;

  if (!startDate) { setStatus('cpn', '❌ 開始日を入力してください', false); return; }
  if (!endDate) { setStatus('cpn', '❌ 終了日を入力してください', false); return; }
  if (startDate > endDate) { setStatus('cpn', '❌ 開始日が終了日より後になっています', false); return; }

  appendLog('popup', `🔘 クーポン広告ボタン押下 (mode=${mode}, ${startDate}〜${endDate})`);

  $('cpn-run').disabled = true;
  setStatus('cpn', `🚀 backgroundに依頼中…(${mode === 'keyword' ? 'KW別 全件' : '商品別'})`, false);
  setProgress('cpn', 0);

  const payload = { startDate, endDate, mode, interval, timeout };

  chrome.runtime.sendMessage({ type: 'run-cpn', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('popup', `⚠ cpn応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
      setStatus('cpn', `\n⚠ ${chrome.runtime.lastError.message}\n(処理は継続している可能性あり)`);
    } else {
      appendLog('popup', `cpn完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.ok) {
        setStatus('cpn', `\n✅ 完了: 成功 ${response.success ?? '-'} / 失敗 ${response.fail ?? '-'}`);
      } else if (response?.loginRequired) {
        setStatus('cpn', `\n${loginHintText(response)}`);
      } else {
        setStatus('cpn', `\n❌ ${response?.error || '不明なエラー'}`);
      }
    }
    $('cpn-run').disabled = false;
  });

  setStatus('cpn', '✅ background処理開始。popup閉じてもOKです\n進捗はクーポン広告ページのオーバーレイで確認できます');
});

// ========== ④ 登録済みKW全件DL(スナップショット) ==========
$('bulk-dl-rppsnap')?.addEventListener('click', async () => {
  appendLog('bulk', `🔘 ④登録済みKW全件DL ボタン押下`);
  if (!(await checkOngoingJobBeforeStart())) return;
  if (!(await ensureFsGranted())) return;

  // 全ボタン無効化
  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-dl-cpn').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;
  $('bulk-dl-rppsnap').disabled = true;
  $('bulk-open').disabled = true;
  setBulkHint('🚀 ④登録済みKW全件DLをbackgroundで実行中…');

  chrome.runtime.sendMessage({ type: 'run-rpp-kw-snapshot', payload: { timeout: 60 } }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
      setBulkHint(`⚠ 応答エラー(処理は続いてる可能性あり。履歴で確認してください)`);
    } else {
      appendLog('bulk', `④ 完了レスポンス: ${JSON.stringify(response)}`);
      if (response?.busy) setBulkHint(`⛔ ${response.error}`, true);
      else if (response?.loginRequired) setBulkHint(loginHintText(response), true);
      else if (response?.ok) setBulkHint(`✅ ④登録済みKW全件DL 完了`);
      else setBulkHint(`❌ ④登録済みKW全件DL 失敗: ${response?.error || '不明'}`);
      if (!response?.busy && !response?.loginRequired) markDone('snap');
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-dl-cpn').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
    $('bulk-dl-rppsnap').disabled = false;
    $('bulk-open').disabled = false;
  });
});

# RMS一括ダウンローダー 引き継ぎドキュメント

**最終更新**: 2026-11-13
**現バージョン**: v6.0.11
**プロジェクト名**: rpp-downloader (ディレクトリ名もこれ)
**フォルダ名・zip名のルール**: zipの中身(拡張が入るフォルダ)は必ず `rpp-downloader/` で統一し、バージョン番号やサフィックスを付けない。配布zipの名前はバージョン付きでよい (例: `rpp-downloader-v6.0.2.zip`)。バージョンは manifest.json で管理する
**拡張の表示名**: RMS一括ダウンローダー

---

## 1. プロジェクト概要

### これは何か
Chrome拡張 (Manifest V3)。**楽天RMS** の各種レポートを「指定した期間について1日=1ファイル」でまとめてダウンロードする。
取得したファイルは **File System Access API** でユーザーが選んだフォルダに直接書き込む (v6.0.0〜)。

### 誰が使っているか
- **ゆかい屋** (shopName=`yukaiya`) と **KAIRY** (shopName=`kai-ry`) という2つの楽天ショップで利用中
- ただし **ショップごとに別の Chrome プロファイル** を立てて分離運用しているので、拡張そのものはショップ切替機能を持っていない
- (過去にショップ切替ドロップダウンを提案したが、ユーザーが分離運用で十分と判断した経緯あり)

### 取得したファイルの行き先
`ADcheck` という外部ツール(楽天・Yahoo広告の分析ツール)に取り込む。
ADcheck は **Shift_JIS CSV** をそのまま読むので、BOM追加・文字コード変換・zip展開は一切してはいけない。

---

## 2. 取得対象のレポート (7種類)

| ① 期間指定DL | 画面 | ファイル名 (v6.0.0時点) |
|---|---|---|
| 商品別売上 | datatool.rms.rakuten.co.jp/realtime/item | `YYYYMMDD_Item_SalesList.csv` (UTF-8 BOM) |
| 全ての広告 (RPP) | ad.rms.rakuten.co.jp/rpp/reports | `rpp_reports_yukaiya_YYYYMMDD.csv` (Shift_JIS) |
| 全商品レポート (RPP) | 同上 | `rpp_item_reports_yukaiya_YYYYMMDD.zip` (中にCSV) |
| 全キーワードレポート (RPP) | 同上 | `rpp_keyword_reports_yukaiya_YYYYMMDD.zip` |
| クーポン広告 商品別 (CPA) | ad.rms.rakuten.co.jp/cpnadv/performance_reports | `CouponAdvance_yukaiya_item_YYYYMMDD.zip` |
| クーポン広告 KW別 (CPA) | 同上 | `CouponAdvance_yukaiya_kw_YYYYMMDD.zip` |

| ④ スナップショット (1回/実行) | | |
|---|---|---|
| 登録済みKW全件 | ad.rms.rakuten.co.jp/rpp/items | `rpp_item_keyword_yukaiya_YYYYMMDD.csv` |

- ①〜③ は「実行日の **前日〜31日前** の31日分」を自動で取得する (v6.0.7〜。以前は30日前まで)。
- 31日前までにしている理由: RPPの720時間の売上はクリック日に計上され、D日の数字が出そろうのは D+31日以降。毎日31日前まで取り直すと、一番古い日が「出そろった数字」で月別フォルダに上書きされる。
- ④ は「実行日=当日時点」のスナップショットなので、1実行で1ファイル。
- `YYYYMMDD` は **データの日付** (集計対象日) であって取得日ではない。
- ADcheck取り込み用フォルダには、これに加えて `_getYYYYMMDD-HHMM` の取得日時サフィックスが入る。

---

## 3. 現在の保存先アーキテクチャ (v6.0.0)

### 流れ
```
injected.js (page context の downloader)
  ↓ blob 完成
  saveViaBackground(blob, {filename, day, kind, isSnapshot})
  ↓ Uint8Array → Array.from → chrome.runtime.sendMessage
  ↓ type:'save-file', payload:{filename, day, kind, isSnapshot, dataArr, mimeType}
  ↓
background.js handleSaveFile
  ↓ AMZ_FS.status() 確認 → granted
  ↓ new Uint8Array(dataArr) でバイト列復元
  ├→ AMZ_FS.writeFile('YYYY-MM-RPP', stripGetSuffix(filename), bytes)   # 月別、上書き
  └→ AMZ_FS.writeFile('ADcheck取り込み用', insertGetSuffix(filename, ts), bytes)
```

### 保存先フォルダの構造
```
{ユーザーが選んだフォルダ}/
  2026-10-CPA/             # CouponAdvance (item + kw)
    CouponAdvance_yukaiya_item_20261001.zip
    CouponAdvance_yukaiya_item_20261002.zip
    ...
    CouponAdvance_yukaiya_kw_20261001.zip
    ...
  2026-10-RPP/             # rpp_reports / rpp_item / rpp_keyword / Item_SalesList
    rpp_reports_yukaiya_20261001.csv
    rpp_item_reports_yukaiya_20261001.zip
    rpp_keyword_reports_yukaiya_20261001.zip
    20261001_Item_SalesList.csv
    ...
  2026-11-CPA/             # 月をまたぐ分は自動で別フォルダへ
  2026-11-RPP/
  ADcheck取り込み用/        # 全ファイルを取得日時サフィックス付きで保存
    rpp_reports_yukaiya_20261001_get20261111-1340.csv
    ...
    rpp_item_keyword_yukaiya_20261111_get20261111-1345.csv   # ④のスナップショットもここだけ
```

### 月別フォルダの振り分けロジック
`handleSaveFile` が呼ばれるときの引数 `day` と `kind` で決まる:
- `day`: `'2026-10-15'` → slice(0,7) で `'2026-10'`
- `kind`: `'CPA'` (CouponAdvance) or `'RPP'` (それ以外) or snapshot
- snapshot は `isSnapshot:true` + `day:null` + `kind:null` で来るので、月別には書かない

kind の決定は各 downloader 側で既にハードコードされている:
- `CouponAdvance_*` → `kind:'CPA'`
- それ以外 → `kind:'RPP'`

### 日時サフィックス処理
```js
// _getYYYYMMDD-HHMM を除去
function stripGetSuffix(filename) {
  return filename.replace(/_get\d{8}-\d{4}/, '');
}
// 拡張子前に _get を挿入
function insertGetSuffix(filename, ts) {
  const dotIdx = filename.lastIndexOf('.');
  if (dotIdx < 0) return `${filename}_get${ts}`;
  return `${filename.slice(0, dotIdx)}_get${ts}${filename.slice(dotIdx)}`;
}
```

---

## 4. バージョン履歴 (直近の大きな変更)

### v6.0.11 (2026-11-13) — 【直近】
- 仕様書「取得済みチェックを外すボタン」に合わせ、セクション見出しの右端に「✓を外す」を1つずつ置いた (📅 期間指定 = ①②③、⚡ 最新状態 = ④)
- ④ の ✓ を別キー `rms_done_flags_snap` に実行日で持つ → 日付が変わると自動で消える。日付入力の変更で消えるのは ①②③ だけ

### v6.0.10 (2026-11-13)
- 「✓ をすべて外す」ボタンを追加 (→ v6.0.11 でセクションごとのボタンに置き換え)
- アイコンを「DL」→「楽」に変更 (色はそのまま)

### v6.0.9 (2026-11-12)
- 🔑 楽天RMSのログイン切れを検知 (HTTP 401 / `system_error` などのエラー画面)。やり直さずにその場で止め、まだ取っていない日を「失敗」として履歴に残す → ログインし直して ♻ で残りだけ取れる
- エラー画面になっているタブを使わず、正しいページへ開き直す (以前はエラー画面のタブで 401 になり続けた)
- 「🔑 ログインが切れています」通知 + RMS のログイン画面を開く。popup にも次にやることを表示

### v6.0.8 (2026-11-12)
- ♻ 再取得で ② (全ての広告/全商品/全KW) の検索条件 `options` を渡していなかったバグを修正 (楽天が「検索条件に誤りがあります」HTTP 400 で拒否していた)

### v6.0.7 (2026-11-11)
- 自動セットを「前日〜31日前」に変更 (RPP 720時間の数字が出そろった日まで取るため)

### v6.0.6 (2026-11-11)
- 取得中にタブ(ウィンドウ)が閉じられたら、②③の残りの手順も止める (以前は新しいタブで続行 → やり直すと2本同時に動き、取り込み用に重複)
- 同じ取得の二重起動を防止 (2本目は ⛔ で断る)

### v6.0.5 (2026-11-11)
- 止まったジョブが popup に「実行中/中止中」のまま残る問題の修正 (中止後90秒進捗なしで片付け、拡張の更新時にも片付け)

### v6.0.4 (2026-11-11)
- 取得中の楽天のタブが閉じられたら検知して中断・通知 (以前は popup が「実行中」のまま止まって見えた)
- 楽天のタブの進捗表示に「このタブは閉じないでください」

### v6.0.3 (2026-11-11)
- HTTPエラー時に楽天の応答本文をログに残す (`httpError`)。全KWの 10/16・10/17 だけ downloadAsync が HTTP 400 になる件の調査用 (原因は未確定)

### v6.0.2 (2026-11-11)
**取り込み用に 0バイトのファイルが残る問題の修正** (詳細は CHANGES_v6.md 先頭)
- `writeFile` を3回までやり直し、サイズを確認し、失敗したら空ファイルを消す
- 月別・取り込み用のどちらか一方でも失敗したら、その日を失敗扱いにする (以前は片方成功で ✅ になっていた)

### v6.0.1 (2026-11-11)
**取得途中で「要許可」になって保存スキップされる問題の修正** (詳細は CHANGES_v6.md 先頭)
- 原因: Chrome は拡張のページが全部閉じて約5秒後に書き込み許可を取り消す。v6.0.0 は folder.html に「閉じてOK」と出していた
- 取得開始時に folder.html をピン留めで確保 (`ensureFolderTab`)
- 途中で許可が切れたら一時停止 → 通知 → 「🔑 許可」で続きから再開 (`waitForGrant`, 最大4分)

### v6.0.0 (2026-11-11)
**File System Access API に切り替え**
- 旧: `chrome.downloads.download` + Offscreen で blob URL生成 + `onDeterminingFilename` でファイル名強制
- 新: `fsstore.js` (AMZ_FS) でユーザー選択フォルダに直接書き込み
- offscreen.html / offscreen.js を削除
- manifest から `downloads` / `offscreen` パーミッションを削除
- popup上部にフォルダ状態行を追加 (未設定/要許可/granted)
- ①〜④ボタン押下時に `ensureFsGranted()` で事前チェック

### v5.14.3 (2026-11-11) — 1つ前
- `onDeterminingFilename` イベントでファイル名を強制上書きする方式 (日本語パス対応)
- 保存先: `Downloads/楽天RMS/{YYYY-MM-CPA|RPP}/` と `Downloads/楽天RMS/ADcheck取り込み用/`

### v5.14.2
- Offscreen Document を使って Service Worker から blob URL を作る (SW で `URL.createObjectURL` が使えない問題対応)

### v5.14.1
- data URL 方式 (Chrome がファイル名を無視する問題で頓挫)

### v5.13.0
- `URL.createObjectURL is not a function` エラーでDL失敗 → Offscreen方式へ

### v5.12.x
- 30日ローリングウィンドウ化 (前日〜30日前を自動セット)
- 完了時 `chrome.notifications` デスクトップ通知
- popup上部に「Chromeの『ダウンロード前に保存場所を確認』をOFFにする」ヒント

### v5.12.7
- **cpnadv API 403** エラー対応: X-XSRF-TOKEN ヘッダを cookie から抽出して付与

### v5.12.0 頃
- **cpnadv API migration**: 2026年10月に楽天がクーポン広告ページを AngularJS → React SPA に移行
  - 旧エンドポイント `/cpnadv/performance_reports/download` (form-urlencoded) → HTTP 405
  - 新エンドポイント `/cpnadv/api/downloads` (JSON + XSRF-TOKEN)
  - payload構造の変更:
    - `selectionType: 3/4` (数値) → `"ITEMS"/"KEYWORDS"` (文字列)
    - `periodType: 3` (数値) → `"SELECTED"` (文字列)
    - 構造: `{feature: '...', reportPayload: {...}}`
  - 非同期ジョブ方式: POST → jobId取得 → polling → GET `/cpnadv/api/downloads/report?jobId=XXX`

### v5.11.x
- ④ 登録済みKW全件DL (スナップショット) ボタン追加
- セクション分割: 上部「期間指定DL」/ 下部「④」で色分け (黄色)
- ①②③④ 完了マーカー (丸にチェック、日付変更でリセット)

### v5.10.x
- 「対象データなし」判定: 3回リトライで全部status=500ならnoDataとして ⚪ グレーマーク

### v5.9.x
- 「♻ 失敗分を再取得」ボタン追加
- 日付保存/固定ロック機能

### v5.8 以前
- RPP 3種連続DL
- クーポン広告 2種連続DL
- 進捗表示オーバーレイ + ⏹中止ボタン
- DL履歴 (chrome.storage.local に50件)

---

## 5. ファイル構成 (現在)

```
rpp-downloader/
  manifest.json           # v6.0.11, permissions: activeTab/scripting/tabs/storage/notifications
  background.js           # Service Worker。importScripts('fsstore.js') で AMZ_FS 使用
  injected.js             # page context に注入する downloader 群
  popup.html              # UI
  popup.js                # popup のロジック
  fsstore.js              # self.AMZ_FS。File System Access API のラッパ (DB名: rakuten_fetch_fs)
  folder.html             # 保存先フォルダ設定ページ (タブで開く)
  folder.js               # 設定ページのロジック (ピッカーID: rakuten-fetch-data)
  icons/
    icon16.png, icon48.png, icon128.png
  README.md
  CHANGES_v6.md           # v6.0.0 の変更詳細
  HANDOFF.md              # このファイル
  dev-tools/              # 拡張の動作には不要。データ確認スクリプトと動作シミュレーション (13章参照)
```

### 削除したファイル (履歴として)
- `offscreen.html`, `offscreen.js` — v5.14.2〜v5.14.3 で使用。v6.0.0 で不要になった

---

## 6. 重要なコード箇所

### background.js の主要関数
- `handleSaveFile(payload)`: ファイル保存の心臓部。v6.0.0 で `AMZ_FS.writeFile` を2回呼ぶ形に書き換え済み
- `handleItemSales(payload)`: ①
- `handleBulkRpp3(payload)`: ②
- `handleCpn(payload)`: ③の単発
- `handleBulkCpn2(payload)`: ③の連続
- `handleRetryFailed(tasks)`: ♻失敗分再取得
- `handleRppKwSnapshot(payload)`: ④
- `notify(title, message, kind)`: `chrome.notifications` で完了通知
- `getOrCreateTab(urlMatch, ensureUrl)`: 該当URLのタブを探す or 新規作成
- `runOnTab(tabId, funcName, params)`: injected.js を注入して関数を呼ぶ
- メッセージハンドラ: `fs-status` / `run-bulk-rpp3` / `run-itemsales` / `run-cpn` / `run-bulk-cpn2` / `run-retry-failed` / `run-rpp-kw-snapshot` / `save-file`

### injected.js の主要関数 (page context)
- `saveViaBackground(blob, opts)`: blob → ArrayBuffer → Array化 → sendMessage
- `rppAllDownloader(params)`: ②全ての広告 (sync、/rpp/performance_reports のCSV直接DL)
- `rppAsyncDownloader(params)`: ②全商品/全KW (async job、POST→poll→GET)
- `itemSalesDownloader(params)`: ①商品別売上 (datatool のCSV直接DL)
- `cpnadvAsyncDownloader(params)`: ③クーポン広告 (v5.12 以降の新API対応)
- `rppKeywordSnapshotDownloader(params)`: ④登録済みKW全件 (ZIPダウンロード)
- `installProgressOverlay(title)`: 進捗オーバーレイ
- `markDay(jobId, day, status)`: マス目表示更新
- `recordDailyHistory(entry)`: DL履歴に1件追加

### popup.js の構成
- 完了マーカー (DONE_KEY = 'rms_done_flags')
- ログシステム (LOG_KEY = 'rms_dl_logs', 最大2000件)
- 失敗エントリ集計 (`aggregateFailures`) + `♻失敗分を再取得` ボタン
- 進行中ジョブ表示 (`renderActiveJob`) + `⏹ 中止` ボタン
- 日付保存/固定 (`bulk-savedate`, `bulk-cleardate`)
- 保存先フォルダ ステータス行 + `ensureFsGranted()` 事前チェック
- 必要なページを一括オープン (`bulk-open`)
- ①②③④ ボタンハンドラ
- 通知ON/OFF トグル
- DL履歴表示

### fsstore.js の API
```js
self.AMZ_FS = {
  getRoot(): Promise<FileSystemDirectoryHandle | null>
  setRoot(handle): Promise<void>
  status(): Promise<{state: 'none'|'granted'|'prompt'|'denied', name?: string}>
  requestPermission(): Promise<'granted'|'prompt'|'denied'|'none'>   // 画面側専用
  writeFile(subdir, filename, data): Promise<string>                  // path文字列を返す
  fileExists(subdir, filename): Promise<boolean>
}
```
- DB名: `rakuten_fetch_fs` (amazon-downloader の `amz_suite_fs` とは別)
- データはUint8Array / Blob / 文字列を受け付ける
- SWから `requestPermission` は呼べない (ユーザー操作内でしか呼べない制約)

---

## 7. storage のキー一覧 (chrome.storage.local)

| キー | 内容 |
|---|---|
| `rms_dl_logs` | ログ (最大2000件) |
| `rms_dl_history` | DL履歴 (最大50件) |
| `rms_done_flags` | 完了マーカー `{is, rpp, cpn, snap}` |
| `rms_cancel_flag` | ⏹中止フラグ |
| `rms_cancel_at` | 中止ボタンを押した時刻 (v6.0.5〜、止まったジョブの判定用) |
| `rms_active_job` | 進行中ジョブ情報 |
| `rms_notify_enabled` | 通知ON/OFF (true/false) |
| `rms_fs_state` | 保存先の状態 ('granted'/'prompt'/'denied'/'none') — folder.js が書く |
| `rms_fs_name` | 保存先フォルダ名 — folder.js が書く |
| `rms_date_locked` | 日付固定の有効/無効 |
| `rms_saved_start_date`, `rms_saved_end_date` | 保存された日付 |

---

## 8. 既知の挙動・制限

### 正常動作だが見落としやすい
- **クーポン広告 (CPA) の CSV は UTF-8 (BOM付き)**: zip の中の CSV は楽天から届いた時点で UTF-8 BOM。RPP 系は Shift_JIS。拡張は変換しないので、どちらも楽天の元のまま
- **「対象データなし」**: その日のレポートに載るデータが無いと楽天APIがstatus=500を返す (楽天の画面では「完了 / 対象データがありません」と出る)。3回リトライで全部500ならnoDataとして ⚪ 扱いにしてファイルを生成しない
  - クーポンKW別は「キーワードからのクーポン獲得が0件の日」がこれになる。クーポン自体が取られていても、キーワード経由でなければKW別は空
  - **KAIRY はクーポンKW別が毎日 ⚪ になるのが普通** (2026-11-13 に確認: 商品別では毎日20〜40件の獲得があるが、楽天の画面で 10/14 のKW別を手動で作っても「対象データがありません」)
  - 直近の例: 11/11の取得で `CouponAdvance_kw` の 10/14, 10/20, 10/24, 10/25 の4日分がnoData
  - 履歴では ⚪ グレーマーク、エラーではない
- **休日のスナップショット**: 自動取得ツール(別運用)が休日明けに1日分だけ取ることがある。それは楽天API側の仕様で、この拡張の制御範囲外

### 楽天RMSのログイン切れ (v6.0.9〜)
- しばらく操作しないと RMS のログインが切れる (2026-11-12: ③ 終了 16:42 → ④ 18:17 で切れていた)。楽天のタブは `/rpp/system_error`、メインメニューは `?act=app_login_error` になり、API は HTTP 401 `正常な処理ができませんでした` を返す
- v6.0.9 からは 401 やエラー画面を見たらその場で止め、「🔑」通知と RMS のログイン画面 (`https://glogin.rms.rakuten.co.jp/`) を出す
- 次にやること: 1つ目が始まる前に止まったら同じボタンを押し直す / 途中で止まったら ♻ 失敗分を再取得 / ④ は ④ を押し直す
- ①〜④ は間を空けずに続けて押すのが安全

### Chrome関連の制約
- **書き込み許可は「拡張のページ(タブ)が1つでも開いている間」だけ有効**。全部閉じると約5秒後に `prompt` に戻る。Service Worker は数に入らない → folder.html をピン留めで開いておく (v6.0.1 で自動化)
- Service Worker から `requestPermission()` は呼べない → 必ず popup か folder.html 経由
- Chrome再起動後は permission が 'prompt' に戻ることがある → ユーザーが folder.html で「許可」を1回押す
- 「ダウンロード」フォルダ直下やデスクトップは Chrome が選ばせないことがある
- 拡張を削除して入れ直すと IndexedDB が消えて保存先未設定に戻る
- **保存先はショートカットではなく本物のフォルダを選ぶ** (2026-11-12 の事例): デスクトップのショートカット経由で選ぶと、ツールにはショートカットの名前が表示される。本物のフォルダ名を変えても表示が変わらない原因になった。Dropbox内の実フォルダ (`Dropbox/【0】【基本】売上データ/01-楽天/ゆかい屋/楽天-ゆかい屋-自動取得分`) から選ぶ
- 保存先フォルダの名前を変えたり移動したりしたら、必ず「変更」から選び直す (古い設定は旧パスを指したままなので保存に失敗する)

### まだ入っていない機能
- 各 downloader の戻り値に `noData` カウントが入っていない (履歴にはあるが通知サマリに出ない)
- 保存成功/失敗の月別・取り込み用の件数を通知に詳細表示する機能
- ADcheck取り込み用フォルダの自動掃除 (手で空にする運用)
- ショップ切替ドロップダウン (ユーザーが別Chromeプロファイルでの分離運用を選択)

---

## 9. ユーザーとの運用取り決め

### 毎日の運用フロー (ユーザー側)
1. 午前中に拡張アイコンをクリック
2. 「📅 前日〜31日前を自動セット」ボタン
3. 「🔗 必要なページを一括オープン」ボタン
4. 楽天RMSに未ログインなら各ページでログイン
5. 「① 商品別売上 DL開始」 → 完了通知を待つ
6. 「② RPP 3種 連続DL」 → 完了通知を待つ
7. 「③ クーポン広告 2種 連続DL」 → 完了通知を待つ
8. 「④ 登録済みKW 全件DL」 → 完了通知を待つ
9. ADcheck取り込み用フォルダの中身をADcheckに取り込む → フォルダを空にする
10. (月別フォルダは保管用なのでそのまま放置)

### 初回セットアップ
1. zipを `chrome://extensions/` で読み込み (デベロッパーモードON)
2. 拡張アイコン → popup 上部「保存先: 未設定」の「設定」ボタン
3. folder.html でフォルダを選ぶ (例: `ダウンロード/楽天データ保管`)
4. Chrome の許可ダイアログで「許可」
5. popup に戻ると緑で表示される

### Chrome再起動後
- popup を開くと「保存先: 要許可」の黄色警告が出る
- 「許可」ボタンを押すと folder.html が開く → 「🔑 このフォルダへの保存を許可」をクリック

---

## 10. 新チャットで最初に確認しておくこと

1. **現バージョン**: zipの `manifest.json` を見て `v6.0.11` (以降) か確認
2. **保存方式**: File System Access API (fsstore.js) か、chrome.downloads か
3. **Rakuten API の変化**: cpnadv API がまた変わってないか (過去にReactに移行済み)
4. **ユーザーの最新の要望**: 13章「このチャットでやったこと」と「未解決・次にやること」を参照

### 類似の兄弟プロジェクト
- **amazon-downloader** (v2.12.15): fsstore.js の元ネタ。Amazon出品者レポート用。同じユーザー所有だが別のChrome拡張
- **yahoo-downloader**: Yahoo!ショッピング版の似たツール (過去に仕様書HANDOFF-yahoo.mdを作成した)

---

## 11. プロジェクト固有の文脈

### ユーザーの呼称・好み
- ユーザー: `kaiyoshida0318@gmail.com` (@KAI と署名している)
- **返答は必ず日本語** (英語で返すと指摘される。途中で英語にならないよう注意)
- 口調: カジュアルな日本語、技術的詳細はストレートに言う
- フォーマット: 絵文字OK、コードブロックOK
- ショップ名: `yukaiya` (ゆかい屋) と `kai-ry` (KAIRY) の2ショップ運用

### 過去の意思決定
- **A. 拡張の名前は "RMS一括ダウンローダー"** (yahoo-downloader-ゆかい屋 等は却下)
- **①の filename `20260101_Item_SalesList.csv` にショップ名プレフィックスを付けない** (他の付けると後方互換性崩れる懸念で却下)
- **ショップ切替ドロップダウンは入れない** (分離運用で十分と判断)
- **保存はダウンロードフォルダではなくユーザー指定フォルダ** (v6.0.0 で実現)

---

## 12. 新チャットへの引き継ぎ要旨 (1段落版)

> これは楽天RMS (ad.rms.rakuten.co.jp, datatool.rms.rakuten.co.jp) の各種レポートを1日1ファイル・前日〜31日前の31日分で一括取得するChrome拡張 (Manifest V3)。ユーザーは `yukaiya` と `kai-ry` の2つの楽天ショップで別Chromeプロファイルで分離運用している。v6.0.0 で保存方式を `chrome.downloads` から File System Access API (`fsstore.js` の `AMZ_FS`) に切り替え済み。保存先は (1) `{選んだフォルダ}/YYYY-MM-{CPA|RPP}/` に `_get` なしで上書き保管、(2) `{選んだフォルダ}/ADcheck取り込み用/` に `_getYYYYMMDD-HHMM` 付きで全保存 (ADcheck外部ツールに取り込む用、ユーザーが取り込み後に手動で空にする運用)。CSV は Shift_JIS (ADcheckが読む形) のまま触らない。クーポン広告 (cpnadv) は2026年10月に楽天がReactに移行済みで新API `/cpnadv/api/downloads` + X-XSRF-TOKEN を使う。完了時は `chrome.notifications` でデスクトップ通知。

---

## 13. このチャットでやったこと (2026-11-11〜12)

### 保存先 (ゆかい屋)
- 現在の保存先: `Dropbox/【0】【基本】売上データ/01-楽天/ゆかい屋/楽天-ゆかい屋-自動取得分` (旧名 `…-テスト` から変更済み)
- Dropbox内に保存できる理由: `chrome.downloads` はダウンロードフォルダの中にしか書けないが、File System Access API はユーザーが選んだ任意のフォルダに書ける。別ツールで「Dropbox内は指定できない」と言われたのは `chrome.downloads` を使っていたため

### 作成した仕様書 (Claude のドキュメント、ユーザーのアカウントにある)
1. Dropbox内フォルダを保存先にする仕組みの仕様書 (タブを閉じると許可が切れる件を含む)
2. 毎日N日分のローリング取得と保存先フォルダ選択を Yahoo / Amazon の拡張に流用する仕様書
   - Amazon: スポンサープロダクト 7日 / ブランド・ディスプレイ 14日のアトリビューション+反映遅れ約3日 → N=18 推奨 (11でも可)
   - Yahoo アイテムリーチ: アトリビューション期間が不明なので N=31 を既定
- 未対応の提案: 仕様書1の fsstore の節に v6.0.2 の writeFile 再試行 (3回・サイズ確認・空ファイル削除) を追記する件 (ユーザー未回答)

### データチェック結果
- 11/11 18:01〜18:32 の取得: 取り込み用177ファイル、欠け・重複・0バイトなし。月別=取り込み用の最新コピーで一致
- 渡した補完ファイル: `補完_RPPキーワード_20261016-17.zip`、`ADcheck取り込み用_重複除去済み.zip` (177件)、0バイトだった `CouponAdvance_yukaiya_kw_20261027_get20261111-1514.zip` の差し替え
- 2025年2月の取り直しテスト: ①・全ての広告・全商品は 28/28。全KWは 26/28 (タイムアウト) → ♻再取得が HTTP 400 → v6.0.8 で修正。**v6.0.8 の再取得が実際のChromeで成功するかは未確認**

### RPP 720時間の取り直し方針
- D日の数字が出そろうのは D+31日以降に取得した時。毎日31日前まで取れば、一番古い日が確定値で上書きされる
- ユーザーの初回取り込み日時から判断した結果:
  - **2025-02 〜 2026-02**: 取り込みが D+31日以降なので確定済み。取り直し不要
  - **2026-03-01 〜 2026-10-11**: ② (RPP 3種) を月ごとに取り直す (合計約2時間)。10/12 以降は毎日の31日ローリングでカバーされる
  - 取り直した日を ADcheck に入れたとき、上書きされるか二重計上になるかを ADcheck 側で確認すること

### 未解決・次にやること
- **v6.0.9 のログイン切れ検知が実際のChromeで動くか未確認**。次にログインが切れたときのログで、🔑 で止まっているか・ログイン画面が開いたかを見る
- RMS のログイン画面の URL (`glogin.rms.rakuten.co.jp`) は確認していない。違っていたら `background.js` の `RMS_LOGIN_URL` を直す
- 2026-11-12 18:17 の ④ (ログイン切れで 401) はまだ取れていない → ログインし直して ④ を押す
- 保存先の表示名がログ上まだ `ゆかい屋-自動取得分-テスト`。ショートカット経由で選んだままの可能性 → 「変更」から本物のフォルダを選び直してもらう
- 履歴 (`rms_dl_history`) の上限は 200 件。42日 × 6種類 = 252件なので、長い期間を取ると古い ① の失敗が ♻ の対象から落ちることがある (今のところ未対応)
- 11/11 15:45 の通常取得で全KWの 10/16・10/17 だけ HTTP 400 (検索条件は付いていた)。v6.0.3 以降は楽天の応答本文がログに出るので、再発したらログで原因を見る
- ユーザーが次にデータ/ログを送ってきたら、v6.0.8 の ♻再取得 (②) が成功しているか確認する

### dev-tools/ (拡張の動作には不要)
- `scripts/extract.py`: ユーザーが送るzip (Windows で作成、ファイル名 cp932) を展開
- `scripts/check.py`: 種類別の日付の欠け、`_get` の付け方、文字コード (RPP=Shift_JIS、CPA内CSV=UTF-8 BOM)、月別=取り込み用の最新コピーかを確認
- `scripts/dedup.py`: 取り込み用フォルダで同じファイルが複数あるとき最新の `_get` だけ残す
- `test/*.js`: Node で動かす簡易シミュレーション (保存の再試行、タブが閉じた時、二重起動、再取得の options、ログイン切れ)
  - 実行: `node dev-tools/test/<名前>.js <拡張のフォルダ>` (第1引数に拡張のフォルダを渡す)
  - `clearchecks_sim.py` (v6.0.11): 「✓を外す」の仕様書テスト項目 (Python + playwright + Google Chrome。`python3 dev-tools/test/clearchecks_sim.py <拡張のフォルダ>`)
  - `login_sim.js` (v6.0.9): 401 で止まる・やり直さない・残りの日が履歴に残る・エラー画面のタブを開き直す・通知 (27項目)
  - `sim.js` は v6.0.4 以降の `chrome.tabs.onRemoved` / `runtime.onInstalled` のダミーが無くて落ちていたので足した

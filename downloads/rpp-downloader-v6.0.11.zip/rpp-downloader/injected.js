// ================================================================
// ファイル保存ヘルパー: background.js の save-file ハンドラ経由で
// (1) 月別フォルダ + (2) ADcheck取り込み用 の2か所に自動振り分け保存。
// 旧来の <a download> 直接ダウンロードは廃止(サブディレクトリ指定ができないため)。
//
// 使い方:
//   await saveViaBackground(blob, {
//     filename: 'rpp_reports_yukaiya_20261011.csv',
//     day: '2026-10-11',           // データの日付
//     kind: 'RPP',                 // 'CPA' or 'RPP'
//     isSnapshot: false            // スナップショット(KW一覧)は true にして月別保存をスキップ
//   });
// ================================================================
// v6.0.3: HTTPエラー時に楽天の応答本文(先頭200文字)もエラーに含める。
// 例: downloadAsync が HTTP 400 を返したとき、理由がログに残るようにする。
async function httpError(res, label) {
  let body = '';
  try { body = (await res.text()).replace(/\s+/g, ' ').trim().slice(0, 200); } catch (_) {}
  return new Error(`${label} HTTP ${res.status}${body ? ` 応答: ${body}` : ''}`);
}

// ================================================================
// v6.0.9: 楽天RMSのログイン切れの検知
// ログインが切れると、楽天の API は HTTP 401 を返し、ページは /rpp/system_error などのエラー画面になる。
// 以前は 401 でも3回やり直して、日ごとに失敗を積み上げていた(何度やっても同じ結果)。
// → 401 やエラー画面への転送を見たら、その場で取得を止めて「ログインし直して」と知らせる。
// ※ injected.js は同じタブに何度も読み込まれるので、ここでは const/let を使わず function だけで書く
// ================================================================
function rmsLoginProblemUrl(url) {
  return /system_error|login_error|glogin\.rms\.rakuten\.co\.jp/i.test(String(url || ''));
}
function rmsLoginError(detail) {
  return new Error(`LOGIN_REQUIRED: 楽天RMSのログインが切れています${detail ? ` (${detail})` : ''}`);
}
function isLoginError(e) {
  return String(e?.message || '').startsWith('LOGIN_REQUIRED:');
}
// 応答が 401、またはログイン画面・エラー画面に転送されていたらログイン切れとして例外にする
function checkLoginResponse(res) {
  if (!res) return;
  if (res.status === 401) throw rmsLoginError('HTTP 401');
  if (res.redirected && rmsLoginProblemUrl(res.url)) {
    let where = res.url;
    try { where = new URL(res.url).pathname; } catch (_) {}
    throw rmsLoginError(`${where} に転送されました`);
  }
}
// ログイン切れで中断するときの後片付け。
// 今の日と、まだ取っていない日をすべて「失敗」として履歴に残す
// → ログインし直したあと「♻ 失敗分を再取得」で残りの日だけ取れる(取り込み用に同じ日が2つ入らない)
async function abortJobForLogin({ jobId, historyType, days, index, err, log, success, fail }) {
  const msg = String(err?.message || '').replace(/^LOGIN_REQUIRED:\s*/, '');
  log(`  🔑 ${days[index]}: ${msg}`);
  let chain = null;
  for (let k = index; k < days.length; k++) {
    const e = (k === index) ? msg : 'ログイン切れで中断(未取得)';
    chain = recordDailyHistory({ type: historyType, day: days[k], ok: false, error: e });
    markDay(jobId, days[k], 'ng', { error: e });
  }
  if (chain) await chain;
  const skipped = days.length - index;
  log(`\n🔑 楽天RMSのログインが切れたので中断しました (保存済み ${success} / 未取得 ${skipped})。` +
      `RMSにログインし直してから「♻ 失敗分を再取得」を押してください`, 100);
  await endJob(jobId, 'aborted');
  return {
    ok: false, loginRequired: true,
    success, fail: fail + skipped,
    error: `楽天RMSのログインが切れています (${msg})`
  };
}

async function saveViaBackground(blob, { filename, day, kind, isSnapshot = false }) {
  // Blob → ArrayBuffer → Array化(sendMessage の構造化クローン対応)
  // background 側は fsstore.js (AMZ_FS.writeFile) で保存先フォルダに直接書き込み。
  const arrayBuffer = await blob.arrayBuffer();
  const dataArr = Array.from(new Uint8Array(arrayBuffer));
  const mimeType = blob.type || 'application/octet-stream';

  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({
        type: 'save-file',
        payload: {
          filename, day, kind, isSnapshot,
          mimeType,
          dataArr
        }
      }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(`保存メッセージ失敗: ${chrome.runtime.lastError.message}`));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || '保存失敗'));
          return;
        }
        resolve(response);
      });
    } catch (e) { reject(e); }
  });
}

// 1日分のDLが終わるたびに呼ぶ簡易履歴記録(直列化)
function recordDailyHistory(entry) {
  window.__rmsHistoryChain = (window.__rmsHistoryChain || Promise.resolve()).then(async () => {
    try {
      const KEY = 'rms_dl_history';
      const s = await chrome.storage.local.get([KEY]);
      const list = s[KEY] || [];
      list.unshift({ t: new Date().toISOString(), ...entry });
      if (list.length > 200) list.length = 200;
      await chrome.storage.local.set({ [KEY]: list });
    } catch (_) {}
  });
  return window.__rmsHistoryChain;
}

// =============== ジョブのライフサイクル管理 (進行中ジョブ表示用) ===============
// 進行中の1ジョブだけを `rms_active_job` に保存し、popup側に表示・中止ボタンを出す。
// 同時実行は想定しない(連続実行のみ)。

async function startJob(type, days) {
  const jobId = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const job = {
    jobId,
    type,
    startedAt: new Date().toISOString(),
    days: days.map(d => ({ day: d, status: 'pending' })),
    status: 'running',
    updatedAt: Date.now()   // v6.0.5: 止まったジョブの検知用
  };
  // 中止フラグはジョブ開始時に必ずクリア
  await chrome.storage.local.set({ rms_active_job: job });
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return jobId;
}

// 各日のステータス更新を直列化
function _jobChain() {
  window.__rmsJobChain = (window.__rmsJobChain || Promise.resolve());
  return window.__rmsJobChain;
}

function markDay(jobId, day, status, extra) {
  window.__rmsJobChain = _jobChain().then(async () => {
    try {
      const s = await chrome.storage.local.get(['rms_active_job']);
      const job = s.rms_active_job;
      if (!job || job.jobId !== jobId) return;
      const d = job.days.find(x => x.day === day);
      if (d) {
        d.status = status;
        if (extra) Object.assign(d, extra);
      }
      job.updatedAt = Date.now();
      await chrome.storage.local.set({ rms_active_job: job });
    } catch (_) {}
  });
  return window.__rmsJobChain;
}

function endJob(jobId, status) {
  window.__rmsJobChain = _jobChain().then(async () => {
    try {
      const s = await chrome.storage.local.get(['rms_active_job']);
      const job = s.rms_active_job;
      if (!job || job.jobId !== jobId) return;
      job.status = status;
      job.endedAt = new Date().toISOString();
      job.updatedAt = Date.now();
      await chrome.storage.local.set({ rms_active_job: job });
    } catch (_) {}
  });
  return window.__rmsJobChain;
}

async function isJobCancelled(jobId) {
  try {
    const s = await chrome.storage.local.get(['rms_cancel_flag']);
    // 'all' なら任意のジョブをキャンセル、または jobId一致でキャンセル
    return s.rms_cancel_flag === 'all' || s.rms_cancel_flag === jobId;
  } catch (_) { return false; }
}

function installProgressOverlay(title) {
  if (window.__rmsDLOverlay?.el?.isConnected) {
    // 既存オーバーレイを再表示してタイトル更新
    window.__rmsDLOverlay.el.style.display = 'block';
    window.__rmsDLOverlay.setTitle(title);
    window.__rmsDLOverlay.clearLog();
    window.__rmsDLOverlay.setProgress(0);
    return;
  }

  const box = document.createElement('div');
  box.id = '__rms_dl_overlay';
  Object.assign(box.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '420px',
    maxHeight: '70vh',
    background: '#ffffff',
    border: '2px solid #bf0000',
    borderRadius: '8px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.25)',
    zIndex: '2147483647',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#222',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    userSelect: 'none'
  });

  // ヘッダー(ドラッグハンドル + 閉じるボタン)
  const header = document.createElement('div');
  Object.assign(header.style, {
    padding: '8px 12px',
    background: '#bf0000',
    color: '#fff',
    fontWeight: 'bold',
    cursor: 'move',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  });
  const titleSpan = document.createElement('span');
  titleSpan.textContent = title || 'RMS一括DL 進捗';
  header.appendChild(titleSpan);

  const closeBtn = document.createElement('span');
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    cursor: 'pointer',
    padding: '0 4px',
    fontSize: '16px',
    lineHeight: '1'
  });
  closeBtn.title = '閉じる(処理は継続します)';
  closeBtn.onclick = (e) => { e.stopPropagation(); box.style.display = 'none'; };
  header.appendChild(closeBtn);

  box.appendChild(header);

  // プログレスバー
  const progTrack = document.createElement('div');
  Object.assign(progTrack.style, {
    width: '100%',
    height: '6px',
    background: '#eee',
    flexShrink: '0'
  });
  const progBar = document.createElement('div');
  Object.assign(progBar.style, {
    height: '100%',
    width: '0%',
    background: '#bf0000',
    transition: 'width 0.3s'
  });
  progTrack.appendChild(progBar);
  box.appendChild(progTrack);

  // ログ領域
  const logEl = document.createElement('div');
  Object.assign(logEl.style, {
    padding: '10px 14px',
    overflowY: 'auto',
    flex: '1',
    whiteSpace: 'pre-wrap',
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
    fontSize: '12px',
    lineHeight: '1.5',
    background: '#fafafa',
    userSelect: 'text'
  });
  logEl.textContent = '開始を待っています…';
  box.appendChild(logEl);

  document.documentElement.appendChild(box);

  // ドラッグ処理
  let dragging = false, offX = 0, offY = 0;
  header.addEventListener('mousedown', (e) => {
    dragging = true;
    const rect = box.getBoundingClientRect();
    offX = e.clientX - rect.left;
    offY = e.clientY - rect.top;
    box.style.transform = 'none';
    box.style.left = rect.left + 'px';
    box.style.top = rect.top + 'px';
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    box.style.left = (e.clientX - offX) + 'px';
    box.style.top = (e.clientY - offY) + 'px';
  });
  window.addEventListener('mouseup', () => { dragging = false; });

  window.__rmsDLOverlay = {
    el: box,
    setTitle: (t) => { titleSpan.textContent = t || 'RMS一括DL 進捗'; },
    log: (text) => {
      logEl.textContent += '\n' + text;
      logEl.scrollTop = logEl.scrollHeight;
    },
    clearLog: () => { logEl.textContent = '開始しました…'; },
    setProgress: (pct) => { progBar.style.width = Math.max(0, Math.min(100, pct)) + '%'; }
  };
}

// -------- 全ての広告(RPP) --------
async function rppAllDownloader({ startDate, endDate, interval, options, daysOverride }) {
  // chrome.storage.localに直接書き込むログ関数
  // (popupが閉じていても確実に記録される。chrome.runtime.sendMessageはpopup閉じると失敗するため)
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('rppAll', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'rppAll', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ rppAllDownloader 開始 (${startDate}〜${endDate}, interval=${interval}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    log(`❌ 日付フォーマット不正 (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付フォーマット不正' };
  }

  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) { log('❌ XSRF-TOKENが見つかりません'); return { ok: false, error: 'XSRF-TOKENが見つかりません' }; }

  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  let days;
  if (Array.isArray(daysOverride) && daysOverride.length > 0) {
    days = [...daysOverride];
    log(`📅 失敗分の再取得モード: ${days.length}日 (${days.join(', ')})`);
  } else {
    days = [];
    for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
    log(`📅 ${days.length}日分`);
  }

  // 進行中ジョブを登録(中止ボタン/進捗マス表示用)
  const jobId = await startJob('② 全ての広告', days);

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let success = 0, fail = 0;
  for (let i = 0; i < days.length; i++) {
    // 中止チェック
    if (await isJobCancelled(jobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(jobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    markDay(jobId, day, 'processing');
    try {
      // 各リクエストのペイロード: 日付以外はUIで指定したoptionsを使う
      const payload = {
        page: 1,
        selectionType: 1,
        startDate: day,
        endDate: day,
        ...options
      };
      const r = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadPerfFile', {
        method: 'POST', credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      checkLoginResponse(r);   // v6.0.9
      if (!r.ok) throw await httpError(r, '全ての広告');
      const cd = r.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      // 楽天のオリジナル: rpp_reports_yukaiya_20260629101357177.csv
      // → 末尾のDL時刻タイムスタンプを対象日(YYYYMMDD)に置換
      const dayStr = day.replaceAll('-', '');
      let fn;
      if (mt) {
        // 末尾の数字列(10桁以上)を対象日に置換
        fn = mt[1].replace(/_\d{10,}(\.[A-Za-z]+)$/, `_${dayStr}$1`);
      } else {
        fn = `rpp_reports_${dayStr}.csv`;
      }
      const blob = await r.blob();
      // 新方式: background経由で月別フォルダ + ADcheck取り込み用 の2か所に自動保存
      await saveViaBackground(blob, { filename: fn, day, kind: 'RPP', isSnapshot: false });
      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: '② 全ての広告', day, ok: true, file: fn });
      markDay(jobId, day, 'ok', { file: fn });
    } catch (e) {
      if (isLoginError(e)) {
        return await abortJobForLogin({ jobId, historyType: '② 全ての広告', days, index: i, err: e, log, success, fail });
      }
      fail++;
      log(`  ❌ ${day} ${e.message}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: '② 全ての広告', day, ok: false, error: e.message });
      markDay(jobId, day, 'ng', { error: e.message });
    }
    if (i < days.length - 1) await sleep(interval * 1000);
  }
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(jobId, 'done');
  return { ok: true, success, fail };
}

// -------- 商品別売上 --------
async function itemSalesDownloader({ startDate, endDate, period, device, tax, filter, filterBy, interval, daysOverride }) {
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('is', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'is', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ itemSalesDownloader 開始 (${startDate}〜${endDate}, period=${period}, device=${device}, tax=${tax})`);

  // 入力ガード(空文字列等を弾く)
  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    log(`❌ 日付フォーマット不正 (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付フォーマット不正' };
  }

  // YYYY-MM-DD → YYYYMMDD
  const yyyymmdd = s => s.replaceAll('-', '');
  // 月次の月初/月末
  const monthStart = s => s.slice(0, 8) + '01';
  const monthEnd = s => {
    const [y, m] = s.split('-').map(Number);
    const last = new Date(y, m, 0).getDate();
    return `${y}-${String(m).padStart(2, '0')}-${String(last).padStart(2, '0')}`;
  };

  // 分割リスト作成(日次=1日ずつ、月次=1ヶ月ずつ、range=1発)
  // daysOverride 指定時は失敗日のみ daily で再取得
  const ranges = [];
  if (Array.isArray(daysOverride) && daysOverride.length > 0) {
    for (const d of daysOverride) {
      ranges.push({ s: d, e: d, label: d });
    }
  } else if (period === 'daily') {
    const [y1, m1, d1] = startDate.split('-').map(Number);
    const [y2, m2, d2] = endDate.split('-').map(Number);
    for (let d = new Date(y1, m1 - 1, d1), e = new Date(y2, m2 - 1, d2); d <= e; d.setDate(d.getDate() + 1)) {
      const s = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      ranges.push({ s, e: s, label: s });
    }
  } else if (period === 'monthly') {
    const [y1, m1] = startDate.split('-').map(Number);
    const [y2, m2] = endDate.split('-').map(Number);
    let y = y1, m = m1;
    while (y < y2 || (y === y2 && m <= m2)) {
      const ms = `${y}-${String(m).padStart(2, '0')}-01`;
      const me = monthEnd(ms);
      ranges.push({ s: ms, e: me, label: `${y}-${String(m).padStart(2, '0')}` });
      m++; if (m > 12) { m = 1; y++; }
    }
  } else {
    ranges.push({ s: startDate, e: endDate, label: `${startDate}_${endDate}` });
  }

  log(`📅 ${ranges.length}件のDLを実行`);

  const BASE = 'https://datatool.rms.rakuten.co.jp/realtime';
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // API用のperiodパラメータ(range時もAPIはdailyでOKらしいが、一応monthlyに切り替え)
  const apiPeriod = (period === 'monthly') ? 'monthly' : 'daily';

  // 共通クエリビルダ
  const buildQuery = (s, e, extra = {}) => {
    const q = new URLSearchParams({
      period: apiPeriod,
      startDate: yyyymmdd(s),
      endDate: yyyymmdd(e),
      tax,
      device,
      filter: filter || '',
      filterBy,
      sortBy: 'sales',
      sort: 'desc',
      ...extra
    });
    return q.toString();
  };

  // 楽天の実CSVフォーマットに合わせたCSVビルダー
  // 文字列は必ず "..." で囲む、数値は囲まない、改行はCRLF
  const esc = v => {
    if (v === null || v === undefined) return '';
    const s = String(v);
    return '"' + s.replaceAll('"', '""') + '"';
  };
  const num = v => (v === null || v === undefined) ? '' : String(v);

  // YYYY-MM-DD → 「2026年04月01日」
  const jpDate = s => {
    const [y, m, d] = s.split('-');
    return `${y}年${m}月${d}日`;
  };
  // 端末ラベル
  const deviceLabel = { all: 'すべて', pc: 'PC', app: '楽天市場アプリ', sp: 'スマートフォン' }[device] || device;
  const taxLabel = tax === 'incl' ? '税込' : '税抜';

  // ファイル名: 楽天の実ファイル名パターンに合わせる
  // 例: 20260401_Item_SalesList.csv
  const fileNameFor = (s, e, label) => {
    if (period === 'daily') return `${s.replaceAll('-', '')}_Item_SalesList.csv`;
    if (period === 'monthly') return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
    return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
  };

  let success = 0, fail = 0;

  // 進行中ジョブを登録(中止ボタン/進捗マス表示用)
  const itemJobId = await startJob('① 商品別売上', ranges.map(r => r.label));

  for (let i = 0; i < ranges.length; i++) {
    if (await isJobCancelled(itemJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${ranges.length}完了)`);
      await endJob(itemJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const { s, e, label } = ranges[i];
    markDay(itemJobId, label, 'processing');
    try {
      // ① 検索(画面表示用のAPIを叩いてセッション整合を取る)
      const searchUrl = `${BASE}/get-shop-item-list?${buildQuery(s, e)}`;
      const sr = await fetch(searchUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
      checkLoginResponse(sr);   // v6.0.9
      if (!sr.ok) throw new Error('search HTTP ' + sr.status);
      await sr.json();

      // ② DL API を maxCycleNumber まで繰り返して全件取得
      let allRows = [];
      let cycle = 0, maxCycle = 0;
      do {
        const dlUrl = `${BASE}/get-shop-item-dl?${buildQuery(s, e, { size: '1000', cycleNumber: String(cycle) })}`;
        const dr = await fetch(dlUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
        checkLoginResponse(dr);   // v6.0.9
        if (!dr.ok) throw new Error('dl HTTP ' + dr.status);
        const dj = await dr.json();
        if (Array.isArray(dj.data)) allRows = allRows.concat(dj.data);
        maxCycle = dj.maxCycleNumber || 0;
        cycle++;
        if (cycle <= maxCycle) await new Promise(r => setTimeout(r, 500));
      } while (cycle <= maxCycle);

      // ③ 楽天の実CSVと同じフォーマットで組み立て
      const lines = [];
      lines.push('※この情報は店舗様および楽天市場での重要な情報となります。データの取扱には十分にご注意ください。');
      lines.push('商品別売上');
      lines.push(`表示期間,${jpDate(s)}から${jpDate(e)}`);
      lines.push(`端末,${deviceLabel}`);
      lines.push(`消費税,${taxLabel}`);
      lines.push(filter ? `キーワード,${esc(filter)}` : 'キーワード');
      lines.push('商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数');
      for (const r of allRows) {
        // API: itemName/mngNumber/itemNumber/itemPrice/units/sales/orderCount
        // CSV順: 商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数
        lines.push([
          esc(r.itemName),
          esc(r.mngNumber),
          esc(r.itemNumber),
          num(r.itemPrice),
          num(r.units),
          num(r.sales),
          num(r.orderCount)
        ].join(','));
      }
      const csv = lines.join('\r\n') + '\r\n';

      // UTF-8 BOM付き(楽天オリジナルもBOM付きUTF-8)
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });

      const fn = fileNameFor(s, e, label);
      // 新方式: background経由で2か所に自動保存。商品別売上はRPP扱い(RPPフォルダへ)
      // label は daily なら 'YYYY-MM-DD'、monthly/range なら別形式なので day は s を使う
      await saveViaBackground(blob, { filename: fn, day: s, kind: 'RPP', isSnapshot: false });

      success++;
      log(`  ✅ ${label} (${allRows.length}件) → ${fn}`, Math.round(((i + 1) / ranges.length) * 100));
      recordDailyHistory({ type: '① 商品別売上', day: label, ok: true, file: fn, rows: allRows.length });
      markDay(itemJobId, label, 'ok', { file: fn, rows: allRows.length });
    } catch (err) {
      if (isLoginError(err)) {
        return await abortJobForLogin({
          jobId: itemJobId, historyType: '① 商品別売上', days: ranges.map(r => r.label),
          index: i, err, log, success, fail
        });
      }
      fail++;
      log(`  ❌ ${label} ${err.message}`, Math.round(((i + 1) / ranges.length) * 100));
      recordDailyHistory({ type: '① 商品別売上', day: label, ok: false, error: err.message });
      markDay(itemJobId, label, 'ng', { error: err.message });
    }
    if (i < ranges.length - 1) await new Promise(r => setTimeout(r, interval * 1000));
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(itemJobId, 'done');
  return { ok: true, success, fail };
}

// -------- 商品別 / キーワード別(RPP 非同期ZIPダウンロード、1日ずつループ) --------
async function rppAsyncDownloader({ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix, reportName, daysOverride }) {
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog(panelPrefix, text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: panelPrefix, text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ ${reportName} 開始 (${startDate}〜${endDate}, selectionType=${selectionType}, timeout=${timeout}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }

  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) { log('❌ XSRF-TOKENが見つかりません'); return { ok: false, error: 'XSRF-TOKENが見つかりません' }; }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // 日付リストを作成(startDate〜endDateを1日ずつ、または daysOverride 指定)
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  let days;
  if (Array.isArray(daysOverride) && daysOverride.length > 0) {
    days = [...daysOverride];
    log(`📅 ${reportName} の失敗分を再取得: ${days.length}日 (${days.join(', ')})`);
  } else {
    days = [];
    for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
    log(`📅 ${reportName} を ${days.length}日分 順番にダウンロードします`);
  }

  // ====== 日ごとのループ ======
  let success = 0, fail = 0;
  const failedDays = [];

  const rppAsyncJobId = await startJob(`② ${reportName || 'RPP非同期'}`, days);

  for (let i = 0; i < days.length; i++) {
    if (await isJobCancelled(rppAsyncJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(rppAsyncJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    const dayNum = i + 1;
    const basePct = Math.round((i / days.length) * 100);

    log(`\n── [${dayNum}/${days.length}] ${day} ──`, basePct);
    markDay(rppAsyncJobId, day, 'processing');

    try {
      // ─ ① この日のジョブ投入前に、既存ジョブID一覧を取得 ─
      log('  🔍 既存ジョブを確認中…');
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const preJson = await pre.json();
          const list = preJson?.data?.userHistoryList || [];
          for (const j of list) existingIds.add(j.id);
        }
      } catch (_) { /* 失敗しても続行 */ }

      // ─ ② downloadAsyncでこの日のジョブ投入(startDate=endDate=day) ─
      log(`  📤 ${day}分のジョブを投入…`);
      const payload = {
        page: 1,
        selectionType,
        startDate: day,
        endDate: day,
        ...options
      };
      const asyncRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadAsync', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      checkLoginResponse(asyncRes);   // v6.0.9
      if (!asyncRes.ok) throw await httpError(asyncRes, 'downloadAsync失敗');
      const asyncJson = await asyncRes.json();
      if (asyncJson?.status !== 'SUCCESS') {
        throw new Error(`downloadAsync応答が予期せぬ形式: ${JSON.stringify(asyncJson).slice(0, 80)}`);
      }

      // ─ ③ listポーリング、この日のジョブが完了するまで待つ ─
      const pollStart = Date.now();
      const pollInterval = 1000; // 1秒ごとにポーリング(短いtimeoutに対応)
      let myJob = null;
      while ((Date.now() - pollStart) / 1000 < timeout) {
        await sleep(pollInterval);
        const elapsed = Math.round((Date.now() - pollStart) / 1000);

        try {
          const listRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
            method: 'GET', credentials: 'include',
            headers: { 'Accept': 'application/json' }
          });
          checkLoginResponse(listRes);   // v6.0.9: 401 なら待ち続けずに止める
          if (!listRes.ok) continue;
          const listJson = await listRes.json();
          const userList = listJson?.data?.userHistoryList || [];

          // 自分のジョブを特定する。
          // 楽天側で reportType の番号が変わる(以前 3/4 → 現在 13/14 等)ため、
          // reportType の固定値では照合しない。代わりに:
          //   - 投入前に存在しなかった新規ジョブ (existingIdsに無い)
          //   - startDate が対象日と一致
          // で特定し、ダウンロード時はジョブ自身の reportType を使う。
          const newJobs = userList.filter(j => {
            if (existingIds.has(j.id)) return false;
            // startDateは "YYYY-MM-DD" または "YYYY-MM-DD 00:00:00" 形式
            if (j.startDate && !j.startDate.startsWith(day)) return false;
            return true;
          });
          if (newJobs.length > 0) {
            // 最新(requestDate降順)を自分のジョブとみなす
            newJobs.sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || ''));
            // 完了(status 2/4) かつ reportTypeを持つジョブを最優先。
            // なければ完了ジョブ、それも無ければ最新ジョブを暫定保持。
            myJob = newJobs.find(j => (j.status === 2 || j.status === 4) && j.reportType != null)
                 || newJobs.find(j => j.status === 2 || j.status === 4)
                 || newJobs[0];
          }

          if (myJob) {
            if (myJob.status === 2 || myJob.status === 4) break;
            else if (myJob.status === 3) {
              // 失敗ジョブしか無い場合のみエラー。新しい候補がまだ出るかもしれないので
              // newJobsに完了/処理中が他に無いことを確認
              const hasPending = newJobs.some(j => j.status === 0 || j.status === 1);
              if (!hasPending) throw new Error(`ジョブが失敗 (id=${myJob.id}, status=3)`);
              else { myJob = null; log(`    ⏳ 生成中… (${elapsed}s経過)`); }
            }
            else log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
          } else {
            log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
          }
        } catch (e) {
          if (e.message.includes('ジョブが失敗') || isLoginError(e)) throw e;
          log(`    ⚠ ポーリング一時エラー: ${e.message}`);
        }
      }

      if (!myJob || (myJob.status !== 2 && myJob.status !== 4)) {
        throw new Error(`タイムアウト(${timeout}秒)`);
      }

      // ─ ④ ZIPを取得して保存 ─
      // ダウンロードに使う reportType は、固定値ではなく
      // 見つかったジョブ自身の reportType を使う(楽天側の番号変更に追従)
      const dlReportType = (myJob.reportType != null) ? myJob.reportType : reportType;
      const storageType = myJob.storageType || 'STAAS';
      const dlUrl = `https://ad.rms.rakuten.co.jp/rpp/api/download/report?downloadId=${myJob.id}&reportType=${dlReportType}&storageType=${storageType}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      checkLoginResponse(zipRes);   // v6.0.9
      if (!zipRes.ok) throw await httpError(zipRes, 'ZIP取得失敗');

      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      // 楽天オリジナル: rpp_item_reports_yukaiya_20260629101404836.zip
      // → 末尾DL時刻を対象日に置換
      const dayStr = day.replaceAll('-', '');
      let fn;
      if (mt) {
        fn = mt[1].replace(/_\d{10,}(\.[A-Za-z]+)$/, `_${dayStr}$1`);
      } else {
        const kind = (selectionType === 3) ? 'item' : 'keyword';
        fn = `rpp_${kind}_reports_${dayStr}.zip`;
      }

      const blob = await zipRes.blob();
      // 新方式: background経由で2か所に自動保存
      await saveViaBackground(blob, { filename: fn, day, kind: 'RPP', isSnapshot: false });

      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: `② ${reportName || 'RPP'}`, day, ok: true, file: fn });
      markDay(rppAsyncJobId, day, 'ok', { file: fn });
    } catch (err) {
      if (isLoginError(err)) {
        return await abortJobForLogin({
          jobId: rppAsyncJobId, historyType: `② ${reportName || 'RPP'}`, days, index: i, err, log, success, fail
        });
      }
      fail++;
      failedDays.push(day);
      log(`  ❌ ${day}: ${err.message}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: `② ${reportName || 'RPP'}`, day, ok: false, error: err.message });
      markDay(rppAsyncJobId, day, 'ng', { error: err.message });
    }

    // 次の日のジョブに進む前に1秒だけ待つ(連続投入でサーバーに優しく)
    if (i < days.length - 1) await sleep(1000);
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(rppAsyncJobId, 'done');

  if (fail === 0) {
    return { ok: true, success, fail, filename: `${success}件のZIPを保存しました` };
  } else {
    return {
      ok: false,
      success, fail,
      error: `成功 ${success} / 失敗 ${fail} (失敗日: ${failedDays.join(', ')})`
    };
  }
}

// -------- クーポンアドバンス広告(cpnadv) 商品別 / KW別 全件 (1日ずつループ) --------
async function cpnadvAsyncDownloader({ startDate, endDate, mode, interval, timeout, daysOverride }) {
  // chrome.storage.localに直接書き込むログ関数
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('cpn', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'cpn', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };

  const reportName = mode === 'keyword' ? 'クーポン広告 全KWレポート' : 'クーポン広告 商品別レポート';
  log(`▶ ${reportName} 開始 (${startDate}〜${endDate}, mode=${mode}, timeout=${timeout}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }

  // 新API(/cpnadv/api/downloads)は cookie の XSRF-TOKEN を X-XSRF-TOKEN ヘッダーに
  // 入れて送る必要がある(axios が自動でやっているのと同じ)。
  // ページが正しく開かれていないと cookie 自体が無効なので、ドメインチェックも行う。
  if (!/ad\.rms\.rakuten\.co\.jp/.test(location.href)) {
    log(`❌ クーポン広告ページが開かれていません`);
    log(`  🔍 現在のURL: ${location.href}`);
    log(`  💡 対処: クーポン広告ページ(https://ad.rms.rakuten.co.jp/cpnadv/performance_reports)を開いてから再実行してください`);
    return { ok: false, error: 'クーポン広告ページが開かれていません' };
  }
  // cookie XSRF-TOKEN を取得(新APIで必要)
  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  let xsrfToken = getCookie('XSRF-TOKEN');
  if (xsrfToken) {
    log(`  ✓ XSRF-TOKEN取得: ${xsrfToken.slice(0, 12)}...`);
  } else {
    log(`  ⚠ XSRF-TOKENがcookieにありません(ページ再読み込みが必要かも)`);
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  // 日付範囲(または daysOverride で失敗分のみ)
  let days;
  if (Array.isArray(daysOverride) && daysOverride.length > 0) {
    days = [...daysOverride];
    log(`📅 失敗分の再取得: ${days.length}日 (${days.join(', ')})`);
  } else {
    days = [];
    for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
    log(`📅 ${days.length}日分 順次ダウンロードします`);
  }

  // 種別パラメータ(ジョブ一覧APIのレスポンスでは数値のままなのでそちらで使う)
  const selectionTypeNum = mode === 'keyword' ? 4 : 3;
  const keywordReportType = mode === 'keyword' ? 'ALL_KEYWORDS' : null;

  // 新API(/cpnadv/api/downloads)用のJSONペイロード
  // 2026年の楽天リニューアル以降、投入APIは JSON POST + CSRFヘッダー不要に変更された
  function buildPayload(day) {
    const reportPayload = {
      selectionType: (mode === 'keyword') ? 'KEYWORDS' : 'ITEMS',
      periodType: 'SELECTED',
      startDate: day,
      endDate: day,
      campaignType: '1',
      rankType: 1,
      reportFilter: 1,
      // 表示/出力項目(ほぼ全ON = 楽天UIで「全てを選択」ONと同じ)
      adFee: true,
      adFeeAfterDiscount: false,
      aovShopXDevice720h: false,
      averageDiscountRate: true,
      bidPrice: true,
      campaignDiscountRate: false,
      consumptionRate: false,
      costPerConversion: true,
      couponAcquired: true,
      couponAcquisitionCost: true,
      couponDiscountAmount: true,
      couponUseGms: true,
      couponUsedRate: true,
      cvShopXDevice720h: true,
      cvrShopXDevice720h: true,
      discountAmountEligible: false,
      discountAmountGranted: false,
      enableExclusion: false,
      gmsShopXDevice720h: true,
      itemDiscountRate: false,
      itemRegistrationType: false,
      roasShopXDevice720h: true,
      roiShopXDevice720h: true,
      totalBudget: false,
      useCount: true
    };
    if (keywordReportType) reportPayload.keywordReportType = keywordReportType;
    return JSON.stringify({
      feature: 'CPNADV_PERFORMANCE_REPORT',
      reportPayload
    });
  }

  // 共通fetchヘッダー(新API: JSON + cookieのXSRF-TOKENをX-XSRF-TOKENヘッダーに入れる)
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/plain, */*'
  };
  if (xsrfToken) headers['X-XSRF-TOKEN'] = xsrfToken;

  let success = 0, fail = 0;
  const failedDays = [];

  const cpnJobLabel = (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別';
  const cpnJobId = await startJob(cpnJobLabel, days);

  for (let i = 0; i < days.length; i++) {
    if (await isJobCancelled(cpnJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(cpnJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    const progBase = Math.round((i / days.length) * 100);
    log(`\n── [${i + 1}/${days.length}] ${day} ──`, progBase);
    markDay(cpnJobId, day, 'processing');

    // ───── 自動リトライ: 同じ日付を最大3回まで投げ直し ─────
    const MAX_ATTEMPTS = 3;
    let attempt = 0;
    let succeeded = false;
    let lastError = null;
    let lastFn = null;

    while (attempt < MAX_ATTEMPTS && !succeeded) {
      attempt++;
      if (attempt > 1) {
        // リトライ前に少し待つ(サーバー負荷を下げる)
        const waitSec = 8;
        log(`  🔄 ${day} リトライ ${attempt}/${MAX_ATTEMPTS}(${waitSec}秒待機後に再投入)`);
        await sleep(waitSec * 1000);
        // 中止チェック
        if (await isJobCancelled(cpnJobId)) {
          log(`⏹ ユーザーが中止しました`);
          await endJob(cpnJobId, 'cancelled');
          return { ok: false, cancelled: true, success, fail, error: '中止されました' };
        }
      }
    try {
      // ─ ① 投入前のジョブIDを記録(自分のジョブを後で識別するため) ─
      log(`  🔍 既存ジョブを確認中…`);
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/api/downloads?page=1', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const preJson = await pre.json();
          const list = preJson?.data?.jobs || [];
          for (const j of list) existingIds.add(j.jobId);
        }
      } catch (_) { /* 取れなくても進む */ }

      // ─ ② この日のジョブを投入(新API: POST /cpnadv/api/downloads、JSON) ─
      // 2026年の楽天cpnadvリニューアル以降、投入APIは JSON POST + X-XSRF-TOKEN必須
      // (axiosのxsrfCookieName/xsrfHeaderName設定で自動付与される挙動を再現)
      // リトライ時は毎回cookieから取り直す(期限切れ対策)
      const freshXsrf = getCookie('XSRF-TOKEN');
      if (freshXsrf) headers['X-XSRF-TOKEN'] = freshXsrf;
      log(`  📤 ${day}分のジョブを投入…`);
      const payloadBody = buildPayload(day);
      const submitRes = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/api/downloads', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: payloadBody
      });
      checkLoginResponse(submitRes);   // v6.0.9
      if (!submitRes.ok) {
        // HTTP 400 等: 楽天のエラーメッセージを詳細ログ
        let errBody = '';
        try { errBody = await submitRes.text(); } catch (_) {}
        log(`  📄 楽天エラーレスポンス (HTTP ${submitRes.status}): ${errBody.slice(0, 600)}`);
        log(`  📄 送信ペイロード先頭: ${payloadBody.slice(0, 250)}`);
        // 「集計期間」エラー = 楽天側でまだ集計が完了してない → 後で再取得可能
        if (submitRes.status === 400 && /集計期間|までの値を指定/.test(errBody)) {
          throw new Error(`NOT_READY: 楽天側で集計未完了(あとで再取得可能)`);
        }
        throw new Error(`投入失敗 HTTP ${submitRes.status}`);
      }
      // 新API: レスポンスは JSON {status:'SUCCESS', data:{jobId:xxx}}
      // jobIdが即座に取れるので、以降のポーリングでそれを使えば確実にジョブを特定できる
      let myJobIdFromSubmit = null;
      try {
        const submitJson = await submitRes.json();
        if (submitJson?.status !== 'SUCCESS') {
          log(`  ⚠ 投入レスポンスが想定外: ${JSON.stringify(submitJson).slice(0, 200)}`);
        } else {
          myJobIdFromSubmit = submitJson?.data?.jobId;
          if (myJobIdFromSubmit) {
            log(`  ✓ ジョブ投入成功 (jobId=${myJobIdFromSubmit})`);
          }
        }
      } catch (e) {
        log(`  ⚠ 投入レスポンスのJSON解析失敗: ${e.message}`);
      }

      // ─ ③ ポーリングしてジョブ完了を待つ ─
      const tStart = Date.now();
      let myJob = null;
      while ((Date.now() - tStart) / 1000 < timeout) {
        await sleep(1000);
        const elapsed = Math.round((Date.now() - tStart) / 1000);
        const listRes = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/api/downloads?page=1', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        checkLoginResponse(listRes);   // v6.0.9
        if (!listRes.ok) { log(`    ⚠ list失敗 HTTP ${listRes.status}`); continue; }
        const listJson = await listRes.json();
        const allJobs = listJson?.data?.jobs || [];

        // 自分のジョブを特定: 投入APIから jobId が返っていればそれを優先、
        // なければ従来通り「新規+属性一致」で探す(fallback)
        if (myJobIdFromSubmit) {
          myJob = allJobs.find(j => j.jobId === myJobIdFromSubmit) || null;
        } else {
          const matchKwType = mode === 'keyword' ? 'ALL_KEYWORDS' : null;
          const newJobs = allJobs.filter(j => {
            if (existingIds.has(j.jobId)) return false;
            if (j.selectionType !== selectionTypeNum) return false;
            // keywordReportTypeチェック(商品別ならnull or undef、KW別ならALL_KEYWORDS)
            if (mode === 'keyword' && j.keywordReportType !== matchKwType) return false;
            if (mode === 'item' && j.keywordReportType && j.keywordReportType !== '') return false;
            return true;
          });
          if (newJobs.length > 0) {
            // sysCreateDatetime降順で最新
            newJobs.sort((a, b) => (b.sysCreateDatetime || '').localeCompare(a.sysCreateDatetime || ''));
            myJob = newJobs.find(j => j.status === 300) || newJobs[0];
          }
        }

        if (myJob) {
          if (myJob.status === 300) break;  // 完了
          if (myJob.status >= 400) {
            // 楽天側でジョブが失敗 → メッセージから「対象データなし」を判定
            log(`    🔍 失敗ジョブの詳細: ${JSON.stringify(myJob)}`);
            // myJob内のあらゆるメッセージフィールドをチェック
            const jobJsonStr = JSON.stringify(myJob);
            const isNoData = /対象データ|該当データ|データがあり|データが存在|ありません|no\s*data|no_data/i.test(jobJsonStr);
            if (isNoData) {
              // 「対象データがありません」= データなし。エラーではなくスキップ扱い
              throw new Error(`NO_DATA: 対象データがありません (jobId=${myJob.jobId})`);
            }
            // ジョブ詳細を取得しようと試みる(エンドポイント推測)
            try {
              const detRes = await fetch(`https://ad.rms.rakuten.co.jp/cpnadv/api/downloads/${myJob.jobId}`, {
                method: 'GET', credentials: 'include', headers: { 'Accept': 'application/json' }
              });
              if (detRes.ok) {
                const detTxt = await detRes.text();
                log(`    🔍 ジョブ詳細レスポンス (HTTP ${detRes.status}): ${detTxt.slice(0, 500)}`);
                // 詳細レスポンスでも「対象データなし」をチェック
                if (/対象データ|該当データ|データがあり|データが存在|ありません/i.test(detTxt)) {
                  throw new Error(`NO_DATA: 対象データがありません (jobId=${myJob.jobId})`);
                }
              } else {
                log(`    🔍 ジョブ詳細取得不可 (HTTP ${detRes.status})`);
              }
            } catch (e) {
              if (e.message?.startsWith('NO_DATA:')) throw e;  // 投げ直し
              log(`    🔍 ジョブ詳細取得例外: ${e.message}`);
            }
            throw new Error(`ジョブ失敗 (status=${myJob.status}, jobId=${myJob.jobId})`);
          }
          // 100/200 は処理中
          log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
        } else {
          log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
        }
      }

      if (!myJob || myJob.status !== 300) {
        throw new Error(`タイムアウト(${timeout}s)`);
      }

      // ─ ④ ZIPを取得して保存 ─
      const dlUrl = `https://ad.rms.rakuten.co.jp/cpnadv/api/downloads/report?jobId=${myJob.jobId}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      checkLoginResponse(zipRes);   // v6.0.9
      if (!zipRes.ok) throw await httpError(zipRes, 'ZIP取得失敗');

      // 楽天のレスポンスは商品別/KW別で同じファイル名パターンになるので、
      // こちら側で「item」or「kw」と「日付」を明示したファイル名を生成する。
      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      const original = mt ? mt[1] : '';
      // 元ファイル名からショップ名を抽出(例: ...__yukaiya_20260629... → yukaiya)
      let shopName = 'shop';
      const sm = original.match(/PerformanceReport_+([A-Za-z0-9_-]+?)_\d{10,}/);
      if (sm) shopName = sm[1];
      const dayStr = day.replaceAll('-', '');
      const modeLabel = (mode === 'keyword') ? 'kw' : 'item';
      const fn = `CouponAdvance_${shopName}_${modeLabel}_${dayStr}.zip`;

      const blob = await zipRes.blob();
      // 新方式: background経由で2か所に自動保存(クーポン広告はCPAフォルダへ)
      await saveViaBackground(blob, { filename: fn, day, kind: 'CPA', isSnapshot: false });

      // 成功!
      succeeded = true;
      lastFn = fn;
      log(`  ✅ ${day} → ${fn}${attempt > 1 ? ` (リトライ${attempt}回目で成功)` : ''}`, Math.round(((i + 1) / days.length) * 100));
    } catch (err) {
      if (err.message?.startsWith('NO_DATA:')) {
        // 対象データなし → リトライしない、エラーでもない
        log(`  ⚪ ${day}: 対象データがありません(スキップ)`);
        succeeded = 'noData';
        break;  // while ループ抜ける
      }
      if (err.message?.startsWith('NOT_READY:')) {
        // 集計未完了 → リトライしない、後で再取得可能
        log(`  ⏰ ${day}: 楽天側で集計未完了。あとで再取得してください`);
        succeeded = 'notReady';
        break;
      }
      if (isLoginError(err)) {
        // v6.0.9: ログイン切れ → やり直しても同じなので、この日以降を止める
        lastError = err;
        succeeded = 'loginRequired';
        break;
      }
      lastError = err;
      log(`  ⚠ ${day} 試行${attempt}/${MAX_ATTEMPTS}失敗: ${err.message}`);
    }
    }  // ← while ループの終わり

    if (succeeded === 'loginRequired') {
      return await abortJobForLogin({
        jobId: cpnJobId, historyType: (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別',
        days, index: i, err: lastError, log, success, fail
      });
    }

    // 最終結果を集計(リトライ全部使い切った後)
    const cpnLabel = (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別';
    if (succeeded === true) {
      success++;
      recordDailyHistory({ type: cpnLabel, day, ok: true, file: lastFn });
      markDay(cpnJobId, day, 'ok', { file: lastFn });
    } else if (succeeded === 'noData') {
      // データなしは success/fail どちらにも入れない(別カテゴリ)
      recordDailyHistory({ type: cpnLabel, day, ok: 'noData', message: '対象データなし' });
      markDay(cpnJobId, day, 'noData');
    } else if (succeeded === 'notReady') {
      // 集計未完了(あとで再取得可能) → failedとしてカウント(♻失敗分再取得の対象にする)
      fail++;
      failedDays.push(day);
      recordDailyHistory({ type: cpnLabel, day, ok: 'notReady', message: '集計未完了(あとで再取得)' });
      markDay(cpnJobId, day, 'notReady');
    } else {
      // 全リトライ失敗: 3回全部 status=500 なら「対象データなし」の可能性が高い
      // (楽天UI上「対象データがありません」と表示される日はAPI経由だとstatus=500になる)
      const isLikelyNoData = /status=500/i.test(lastError?.message || '');
      if (isLikelyNoData) {
        log(`  ⚪ ${day}: 対象データなしと推定(${MAX_ATTEMPTS}回とも status=500)`);
        recordDailyHistory({ type: cpnLabel, day, ok: 'noData', message: '対象データなし(3回試行)' });
        markDay(cpnJobId, day, 'noData');
      } else {
        fail++;
        failedDays.push(day);
        const errMsg = `${lastError?.message || '失敗'} (${MAX_ATTEMPTS}回試行)`;
        log(`  ❌ ${day}: ${errMsg}`, Math.round(((i + 1) / days.length) * 100));
        recordDailyHistory({ type: cpnLabel, day, ok: false, error: errMsg });
        markDay(cpnJobId, day, 'ng', { error: errMsg });
      }
    }

    if (i < days.length - 1) await sleep((interval || 1) * 1000);
  }

  const finalMsg = `🎉 完了: 成功 ${success} / 失敗 ${fail}`;
  log(`\n${finalMsg}`, 100);
  await endJob(cpnJobId, 'done');

  if (fail === 0) return { ok: true, success, fail };
  return { ok: false, error: `成功 ${success} / 失敗 ${fail} (失敗日: ${failedDays.join(', ')})`, success, fail };
}

// -------- ④ 登録済みキーワード全件ダウンロード(スナップショット) --------
// 対象日という概念はなく、ボタン押した時点で楽天に設定されている全KWのCSVを取得する。
// フロー:
//   1) POST /rpp/api/keywords/downloadAll → 201 {status:'SUCCESS'}
//   2) GET  /rpp/api/download/list → status=2(完了)になるまでポーリング
//   3) GET  /rpp/api/download/report?downloadId=xxx&reportType=12 → ZIP取得
async function rppKeywordSnapshotDownloader({ timeout = 60 } = {}) {
  installProgressOverlay('🛒 ④ 登録済みKW全件DL(スナップショット)');

  // 他のdownloaderと同じログパターン(chrome.storage.local に直列書き込み)
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('rppSnap', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'rppSnap', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  log(`▶ 登録済みKW全件DL 開始`);

  // 進行中ジョブに登録(1日分だけの疑似day)
  const jobLabel = '④ 登録済みKW全件';
  const jobId = await startJob(jobLabel, ['snapshot']);
  markDay(jobId, 'snapshot', 'processing');

  const REPORT_TYPE = 12;  // 登録済みKW全件DLの識別子

  const MAX_ATTEMPTS = 3;
  let attempt = 0;
  let succeeded = false;
  let lastError = null;
  let lastFn = null;

  while (attempt < MAX_ATTEMPTS && !succeeded) {
    attempt++;
    if (attempt > 1) {
      log(`  🔄 リトライ ${attempt}/${MAX_ATTEMPTS}(8秒待機後に再投入)`);
      await sleep(8000);
      if (await isJobCancelled(jobId)) {
        await endJob(jobId, 'cancelled');
        return { ok: false, cancelled: true, error: '中止されました' };
      }
    }
    try {
      // ① 投入前のジョブIDを記録(自分のジョブを識別するため)
      log(`  🔍 既存ジョブを確認中…`);
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
          method: 'GET', credentials: 'include', headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const j = await pre.json();
          const list = j?.data?.userHistoryList || [];
          for (const it of list) existingIds.add(it.id);
        }
      } catch (_) {}

      // XSRF-TOKEN 取得(cookie から。楽天RPP APIはこのヘッダー必須)
      const getCookie = n => {
        const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : null;
      };
      const xsrfToken = getCookie('XSRF-TOKEN');
      if (!xsrfToken) {
        log(`  ❌ XSRF-TOKENが見つかりません(ページ再読み込みが必要かも)`);
        throw new Error('XSRF-TOKENが見つかりません');
      }

      // ② POST /rpp/api/keywords/downloadAll (ボディ空、XSRF必須)
      log(`  📤 登録済みKW全件DLを投入…`);
      const submitRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/keywords/downloadAll', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'X-XSRF-TOKEN': xsrfToken
        }
      });
      if (!submitRes.ok) {
        let errBody = '';
        try { errBody = await submitRes.clone().text(); } catch (_) {}
        log(`  📄 楽天エラーレスポンス (HTTP ${submitRes.status}): ${errBody.slice(0, 300)}`);
      }
      checkLoginResponse(submitRes);   // v6.0.9: 401 ならやり直さずに止める
      if (!submitRes.ok) throw new Error(`投入失敗 HTTP ${submitRes.status}`);
      const subJson = await submitRes.json().catch(() => ({}));
      if (subJson.status !== 'SUCCESS') {
        log(`  ⚠ 投入レスポンス想定外: ${JSON.stringify(subJson).slice(0, 200)}`);
      }

      // ③ list をポーリング → 新規で reportType=12 かつ status=2(完了)を待つ
      const start = Date.now();
      let myJob = null;
      while ((Date.now() - start) / 1000 < timeout) {
        if (await isJobCancelled(jobId)) {
          await endJob(jobId, 'cancelled');
          return { ok: false, cancelled: true, error: '中止されました' };
        }
        await sleep(1500);
        const elapsed = Math.floor((Date.now() - start) / 1000);
        try {
          const lr = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
            method: 'GET', credentials: 'include', headers: { 'Accept': 'application/json' }
          });
          checkLoginResponse(lr);   // v6.0.9
          if (!lr.ok) { log(`    ⚠ list HTTP ${lr.status}`); continue; }
          const lj = await lr.json();
          const list = lj?.data?.userHistoryList || [];
          // 新規 + reportType=12 のジョブを探す
          const candidates = list.filter(j => !existingIds.has(j.id) && j.reportType === REPORT_TYPE);
          if (candidates.length === 0) {
            log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
            continue;
          }
          myJob = candidates[0];  // 最新
          if (myJob.status === 2) { break; }  // 完了
          if (myJob.status >= 4) { throw new Error(`ジョブ失敗 (status=${myJob.status}, id=${myJob.id})`); }
          log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
        } catch (e) {
          if (e.message?.startsWith('ジョブ失敗') || isLoginError(e)) throw e;
          log(`    ⚠ list例外: ${e.message}`);
        }
      }
      if (!myJob || myJob.status !== 2) {
        throw new Error(`タイムアウト(${timeout}s): ジョブが完了しませんでした`);
      }

      // ④ ZIP取得: GET /rpp/api/download/report?downloadId=xxx&reportType=12
      log(`  📥 ZIPを取得中… (downloadId=${myJob.id})`);
      const dlUrl = `https://ad.rms.rakuten.co.jp/rpp/api/download/report?downloadId=${myJob.id}&reportType=${REPORT_TYPE}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      checkLoginResponse(zipRes);   // v6.0.9
      if (!zipRes.ok) throw await httpError(zipRes, 'ZIP取得失敗');

      // ファイル名: 楽天オリジナル名末尾のタイムスタンプを取得日(YYYYMMDD)に置換
      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      const now = new Date();
      const todayStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
      let fn;
      if (mt) {
        fn = mt[1].replace(/_\d{10,}(\.[A-Za-z]+)$/, `_${todayStr}$1`);
      } else {
        fn = `rpp_item_keyword_${todayStr}.zip`;
      }

      const blob = await zipRes.blob();
      // 新方式: スナップショットなので月別フォルダには保存しない(isSnapshot: true)
      // 取り込み用フォルダにのみ保存される
      await saveViaBackground(blob, { filename: fn, day: null, kind: null, isSnapshot: true });

      succeeded = true;
      lastFn = fn;
      log(`  ✅ 登録済みKW全件DL 完了 → ${fn}${attempt > 1 ? ` (リトライ${attempt}回目で成功)` : ''}`, 100);
    } catch (err) {
      lastError = err;
      if (isLoginError(err)) {
        // v6.0.9: ログイン切れ → やり直しても同じなのですぐ止める
        const msg = err.message.replace(/^LOGIN_REQUIRED:\s*/, '');
        recordDailyHistory({ type: jobLabel, day: 'スナップショット', ok: false, error: msg });
        markDay(jobId, 'snapshot', 'ng', { error: msg });
        log(`\n🔑 ${msg}。RMSにログインし直してから ④ をもう一度押してください`, 100);
        await endJob(jobId, 'aborted');
        return { ok: false, loginRequired: true, success: 0, fail: 1, error: msg };
      }
      log(`  ⚠ 試行${attempt}/${MAX_ATTEMPTS}失敗: ${err.message}`);
    }
  }

  // 最終集計
  if (succeeded) {
    recordDailyHistory({ type: jobLabel, day: 'スナップショット', ok: true, file: lastFn });
    markDay(jobId, 'snapshot', 'ok', { file: lastFn });
    log(`\n🎉 完了`, 100);
    await endJob(jobId, 'done');
    return { ok: true, success: 1, fail: 0, filename: lastFn };
  } else {
    const errMsg = `${lastError?.message || '失敗'} (${MAX_ATTEMPTS}回試行)`;
    recordDailyHistory({ type: jobLabel, day: 'スナップショット', ok: false, error: errMsg });
    markDay(jobId, 'snapshot', 'ng', { error: errMsg });
    log(`\n❌ 失敗: ${errMsg}`, 100);
    await endJob(jobId, 'done');
    return { ok: false, success: 0, fail: 1, error: errMsg };
  }
}

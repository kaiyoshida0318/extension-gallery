# Amazon広告 キャンペーン一括ダウンローダー v1.0.0

Amazon広告コンソール(advertising-japan.amazon.com)のキャンペーンデータを、
日付範囲で **1日ずつCSV** に一括ダウンロードするChrome拡張。
楽天版「RMS一括ダウンローダー」の構造を流用しています。

## 仕組み

1. キャンペーン画面が使う内部API `POST /a9g-api-gateway/cm/dds/retrieveReport` を流用
2. リクエストボディの `startDate` / `endDate` を1日ずつ差し替えてループ
3. `offsetPagination` を自動ページング(50件超の口座も全件取得)
4. レスポンスJSONから各キャンペーン行を取り出し、`fields` の順でCSV化(UTF-8 BOM付き=Excel可)
5. `YYYY-MMDD.csv(例: 2026-0601.csv)` を日数ぶん保存

## インストール

1. このフォルダ `amzn-downloader/` を用意
2. Chromeで `chrome://extensions` → 「デベロッパーモード」ON
3. 「パッケージ化されていない拡張機能を読み込む」→ `amzn-downloader` を選択

## 使い方

1. `advertising-japan.amazon.com/campaign-manager/all-campaigns` を**ログイン状態で開く**
2. 拡張アイコンをクリック → 開始日・終了日・DL間隔を設定
3. 「1日ずつCSVを一括ダウンロード」を押す

採取済みのリクエスト(あなたの retrieveReport)を初期値として組み込んであるので、
そのまま動きます。

## トークンが切れたら(401/403が出たら)

CSRFトークンはセッション単位で失効します。出たら:

1. キャンペーン画面で `F12` → Network → `retrieveReport` を右クリック → **Copy as fetch**
2. 拡張の「リクエスト設定(上級)」を開いてテキスト欄に貼り付け → 「リクエストを保存」

## うまくCSVが作れない場合

- ログ(「📋 ログをコピー」)に `⚠️ 行が見つかりません。レスポンス構造: ...` が出ていたら、
  レスポンスのJSON構造が想定と違います。そのログと、retrieveReportの
  レスポンス(DevTools→該当行→Response/Previewタブ)を送ってもらえれば、
  行の取り出しロジックを調整します。

## 注意

- 自分のアカウントのデータを自分でダウンロードする用途を想定しています。
- Amazonの利用規約で自動取得が制限される場合があるため、ご自身の契約条件をご確認ください。

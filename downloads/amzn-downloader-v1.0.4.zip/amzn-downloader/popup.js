// ============================================================
// Amazon広告 キャンペーン一括ダウンローダー v1.0.0
// 楽天版の構造を流用。retrieveReport を日付ループ + ページング + CSV化。
// ============================================================
const $ = id => document.getElementById(id);
const LOG_KEY = 'amzn_dl_logs';
const TMPL_KEY = 'amzn_dl_template';   // {raw, url, headers, body}
const LOG_MAX = 2000;

// ---- 初期テンプレ(ユーザーが採取した retrieveReport を流用) ----
const DEFAULT_TEMPLATE = {
  raw: '',
  url: 'https://advertising-japan.amazon.com/a9g-api-gateway/cm/dds/retrieveReport',
  headers: {
    'accept': 'application/json',
    'advertisertype': 'SELLER',
    'amazon-ads-account-id': 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m',
    'amazon-advertising-api-advertiserid': 'ENTITY15N4IW58E6FGF',
    'amazon-advertising-api-clientid': 'amzn.advertising.789c1d8bc111003008c2560a5a6bdd7fb1aa1f2e9083171222846d7603376e52294ab285563eae55ae6a9edde7a2f30104c80e2f',
    'amazon-advertising-api-csrf-data': 'amzn.advertising.789c1d8bc111003008c2560a5a6bdd7fb1aa1f2e9083171222846d7603376e52294ab285563eae55ae6a9edde7a2f30104c80e2f',
    'amazon-advertising-api-csrf-token': 'gxNb05cSf9Z+e9ELxdgA7hCuNTV5p2D1ZxnyurPxFxqwAAAAAgAAAABqIPFHcmF3AAAAAIwO8jooET7XVH9o5/E9xQ==',
    'amazon-advertising-api-isimpersonator': 'false',
    'amazon-advertising-api-isportalserver': 'false',
    'amazon-advertising-api-marketplaceid': 'A1VC38T7YXB528',
    'content-type': 'application/json',
    'prefer': 'return=representation',
    'x-amz-isglobalcampaignenabled': 'true'
  },
  body: {"reportConfig":{"reportId":"CrossProgramCampaignFullFunnelReport","fields":["campaignExternalId","hasChildren","campaignName","state","statusName","marketplaceId","programType","isDspCampaign","campaignCostType","isGlobalCampaign","campaignId","strategyId","bidAdjustmentPredicates","bidAdjustmentPercentages","statusReasons","marketplaceIds","campaignType","campaignTargetingType","strategyName","isAutoManagedCampaign","campaignRetailer","portfolioId","portfolioExternalId","portfolioName","currencyCode","startDate","endDate","effectiveDailyCoverage","estimatedMissedSalesRangeMin","estimatedMissedSalesRangeMax","estimatedMissedImpressionsRangeMin","estimatedMissedImpressionsRangeMax","estimatedMissedClicksRangeMin","estimatedMissedClicksRangeMax","currencyOfView","campaignBudgetAmount","campaignBudgetAmountCoV","campaignBudgetType","autoScaleGlobalCampaign","campaignEffectiveBudget","campaignEffectiveBudgetCoV","campaignRuleBasedBudgetAmount","campaignRuleBasedBudgetAmountCoV","campaignApplicableBudgetRuleId","campaignApplicableBudgetRuleName","isAnyRuleAssociatedWithCampaign","globalCampaignInputBudget","globalCampaignInputBudgetCurrencyCode","impressions","clicks","ctr","spend","spendCoV","cpc","cpcCoV","orders","bidType","costPerThousandImpressions","costPerThousandImpressionsCoV","sales","salesCoV","vcpm","vcpmCoV","detailPageViews","viewThroughRate","clickThroughRateForViews","videoFirstQuartile","videoMidpoint","videoThirdQuartile","videoComplete","videoUnmute","ntbOrders","ntbPercentOfOrders","ntbSales","ntbSalesCoV","ntbPercentOfSales","longTermSales","longTermSalesCoV","longTermROAS","topOfSearchImpressionShare","roas","campaignBiddingStrategy","cumulativeReach","householdReach","viewableImpressions"],"filter":{"and":[{"field":"state","values":["ENABLED","PAUSED"],"comparisonOperator":"IN","not":false},{"field":"programType","values":["SP","HSA","SB2","SBV","SPOT","DA","DA_SDP"],"comparisonOperator":"IN","not":false}]},"startDate":"2026-06-03","endDate":"2026-06-03","timeUnits":["SUMMARY","DAILY"],"offsetPagination":{"size":50,"offset":0},"currencyOfView":"JPY"}}
};

// ---------- ログ ----------
async function appendLog(cat, text, extra = null) {
  try {
    const s = await chrome.storage.local.get([LOG_KEY]);
    const logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), cat, msg: String(text), extra });
    if (logs.length > LOG_MAX) logs.splice(0, logs.length - LOG_MAX);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  } catch (_) {}
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'amzn-log') {
    appendLog(msg.cat || 'page', msg.text, msg.extra || null);
    setStatus(msg.text);
    if (typeof msg.extra?.progress === 'number') setProgress(msg.extra.progress);
  }
});
function setStatus(msg, append = true) {
  const el = $('status');
  if (append) el.textContent += '\n' + msg; else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(pct) { $('progress').style.width = pct + '%'; }

// ---------- 日付初期値(直近7日) ----------
(function initDates() {
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const today = new Date(); const w = new Date(); w.setDate(today.getDate()-7);
  $('end').value = fmt(today); $('start').value = fmt(w);
})();

// ---------- テンプレ管理 ----------
async function getTemplate() {
  const s = await chrome.storage.local.get([TMPL_KEY]);
  return s[TMPL_KEY] || DEFAULT_TEMPLATE;
}
(async function showTemplate() {
  const t = await getTemplate();
  if (t.raw) $('tmpl').value = t.raw;
})();

// "Copy as fetch" のテキストを {url, headers, body} に変換
function parseFetchSnippet(text) {
  const urlM = text.match(/fetch\(\s*["'`]([^"'`]+)["'`]/);
  if (!urlM) throw new Error('URLが見つかりません(fetch("...")の形式で貼ってください)');
  const url = urlM[1];

  const hM = text.match(/["']headers["']\s*:\s*(\{[\s\S]*?\})\s*,\s*\n?\s*["'](?:referrer|referrerPolicy|body|method|mode|credentials)["']/);
  let headers = {};
  if (hM) { try { headers = JSON.parse(hM[1]); } catch (e) { throw new Error('headersの解析に失敗: ' + e.message); } }

  const bM = text.match(/["']body["']\s*:\s*("(?:\\.|[^"\\])*")/);
  if (!bM) throw new Error('bodyが見つかりません');
  let body;
  try { body = JSON.parse(JSON.parse(bM[1])); }
  catch (e) { throw new Error('bodyの解析に失敗: ' + e.message); }

  // ブラウザが拒否する/上書きする禁止ヘッダを除去
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent)/i;
  const clean = {};
  for (const [k, v] of Object.entries(headers)) if (!drop.test(k)) clean[k] = v;

  return { raw: text, url, headers: clean, body };
}

$('savetmpl').addEventListener('click', async () => {
  try {
    const parsed = parseFetchSnippet($('tmpl').value);
    await chrome.storage.local.set({ [TMPL_KEY]: parsed });
    const n = parsed.body?.reportConfig?.fields?.length ?? '?';
    $('tmpl-status').textContent = `✅ 保存しました(列 ${n}個 / ${Object.keys(parsed.headers).length}ヘッダ)`;
  } catch (e) {
    $('tmpl-status').textContent = '❌ ' + e.message;
  }
});

// ---------- ログのコピー/クリア ----------
$('copylog').addEventListener('click', async () => {
  const s = await chrome.storage.local.get([LOG_KEY]);
  const logs = s[LOG_KEY] || [];
  const m = chrome.runtime.getManifest();
  const head = `=== ${m.name} v${m.version} ログ ===\n${new Date().toISOString()}\nUA: ${navigator.userAgent}\n\n`;
  const body = logs.map(l => `[${l.t.replace('T',' ').replace(/\..+/,'')}] (${l.cat}) ${l.msg}` + (l.extra ? ` | ${JSON.stringify(l.extra)}` : '')).join('\n');
  await navigator.clipboard.writeText(head + body);
  const b = $('copylog'); b.textContent = '✅ コピー済'; setTimeout(() => b.textContent = '📋 ログをコピー', 1500);
});
$('clearlog').addEventListener('click', async () => {
  await chrome.storage.local.remove([LOG_KEY]); setStatus('ログをクリアしました', false);
});

// ---------- 実行 ----------
$('run').addEventListener('click', async () => {
  const startDate = $('start').value, endDate = $('end').value;
  const interval = parseFloat($('interval').value) || 0;
  if (!startDate || !endDate) { setStatus('❌ 開始日・終了日を入力してください', false); return; }

  const tmpl = await getTemplate();
  const btn = $('run'); btn.disabled = true;
  setStatus('▶ 実行準備中...', false); setProgress(0);
  await appendLog('run', `開始 ${startDate}〜${endDate}`);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('アクティブなタブが見つかりません');
    if (!/advertising(-japan)?\.amazon\.com/.test(tab.url || '')) {
      setStatus('⚠️ Amazon広告のページではないかもしれません。Cookieが効かず失敗する場合があります。');
    }
    const result = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: amazonDownloader,
      args: [{ startDate, endDate, interval, tmpl }]
    }))[0]?.result;

    if (result?.ok) setStatus(`\n🎉 完了: 成功 ${result.success} / 失敗 ${result.fail}`);
    else setStatus(`\n❌ エラー: ${result?.error || '不明'}`);
  } catch (e) {
    setStatus(`\n❌ ${e.message}`); appendLog('error', e.message);
  } finally { btn.disabled = false; }
});

// ============================================================
// ▼ ページ(advertising-japan.amazon.com)に注入される本体
// ============================================================
async function amazonDownloader({ startDate, endDate, interval, tmpl }) {
  const writeLog = async (text, extra) => {
    try {
      const KEY = 'amzn_dl_logs';
      const s = await chrome.storage.local.get([KEY]);
      const logs = s[KEY] || [];
      logs.push({ t: new Date().toISOString(), cat: 'amzn', msg: String(text), extra: extra || null });
      if (logs.length > 2000) logs.splice(0, logs.length - 2000);
      await chrome.storage.local.set({ [KEY]: logs });
    } catch (_) {}
  };
  const log = (text, progress) => {
    writeLog(text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'amzn-log', cat: 'amzn', text, extra: { progress } }); } catch (_) {}
  };

  const fields = tmpl?.body?.reportConfig?.fields || [];
  if (!tmpl?.url || !fields.length) { log('❌ リクエストテンプレートが不正です'); return { ok: false, error: 'テンプレート不正' }; }

  // 日付リスト
  const toD = x => { const [y,m,d] = x.split('-').map(Number); return new Date(y, m-1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate()+1)) days.push(fmt(d));
  log(`📅 ${days.length}日分 / ${fields.length}列`);

  // レスポンスJSONからキャンペーン行の配列を探す
  const findRows = (obj) => {
    let best = [];
    const isRow = o => o && typeof o === 'object' && ('campaignId' in o || 'campaignName' in o || 'campaignExternalId' in o);
    const visit = v => {
      if (Array.isArray(v)) { if (v.length && isRow(v[0]) && v.length > best.length) best = v; v.forEach(visit); }
      else if (v && typeof v === 'object') Object.values(v).forEach(visit);
    };
    visit(obj);
    return best;
  };
  const csvCell = v => {
    if (v === null || v === undefined) return '';
    let s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let success = 0, fail = 0;

  const MAX_RETRY = 3;          // 1日あたり最大試行回数
  const failedDays = [];

  // 1日分を取得してCSV保存(成功で件数を返す)。失敗時は例外を投げる。
  const fetchOneDay = async (day) => {
    const size = tmpl.body.reportConfig?.offsetPagination?.size || 50;
    let offset = 0, allRows = [], page = 0;
    while (true) {
      page++;
      const body = JSON.parse(JSON.stringify(tmpl.body));
      body.reportConfig.startDate = day;
      body.reportConfig.endDate = day;
      body.reportConfig.offsetPagination = { size, offset };

      const res = await fetch(tmpl.url, {
        method: 'POST', credentials: 'include', mode: 'cors',
        headers: { ...tmpl.headers },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const t = await res.text().catch(() => '');
        const note = res.status === 429 ? '(リクエスト過多。間隔を空けて再試行)'
                   : (res.status === 401 || res.status === 403) ? '(セッション/トークン切れ。retrieveReportを再取得して貼り直し)'
                   : '';
        const err = new Error(`HTTP ${res.status}${note} ${t.slice(0,120)}`);
        err.status = res.status;
        throw err;
      }
      const json = await res.json();
      const rows = findRows(json);
      if (page === 1 && rows.length === 0) {
        log(`  ⚠️ ${day} 行が見つかりません。レスポンス構造: ${Object.keys(json).join(',').slice(0,120)}`);
      }
      allRows = allRows.concat(rows);
      if (rows.length < size || page > 200) break;
      offset += size;
      await sleep(300);
    }

    const header = fields.join(',');
    const lines = allRows.map(r => fields.map(f => csvCell(r[f])).join(','));
    const csv = '\uFEFF' + header + '\n' + lines.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const u = URL.createObjectURL(blob);
    const [yy, mm, dd] = day.split('-');
    const fname = `${yy}-${mm}${dd}.csv`;  // 例: 2026年6月1日 → 2026-0601.csv
    const a = document.createElement('a');
    a.href = u; a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(u);
    return allRows.length;
  };

  for (let i = 0; i < days.length; i++) {
    const day = days[i];
    let done = false;
    for (let attempt = 1; attempt <= MAX_RETRY && !done; attempt++) {
      try {
        const n = await fetchOneDay(day);
        success++;
        log(`  ✅ ${day} → ${n}件${attempt > 1 ? `(${attempt}回目で成功)` : ''}`, Math.round(((i+1)/days.length)*100));
        done = true;
      } catch (e) {
        // 400/422(InvalidInput=日付がレポート提供期間外 等)はリトライ無意味→即打ち切り
        const noRetry = e.status === 400 || e.status === 422 || /InvalidInput/i.test(e.message || '');
        if (noRetry) {
          fail++; failedDays.push(day);
          log(`  ❌ ${day} 取得不可(リトライ対象外): ${e.message}\n     ※ Amazonのレポート提供期間(スポンサープロダクト約95日/ブランド・ディスプレイ約60日)を超えている可能性が高いです`, Math.round(((i+1)/days.length)*100));
          break;
        }
        if (attempt < MAX_RETRY) {
          // 429やサーバー混雑(504等)は待ち時間を増やしてリトライ(バックオフ)
          const wait = (e.status === 429 ? 5 : 2) * attempt;
          log(`  ↻ ${day} 失敗(${attempt}/${MAX_RETRY}): ${e.message} → ${wait}秒後に再試行`);
          await sleep(wait * 1000);
        } else {
          fail++; failedDays.push(day);
          log(`  ❌ ${day} ${MAX_RETRY}回試行して失敗: ${e.message}`, Math.round(((i+1)/days.length)*100));
        }
      }
    }
    if (i < days.length - 1) await sleep(interval * 1000);
  }

  if (failedDays.length) log(`⚠️ 取得できなかった日: ${failedDays.join(', ')}`);
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  return { ok: true, success, fail, failedDays };
}

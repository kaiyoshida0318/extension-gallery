// ========== 共通ユーティリティ ==========
const $ = id => document.getElementById(id);

function setStatus(panelPrefix, msg, append = true) {
  const el = $(`${panelPrefix}-status`);
  if (append) el.textContent += '\n' + msg;
  else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(panelPrefix, pct) {
  $(`${panelPrefix}-progress`).style.width = pct + '%';
}

// タブ切替
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $(`panel-${tab.dataset.panel}`).classList.add('active');
  });
});

// 初期日付: 開始日は空欄、終了日は昨日
(() => {
  const t = new Date();
  const y = new Date(t); y.setDate(y.getDate() - 1);
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const yesterday = fmt(y);

  // 終了日: 昨日
  ['bulk-end', 'rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end'].forEach(id => {
    const el = $(id);
    if (el) el.value = yesterday;
  });
  // 開始日: 空欄(明示的に空)
  ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'].forEach(id => {
    const el = $(id);
    if (el) el.value = '';
  });
})();

// 開始日が空かどうかで背景色を切り替える
const START_DATE_IDS = ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'];
function refreshEmptyHighlight() {
  START_DATE_IDS.forEach(id => {
    const el = $(id);
    if (!el) return;
    if (el.value) el.classList.remove('empty-required');
    else el.classList.add('empty-required');
  });
}
// 初期表示で適用
refreshEmptyHighlight();
// 各開始日inputが変更されたら再判定
START_DATE_IDS.forEach(id => {
  const el = $(id);
  if (el) {
    el.addEventListener('input', refreshEmptyHighlight);
    el.addEventListener('change', refreshEmptyHighlight);
  }
});

// 上部の一括期間を変更したら、下の各タブの日付も同期(空欄の時は同期しない)
function syncBulkDatesToTabs() {
  const s = $('bulk-start').value;
  const e = $('bulk-end').value;
  if (s) ['rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'].forEach(id => { $(id).value = s; });
  if (e) ['rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end'].forEach(id => { $(id).value = e; });
  refreshEmptyHighlight();
}
$('bulk-start').addEventListener('change', syncBulkDatesToTabs);
$('bulk-end').addEventListener('change', syncBulkDatesToTabs);

// 一括ヒント表示
function setBulkHint(msg, isError = false) {
  const el = $('bulk-hint');
  el.textContent = msg;
  el.style.color = isError ? '#a01010' : '#806000';
}

// ========== 一括: 必要なページを開く ==========
const REQUIRED_URLS = [
  { url: 'https://datatool.rms.rakuten.co.jp/realtime/item', match: 'datatool.rms.rakuten.co.jp/realtime/item' },
  { url: 'https://ad.rms.rakuten.co.jp/rpp/reports', match: 'ad.rms.rakuten.co.jp/rpp/reports' }
];

$('bulk-open').addEventListener('click', async () => {
  $('bulk-open').disabled = true;
  setBulkHint('🔍 既存タブを確認中…');
  try {
    const tabs = await chrome.tabs.query({});
    let opened = 0, existing = 0;
    for (const u of REQUIRED_URLS) {
      const found = tabs.find(t => t.url && t.url.includes(u.match));
      if (found) {
        existing++;
      } else {
        await chrome.tabs.create({ url: u.url, active: false });
        opened++;
      }
    }
    setBulkHint(`✅ 既存 ${existing}件、新規オープン ${opened}件`);
  } catch (e) {
    setBulkHint(`❌ エラー: ${e.message}`, true);
  } finally {
    $('bulk-open').disabled = false;
  }
});

// ========== 一括: 4種類まとめてダウンロード ==========
$('bulk-dl').addEventListener('click', async () => {
  const startDate = $('bulk-start').value;
  const endDate = $('bulk-end').value;
  if (!startDate) { setBulkHint('❌ 開始日を入力してください', true); return; }
  if (!endDate) { setBulkHint('❌ 終了日を入力してください', true); return; }
  if (startDate > endDate) { setBulkHint('❌ 開始日が終了日より後になっています', true); return; }
  // 各タブの日付欄も最終同期
  syncBulkDatesToTabs();

  $('bulk-dl').disabled = true;
  $('bulk-open').disabled = true;
  setBulkHint('🚀 一括DLを開始…');

  // 必要なタブを取得(無ければユーザーに知らせる)
  const tabs = await chrome.tabs.query({});
  const itemSalesTab = tabs.find(t => t.url && t.url.includes('datatool.rms.rakuten.co.jp/realtime/item'));
  const rppTab = tabs.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));

  const missing = [];
  if (!itemSalesTab) missing.push('商品別売上(datatool)');
  if (!rppTab) missing.push('RPP(ad.rms)');
  if (missing.length) {
    setBulkHint(`❌ タブが開かれていません: ${missing.join(', ')}。先に「一括オープン」を押してください`, true);
    $('bulk-dl').disabled = false;
    $('bulk-open').disabled = false;
    return;
  }

  // 4種類のジョブを順次実行(同じRPPタブを3回使うので並列にはしない)
  const jobs = [
    {
      name: '商品別売上',
      tabId: itemSalesTab.id,
      fn: itemSalesDownloader,
      args: [{
        startDate, endDate,
        period: $('is-period').value || 'daily',
        device: $('is-device').value || 'all',
        tax: $('is-tax').value || 'incl',
        filter: ($('is-filter').value || '').trim(),
        filterBy: $('is-filterBy').value || 'all',
        interval: parseFloat($('is-interval').value) || 3
      }],
      overlayTitle: '🛒 商品別売上 ダウンロード中'
    },
    {
      name: '全ての広告',
      tabId: rppTab.id,
      fn: rppAllDownloader,
      args: [{
        startDate, endDate,
        interval: parseFloat($('rppAll-interval').value) || 3,
        options: collectRppOptions('rppAll')
      }],
      overlayTitle: '🛒 全ての広告 ダウンロード中'
    },
    {
      name: '商品別レポート',
      tabId: rppTab.id,
      fn: rppAsyncDownloader,
      args: [{
        startDate, endDate,
        timeout: parseInt($('rppItem-timeout').value, 10) || 10,
        options: collectRppOptions('rppItem'),
        selectionType: 3, reportType: 4,
        panelPrefix: 'rppItem', reportName: '全商品レポート'
      }],
      overlayTitle: '🛒 全商品レポート ダウンロード中'
    },
    {
      name: 'キーワード別レポート',
      tabId: rppTab.id,
      fn: rppAsyncDownloader,
      args: [{
        startDate, endDate,
        timeout: parseInt($('rppKw-timeout').value, 10) || 10,
        options: collectRppOptions('rppKw'),
        selectionType: 4, reportType: 3,
        panelPrefix: 'rppKw', reportName: '全キーワードレポート'
      }],
      overlayTitle: '🛒 全キーワードレポート ダウンロード中'
    }
  ];

  let okCount = 0, ngCount = 0;
  for (let i = 0; i < jobs.length; i++) {
    const job = jobs[i];
    setBulkHint(`▶ [${i + 1}/${jobs.length}] ${job.name} を実行中…`);
    try {
      // オーバーレイ準備
      await chrome.scripting.executeScript({
        target: { tabId: job.tabId },
        func: installProgressOverlay,
        args: [job.overlayTitle]
      });
      // 本体実行
      const r = (await chrome.scripting.executeScript({
        target: { tabId: job.tabId },
        func: job.fn,
        args: job.args
      }))[0].result;
      if (r?.ok) okCount++;
      else { ngCount++; console.warn(`[${job.name}]`, r?.error); }
    } catch (e) {
      ngCount++;
      console.error(`[${job.name}]`, e);
    }
  }

  setBulkHint(`🎉 一括DL完了: 成功 ${okCount} / 失敗 ${ngCount}`);
  $('bulk-dl').disabled = false;
  $('bulk-open').disabled = false;
});

// リアルタイムログ受信(どのパネルから来たかをmsg.panelで判定)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'rms-log') {
    setStatus(msg.panel, msg.text);
    if (typeof msg.progress === 'number') setProgress(msg.panel, msg.progress);
  }
});

// ========== 全ての広告(RPP) ==========

// フォーム値を集める(prefixで使い回す: rppAll / rppItem / rppKw)
function collectRppOptions(prefix) {
  const getRadio = name => document.querySelector(`input[name="${name}"]:checked`)?.value;
  const getCb = id => $(id)?.checked;
  return {
    periodType: parseInt(getRadio(`${prefix}-periodType`) || '0', 10),
    campaignType: getRadio(`${prefix}-campaignType`) || '1',
    reportFilter: parseInt(getRadio(`${prefix}-reportFilter`) || '1', 10),
    rankType: 1,
    allUsers: getCb(`${prefix}-allUsers`),
    newUsers: getCb(`${prefix}-newUsers`),
    existingUsers: getCb(`${prefix}-existingUsers`),
    noOfClicks: getCb(`${prefix}-noOfClicks`),
    adsalesBefore: getCb(`${prefix}-adsalesBefore`),
    cpc: getCb(`${prefix}-cpc`),
    h12: getCb(`${prefix}-h12`),
    h720: getCb(`${prefix}-h720`),
    gms: getCb(`${prefix}-gms`),
    roas: getCb(`${prefix}-roas`),
    cv: getCb(`${prefix}-cv`),
    cvr: getCb(`${prefix}-cvr`),
    cpa: getCb(`${prefix}-cpa`)
  };
}

// 既定値に戻す処理(prefixで使い回す)
// allCheckedAll: 「全ての広告」は新規・既存OFFが初期値。商品別/キーワード別は全てONが画像の状態
function resetRppForm(prefix, opts = { userAllOn: false, h12On: false }) {
  const setRadio = (name, value) => {
    const el = document.querySelector(`input[name="${name}"][value="${value}"]`);
    if (el) el.checked = true;
  };
  setRadio(`${prefix}-periodType`, '0');
  setRadio(`${prefix}-campaignType`, '1');
  setRadio(`${prefix}-reportFilter`, '1');
  const cbMap = {
    [`${prefix}-allUsers`]: true,
    [`${prefix}-newUsers`]: opts.userAllOn,
    [`${prefix}-existingUsers`]: opts.userAllOn,
    [`${prefix}-noOfClicks`]: true,
    [`${prefix}-adsalesBefore`]: true,
    [`${prefix}-cpc`]: true,
    [`${prefix}-h12`]: opts.h12On,
    [`${prefix}-h720`]: true,
    [`${prefix}-gms`]: true,
    [`${prefix}-roas`]: true,
    [`${prefix}-cv`]: true,
    [`${prefix}-cvr`]: true,
    [`${prefix}-cpa`]: true
  };
  for (const [id, val] of Object.entries(cbMap)) {
    const el = $(id);
    if (el) el.checked = val;
  }
}

// 既定値に戻すボタン(全ての広告)
$('rppAll-reset').addEventListener('click', () => {
  resetRppForm('rppAll', { userAllOn: false, h12On: false });
});

// 既定値に戻すボタン(商品別 / キーワード別)
$('rppItem-reset').addEventListener('click', () => {
  resetRppForm('rppItem', { userAllOn: true, h12On: true });
});
$('rppKw-reset').addEventListener('click', () => {
  resetRppForm('rppKw', { userAllOn: true, h12On: true });
});

// 全ての広告 ボタン
$('rppAll-run').addEventListener('click', async () => {
  const startDate = $('rppAll-start').value;
  const endDate = $('rppAll-end').value;
  const interval = parseFloat($('rppAll-interval').value) || 1;

  if (!startDate) { setStatus('rppAll', '❌ 開始日を入力してください', false); return; }
  if (!endDate) { setStatus('rppAll', '❌ 終了日を入力してください', false); return; }
  if (startDate > endDate) { setStatus('rppAll', '❌ 開始日が終了日より後になっています', false); return; }

  // RPPタブを「URL一致」で探す(アクティブでなくてもOK)
  const allTabs = await chrome.tabs.query({});
  const tab = allTabs.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
  if (!tab) {
    setStatus('rppAll', '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
  }

  const options = collectRppOptions('rppAll');

  $('rppAll-run').disabled = true;
  setStatus('rppAll', '🚀 開始…', false);
  setProgress('rppAll', 0);

  try {
    // ページにオーバーレイ進捗ウィンドウを設置
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 全ての広告 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: rppAllDownloader,
      args: [{ startDate, endDate, interval, options }]
    }))[0].result;
    if (r?.ok) setStatus('rppAll', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('rppAll', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('rppAll', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('rppAll-run').disabled = false;
  }
});

// ========== 商品別売上 ボタン ==========
$('is-run').addEventListener('click', async () => {
  const params = {
    startDate: $('is-start').value,
    endDate: $('is-end').value,
    period: $('is-period').value,
    device: $('is-device').value,
    tax: $('is-tax').value,
    filter: $('is-filter').value.trim(),
    filterBy: $('is-filterBy').value,
    interval: parseFloat($('is-interval').value) || 2
  };

  if (!params.startDate) { setStatus('is', '❌ 開始日を入力してください', false); return; }
  if (!params.endDate) { setStatus('is', '❌ 終了日を入力してください', false); return; }
  if (params.startDate > params.endDate) { setStatus('is', '❌ 開始日が終了日より後になっています', false); return; }

  // 商品別売上タブをURL一致で探す
  const allTabsIs = await chrome.tabs.query({});
  const tab = allTabsIs.find(t => t.url && t.url.includes('datatool.rms.rakuten.co.jp/realtime/item'));
  if (!tab) {
    setStatus('is', '❌ 商品別売上ページ(datatool.rms.rakuten.co.jp/realtime/item)を開いてください', false); return;
  }

  $('is-run').disabled = true;
  setStatus('is', '🚀 開始…', false);
  setProgress('is', 0);

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 商品別売上 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: itemSalesDownloader,
      args: [params]
    }))[0].result;
    if (r?.ok) setStatus('is', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('is', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('is', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('is-run').disabled = false;
  }
});

// ========== 商品別 / キーワード別(RPP 非同期レポート) 共通ハンドラ ==========
// reportType: 4 = 全商品レポート, 3 = 全キーワードレポート
// selectionType: 3 = 商品別, 4 = キーワード別
function registerRppAsyncHandler(prefix, selectionType, reportType, reportName, buttonLabelWhenDone) {
  $(`${prefix}-run`).addEventListener('click', async () => {
    const startDate = $(`${prefix}-start`).value;
    const endDate = $(`${prefix}-end`).value;
    const timeout = parseInt($(`${prefix}-timeout`).value, 10) || 120;

    if (!startDate) { setStatus(prefix, '❌ 開始日を入力してください', false); return; }
    if (!endDate) { setStatus(prefix, '❌ 終了日を入力してください', false); return; }
    if (startDate > endDate) { setStatus(prefix, '❌ 開始日が終了日より後になっています', false); return; }

    // RPPタブをURL一致で探す
    const allTabsRpp = await chrome.tabs.query({});
    const tab = allTabsRpp.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
    if (!tab) {
      setStatus(prefix, '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
    }

    const options = collectRppOptions(prefix);

    $(`${prefix}-run`).disabled = true;
    setStatus(prefix, `🚀 ${reportName} 開始…`, false);
    setProgress(prefix, 0);

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: installProgressOverlay,
        args: [`🛒 ${reportName} ダウンロード中`]
      });

      const r = (await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: rppAsyncDownloader,
        args: [{ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix: prefix, reportName }]
      }))[0].result;
      if (r?.ok) setStatus(prefix, `\n✅ ${r.filename || '完了'}`);
      else setStatus(prefix, `\n❌ ${r?.error || '不明なエラー'}`);
    } catch (e) {
      setStatus(prefix, `\n❌ 実行エラー: ${e.message}`);
    } finally {
      $(`${prefix}-run`).disabled = false;
    }
  });
}

registerRppAsyncHandler('rppItem', 3, 4, '全商品レポート');
registerRppAsyncHandler('rppKw', 4, 3, '全キーワードレポート');

// =========================================================
// ========== ページコンテキスト実行関数 ==========
// =========================================================

// ページ上にドラッグ可能なオーバーレイ進捗ウィンドウを設置する。
// window.__rmsDLOverlay に API を生やし、以降のdownloaderがそれを呼び出す。
// 既に設置済みなら再利用する。
function installProgressOverlay(title) {
  if (window.__rmsDLOverlay?.el?.isConnected) {
    // 既存オーバーレイを再表示してタイトル更新
    window.__rmsDLOverlay.el.style.display = 'block';
    window.__rmsDLOverlay.setTitle(title);
    window.__rmsDLOverlay.clearLog();
    window.__rmsDLOverlay.setProgress(0);
    return;
  }

  const box = document.createElement('div');
  box.id = '__rms_dl_overlay';
  Object.assign(box.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '420px',
    maxHeight: '70vh',
    background: '#ffffff',
    border: '2px solid #bf0000',
    borderRadius: '8px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.25)',
    zIndex: '2147483647',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#222',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    userSelect: 'none'
  });

  // ヘッダー(ドラッグハンドル + 閉じるボタン)
  const header = document.createElement('div');
  Object.assign(header.style, {
    padding: '8px 12px',
    background: '#bf0000',
    color: '#fff',
    fontWeight: 'bold',
    cursor: 'move',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  });
  const titleSpan = document.createElement('span');
  titleSpan.textContent = title || 'RMS一括DL 進捗';
  header.appendChild(titleSpan);

  const closeBtn = document.createElement('span');
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    cursor: 'pointer',
    padding: '0 4px',
    fontSize: '16px',
    lineHeight: '1'
  });
  closeBtn.title = '閉じる(処理は継続します)';
  closeBtn.onclick = (e) => { e.stopPropagation(); box.style.display = 'none'; };
  header.appendChild(closeBtn);

  box.appendChild(header);

  // プログレスバー
  const progTrack = document.createElement('div');
  Object.assign(progTrack.style, {
    width: '100%',
    height: '6px',
    background: '#eee',
    flexShrink: '0'
  });
  const progBar = document.createElement('div');
  Object.assign(progBar.style, {
    height: '100%',
    width: '0%',
    background: '#bf0000',
    transition: 'width 0.3s'
  });
  progTrack.appendChild(progBar);
  box.appendChild(progTrack);

  // ログ領域
  const logEl = document.createElement('div');
  Object.assign(logEl.style, {
    padding: '10px 14px',
    overflowY: 'auto',
    flex: '1',
    whiteSpace: 'pre-wrap',
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
    fontSize: '12px',
    lineHeight: '1.5',
    background: '#fafafa',
    userSelect: 'text'
  });
  logEl.textContent = '開始を待っています…';
  box.appendChild(logEl);

  document.documentElement.appendChild(box);

  // ドラッグ処理
  let dragging = false, offX = 0, offY = 0;
  header.addEventListener('mousedown', (e) => {
    dragging = true;
    const rect = box.getBoundingClientRect();
    offX = e.clientX - rect.left;
    offY = e.clientY - rect.top;
    box.style.transform = 'none';
    box.style.left = rect.left + 'px';
    box.style.top = rect.top + 'px';
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    box.style.left = (e.clientX - offX) + 'px';
    box.style.top = (e.clientY - offY) + 'px';
  });
  window.addEventListener('mouseup', () => { dragging = false; });

  window.__rmsDLOverlay = {
    el: box,
    setTitle: (t) => { titleSpan.textContent = t || 'RMS一括DL 進捗'; },
    log: (text) => {
      logEl.textContent += '\n' + text;
      logEl.scrollTop = logEl.scrollHeight;
    },
    clearLog: () => { logEl.textContent = '開始しました…'; },
    setProgress: (pct) => { progBar.style.width = Math.max(0, Math.min(100, pct)) + '%'; }
  };
}

// -------- 全ての広告(RPP) --------
async function rppAllDownloader({ startDate, endDate, interval, options }) {
  const log = (text, progress) => {
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'rppAll', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) return { ok: false, error: 'XSRF-TOKENが見つかりません' };

  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
  log(`📅 ${days.length}日分`);

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let success = 0, fail = 0;
  for (let i = 0; i < days.length; i++) {
    const day = days[i];
    try {
      // 各リクエストのペイロード: 日付以外はUIで指定したoptionsを使う
      const payload = {
        page: 1,
        selectionType: 1,
        startDate: day,
        endDate: day,
        ...options
      };
      const r = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadPerfFile', {
        method: 'POST', credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const cd = r.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      const fn = mt ? mt[1] : `rpp_${day}.csv`;
      const blob = await r.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = fn; document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(u);
      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
    } catch (e) {
      fail++;
      log(`  ❌ ${day} ${e.message}`, Math.round(((i + 1) / days.length) * 100));
    }
    if (i < days.length - 1) await sleep(interval * 1000);
  }
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  return { ok: true, success, fail };
}

// -------- 商品別売上 --------
async function itemSalesDownloader({ startDate, endDate, period, device, tax, filter, filterBy, interval }) {
  const log = (text, progress) => {
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'is', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };

  // YYYY-MM-DD → YYYYMMDD
  const yyyymmdd = s => s.replaceAll('-', '');
  // 月次の月初/月末
  const monthStart = s => s.slice(0, 8) + '01';
  const monthEnd = s => {
    const [y, m] = s.split('-').map(Number);
    const last = new Date(y, m, 0).getDate();
    return `${y}-${String(m).padStart(2, '0')}-${String(last).padStart(2, '0')}`;
  };

  // 分割リスト作成(日次=1日ずつ、月次=1ヶ月ずつ、range=1発)
  const ranges = [];
  if (period === 'daily') {
    const [y1, m1, d1] = startDate.split('-').map(Number);
    const [y2, m2, d2] = endDate.split('-').map(Number);
    for (let d = new Date(y1, m1 - 1, d1), e = new Date(y2, m2 - 1, d2); d <= e; d.setDate(d.getDate() + 1)) {
      const s = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      ranges.push({ s, e: s, label: s });
    }
  } else if (period === 'monthly') {
    const [y1, m1] = startDate.split('-').map(Number);
    const [y2, m2] = endDate.split('-').map(Number);
    let y = y1, m = m1;
    while (y < y2 || (y === y2 && m <= m2)) {
      const ms = `${y}-${String(m).padStart(2, '0')}-01`;
      const me = monthEnd(ms);
      ranges.push({ s: ms, e: me, label: `${y}-${String(m).padStart(2, '0')}` });
      m++; if (m > 12) { m = 1; y++; }
    }
  } else {
    ranges.push({ s: startDate, e: endDate, label: `${startDate}_${endDate}` });
  }

  log(`📅 ${ranges.length}件のDLを実行`);

  const BASE = 'https://datatool.rms.rakuten.co.jp/realtime';
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // API用のperiodパラメータ(range時もAPIはdailyでOKらしいが、一応monthlyに切り替え)
  const apiPeriod = (period === 'monthly') ? 'monthly' : 'daily';

  // 共通クエリビルダ
  const buildQuery = (s, e, extra = {}) => {
    const q = new URLSearchParams({
      period: apiPeriod,
      startDate: yyyymmdd(s),
      endDate: yyyymmdd(e),
      tax,
      device,
      filter: filter || '',
      filterBy,
      sortBy: 'sales',
      sort: 'desc',
      ...extra
    });
    return q.toString();
  };

  // 楽天の実CSVフォーマットに合わせたCSVビルダー
  // 文字列は必ず "..." で囲む、数値は囲まない、改行はCRLF
  const esc = v => {
    if (v === null || v === undefined) return '';
    const s = String(v);
    return '"' + s.replaceAll('"', '""') + '"';
  };
  const num = v => (v === null || v === undefined) ? '' : String(v);

  // YYYY-MM-DD → 「2026年04月01日」
  const jpDate = s => {
    const [y, m, d] = s.split('-');
    return `${y}年${m}月${d}日`;
  };
  // 端末ラベル
  const deviceLabel = { all: 'すべて', pc: 'PC', app: '楽天市場アプリ', sp: 'スマートフォン' }[device] || device;
  const taxLabel = tax === 'incl' ? '税込' : '税抜';

  // ファイル名: 楽天の実ファイル名パターンに合わせる
  // 例: 20260401_Item_SalesList.csv
  const fileNameFor = (s, e, label) => {
    if (period === 'daily') return `${s.replaceAll('-', '')}_Item_SalesList.csv`;
    if (period === 'monthly') return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
    return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
  };

  let success = 0, fail = 0;

  for (let i = 0; i < ranges.length; i++) {
    const { s, e, label } = ranges[i];
    try {
      // ① 検索(画面表示用のAPIを叩いてセッション整合を取る)
      const searchUrl = `${BASE}/get-shop-item-list?${buildQuery(s, e)}`;
      const sr = await fetch(searchUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
      if (!sr.ok) throw new Error('search HTTP ' + sr.status);
      await sr.json();

      // ② DL API を maxCycleNumber まで繰り返して全件取得
      let allRows = [];
      let cycle = 0, maxCycle = 0;
      do {
        const dlUrl = `${BASE}/get-shop-item-dl?${buildQuery(s, e, { size: '1000', cycleNumber: String(cycle) })}`;
        const dr = await fetch(dlUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
        if (!dr.ok) throw new Error('dl HTTP ' + dr.status);
        const dj = await dr.json();
        if (Array.isArray(dj.data)) allRows = allRows.concat(dj.data);
        maxCycle = dj.maxCycleNumber || 0;
        cycle++;
        if (cycle <= maxCycle) await new Promise(r => setTimeout(r, 500));
      } while (cycle <= maxCycle);

      // ③ 楽天の実CSVと同じフォーマットで組み立て
      const lines = [];
      lines.push('※この情報は店舗様および楽天市場での重要な情報となります。データの取扱には十分にご注意ください。');
      lines.push('商品別売上');
      lines.push(`表示期間,${jpDate(s)}から${jpDate(e)}`);
      lines.push(`端末,${deviceLabel}`);
      lines.push(`消費税,${taxLabel}`);
      lines.push(filter ? `キーワード,${esc(filter)}` : 'キーワード');
      lines.push('商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数');
      for (const r of allRows) {
        // API: itemName/mngNumber/itemNumber/itemPrice/units/sales/orderCount
        // CSV順: 商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数
        lines.push([
          esc(r.itemName),
          esc(r.mngNumber),
          esc(r.itemNumber),
          num(r.itemPrice),
          num(r.units),
          num(r.sales),
          num(r.orderCount)
        ].join(','));
      }
      const csv = lines.join('\r\n') + '\r\n';

      // UTF-8 BOM付き(楽天オリジナルもBOM付きUTF-8)
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });

      const fn = fileNameFor(s, e, label);
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = fn; document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(u);

      success++;
      log(`  ✅ ${label} (${allRows.length}件) → ${fn}`, Math.round(((i + 1) / ranges.length) * 100));
    } catch (err) {
      fail++;
      log(`  ❌ ${label} ${err.message}`, Math.round(((i + 1) / ranges.length) * 100));
    }
    if (i < ranges.length - 1) await new Promise(r => setTimeout(r, interval * 1000));
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  return { ok: true, success, fail };
}

// -------- 商品別 / キーワード別(RPP 非同期ZIPダウンロード、1日ずつループ) --------
async function rppAsyncDownloader({ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix, reportName }) {
  const log = (text, progress) => {
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: panelPrefix, text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) return { ok: false, error: 'XSRF-TOKENが見つかりません' };

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // 日付リストを作成(startDate〜endDateを1日ずつ)
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));

  log(`📅 ${reportName} を ${days.length}日分 順番にダウンロードします`);

  // ====== 日ごとのループ ======
  let success = 0, fail = 0;
  const failedDays = [];

  for (let i = 0; i < days.length; i++) {
    const day = days[i];
    const dayNum = i + 1;
    const basePct = Math.round((i / days.length) * 100);

    log(`\n── [${dayNum}/${days.length}] ${day} ──`, basePct);

    try {
      // ─ ① この日のジョブ投入前に、既存ジョブID一覧を取得 ─
      log('  🔍 既存ジョブを確認中…');
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const preJson = await pre.json();
          const list = preJson?.data?.userHistoryList || [];
          for (const j of list) existingIds.add(j.id);
        }
      } catch (_) { /* 失敗しても続行 */ }

      // ─ ② downloadAsyncでこの日のジョブ投入(startDate=endDate=day) ─
      log(`  📤 ${day}分のジョブを投入…`);
      const payload = {
        page: 1,
        selectionType,
        startDate: day,
        endDate: day,
        ...options
      };
      const asyncRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadAsync', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      if (!asyncRes.ok) throw new Error(`downloadAsync失敗 HTTP ${asyncRes.status}`);
      const asyncJson = await asyncRes.json();
      if (asyncJson?.status !== 'SUCCESS') {
        throw new Error(`downloadAsync応答が予期せぬ形式: ${JSON.stringify(asyncJson).slice(0, 80)}`);
      }

      // ─ ③ listポーリング、この日のジョブが完了するまで待つ ─
      const pollStart = Date.now();
      const pollInterval = 1000; // 1秒ごとにポーリング(短いtimeoutに対応)
      let myJob = null;
      while ((Date.now() - pollStart) / 1000 < timeout) {
        await sleep(pollInterval);
        const elapsed = Math.round((Date.now() - pollStart) / 1000);

        try {
          const listRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
            method: 'GET', credentials: 'include',
            headers: { 'Accept': 'application/json' }
          });
          if (!listRes.ok) continue;
          const listJson = await listRes.json();
          const userList = listJson?.data?.userHistoryList || [];

          // 自分のジョブを特定する。
          // 楽天側で reportType の番号が変わる(以前 3/4 → 現在 13/14 等)ため、
          // reportType の固定値では照合しない。代わりに:
          //   - 投入前に存在しなかった新規ジョブ (existingIdsに無い)
          //   - startDate が対象日と一致
          // で特定し、ダウンロード時はジョブ自身の reportType を使う。
          const newJobs = userList.filter(j => {
            if (existingIds.has(j.id)) return false;
            // startDateは "YYYY-MM-DD" または "YYYY-MM-DD 00:00:00" 形式
            if (j.startDate && !j.startDate.startsWith(day)) return false;
            return true;
          });
          if (newJobs.length > 0) {
            // 最新(requestDate降順)を自分のジョブとみなす
            newJobs.sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || ''));
            // 完了(status 2/4) かつ reportTypeを持つジョブを最優先。
            // なければ完了ジョブ、それも無ければ最新ジョブを暫定保持。
            myJob = newJobs.find(j => (j.status === 2 || j.status === 4) && j.reportType != null)
                 || newJobs.find(j => j.status === 2 || j.status === 4)
                 || newJobs[0];
          }

          if (myJob) {
            if (myJob.status === 2 || myJob.status === 4) break;
            else if (myJob.status === 3) {
              // 失敗ジョブしか無い場合のみエラー。新しい候補がまだ出るかもしれないので
              // newJobsに完了/処理中が他に無いことを確認
              const hasPending = newJobs.some(j => j.status === 0 || j.status === 1);
              if (!hasPending) throw new Error(`ジョブが失敗 (id=${myJob.id}, status=3)`);
              else { myJob = null; log(`    ⏳ 生成中… (${elapsed}s経過)`); }
            }
            else log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
          } else {
            log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
          }
        } catch (e) {
          if (e.message.includes('ジョブが失敗')) throw e;
          log(`    ⚠ ポーリング一時エラー: ${e.message}`);
        }
      }

      if (!myJob || (myJob.status !== 2 && myJob.status !== 4)) {
        throw new Error(`タイムアウト(${timeout}秒)`);
      }

      // ─ ④ ZIPを取得して保存 ─
      // ダウンロードに使う reportType は、固定値ではなく
      // 見つかったジョブ自身の reportType を使う(楽天側の番号変更に追従)
      const dlReportType = (myJob.reportType != null) ? myJob.reportType : reportType;
      const storageType = myJob.storageType || 'STAAS';
      const dlUrl = `https://ad.rms.rakuten.co.jp/rpp/api/download/report?downloadId=${myJob.id}&reportType=${dlReportType}&storageType=${storageType}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      if (!zipRes.ok) throw new Error(`ZIP取得失敗 HTTP ${zipRes.status}`);

      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      const fn = mt ? mt[1] : `rpp_report_${dlReportType}_${day.replaceAll('-', '')}_${myJob.id}.zip`;

      const blob = await zipRes.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u;
      a.download = fn;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(u);

      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
    } catch (err) {
      fail++;
      failedDays.push(day);
      log(`  ❌ ${day}: ${err.message}`, Math.round(((i + 1) / days.length) * 100));
    }

    // 次の日のジョブに進む前に1秒だけ待つ(連続投入でサーバーに優しく)
    if (i < days.length - 1) await sleep(1000);
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);

  if (fail === 0) {
    return { ok: true, success, fail, filename: `${success}件のZIPを保存しました` };
  } else {
    return {
      ok: false,
      error: `成功 ${success} / 失敗 ${fail} (失敗日: ${failedDays.join(', ')})`
    };
  }
}

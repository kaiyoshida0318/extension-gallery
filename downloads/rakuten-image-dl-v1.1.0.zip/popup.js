// popup.js
const btn = document.getElementById('dlBtn');
const pickBtn = document.getElementById('pickBtn');
const statusEl = document.getElementById('status');
const logEl = document.getElementById('log');
const siteLabel = document.getElementById('siteLabel');

function log(msg) {
  console.log('[ShopDL]', msg);
  const time = new Date().toLocaleTimeString();
  logEl.textContent += `[${time}] ${msg}\n`;
  logEl.scrollTop = logEl.scrollHeight;
}
function setStatus(msg) { statusEl.textContent = msg; log(msg); }

window.addEventListener('error', (e) => log('💥 ' + e.message));
window.addEventListener('unhandledrejection', (e) => log('💥 ' + (e.reason?.message || e.reason)));

// 起動時に現在のタブから対応サイトを判定して表示
(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const site = detectSite(tab?.url);
    if (site === 'rakuten') siteLabel.textContent = '🛍️ 楽天モード';
    else if (site === 'yahoo') siteLabel.textContent = '🅨 Yahoo!ショッピングモード';
    else siteLabel.textContent = '⚠️ 対応ページを開いてください';
  } catch {}
})();

function detectSite(url) {
  if (!url) return null;
  if (url.includes('item.rakuten.co.jp')) return 'rakuten';
  if (url.includes('store.shopping.yahoo.co.jp') || url.includes('shopping.yahoo.co.jp')) return 'yahoo';
  return null;
}

btn.addEventListener('click', async () => {
  log('▶ 商品画像取得');
  btn.disabled = true; pickBtn.disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const site = detectSite(tab?.url);
    if (!site) {
      setStatus('⚠️ 楽天またはYahoo!ショッピングの商品ページで実行してください');
      return;
    }
    log('サイト判定: ' + site);
    setStatus(`${site === 'rakuten' ? '楽天' : 'Yahoo!'}: 画像収集中…`);

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: site === 'rakuten' ? collectRakutenImages : collectYahooImages
    });
    log('検出: ' + JSON.stringify({ count: result?.urls?.length, debug: result?.debug }));

    if (!result?.urls?.length) {
      setStatus(`画像が見つかりませんでした\n${result?.debug || ''}`);
      return;
    }

    const preview = result.urls.slice(0, 20).map((u, i) => `${i+1}. ${u}`).join('\n');
    const more = result.urls.length > 20 ? `\n... 他${result.urls.length - 20}件` : '';
    setStatus(`✅ ${result.urls.length}件 検出\n${result.debug}\n\n${preview}${more}\n\nダウンロード開始…`);

    const response = await chrome.runtime.sendMessage({
      type: 'DOWNLOAD_ALL', urls: result.urls, folder: result.folder
    });

    if (response?.ok) {
      setStatus(`✅ ${response.success}/${result.urls.length}件 DL開始\nフォルダ: ${result.folder}\n\n${preview}${more}`);
    } else {
      setStatus('⚠️ エラー: ' + response?.error);
    }
  } catch (e) {
    setStatus('⚠️ ' + e.message);
    log('💥 ' + (e.stack || e));
  } finally {
    btn.disabled = false; pickBtn.disabled = false;
  }
});

pickBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const site = detectSite(tab?.url);
    if (!site) {
      setStatus('⚠️ 楽天またはYahoo!ショッピングの商品ページで実行してください');
      return;
    }
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: startPicker, args: [site] });
    window.close();
  } catch (e) {
    setStatus('⚠️ ' + e.message);
  }
});

// ================================
// 楽天: width="100%" の img を取得
// ================================
function collectRakutenImages() {
  try {
    const allImgs = document.querySelectorAll('img');
    const productImgs = [];
    let widthMatched = 0;

    allImgs.forEach(img => {
      const widthAttr = img.getAttribute('width');
      const styleWidth = img.style.width;
      const isFullWidth =
        (widthAttr && widthAttr.trim() === '100%') ||
        (styleWidth && styleWidth.replace(/\s/g, '') === '100%');
      if (!isFullWidth) return;
      widthMatched++;
      const src = img.currentSrc || img.src || img.getAttribute('src');
      if (!src || src.startsWith('data:') || src.startsWith('blob:')) return;
      productImgs.push(src);
    });

    let arr = productImgs.map(u => {
      try { return new URL(u, location.href).toString(); } catch { return null; }
    }).filter(Boolean);

    arr = arr.filter(u => {
      try {
        const url = new URL(u);
        return url.hostname === 'image.rakuten.co.jp' || url.hostname.endsWith('.r10s.jp');
      } catch { return false; }
    });

    // ホスト統一
    arr = arr.map(u => {
      try {
        const url = new URL(u);
        if (url.hostname === 'shop.r10s.jp') url.hostname = 'image.rakuten.co.jp';
        return url.toString();
      } catch { return u; }
    });

    const seen = new Set();
    const ordered = [];
    for (const u of arr) {
      if (!seen.has(u)) { seen.add(u); ordered.push(u); }
    }

    const debug = `全img${allImgs.length}件 → width=100%が${widthMatched}件 → 対象${ordered.length}件`;
    const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+)/);
    const folder = 'shop-images/rakuten_' + (m ? `${m[1]}_${m[2]}` : Date.now());
    return { urls: ordered, folder, debug };
  } catch (e) {
    return { urls: [], folder: '', debug: 'エラー: ' + e.message };
  }
}

// ================================
// Yahoo!ショッピング: メイン画像+サムネ
// ================================
function collectYahooImages() {
  try {
    // Yahoo!の商品画像CDNは item-shopping.c.yimg.jp/i/[サイズ]/[ストア]_[商品]... 
    //   /i/n/... = 元サイズ (original)
    //   /i/l/... = large
    //   /i/j/... = middle
    //   /i/g/... = small (thumbnail)
    // メタタグ og:image でメイン画像取得
    const ogMeta = document.querySelector('meta[property="og:image"]');
    const ogImage = ogMeta?.getAttribute('content') || '';

    // ページ内の全img から item-shopping.c.yimg.jp/i/... のもの
    const allImgs = document.querySelectorAll('img');
    const found = new Map(); // key: 商品コード付きの識別子, value: URL

    allImgs.forEach(img => {
      const srcs = [img.currentSrc, img.src, img.getAttribute('src')];
      if (img.srcset) {
        img.srcset.split(',').forEach(p => srcs.push(p.trim().split(' ')[0]));
      }
      srcs.forEach(src => {
        if (!src || src.startsWith('data:') || src.startsWith('blob:')) return;
        try {
          const url = new URL(src, location.href);
          if (!url.hostname.endsWith('.yimg.jp')) return;
          // item-shopping.c.yimg.jp/i/[size]/[path]
          const m = url.pathname.match(/^\/i\/([a-z])\/(.+)$/);
          if (!m) return;
          const size = m[1];
          const identifier = m[2]; // yukaiya_ih-22-04_1_d_20220727113438 など
          // 元サイズ(n)を優先。既に登録済みで新しいのがサムネなら上書きしない
          const rank = { n: 4, l: 3, j: 2, g: 1 }; // 元サイズが最高
          const existingUrl = found.get(identifier);
          if (!existingUrl) {
            found.set(identifier, url.origin + '/i/n/' + identifier);
          }
        } catch {}
      });
    });

    // og:image も同じ処理
    if (ogImage) {
      try {
        const url = new URL(ogImage, location.href);
        const m = url.pathname.match(/^\/i\/([a-z])\/(.+)$/);
        if (m) {
          const identifier = m[2];
          if (!found.has(identifier)) {
            found.set(identifier, url.origin + '/i/n/' + identifier);
          }
        }
      } catch {}
    }

    // 順序: メイン画像（サフィックスなし）→ _1_d_... → _2_d_... の順
    const urls = Array.from(found.values());
    urls.sort((a, b) => {
      // ファイル名の末尾の番号を抽出
      const ma = a.match(/_(\d+)_[a-z]_/);
      const mb = b.match(/_(\d+)_[a-z]_/);
      const na = ma ? parseInt(ma[1]) : -1; // メイン画像(番号なし)は先頭
      const nb = mb ? parseInt(mb[1]) : -1;
      return na - nb;
    });

    const debug = `全img${allImgs.length}件 → yimg.jp画像${urls.length}件（メイン+サムネ）`;

    // フォルダ名: ストアID + 商品コード
    // URL: /yukaiya/ih-22-04.html
    const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+?)(?:\.html)?$/);
    const folder = 'shop-images/yahoo_' + (m ? `${m[1]}_${m[2]}` : Date.now());

    return { urls, folder, debug };
  } catch (e) {
    return { urls: [], folder: '', debug: 'エラー: ' + e.message };
  }
}

// ================================
// 範囲指定モード
// ================================
function startPicker(site) {
  if (window.__shopPickerActive) return;
  window.__shopPickerActive = true;
  const overlay = document.createElement('div');
  overlay.style.cssText = `position:fixed;pointer-events:none;border:3px solid #bf0000;background:rgba(191,0,0,0.08);z-index:2147483646;transition:all 0.05s;box-sizing:border-box;`;
  document.body.appendChild(overlay);
  const hint = document.createElement('div');
  hint.textContent = '画像エリアにカーソル合わせてクリック / Esc:キャンセル';
  hint.style.cssText = `position:fixed;top:10px;left:50%;transform:translateX(-50%);background:#bf0000;color:white;padding:8px 16px;border-radius:4px;font:bold 13px sans-serif;z-index:2147483647;pointer-events:none;box-shadow:0 2px 8px rgba(0,0,0,0.3);`;
  document.body.appendChild(hint);
  let cur = null;
  const onOver = (e) => {
    const el = e.target;
    if (!el || el === overlay || el === hint) return;
    cur = el;
    const r = el.getBoundingClientRect();
    overlay.style.left = r.left + 'px'; overlay.style.top = r.top + 'px';
    overlay.style.width = r.width + 'px'; overlay.style.height = r.height + 'px';
  };
  const onClick = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (!cur) return;
    cleanup();
    const urls = new Set();
    if (cur.tagName === 'IMG') { const s = cur.currentSrc || cur.src; if (s && !s.startsWith('data:')) urls.add(s); }
    cur.querySelectorAll('img').forEach(img => {
      [img.currentSrc, img.src].forEach(s => { if (s && !s.startsWith('data:') && !s.startsWith('blob:')) urls.add(s); });
    });
    let arr = Array.from(urls).map(u => { try { return new URL(u, location.href).toString(); } catch { return null; } }).filter(Boolean);

    if (site === 'rakuten') {
      arr = arr.filter(u => { try { const url = new URL(u); return url.hostname === 'image.rakuten.co.jp' || url.hostname.endsWith('.r10s.jp'); } catch { return false; } });
    } else if (site === 'yahoo') {
      // yimg.jp の /i/[サイズ]/... を元サイズ(n)に変換
      const found = new Map();
      arr.forEach(u => {
        try {
          const url = new URL(u);
          if (!url.hostname.endsWith('.yimg.jp')) return;
          const m = url.pathname.match(/^\/i\/([a-z])\/(.+)$/);
          if (!m) return;
          const id = m[2];
          if (!found.has(id)) found.set(id, url.origin + '/i/n/' + id);
        } catch {}
      });
      arr = Array.from(found.values());
    }

    arr = Array.from(new Set(arr));
    if (arr.length === 0) { toast('画像が見つかりません', true); return; }
    const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+?)(?:\.html)?$/);
    const prefix = site === 'yahoo' ? 'yahoo_' : 'rakuten_';
    const folder = 'shop-images/' + prefix + (m ? `${m[1]}_${m[2]}` : Date.now());
    toast(`${arr.length}件 DL中…`);
    chrome.runtime.sendMessage({ type: 'DOWNLOAD_ALL', urls: arr, folder }, (res) => {
      if (res?.ok) toast(`✅ ${res.success}/${arr.length}件 DL開始`); else toast('⚠️ ' + (res?.error || '不明'), true);
    });
  };
  const onKey = (e) => { if (e.key === 'Escape') { cleanup(); toast('キャンセル'); } };
  function cleanup() {
    document.removeEventListener('mouseover', onOver, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    overlay.remove(); hint.remove();
    window.__shopPickerActive = false;
  }
  function toast(t, err) {
    const d = document.createElement('div');
    d.textContent = t;
    d.style.cssText = `position:fixed;top:10px;left:50%;transform:translateX(-50%);background:${err?'#bf0000':'#222'};color:white;padding:10px 18px;border-radius:4px;font:13px sans-serif;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.3);`;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 3500);
  }
  document.addEventListener('mouseover', onOver, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKey, true);
}

// =====================================================
// NE Quick Access - background service worker
// MAIN world でページ内JS関数を呼び出す（CSP回避）
// =====================================================

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === 'executeInMainWorld') {
    executeInMainWorld(sender.tab.id, req.fnPath, req.id)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message || String(e) }));
    return true; // async
  }
  if (req.action === 'gistPush') {
    gistPush(req.token, req.gistId, req.filename, req.content)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }
  if (req.action === 'gistPull') {
    gistPull(req.token, req.gistId, req.filename)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }
  if (req.action === 'gistGetAll') {
    gistGetAll(req.token, req.gistId)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }
  if (req.action === 'gistPushFiles') {
    gistPushFiles(req.token, req.gistId, req.files)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }
});

// Gist内の全ファイルを取得（content文字列のマップを返す）
async function gistGetAll(token, gistId) {
  try {
    const res = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
      headers: { 'Authorization': 'token ' + token, 'Accept': 'application/vnd.github+json' }
    });
    if (!res.ok) {
      const t = await res.text();
      return { ok: false, error: `(${res.status}) ${t.slice(0, 150)}` };
    }
    const gist = await res.json();
    const files = {};
    Object.keys(gist.files || {}).forEach(name => {
      files[name] = gist.files[name].content;
    });
    return { ok: true, files };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || String(e)) };
  }
}

// 複数ファイルをまとめて書き込み（filesMap: {filename: content}）
async function gistPushFiles(token, gistId, filesMap) {
  try {
    const files = {};
    Object.keys(filesMap).forEach(name => { files[name] = { content: filesMap[name] }; });
    const res = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
      method: 'PATCH',
      headers: {
        'Authorization': 'token ' + token,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ files })
    });
    if (!res.ok) {
      const t = await res.text();
      return { ok: false, error: `(${res.status}) ${t.slice(0, 150)}` };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || String(e)) };
  }
}

// Gistへ書き込み（送信）
async function gistPush(token, gistId, filename, content) {
  try {
    const res = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
      method: 'PATCH',
      headers: {
        'Authorization': 'token ' + token,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ files: { [filename]: { content } } })
    });
    if (!res.ok) {
      const t = await res.text();
      return { ok: false, error: `(${res.status}) ${t.slice(0, 150)}` };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || String(e)) };
  }
}

// Gistから取得（受信）
async function gistPull(token, gistId, filename) {
  try {
    const res = await fetch(`https://api.github.com/gists/${encodeURIComponent(gistId)}`, {
      headers: {
        'Authorization': 'token ' + token,
        'Accept': 'application/vnd.github+json'
      }
    });
    if (!res.ok) {
      const t = await res.text();
      return { ok: false, error: `(${res.status}) ${t.slice(0, 150)}` };
    }
    const gist = await res.json();
    const file = gist.files && gist.files[filename];
    if (!file || file.content === undefined) {
      return { ok: false, error: 'Gistに該当ファイルがありません（先に送信してください）' };
    }
    return { ok: true, content: file.content };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || String(e)) };
  }
}

async function executeInMainWorld(tabId, fnPath, id) {
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (fnPath, id) => {
        try {
          // fnPath は "originalStatus.search" or "searchBookmark.search"
          const [objName, methodName] = fnPath.split('.');
          const obj = window[objName];
          if (typeof obj === 'undefined') {
            return { ok: false, error: `${objName} がページに存在しません` };
          }
          if (typeof obj[methodName] !== 'function') {
            return { ok: false, error: `${fnPath} は関数ではありません` };
          }
          obj[methodName](id);
          return { ok: true };
        } catch (e) {
          return { ok: false, error: e.message || String(e) };
        }
      },
      args: [fnPath, id]
    });

    return result?.result || { ok: false, error: '実行結果が取得できませんでした' };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  }
}

const $ = (id) => document.getElementById(id);

function jstToday(offsetDays = 0) {
  const d = new Date(Date.now() + 9 * 3600 * 1000 + offsetDays * 86400000);
  return d.toISOString().slice(0, 10);
}

async function load() {
  const { settings = {}, state = {}, logs = [] } = await chrome.storage.local.get(['settings', 'state', 'logs']);
  $('start').value = settings.start || jstToday(-1);
  $('end').value = settings.end || jstToday(-1);
  $('fulfillment').value = 'fba';   // 開くたびにAmazon出荷(FBA)で表示
  $('interval').value = settings.interval ?? 2;
  $('folder').value = settings.folder || '';
  renderState(state);
  renderLogs(logs);
  if (!state.running) chrome.action.setBadgeText({ text: '' });   // 完了バッジを既読にする
}

function options() {
  return {
    start: $('start').value,
    end: $('end').value,
    fulfillment: $('fulfillment').value,
    interval: Number($('interval').value) || 0,
    folder: $('folder').value.trim(),
  };
}

function renderState(s) {
  const total = s.total || 0, done = s.done || 0;
  $('prog').max = Math.max(total, 1);
  $('prog').value = done;
  $('run').disabled = !!s.running;
  $('status').textContent = s.running
    ? `実行中… ${done}/${total}日${s.current ? '（' + s.current + '）' : ''}`
    : total ? `完了 ${done}/${total}日` : '待機中';
}
function renderLogs(logs) {
  const el = $('log');
  el.value = logs.join('\n');
  el.scrollTop = el.scrollHeight;
}

document.querySelectorAll('.quick button').forEach((b) => b.addEventListener('click', () => {
  const q = b.dataset.q;
  $('end').value = jstToday(-1);
  $('start').value = q === 'yesterday' ? jstToday(-1) : jstToday(-Number(q));
}));

$('run').addEventListener('click', async () => {
  const o = options();
  if (!o.start || !o.end) return ($('status').textContent = '開始日と終了日を入力してください');
  if (o.start > o.end) return ($('status').textContent = '開始日が終了日より後になっています');
  const days = (Date.parse(o.end) - Date.parse(o.start)) / 86400000 + 1;
  if (days > 366) return ($('status').textContent = '期間は366日以内にしてください');
  await chrome.storage.local.set({ settings: o });
  const res = await chrome.runtime.sendMessage({ type: 'start', options: o });
  if (!res || !res.ok) $('status').textContent = (res && res.error) || '開始できませんでした';
});
$('stop').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'stop' }));
$('copy').addEventListener('click', async () => {
  await navigator.clipboard.writeText($('log').value);
  $('copy').textContent = 'コピー済';
  setTimeout(() => ($('copy').textContent = 'コピー'), 1200);
});
$('clear').addEventListener('click', () => chrome.storage.local.set({ logs: [] }));

['start', 'end', 'interval', 'folder'].forEach((id) =>
  $(id).addEventListener('change', () => chrome.storage.local.set({ settings: options() })));

chrome.storage.onChanged.addListener((ch) => {
  if (ch.state) renderState(ch.state.newValue || {});
  if (ch.logs) renderLogs(ch.logs.newValue || []);
});

$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
load();

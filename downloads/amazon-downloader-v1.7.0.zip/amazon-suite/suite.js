// 最上部：共通の開始日/終了日 と「必要ページを開く」
const $ = (id) => document.getElementById(id);
function jstToday(off = 0) {
  return new Date(Date.now() + 9 * 3600 * 1000 + off * 86400000).toISOString().slice(0, 10);
}
async function initTop() {
  const { sharedDates } = await chrome.storage.local.get('sharedDates');
  const s = sharedDates && sharedDates.start ? sharedDates.start : jstToday(-1);
  const e = sharedDates && sharedDates.end ? sharedDates.end : jstToday(-1);
  $('top-start').value = s;
  $('top-end').value = e;
  await chrome.storage.local.set({ sharedDates: { start: s, end: e } });
}
function save() {
  chrome.storage.local.set({ sharedDates: { start: $('top-start').value, end: $('top-end').value } });
}
$('top-start').addEventListener('change', save);
$('top-end').addEventListener('change', save);

$('top-open').addEventListener('click', async () => {
  const urls = [
    'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
    'https://sellercentral-japan.amazon.com/orders-v3?page=1'
  ];
  for (const u of urls) { try { await chrome.tabs.create({ url: u, active: false }); } catch (_) {} }
  const b = $('top-open'); b.textContent = '✅ 開きました（各タブを一度表示してください）';
  setTimeout(() => (b.textContent = '🗂️ 必要ページを開く'), 2500);
});

initTop();

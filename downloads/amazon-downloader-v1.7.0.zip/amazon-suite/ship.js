const $ = (id) => document.getElementById(id);

async function load() {
  const { settings = {}, state = {}, logs = [] } = await chrome.storage.local.get(['settings', 'state', 'logs']);
  $('fulfillment').value = 'fba';   // 開くたびにAmazon出荷(FBA)で表示
  renderState(state);
  renderLogs(logs);
  if (!state.running) chrome.action.setBadgeText({ text: '' });
}

function renderState(s) {
  const total = s.total || 0, done = s.done || 0;
  $('prog').max = Math.max(total, 1);
  $('prog').value = done;
  $('run').disabled = !!s.running;
  $('status').textContent = s.running
    ? `実行中… ${done}/${total}日${s.current ? '（' + s.current + '）' : ''}`
    : total ? `完了 ${done}/${total}日` : '待機中';
  const doneEl = document.getElementById('done');
  if (doneEl) doneEl.classList.toggle('show', !s.running && total > 0 && done >= total);
}
function renderLogs(logs) {
  const el = $('log');
  el.value = logs.join('\n');
  el.scrollTop = el.scrollHeight;
}

$('run').addEventListener('click', async () => {
  const sd = (await chrome.storage.local.get('sharedDates')).sharedDates || {};
  const o = { start: sd.start, end: sd.end, fulfillment: $('fulfillment').value, interval: 2, folder: '' };
  if (!o.start || !o.end) return ($('status').textContent = '上部で開始日と終了日を入力してください');
  if (o.start > o.end) return ($('status').textContent = '開始日が終了日より後になっています');
  const days = (Date.parse(o.end) - Date.parse(o.start)) / 86400000 + 1;
  if (days > 366) return ($('status').textContent = '期間は366日以内にしてください');
  await chrome.storage.local.set({ settings: o });
  const res = await chrome.runtime.sendMessage({ type: 'start', options: o });
  if (!res || !res.ok) $('status').textContent = (res && res.error) || '開始できませんでした';
});
$('stop').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'stop' }));
$('copy').addEventListener('click', async () => {
  await navigator.clipboard.writeText($('log').value);
  $('copy').textContent = '📋 コピー済';
  setTimeout(() => ($('copy').textContent = '📋 ログをコピー'), 1200);
});
$('clear').addEventListener('click', () => chrome.storage.local.set({ logs: [] }));
$('fulfillment').addEventListener('change', () => chrome.storage.local.set({ settings: { fulfillment: $('fulfillment').value } }));

chrome.storage.onChanged.addListener((ch) => {
  if (ch.state) renderState(ch.state.newValue || {});
  if (ch.logs) renderLogs(ch.logs.newValue || []);
});

$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
load();

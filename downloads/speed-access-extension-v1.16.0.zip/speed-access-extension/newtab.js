// ============================================
// Speed Access - Chrome Extension (GitHub版)
// ============================================

// ============================================
// 配布用の固定設定 (配布者がここを編集してから配布)
// ユーザーはPATだけ入力すればOK
// ============================================
const FIXED_CONFIG = {
  OWNER: 'kaiyoshida0318',                  // ← GitHubユーザー名 (配布者が事前に設定)
  REPO: 'speed-access-data',                // ← リポジトリ名 (配布者が事前に設定)
  FILE_PATH: 'shared-tabs.json',
  BRANCH: 'main'
};

// 実行時設定 (FIXED_CONFIG + ユーザー入力のPAT)
let GITHUB_CONFIG = {
  ...FIXED_CONFIG,
  TOKEN: ''
};
// 最終同期日時 (タブIDごと)
let lastSyncTimes = {};
// 同期ON/OFF。OFFにすると「編集時の自動アップロード」と「起動時の自動取得」を止める。
// 手動の反映/取得ボタンはOFF中でも動く。
let syncEnabled = true;
// OFF中にローカルで共有タブを編集したか (未反映があるか) のフラグ
let sharedDirty = false;

// タブ編集(複数選択)モード
let bulkEditMode = false;
let bulkSelected = new Set(); // 選択中のタイルID

// ローカル編集の世代カウンタ。自動取得(fetch)の途中で編集が入ったら、
// 取得結果でローカルを上書きしないための検知に使う。
let localEditSeq = 0;
function markLocalEdit() { localEditSeq++; }
// 自分自身が保存した直後のタイミング (他ページ変更の取り込みで自分の書き込みを無視するため)
let lastLocalSaveAt = 0;

// 同期ON/OFFを切り替えて保存
function setSyncEnabled(v) {
  syncEnabled = !!v;
  chrome.storage.local.set({ speedAccessSyncEnabled: syncEnabled });
  appLog('info', 'sync', `同期を ${syncEnabled ? 'ON' : 'OFF'} にしました`);
}

const EXPORT_VERSION = 1;

// ============================================
// ★★★ 同期の仕組み 説明文 ★★★
// 歯車 → 同期 → 「同期の仕組み」で表示される。
// ■ 重要: 同期の挙動を変更したら、必ずこの説明文も合わせて更新すること。
//   (起動時の自動取得、反映/取得の対象範囲、個人タブの扱い などを変えたとき)
// ============================================
const SYNC_BEHAVIOR_HTML = `
  <div style="font-size:13px;line-height:1.8;color:#333;">
    <p style="margin:0 0 12px;">このツールの「共有タブ」は、GitHub上の <code>shared-tabs.json</code> を通じてチームと同期します。挙動は次のとおりです。</p>

    <h3 style="font-size:14px;margin:16px 0 6px;">🔄 開くたびに自動でダウンロード</h3>
    <p style="margin:0 0 12px;">新しいタブを開くたびに、いま開いている<b>共有タブ</b>の最新内容をGitHubから<b>自動的に取得（ダウンロード）</b>します。バックグラウンドで静かに動くので通知は出ません。誰かがPCで更新した内容は、あなたが新しいタブを開いた時点で反映されます。</p>

    <h3 style="font-size:14px;margin:16px 0 6px;">⬆️ アップロード（反映）は手動だけ</h3>
    <p style="margin:0 0 12px;">あなたの変更がGitHubに送られるのは、メニューから<b>「反映-当タブ」</b>を押したときだけです。自動では絶対に書き込みません。編集しただけではチームに反映されないので、共有したいときは反映を押してください。</p>

    <h3 style="font-size:14px;margin:16px 0 6px;">👤 個人タブは同期されない</h3>
    <p style="margin:0 0 12px;"><b>個人タブ</b>はこのPC内（ブラウザのローカル保存）にのみ保存され、GitHubには一切送られません。あなただけのものです。</p>

    <h3 style="font-size:14px;margin:16px 0 6px;">🔌 同期 ON / OFF</h3>
    <p style="margin:0 0 12px;">メニュー先頭の<b>「同期: ON/OFF」</b>で切り替えられます。<b>OFF</b>にすると、編集してもGitHubに自動で書き込まれず、起動時の自動ダウンロードも止まります（このPCの中だけで作業）。たくさん編集するときは、先にOFFにして自由に直し、終わってから<b>「反映-全タブ」</b>でまとめて送るのがおすすめです。1個ずつ反映するより通信の衝突が起きにくくなります。</p>
    <p style="margin:0 0 12px;color:#b06000;">※ OFF中の変更は「未反映」の状態です。送信する前にONに戻しただけでは送られません。必ず「反映-全タブ」（または「反映-当タブ」）を押してください。反映ボタンは手動操作なので、同期OFF中でもちゃんとGitHubに送信されます。</p>
    <p style="margin:0 0 12px;color:#b06000;">※ 「新しいタブ」画面を複数開いたまま作業しないでください。片方だけで編集し、別の画面が古い状態のままだと、あとから上書きが起きることがあります。OFFにすると開いている全ページに反映されますが、確実にするなら作業用は1枚にしておくと安全です。</p>

    <h3 style="font-size:14px;margin:16px 0 6px;">🧭 メニューの各操作</h3>
    <ul style="margin:0 0 12px;padding-left:20px;">
      <li><b>同期: ON/OFF</b>：自動同期の切り替え</li>
      <li><b>反映-当タブ</b>：いま見ている共有タブの内容をGitHubに送信（アップロード）</li>
      <li><b>反映-全タブ</b>：開いている全共有タブを1回でまとめて送信。他メンバーのタブは消えない</li>
      <li><b>取得-当タブ</b>：いま見ている共有タブの最新をGitHubから読み込み（ダウンロード）</li>
      <li><b>取得-全タブ</b>：開いている全共有タブをまとめて最新化（ダウンロード）</li>
    </ul>

    <h3 style="font-size:14px;margin:16px 0 6px;">⚠️ 同時編集について</h3>
    <p style="margin:0;">同じ共有タブを複数人が同時に編集して反映すると、<b>後から反映した人の内容が優先</b>されます（後勝ち）。大きな変更をする前に「取得-当タブ」で最新にしておくと安全です。</p>
  </div>
`;

// ============================================
// State
// ============================================
let state = {
  tabs: [],
  activeTabId: null
};

let currentEditingTile = null;
let pendingConfirmAction = null;
let pendingImportData = null;

// タイルドラッグ中の状態
let draggedTile = null;  // { tileId, sourceTabId }
let tabHoverTimer = null;  // タブホバーで切替するためのタイマー

// 画像キャッシュ (URL → Base64 dataURL)
const imageCache = new Map();
const cacheFetchingUrls = new Set();  // フェッチ中URL (重複防止)
let imageCacheLoaded = false;

// アプリログ (デバッグ用)
const APP_LOG = [];
const MAX_LOG_ENTRIES = 200;

function appLog(level, category, message, extra = null) {
  const entry = {
    time: new Date().toISOString(),
    level,        // 'info' | 'warn' | 'error' | 'debug'
    category,     // 'github' | 'sync' | 'image' | 'tab' | 'storage' | 'general'
    message: String(message),
    extra: extra ? (typeof extra === 'string' ? extra : JSON.stringify(extra).slice(0, 500)) : null
  };
  APP_LOG.push(entry);
  if (APP_LOG.length > MAX_LOG_ENTRIES) APP_LOG.shift();

  // コンソールにも出力
  const prefix = `[SpeedAccess/${category}]`;
  if (level === 'error') console.error(prefix, message, extra || '');
  else if (level === 'warn') console.warn(prefix, message, extra || '');
  else console.log(prefix, message, extra || '');
}

// レイアウト設定のデフォルト
const DEFAULT_LAYOUT = {
  columns: 6,
  width: 240,
  height: 140,
  gap: 16,
  headerSpacing: 24
};
// 推奨レイアウト (ユーザーが見つけた使いやすい設定)
const RECOMMENDED_LAYOUT = {
  columns: 6,
  width: 260,
  height: 150,
  gap: 8,
  headerSpacing: 64
};
// 全タブのレイアウト設定 { [tabId]: layout }
let allLayouts = {};
// 現在表示中のレイアウト (アクティブタブの設定)
let layoutSettings = { ...DEFAULT_LAYOUT };

// ============================================
// Storage - 個人データ (chrome.storage.local)
// ============================================
const personalStorage = {
  async load() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessData'], (result) => {
        if (result.speedAccessData) {
          resolve(result.speedAccessData);
        } else {
          // 最初は空 (ユーザーが最初のタブを作る)
          resolve({
            tabs: [],
            activeTabId: null
          });
        }
      });
    });
  },

  async save(data) {
    lastLocalSaveAt = Date.now();
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessData: data }, resolve);
    });
  },

  async loadLayout() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLayouts', 'speedAccessLayout'], (result) => {
        // 新形式: タブごとのレイアウト
        if (result.speedAccessLayouts && typeof result.speedAccessLayouts === 'object') {
          resolve(result.speedAccessLayouts);
          return;
        }
        // 旧形式: 単一レイアウト (マイグレーション)
        if (result.speedAccessLayout) {
          const oldLayout = { ...DEFAULT_LAYOUT, ...result.speedAccessLayout };
          // 旧設定を全タブのデフォルトとして扱う
          resolve({ _default: oldLayout });
          return;
        }
        resolve({});
      });
    });
  },

  async saveLayout(allLayouts) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLayouts: allLayouts }, resolve);
    });
  },

  async loadImageCache() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessImageCache'], (result) => {
        resolve(result.speedAccessImageCache || {});
      });
    });
  },

  async saveImageCache(cacheObj) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessImageCache: cacheObj }, resolve);
    });
  },

  async loadSyncConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessSyncConfig'], (result) => {
        resolve(result.speedAccessSyncConfig || null);
      });
    });
  },

  async saveSyncConfig(config) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessSyncConfig: config }, resolve);
    });
  },

  async loadLastSyncTimes() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLastSyncTimes'], (result) => {
        resolve(result.speedAccessLastSyncTimes || {});
      });
    });
  },

  async saveLastSyncTimes(times) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLastSyncTimes: times }, resolve);
    });
  }
};

// ============================================
// Storage - 共有データ (GitHub API)
// ============================================
const sharedStorage = {
  // ファイルごとのSHAをキャッシュ (GitHubの更新にはSHAが必要)
  _fileSha: null,

  isConfigured() {
    return GITHUB_CONFIG.OWNER.trim().length > 0 &&
           GITHUB_CONFIG.REPO.trim().length > 0 &&
           GITHUB_CONFIG.TOKEN.trim().length > 0;
  },

  _apiUrl() {
    return `https://api.github.com/repos/${GITHUB_CONFIG.OWNER.trim()}/${GITHUB_CONFIG.REPO.trim()}/contents/${GITHUB_CONFIG.FILE_PATH.trim()}`;
  },

  _headers() {
    return {
      'Authorization': `Bearer ${GITHUB_CONFIG.TOKEN.trim()}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28'
    };
  },

  // UTF-8文字列をBase64に
  _encodeBase64(str) {
    // 日本語などマルチバイト文字対応
    return btoa(unescape(encodeURIComponent(str)));
  },

  _decodeBase64(str) {
    return decodeURIComponent(escape(atob(str.replace(/\n/g, ''))));
  },

  async fetchAll() {
    if (!this.isConfigured()) {
      appLog('warn', 'github', 'fetchAll skipped: not configured');
      throw new Error('GitHub連携の初期セットアップが完了していません。README.mdを確認してください。');
    }

    const url = `${this._apiUrl()}?ref=${GITHUB_CONFIG.BRANCH}&_=${Date.now()}`;
    appLog('debug', 'github', 'fetchAll: GET ' + url);
    const res = await fetch(url, {
      headers: this._headers(),
      cache: 'no-store'
    });

    if (res.status === 404) {
      // ファイルがまだ存在しない場合
      this._fileSha = null;
      appLog('info', 'github', 'fetchAll: file not found (404), returning empty');
      return {};
    }
    if (!res.ok) {
      const errText = await res.text();
      appLog('error', 'github', `fetchAll failed: ${res.status}`, errText.slice(0, 200));
      throw new Error(`GitHub API エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const fileData = await res.json();
    this._fileSha = fileData.sha;

    try {
      let b64 = fileData.content;
      // 重要: GitHub Contents API は 1MB を超えるファイルの content を空文字で返す仕様。
      // その場合は Blobs API (最大100MB対応) から本文を取り直す。
      // これを怠ると「中身が空」と誤認し、共有タブが取得できない/誤って上書きする原因になる。
      if ((!b64 || !b64.trim()) && fileData.sha && (fileData.size > 0 || fileData.encoding === 'none')) {
        appLog('warn', 'github', `fetchAll: Contents APIが本文を返さず (size=${fileData.size}B, 1MB超の可能性)。Blobs APIで再取得します`);
        const blobUrl = `https://api.github.com/repos/${GITHUB_CONFIG.OWNER.trim()}/${GITHUB_CONFIG.REPO.trim()}/git/blobs/${fileData.sha}?_=${Date.now()}`;
        const blobRes = await fetch(blobUrl, { headers: this._headers(), cache: 'no-store' });
        if (!blobRes.ok) {
          const errText = await blobRes.text();
          appLog('error', 'github', `fetchAll: Blobs API失敗 (${blobRes.status})`, errText.slice(0, 200));
          throw new Error(`GitHub Blobs API エラー (${blobRes.status})。大きいファイルの取得に失敗しました。`);
        }
        const blobData = await blobRes.json();
        b64 = blobData.content;
        appLog('info', 'github', 'fetchAll: Blobs APIから本文を取得しました');
      }

      const content = (b64 && b64.trim()) ? this._decodeBase64(b64) : '';
      if (!content || !content.trim()) {
        // ファイルが空 (新規作成直後など)
        appLog('warn', 'github', 'fetchAll: ファイルは存在するが中身が空');
        return {};
      }
      const parsed = JSON.parse(content) || {};
      const keys = Object.keys(parsed);
      appLog('info', 'github', `fetchAll success: ${keys.length} 個の共有タブを取得`, { codes: keys, sha: fileData.sha });
      return parsed;
    } catch (err) {
      appLog('error', 'github', 'fetchAll: JSON パースエラー (データ保護のため処理中断)', err.message);
      // 重要: パースエラー時はエラーを投げて保存を止める (データ消失防止)
      throw new Error(`GitHub上のshared-tabs.jsonが壊れています (${err.message})。保存を中止しました。ファイルを手動で修正してください。`);
    }
  },

  _repoApiBase() {
    return `https://api.github.com/repos/${GITHUB_CONFIG.OWNER.trim()}/${GITHUB_CONFIG.REPO.trim()}`;
  },

  async saveAll(allData) {
    if (!this.isConfigured()) {
      throw new Error('GitHub連携の初期セットアップが完了していません。');
    }

    const jsonStr = JSON.stringify(allData, null, 2);
    const byteSize = new TextEncoder().encode(jsonStr).length;
    const codes = Object.keys(allData);

    // ファイル全体が約1MBに近づいたら Git Data API 方式 (最大100MB対応) に自動で切り替える。
    // Contents API (PUT) は大きいファイルで不安定なため。普段は軽いPUTのまま。
    const LARGE_THRESHOLD = 1000 * 1024; // 約1MB (安全マージンを取って1MBより少し手前)
    if (byteSize > LARGE_THRESHOLD) {
      appLog('info', 'github', `saveAll: 大きいファイル(${byteSize}B) → Git Data API方式で保存`, { codes });
      return this._saveViaGitData(jsonStr, codes);
    }

    // 通常 (小さいファイル): Contents API
    if (!this._fileSha) {
      try { await this.fetchAll(); } catch {}
    }

    const body = {
      message: `Update shared-tabs.json (${new Date().toISOString()})`,
      content: this._encodeBase64(jsonStr),
      branch: GITHUB_CONFIG.BRANCH
    };

    if (this._fileSha) {
      body.sha = this._fileSha;
    }

    appLog('debug', 'github', `saveAll: PUT (${codes.length} codes, ${byteSize}B)`, { codes });

    const res = await fetch(this._apiUrl(), {
      method: 'PUT',
      headers: {
        ...this._headers(),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      const errText = await res.text();

      // SHAのコンフリクト (他のユーザーが先に書き込んだ) → リトライ
      if (res.status === 409 || errText.includes('does not match')) {
        appLog('warn', 'github', 'saveAll: SHA conflict, retrying');
        this._fileSha = null;
        await this.fetchAll();
        return this.saveAll(allData);
      }

      appLog('error', 'github', `saveAll failed: ${res.status}`, errText.slice(0, 200));
      throw new Error(`GitHub 保存エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const result = await res.json();
    this._fileSha = result.content?.sha || null;
    appLog('info', 'github', `saveAll success (${codes.length} codes)`, { sha: this._fileSha });
  },

  // 大きいファイル用の保存: blob → tree → commit → ref の4ステップ (Git Data API, 最大100MB)
  // 必要なPAT権限は Contents: Read and write のみ (Contents権限にGit Data操作が含まれる)
  async _saveViaGitData(jsonStr, codes, _isRetry) {
    const base = this._repoApiBase();
    const branch = GITHUB_CONFIG.BRANCH.trim();
    const h = { ...this._headers(), 'Content-Type': 'application/json' };

    // 1. 現在のブランチ先端コミットを取得
    const refRes = await fetch(`${base}/git/ref/heads/${branch}?_=${Date.now()}`, { headers: this._headers(), cache: 'no-store' });
    if (!refRes.ok) {
      const t = await refRes.text();
      appLog('error', 'github', `_saveViaGitData: ref取得失敗 (${refRes.status})`, t.slice(0, 200));
      throw new Error(`GitHub 保存エラー (ref取得 ${refRes.status}): ${t.slice(0, 100)}`);
    }
    const latestCommitSha = (await refRes.json()).object.sha;

    // 2. そのコミットのツリーSHAを取得 (差分のベースにする)
    const commitRes = await fetch(`${base}/git/commits/${latestCommitSha}`, { headers: this._headers(), cache: 'no-store' });
    if (!commitRes.ok) {
      const t = await commitRes.text();
      throw new Error(`GitHub 保存エラー (commit取得 ${commitRes.status}): ${t.slice(0, 100)}`);
    }
    const baseTreeSha = (await commitRes.json()).tree.sha;

    // 3. 新しいファイル内容をblobとして作成
    const blobRes = await fetch(`${base}/git/blobs`, {
      method: 'POST', headers: h,
      body: JSON.stringify({ content: this._encodeBase64(jsonStr), encoding: 'base64' })
    });
    if (!blobRes.ok) {
      const t = await blobRes.text();
      throw new Error(`GitHub 保存エラー (blob作成 ${blobRes.status}): ${t.slice(0, 100)}`);
    }
    const blobSha = (await blobRes.json()).sha;

    // 4. ツリーを作成 (該当ファイルだけ差し替え)
    const treeRes = await fetch(`${base}/git/trees`, {
      method: 'POST', headers: h,
      body: JSON.stringify({
        base_tree: baseTreeSha,
        tree: [{ path: GITHUB_CONFIG.FILE_PATH.trim(), mode: '100644', type: 'blob', sha: blobSha }]
      })
    });
    if (!treeRes.ok) {
      const t = await treeRes.text();
      throw new Error(`GitHub 保存エラー (tree作成 ${treeRes.status}): ${t.slice(0, 100)}`);
    }
    const newTreeSha = (await treeRes.json()).sha;

    // 5. コミットを作成
    const newCommitRes = await fetch(`${base}/git/commits`, {
      method: 'POST', headers: h,
      body: JSON.stringify({
        message: `Update shared-tabs.json (${new Date().toISOString()})`,
        tree: newTreeSha,
        parents: [latestCommitSha]
      })
    });
    if (!newCommitRes.ok) {
      const t = await newCommitRes.text();
      throw new Error(`GitHub 保存エラー (commit作成 ${newCommitRes.status}): ${t.slice(0, 100)}`);
    }
    const newCommitSha = (await newCommitRes.json()).sha;

    // 6. ブランチ先端を新コミットに進める
    const patchRes = await fetch(`${base}/git/refs/heads/${branch}`, {
      method: 'PATCH', headers: h,
      body: JSON.stringify({ sha: newCommitSha, force: false })
    });
    if (!patchRes.ok) {
      const t = await patchRes.text();
      // 他の人が先にコミットしてfast-forwardできない → 1回だけ最初からリトライ
      if (!_isRetry && (patchRes.status === 422 || t.includes('fast forward') || t.includes('not a fast'))) {
        appLog('warn', 'github', '_saveViaGitData: ブランチ競合、最初からやり直します');
        return this._saveViaGitData(jsonStr, codes, true);
      }
      throw new Error(`GitHub 保存エラー (ref更新 ${patchRes.status}): ${t.slice(0, 100)}`);
    }

    this._fileSha = blobSha;
    appLog('info', 'github', `saveAll success via Git Data API (${codes.length} codes)`, { commit: newCommitSha });
  },

  async getByCode(code) {
    const all = await this.fetchAll();
    return all[code] || null;
  },

  async saveByCode(code, tabData) {
    const all = await this.fetchAll();
    all[code] = tabData;
    appLog('info', 'github', `saveByCode: ${code}`, { name: tabData.name, tiles: tabData.tiles?.length });
    await this.saveAll(all);
  },

  async deleteByCode(code) {
    const all = await this.fetchAll();
    if (all[code]) {
      delete all[code];
      appLog('info', 'github', `deleteByCode: ${code}`);
      await this.saveAll(all);
    } else {
      appLog('warn', 'github', `deleteByCode: ${code} not found`);
    }
  },

  async renameByCode(code, newName) {
    const all = await this.fetchAll();
    if (all[code]) {
      const oldName = all[code].name;
      all[code].name = newName;
      appLog('info', 'github', `renameByCode: ${code}`, { from: oldName, to: newName });
      await this.saveAll(all);
    } else {
      appLog('warn', 'github', `renameByCode: ${code} not found`);
    }
  }
};

// ============================================
// Helpers
// ============================================
function getFaviconUrl(url) {
  try {
    const domain = new URL(url).hostname;
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
  } catch {
    return '';
  }
}

// ============================================
// 画像キャッシュ
// ============================================
async function loadImageCacheToMemory() {
  if (imageCacheLoaded) return;
  try {
    const stored = await personalStorage.loadImageCache();
    Object.entries(stored).forEach(([key, value]) => {
      imageCache.set(key, value);
    });
  } catch (err) {
    console.error('Failed to load image cache:', err);
  }
  imageCacheLoaded = true;
}

let saveCacheTimer = null;
function scheduleSaveImageCache() {
  if (saveCacheTimer) clearTimeout(saveCacheTimer);
  saveCacheTimer = setTimeout(async () => {
    saveCacheTimer = null;
    const obj = {};
    imageCache.forEach((value, key) => { obj[key] = value; });
    try {
      await personalStorage.saveImageCache(obj);
    } catch (err) {
      console.error('Failed to save image cache:', err);
    }
  }, 1000);
}

// 画像URLをBase64化してキャッシュ
async function fetchAndCacheImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;  // 既にdata:URLならそのまま
  if (imageCache.has(url)) return imageCache.get(url);
  if (cacheFetchingUrls.has(url)) return null;

  cacheFetchingUrls.add(url);
  try {
    const res = await fetch(url, { cache: 'force-cache' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();

    // 300KB以上の画像はキャッシュしない (容量保護)
    if (blob.size > 300 * 1024) {
      cacheFetchingUrls.delete(url);
      return null;
    }

    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    imageCache.set(url, dataUrl);
    scheduleSaveImageCache();
    return dataUrl;
  } catch (err) {
    return null;
  } finally {
    cacheFetchingUrls.delete(url);
  }
}

function getCachedImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;
  return imageCache.get(url) || null;
}

function getDisplayImageSrc(url) {
  if (!url) return '';
  const cached = getCachedImage(url);
  return cached || url;
}

// 表示中のタイル画像をバックグラウンドでプリフェッチ
function prefetchImages(urls) {
  const CONCURRENT = 4;
  const queue = [...new Set(urls)].filter(u =>
    u && !u.startsWith('data:') && !imageCache.has(u) && !cacheFetchingUrls.has(u)
  );

  let running = 0;
  function runNext() {
    while (running < CONCURRENT && queue.length > 0) {
      const url = queue.shift();
      running++;
      fetchAndCacheImage(url).finally(() => {
        running--;
        runNext();
      });
    }
  }
  runNext();
}

function normalizeUrl(url) {
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (!/^https?:\/\//i.test(trimmed)) {
    return 'https://' + trimmed;
  }
  return trimmed;
}

function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function showToast(message, isError = false, duration = 2500) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast' + (isError ? ' error' : '');
  toast.classList.remove('hidden');
  // 既存のタイマーがあればクリア
  if (toast._hideTimer) clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.add('hidden'), duration);
}

function formatDateForFile(d = new Date()) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// ============================================
// Layout settings
// ============================================
function getLayoutForTab(tabId) {
  if (allLayouts[tabId]) {
    return { ...DEFAULT_LAYOUT, ...allLayouts[tabId] };
  }
  // フォールバック: _default (旧形式マイグレーション用)
  if (allLayouts._default) {
    return { ...DEFAULT_LAYOUT, ...allLayouts._default };
  }
  return { ...DEFAULT_LAYOUT };
}

function applyLayoutSettings() {
  const root = document.documentElement;
  root.style.setProperty('--tile-gap', `${layoutSettings.gap}px`);
  root.style.setProperty('--tile-width', `${layoutSettings.width}px`);
  root.style.setProperty('--tile-height', `${layoutSettings.height}px`);
  root.style.setProperty('--header-spacing', `${layoutSettings.headerSpacing}px`);

  // 画面幅から実際に表示できる列数を計算
  const main = document.querySelector('.main');
  const mainPadding = 80; // 左右40pxずつ
  const availableWidth = (main ? main.clientWidth : window.innerWidth) - mainPadding;
  const tileWithGap = layoutSettings.width + layoutSettings.gap;
  const maxFitColumns = Math.max(1, Math.floor((availableWidth + layoutSettings.gap) / tileWithGap));

  // ユーザー設定列数 (0=自動なら maxFitColumns) と実際に入る列数の小さい方
  let actualColumns;
  if (layoutSettings.columns === 0) {
    actualColumns = maxFitColumns;
  } else {
    actualColumns = Math.min(layoutSettings.columns, maxFitColumns);
  }

  // タイル幅は固定。列数だけが画面幅で変動
  const gridTemplate = `repeat(${actualColumns}, ${layoutSettings.width}px)`;
  root.style.setProperty('--grid-template', gridTemplate);
  root.style.setProperty('--tile-columns', String(actualColumns));
}

// ウィンドウリサイズ時に再計算
let resizeTimer = null;
window.addEventListener('resize', () => {
  if (resizeTimer) clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    applyLayoutSettings();
  }, 50);
});

function loadLayoutForActiveTab() {
  layoutSettings = getLayoutForTab(state.activeTabId);
  applyLayoutSettings();
}

function showLayoutModal() {
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();

  // モーダルのタイトルに対象タブ名を表示
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const titleEl = document.querySelector('#layout-modal .modal-header h2');
  if (titleEl && activeTab) {
    titleEl.textContent = `レイアウト設定: ${activeTab.name}`;
  }

  document.getElementById('layout-modal').classList.remove('hidden');
}

function hideLayoutModal() {
  document.getElementById('layout-modal').classList.add('hidden');
}

// ============================================
// 同期設定モーダル (PATのみ入力)
// ============================================
function showSyncModal() {
  document.getElementById('sync-token').value = GITHUB_CONFIG.TOKEN || '';

  // 固定値表示の更新
  document.getElementById('sync-fixed-info').textContent = `${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;

  updateSyncStatus();
  document.getElementById('sync-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('sync-token').focus(), 50);
}

function hideSyncModal() {
  document.getElementById('sync-modal').classList.add('hidden');
}

// ============================================
// 共有タブの管理モーダル
// ============================================
function showManageSharedModal() {
  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }
  document.getElementById('manage-shared-modal').classList.remove('hidden');
  loadManageSharedList();
}

function hideManageSharedModal() {
  document.getElementById('manage-shared-modal').classList.add('hidden');
}

// 同期の仕組み 説明モーダル
function showSyncInfoModal() {
  const body = document.getElementById('sync-info-body');
  if (body) body.innerHTML = SYNC_BEHAVIOR_HTML;
  document.getElementById('sync-info-modal').classList.remove('hidden');
}

function hideSyncInfoModal() {
  document.getElementById('sync-info-modal').classList.add('hidden');
}

// ============================================
// ログビューア
// ============================================
function showLogModal() {
  document.getElementById('log-modal').classList.remove('hidden');
  renderLogs();
}

function hideLogModal() {
  document.getElementById('log-modal').classList.add('hidden');
}

function renderLogs() {
  const viewer = document.getElementById('log-viewer');
  const levelFilter = document.getElementById('log-filter-level').value;
  const categoryFilter = document.getElementById('log-filter-category').value;

  // フィルタ適用
  const levelOrder = { error: 0, warn: 1, info: 2, debug: 3 };
  const levelThreshold = levelFilter === 'all' ? 99 : levelOrder[levelFilter];

  const filtered = APP_LOG.filter(entry => {
    if (levelFilter !== 'all' && levelOrder[entry.level] > levelThreshold) return false;
    if (categoryFilter !== 'all' && entry.category !== categoryFilter) return false;
    return true;
  });

  document.getElementById('log-count').textContent = `${filtered.length} / ${APP_LOG.length} 件`;

  if (filtered.length === 0) {
    viewer.innerHTML = '<div class="log-empty">該当するログがありません</div>';
    return;
  }

  // 新しいログを上に表示
  const reversed = [...filtered].reverse();
  viewer.innerHTML = reversed.map(entry => {
    const t = entry.time.slice(11, 19);  // HH:MM:SS だけ
    const extra = entry.extra ? `<div class="log-entry-extra">${escapeHtml(entry.extra)}</div>` : '';
    return `
      <div class="log-entry ${entry.level}">
        <span class="log-entry-time">${t}</span>
        <span class="log-entry-level ${entry.level}">${entry.level}</span>
        <span class="log-entry-category">${escapeHtml(entry.category)}</span>
        <span class="log-entry-message">${escapeHtml(entry.message)}</span>
        ${extra}
      </div>
    `;
  }).join('');
}

function clearLogs() {
  if (!confirm('ログを全てクリアしますか？')) return;
  APP_LOG.length = 0;
  appLog('info', 'general', 'ログをクリアしました');
  renderLogs();
}

async function copyLogsToClipboard() {
  const text = APP_LOG.map(entry => {
    const t = entry.time;
    const extra = entry.extra ? ` ${entry.extra}` : '';
    return `[${t}] [${entry.level.toUpperCase()}] [${entry.category}] ${entry.message}${extra}`;
  }).join('\n');

  try {
    await navigator.clipboard.writeText(text);
    showToast(`${APP_LOG.length} 件のログをコピーしました`);
  } catch (err) {
    // フォールバック: テキストエリア経由でコピー
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast(`${APP_LOG.length} 件のログをコピーしました`);
  }
}

async function loadManageSharedList() {
  const listEl = document.getElementById('manage-shared-list');
  listEl.innerHTML = '<div class="shared-list-loading">読み込み中...</div>';

  appLog('info', 'tab', '共有タブ管理画面を開きました');

  try {
    const all = await sharedStorage.fetchAll();
    const codes = Object.keys(all);
    appLog('info', 'tab', `共有タブ管理: ${codes.length} 個のタブを表示`, { codes });

    if (codes.length === 0) {
      listEl.innerHTML = '<div class="shared-list-empty">共有タブがまだありません。</div>';
      return;
    }

    listEl.innerHTML = '';
    codes.forEach(code => {
      const data = all[code];
      const name = data.name || code;
      const tileCount = Array.isArray(data.tiles) ? data.tiles.length : 0;
      // 自分が今このタブを開いているか
      const isOpen = state.tabs.some(t => t.type === 'shared' && t.code === code);

      const item = document.createElement('div');
      item.className = 'manage-shared-item';
      item.innerHTML = `
        <div class="manage-shared-item-info">
          <span class="manage-shared-item-name">${escapeHtml(name)}${isOpen ? ' <span style="color:#1967d2;font-size:11px;">(使用中)</span>' : ''}</span>
          <span class="manage-shared-item-meta">${escapeHtml(code)} ・ ${tileCount} タイル</span>
        </div>
        <div class="manage-shared-item-actions">
          <button class="manage-shared-btn" data-action="rename">名称変更</button>
          <button class="manage-shared-btn danger" data-action="delete">削除</button>
        </div>
      `;

      item.querySelector('[data-action="rename"]').addEventListener('click', () => {
        renameSharedTab(code, name);
      });
      item.querySelector('[data-action="delete"]').addEventListener('click', () => {
        deleteSharedTab(code, name);
      });

      listEl.appendChild(item);
    });
  } catch (err) {
    listEl.innerHTML = `<div class="shared-list-empty">取得に失敗しました。<br>${escapeHtml(err.message)}</div>`;
  }
}

async function renameSharedTab(code, currentName) {
  const newName = prompt(`「${currentName}」の新しい名前を入力してください:`, currentName);
  if (newName === null) return;  // キャンセル
  const trimmed = newName.trim();
  if (!trimmed) {
    showToast('名前を入力してください', true);
    return;
  }
  if (trimmed === currentName) return;  // 変更なし

  try {
    await sharedStorage.renameByCode(code, trimmed);

    // 自分が開いているタブも更新
    const localTab = state.tabs.find(t => t.type === 'shared' && t.code === code);
    if (localTab) {
      localTab.name = trimmed;
      await personalStorage.save(state);
      render();
    }

    showToast('名称を変更しました (全メンバーに反映)');
    loadManageSharedList();  // 一覧を更新
  } catch (err) {
    showToast('名称変更に失敗: ' + err.message, true);
  }
}

function deleteSharedTab(code, name) {
  showConfirm(
    `共有タブ「${name}」を削除しますか？\n\n⚠️ GitHub上の共有データが削除され、全メンバーの画面からも消えます。この操作は取り消せません。`,
    async () => {
      try {
        await sharedStorage.deleteByCode(code);

        // 自分が開いているタブからも削除
        const localTab = state.tabs.find(t => t.type === 'shared' && t.code === code);
        if (localTab) {
          state.tabs = state.tabs.filter(t => t.id !== localTab.id);
          if (state.activeTabId === localTab.id) {
            state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
          }
          if (allLayouts[localTab.id]) {
            delete allLayouts[localTab.id];
            await personalStorage.saveLayout(allLayouts);
          }
          loadLayoutForActiveTab();
          await personalStorage.save(state);
          render();
        }

        showToast('共有タブを削除しました');
        loadManageSharedList();  // 一覧を更新
      } catch (err) {
        showToast('削除に失敗: ' + err.message, true);
      }
    }
  );
}

function updateSyncStatus() {
  const status = document.getElementById('sync-status');
  const statusVal = document.getElementById('sync-status-value');
  const lastTimeVal = document.getElementById('sync-last-time');

  if (sharedStorage.isConfigured()) {
    status.classList.remove('hidden');
    statusVal.textContent = '設定済み';
    statusVal.className = 'ok';
  } else {
    status.classList.remove('hidden');
    statusVal.textContent = '未設定';
    statusVal.className = 'ng';
  }

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared' && lastSyncTimes[activeTab.id]) {
    const date = new Date(lastSyncTimes[activeTab.id]);
    lastTimeVal.textContent = formatDateTime(date);
  } else if (activeTab && activeTab.type === 'shared') {
    lastTimeVal.textContent = '未同期';
  } else {
    lastTimeVal.textContent = '(共有タブを開いてください)';
  }
}

function formatDateTime(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${yyyy}/${mm}/${dd} ${hh}:${mi}`;
}

async function saveSyncSettings() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  GITHUB_CONFIG.TOKEN = token;

  // SHAキャッシュをリセット
  sharedStorage._fileSha = null;

  await personalStorage.saveSyncConfig({ TOKEN: token });

  hideSyncModal();
  showToast('Personal Access Token を保存しました');

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared') {
    await syncActiveSharedTab();
    renderTiles();
  }
}

async function testSyncConnection() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  const statusVal = document.getElementById('sync-status-value');
  document.getElementById('sync-status').classList.remove('hidden');
  statusVal.textContent = '接続中...';
  statusVal.className = '';

  try {
    const url = `https://api.github.com/repos/${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    if (res.ok) {
      statusVal.textContent = '✓ 接続成功';
      statusVal.className = 'ok';
      showToast('接続テストに成功しました');
    } else if (res.status === 401) {
      statusVal.textContent = '✕ トークンが無効';
      statusVal.className = 'ng';
      showToast('トークンが無効です (401)', true);
    } else if (res.status === 404) {
      statusVal.textContent = '✕ リポジトリが見つからない';
      statusVal.className = 'ng';
      showToast(`リポジトリ ${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO} にアクセスできません (404)`, true);
    } else {
      statusVal.textContent = `✕ エラー (${res.status})`;
      statusVal.className = 'ng';
      showToast(`接続エラー: ${res.status}`, true);
    }
  } catch (err) {
    statusVal.textContent = '✕ 接続失敗';
    statusVal.className = 'ng';
    showToast('接続失敗: ' + err.message, true);
  }
}

function updateLayoutValueLabels() {
  const cols = layoutSettings.columns;
  document.getElementById('columns-value').textContent = cols === 0 ? '自動' : `${cols}列`;
  document.getElementById('width-value').textContent = `${layoutSettings.width}px`;
  document.getElementById('height-value').textContent = `${layoutSettings.height}px`;
  document.getElementById('gap-value').textContent = `${layoutSettings.gap}px`;
  document.getElementById('header-spacing-value').textContent = `${layoutSettings.headerSpacing}px`;
}

async function updateLayoutFromSliders() {
  layoutSettings.columns = parseInt(document.getElementById('columns-slider').value, 10);
  layoutSettings.width = parseInt(document.getElementById('width-slider').value, 10);
  layoutSettings.height = parseInt(document.getElementById('height-slider').value, 10);
  layoutSettings.gap = parseInt(document.getElementById('gap-slider').value, 10);
  layoutSettings.headerSpacing = parseInt(document.getElementById('header-spacing-slider').value, 10);
  updateLayoutValueLabels();
  applyLayoutSettings();
  // アクティブタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
}

async function resetLayout() {
  layoutSettings = { ...DEFAULT_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブの設定を削除 (デフォルトに戻す)
  delete allLayouts[state.activeTabId];
  await personalStorage.saveLayout(allLayouts);
  showToast('このタブをデフォルトに戻しました');
}

async function applyRecommendedLayout() {
  layoutSettings = { ...RECOMMENDED_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
  showToast('推奨設定を適用しました');
}

async function applyLayoutToAllTabs() {
  // 現在のレイアウトを全タブに適用
  state.tabs.forEach(tab => {
    allLayouts[tab.id] = { ...layoutSettings };
  });
  await personalStorage.saveLayout(allLayouts);
  showToast('全タブに適用しました');
}

// ============================================
// Sync logic
// ============================================
async function syncActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  try {
    const seqAtStart = localEditSeq;
    const remote = await sharedStorage.getByCode(activeTab.code);
    // 取得している間にOFFにした/ローカル編集した場合は上書きしない
    if (!syncEnabled || localEditSeq !== seqAtStart) {
      appLog('info', 'sync', 'タブ取得: 取得中にOFF/編集あり → 上書きをスキップ');
      return;
    }
    if (remote && Array.isArray(remote.tiles)) {
      activeTab.tiles = remote.tiles;
      if (remote.name) activeTab.name = remote.name;
      await personalStorage.save(state);
    }
    // 同期成功 → 時刻を記録
    lastSyncTimes[activeTab.id] = Date.now();
    await personalStorage.saveLastSyncTimes(lastSyncTimes);
  } catch (err) {
    console.error('Sync failed:', err);
    showToast('同期に失敗しました: ' + err.message, true);
  }
}

async function saveSharedTab(tab, force = false) {
  // 同期OFF中の「自動保存」だけを止める。手動の反映ボタン(force=true)は常に送信する。
  if (!syncEnabled && !force) {
    sharedDirty = true;
    await personalStorage.save(state);
    return;
  }
  try {
    await sharedStorage.saveByCode(tab.code, {
      name: tab.name,
      tiles: tab.tiles
    });
    // 保存成功 → 時刻を記録
    lastSyncTimes[tab.id] = Date.now();
    personalStorage.saveLastSyncTimes(lastSyncTimes).catch(() => {});
  } catch (err) {
    console.error('Save shared failed:', err);
    showToast('共有データの保存に失敗: ' + err.message, true);
    throw err;
  }
}

async function saveActiveTab() {
  markLocalEdit();
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  await personalStorage.save(state);
  if (activeTab && activeTab.type === 'shared') {
    await saveSharedTab(activeTab);
  }
}

// ============================================
// Export / Import
// ============================================
function exportData() {
  const exportObj = {
    format: 'speed-access',
    version: EXPORT_VERSION,
    exportedAt: new Date().toISOString(),
    tabs: state.tabs.map(tab => ({
      id: tab.id,
      name: tab.name,
      type: tab.type,
      code: tab.code || null,
      tiles: tab.tiles.map(tile => ({
        title: tile.title,
        url: tile.url,
        image: tile.image || ''
      }))
    }))
  };

  const json = JSON.stringify(exportObj, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `speed-access-export-${formatDateForFile()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('エクスポートしました');
}

function parseImportData(raw) {
  if (!raw || typeof raw !== 'object') {
    throw new Error('無効なファイル形式です');
  }

  if (raw.format === 'speed-access' && Array.isArray(raw.tabs)) {
    return raw.tabs.map(tab => ({
      name: tab.name || 'タブ',
      type: tab.type === 'shared' ? 'shared' : 'personal',
      code: tab.code || null,
      tiles: (tab.tiles || []).map(t => ({
        title: t.title || '',
        url: t.url || '',
        image: t.image || ''
      })).filter(t => t.url)
    }));
  }

  if (Array.isArray(raw.dials)) {
    const groups = Array.isArray(raw.groups) ? raw.groups : [{ id: 0, title: 'Home' }];
    const groupMap = {};
    groups.forEach(g => {
      groupMap[g.id] = {
        name: g.title || 'タブ',
        type: 'personal',
        code: null,
        tiles: []
      };
    });

    const sortedDials = [...raw.dials].sort((a, b) => (a.position || 0) - (b.position || 0));

    sortedDials.forEach(dial => {
      const groupId = dial.idgroup !== undefined ? dial.idgroup : 0;
      if (!groupMap[groupId]) {
        groupMap[groupId] = { name: 'その他', type: 'personal', code: null, tiles: [] };
      }
      if (dial.url) {
        let title = dial.title || '';
        title = title.trim();
        const firstToken = title.split(/\s+/)[0];
        if (firstToken && firstToken.length > 0) {
          title = firstToken;
        }
        if (!title || title === '.') {
          try {
            title = new URL(dial.url).hostname.replace(/^www\./, '');
          } catch {
            title = 'リンク';
          }
        }

        groupMap[groupId].tiles.push({
          title,
          url: dial.url,
          image: dial.thumbnail || ''
        });
      }
    });

    const orderedGroups = groups
      .slice()
      .sort((a, b) => (a.position || 0) - (b.position || 0))
      .map(g => groupMap[g.id])
      .filter(Boolean);

    return orderedGroups;
  }

  throw new Error('対応していないファイル形式です');
}

function renderImportPreview(parsedTabs) {
  const container = document.getElementById('import-preview');
  const html = parsedTabs.map(tab => `
    <div class="import-preview-group">
      <div class="import-preview-group-title">
        <span>${escapeHtml(tab.name)}${tab.type === 'shared' ? ' <span class="tab-badge">共有</span>' : ''}</span>
        <span class="import-preview-group-count">${tab.tiles.length} タイル</span>
      </div>
      <div class="import-preview-items">
        ${tab.tiles.slice(0, 5).map(t => escapeHtml(t.title || t.url)).join(' / ')}
        ${tab.tiles.length > 5 ? ` <span style="color:#999">他 ${tab.tiles.length - 5} 件</span>` : ''}
      </div>
    </div>
  `).join('');
  container.innerHTML = html || '<div style="color:#999;font-size:12px;">インポート可能な項目がありません</div>';
}

async function handleImportFile(file) {
  console.log('[Import] ファイル読み込み開始:', file.name, file.size, 'bytes');
  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    console.log('[Import] JSON パース成功');
    const parsed = parseImportData(raw);
    console.log('[Import] データ変換成功:', parsed.length, '個のタブ');
    parsed.forEach((t, i) => {
      console.log(`  [${i}] "${t.name}" - ${t.tiles.length} タイル`);
    });

    pendingImportData = parsed;
    document.getElementById('import-preview-container').classList.remove('hidden');
    renderImportPreview(parsed);
    document.getElementById('import-execute').disabled = parsed.length === 0;
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('ファイルの読み込みに失敗: ' + err.message, true);
    pendingImportData = null;
    document.getElementById('import-preview-container').classList.add('hidden');
    document.getElementById('import-execute').disabled = true;
  }
}

async function executeImport() {
  if (!pendingImportData) return;

  const mode = document.querySelector('input[name="import-mode"]:checked').value;

  console.log('[Import] モード:', mode);
  console.log('[Import] インポート対象:', pendingImportData.length, '個のタブ');

  try {
    if (mode === 'replace') {
      // replaceモード: 全タブをクリア
      state.tabs = [];
    }

    let firstImportedTabId = null;
    let totalTilesAdded = 0;

    for (const importTab of pendingImportData) {
      const newTab = {
        id: generateId('tab'),
        name: importTab.name,
        type: importTab.type === 'shared' ? 'shared' : 'personal',
        tiles: importTab.tiles.map(t => ({
          id: generateId('tile'),
          title: t.title,
          url: t.url,
          image: t.image,
          showLabel: t.showLabel,
          label: t.label,
          labelSize: t.labelSize,
          labelColor: t.labelColor,
          labelWeight: t.labelWeight,
          labelPos: t.labelPos,
          contentType: t.contentType,
          contentText: t.contentText,
          contentSize: t.contentSize,
          contentWeight: t.contentWeight,
          contentColor: t.contentColor,
          btn1: t.btn1,
          btn2: t.btn2
        }))
      };

      if (importTab.type === 'shared' && importTab.code) {
        newTab.code = importTab.code;
      } else {
        newTab.type = 'personal';
        delete newTab.code;
      }

      state.tabs.push(newTab);
      totalTilesAdded += newTab.tiles.length;
      if (!firstImportedTabId) firstImportedTabId = newTab.id;
    }

    // インポートしたタブをアクティブに
    if (firstImportedTabId) {
      state.activeTabId = firstImportedTabId;
    }

    console.log('[Import] 完了:', totalTilesAdded, 'タイル追加');
    console.log('[Import] 保存前のstate:', {
      tabs: state.tabs.length,
      totalTiles: state.tabs.reduce((sum, t) => sum + t.tiles.length, 0),
      activeTabId: state.activeTabId
    });

    // chrome.storage.local の 5MB 制限対策: データサイズを確認
    const dataSize = JSON.stringify(state).length;
    console.log('[Import] データサイズ:', Math.round(dataSize / 1024), 'KB');

    if (dataSize > 4.5 * 1024 * 1024) {
      showToast('データが大きすぎます。画像URLを減らしてください', true);
      return;
    }

    await personalStorage.save(state);
    console.log('[Import] 保存完了');

    // 共有タブはリモートにも保存
    if (sharedStorage.isConfigured()) {
      for (const tab of state.tabs) {
        if (tab.type === 'shared' && tab.code) {
          try { await saveSharedTab(tab); } catch (err) {
            console.warn('[Import] 共有保存失敗:', err);
          }
        }
      }
    }

    hideImportModal();
    showToast(`${pendingImportData.length} 個のタブ / ${totalTilesAdded} 個のタイルをインポートしました`);
    pendingImportData = null;
    render();

    // インポートした全タイルの画像をバックグラウンドでキャッシュ
    const allUrls = [];
    state.tabs.forEach(tab => {
      tab.tiles.forEach(t => allUrls.push(t.image || getFaviconUrl(t.url)));
    });
    prefetchImages(allUrls);
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('インポートエラー: ' + err.message, true);
  }
}

// ============================================
// Rendering
// ============================================
function render() {
  const app = document.getElementById('app');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const isSharedTab = activeTab && activeTab.type === 'shared';

  app.innerHTML = `
    <header class="header">
      <div class="header-row">
        <div class="tabs-container" id="tabs-container"></div>
        <div class="header-actions">
          ${isSharedTab ? `
            <div class="shared-code-display" title="このタブの合言葉コード">🔗 共有: ${escapeHtml(activeTab.code)}</div>
            <div class="sync-btn-wrapper">
              <button class="sync-btn" id="sync-btn" title="同期メニュー">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="23 4 23 10 17 10"/>
                  <polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                </svg>
                同期
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-left:2px;">
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </button>
            </div>
          ` : ''}
          <button class="header-btn${bulkEditMode ? ' active' : ''}" id="bulk-edit-btn" title="タブ編集 (複数選択して移動/コピー/削除)">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="9 11 12 14 22 4"/>
              <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
            </svg>
            <span style="font-size:13px;">タブ編集</span>
          </button>
          <button class="header-btn" id="settings-btn" title="設定">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
        </div>
      </div>
    </header>
    <main class="main">
      <div class="tiles-grid" id="tiles-grid"></div>
    </main>
  `;

  renderTabs();
  renderTiles();
  attachMainEvents();
  setupTabDropZones();
  updateBulkBar();
}

function renderTabs() {
  const container = document.getElementById('tabs-container');
  container.innerHTML = '';

  state.tabs.forEach((tab) => {
    const btn = document.createElement('div');
    btn.className = 'tab' + (tab.id === state.activeTabId ? ' active' : '');
    btn.dataset.tabId = tab.id;
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('draggable', 'true');

    const sharedLabel = tab.type === 'shared'
      ? '<span class="tab-shared-label">共有</span>'
      : '<span class="tab-shared-label placeholder">&nbsp;</span>';
    btn.innerHTML = `
      <div class="tab-content">
        ${sharedLabel}
        <span class="tab-name">${escapeHtml(tab.name)}</span>
      </div>
      <button class="tab-menu-btn" data-action="menu" type="button" aria-label="タブメニュー">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" pointer-events="none">
          <circle cx="12" cy="12" r="1"/>
          <circle cx="12" cy="5" r="1"/>
          <circle cx="12" cy="19" r="1"/>
        </svg>
      </button>
    `;

    btn.addEventListener('click', (e) => {
      const menuBtn = e.target.closest('[data-action="menu"]');
      if (menuBtn) {
        e.stopPropagation();
        e.preventDefault();
        showTabMenu(tab.id, menuBtn);
        return;
      }
      selectTab(tab.id);
    });

    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTabMenu(tab.id, btn);
    });

    // ドラッグ&ドロップ
    btn.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', tab.id);
      btn.classList.add('dragging');
    });

    btn.addEventListener('dragend', () => {
      btn.classList.remove('dragging');
      document.querySelectorAll('.tab').forEach(el => {
        el.classList.remove('drag-over-left', 'drag-over-right');
      });
    });

    btn.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置で左右どちらに挿入するか判定
      const rect = btn.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      btn.classList.remove('drag-over-left', 'drag-over-right');
      if (e.clientX < midpoint) {
        btn.classList.add('drag-over-left');
      } else {
        btn.classList.add('drag-over-right');
      }
    });

    btn.addEventListener('dragleave', () => {
      btn.classList.remove('drag-over-left', 'drag-over-right');
    });

    btn.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const insertRight = btn.classList.contains('drag-over-right');
      btn.classList.remove('drag-over-left', 'drag-over-right');

      const draggedId = e.dataTransfer.getData('text/plain');
      if (!draggedId || draggedId === tab.id) return;

      const draggedIndex = state.tabs.findIndex(t => t.id === draggedId);
      if (draggedIndex < 0) return;

      const [moved] = state.tabs.splice(draggedIndex, 1);

      let dropIndex = state.tabs.findIndex(t => t.id === tab.id);
      if (dropIndex < 0) {
        state.tabs.push(moved);
      } else {
        if (insertRight) dropIndex += 1;
        state.tabs.splice(dropIndex, 0, moved);
      }

      // タブバーだけ再描画 (タイルグリッドは変化なし)
      renderTabs();
      setupTabDropZones();

      // 保存はバックグラウンド
      personalStorage.save(state).catch(err => console.error('save failed:', err));
    });

    container.appendChild(btn);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tab-add-btn';
  addBtn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  `;
  addBtn.title = 'タブを追加';
  addBtn.addEventListener('click', showAddTabModal);
  container.appendChild(addBtn);
}

function renderTiles() {
  const grid = document.getElementById('tiles-grid');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);

  // タブが存在しない場合はウェルカム画面
  if (!activeTab) {
    grid.innerHTML = '';
    grid.classList.add('empty-grid');
    const welcome = document.createElement('div');
    welcome.className = 'welcome-screen';
    welcome.innerHTML = `
      <div class="welcome-icon">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="3" width="7" height="7"/>
          <rect x="14" y="3" width="7" height="7"/>
          <rect x="14" y="14" width="7" height="7"/>
          <rect x="3" y="14" width="7" height="7"/>
        </svg>
      </div>
      <h2>Speed Accessへようこそ</h2>
      <p>最初のタブを作成して始めましょう。<br>個人用/共有用を選べます。</p>
      <button class="btn-primary" id="welcome-create-tab">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="12" y1="5" x2="12" y2="19"/>
          <line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        タブを作成
      </button>
    `;
    grid.appendChild(welcome);
    document.getElementById('welcome-create-tab').addEventListener('click', showAddTabModal);
    return;
  }

  grid.classList.remove('empty-grid');
  grid.innerHTML = '';

  activeTab.tiles.forEach((tile) => {
    const tileEl = document.createElement('a');
    tileEl.className = 'tile';
    tileEl.href = tile.url;
    tileEl.dataset.tileId = tile.id;
    tileEl.setAttribute('draggable', 'true');

    // タイルの中身: 文字列モードならテキスト、それ以外は画像(無ければfavicon)
    if (tile.contentType === 'text' && tile.contentText) {
      const txt = document.createElement('div');
      txt.className = 'tile-content-text size-' + (tile.contentSize || 'medium') + ' weight-' + (tile.contentWeight || 'bold');
      txt.style.color = tile.contentColor || '#1A1A1A';
      txt.textContent = tile.contentText; // 改行はCSSのwhite-space:pre-wrapで反映
      tileEl.appendChild(txt);
    } else {
      // 画像URL: tile.image があればそれ、なければfavicon
      const primaryUrl = tile.image || getFaviconUrl(tile.url);
      const fallbackUrl = getFaviconUrl(tile.url);
      const displaySrc = getDisplayImageSrc(primaryUrl);
      const isFavicon = !tile.image;
      const initialClass = isFavicon ? 'favicon' : '';
      const imageHtml = `<img src="${escapeHtml(displaySrc)}" alt="" class="${initialClass}" data-original-url="${escapeHtml(primaryUrl)}" onerror="this.onerror=null;this.src='${escapeHtml(fallbackUrl)}';this.className='favicon';">`;
      tileEl.innerHTML = imageHtml;
    }

    tileEl.title = tile.title || tile.contentText || tile.url;

    // タイル内サブボタン (文字が設定されているものだけ表示)
    if (!bulkEditMode) {
      [['btn1', 'left'], ['btn2', 'right']].forEach(([key, side]) => {
        const b = tile[key];
        if (b && b.text) {
          const sb = document.createElement('span');
          sb.className = 'tile-subbtn tile-subbtn-' + side + ' h-' + (b.height || 's');
          const bc = b.color || '#202124';
          sb.style.borderColor = bc;
          if (b.style === 'fill') { sb.style.background = bc; sb.style.color = '#fff'; }
          else { sb.style.background = '#fff'; sb.style.color = bc; }
          sb.style.width = 'calc(' + (b.size || 50) + '% - 9px)';
          sb.textContent = b.text;
          sb.title = b.text + (b.url ? ' → ' + b.url : '');
          sb.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (b.url) window.location.href = b.url;
          });
          tileEl.appendChild(sb);
        }
      });
    }

    // 右下テキスト (ONのタイルのみ表示・太字・右寄せ)
    if (tile.showLabel && tile.label) {
      const lbl = document.createElement('div');
      lbl.className = 'tile-label-text size-' + (tile.labelSize || 'medium') + ' weight-' + (tile.labelWeight || 'bold') + ' pos-' + (tile.labelPos || 'br');
      lbl.style.color = tile.labelColor || '#1A1A1A';
      lbl.textContent = tile.label;
      tileEl.appendChild(lbl);
    }

    if (bulkEditMode) {
      // タブ編集モード: クリックで選択/解除 (ページ遷移しない)
      tileEl.setAttribute('draggable', 'false');
      tileEl.classList.add('bulk-selectable');
      if (bulkSelected.has(tile.id)) tileEl.classList.add('bulk-selected');
      const check = document.createElement('div');
      check.className = 'bulk-check';
      check.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>';
      tileEl.appendChild(check);
      tileEl.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleTileSelection(tile.id, tileEl);
      });
    }

    tileEl.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTileMenu(tile, e.clientX, e.clientY);
    });

    // ドラッグ開始 - タイルIDと元タブIDを記録
    tileEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('application/x-tile-id', tile.id);
      e.dataTransfer.setData('application/x-source-tab-id', state.activeTabId);
      // fallback for Firefox/Safari
      e.dataTransfer.setData('text/plain', `tile:${tile.id}`);
      tileEl.classList.add('dragging');
      draggedTile = { tileId: tile.id, sourceTabId: state.activeTabId };
    });

    tileEl.addEventListener('dragend', () => {
      tileEl.classList.remove('dragging');
      document.querySelectorAll('.tile').forEach(el => {
        el.classList.remove('tile-drop-before', 'tile-drop-after');
      });
      document.querySelectorAll('.tile-add').forEach(el => {
        el.classList.remove('tile-drop-before');
      });
      draggedTile = null;
    });

    // ドロップ先としての動作
    tileEl.addEventListener('dragover', (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置でこのタイルの前/後ろに挿入するか判定
      const rect = tileEl.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
      if (e.clientX < midpoint) {
        tileEl.classList.add('tile-drop-before');
      } else {
        tileEl.classList.add('tile-drop-after');
      }
    });

    tileEl.addEventListener('dragleave', (e) => {
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
    });

    tileEl.addEventListener('drop', async (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.stopPropagation();

      const insertAfter = tileEl.classList.contains('tile-drop-after');
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');

      await handleTileDrop(draggedTile, state.activeTabId, tile.id, insertAfter);
    });

    grid.appendChild(tileEl);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tile-add';
  addBtn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
    <span>追加</span>
  `;
  addBtn.addEventListener('click', openAddTile);

  // 追加ボタンへのdrop = 末尾に配置
  addBtn.addEventListener('dragover', (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    addBtn.classList.add('tile-drop-before');
  });
  addBtn.addEventListener('dragleave', () => {
    addBtn.classList.remove('tile-drop-before');
  });
  addBtn.addEventListener('drop', async (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.stopPropagation();
    addBtn.classList.remove('tile-drop-before');
    // 末尾に配置 (anchorTileId = null を渡す)
    await handleTileDrop(draggedTile, state.activeTabId, null, true);
  });

  grid.appendChild(addBtn);

  if (activeTab.tiles.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = `
      <h3>まだタイルがありません</h3>
      <p>「+ 追加」から最初のリンクを登録しましょう</p>
    `;
    grid.insertBefore(empty, addBtn);
  }

  // 表示中タイルの画像をバックグラウンドでプリフェッチ
  if (imageCacheLoaded) {
    const urlsToPrefetch = activeTab.tiles.map(t => t.image || getFaviconUrl(t.url));
    prefetchImages(urlsToPrefetch);
  }
}

function attachMainEvents() {
  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showSyncMenu(syncBtn);
    });
  }

  const settingsBtn = document.getElementById('settings-btn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showSettingsMenu(settingsBtn);
    });
  }

  const bulkBtn = document.getElementById('bulk-edit-btn');
  if (bulkBtn) {
    bulkBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleBulkEditMode();
    });
  }
}

// ============================================
// Settings menu
// ============================================
function showSyncMenu(btnEl) {
  // 既存メニューを閉じる
  document.querySelectorAll('.dropdown-menu, .tab-context-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.innerHTML = `
    <button data-action="toggle-sync">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${syncEnabled ? '#188038' : '#d93025'}" stroke-width="2">
        <path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>
        <line x1="12" y1="2" x2="12" y2="12"/>
      </svg>
      <span style="color:${syncEnabled ? '#188038' : '#d93025'};font-weight:600;">
        同期: ${syncEnabled ? 'ON' : 'OFF'}
      </span>
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="push-current">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      反映-当タブ (アップロード)
    </button>
    <button data-action="push-all">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      反映-全タブ (一括アップロード)
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="pull-current">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      取得-当タブ (ダウンロード)
    </button>
    <button data-action="pull-all">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      取得-全タブ (ダウンロード)
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="sync-info">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="16" x2="12" y2="12"/>
        <line x1="12" y1="8" x2="12.01" y2="8"/>
      </svg>
      同期の仕組み
    </button>
  `;

  btnEl.parentElement.appendChild(menu);

  menu.querySelector('[data-action="toggle-sync"]').addEventListener('click', () => {
    menu.remove();
    const turningOn = !syncEnabled;
    setSyncEnabled(turningOn);
    if (turningOn) {
      // ONに戻した。未反映があれば自動取得で上書きしないよう、取得はせず注意を促す
      if (sharedDirty) {
        showToast('同期をONにしました。未反映の変更があります → 「反映-全タブ」で送信してください', true);
      } else {
        showToast('同期をONにしました');
      }
    } else {
      showToast('同期をOFFにしました（編集はこのPCのみ。終わったら「反映-全タブ」で送信）');
    }
  });
  menu.querySelector('[data-action="push-current"]').addEventListener('click', async () => {
    menu.remove();
    await pushActiveSharedTab();
  });
  menu.querySelector('[data-action="push-all"]').addEventListener('click', async () => {
    menu.remove();
    await pushAllSharedTabs();
  });
  menu.querySelector('[data-action="pull-current"]').addEventListener('click', async () => {
    menu.remove();
    await pullActiveSharedTab();
  });
  menu.querySelector('[data-action="pull-all"]').addEventListener('click', async () => {
    menu.remove();
    await pullAllSharedTabs();
  });
  menu.querySelector('[data-action="sync-info"]').addEventListener('click', () => {
    menu.remove();
    showSyncInfoModal();
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target) && !btnEl.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 10);
}

// 反映-全タブ: 開いている全共有タブを「1回の書き込み」でGitHubに送信する。
// - GitHubの現状を土台にして、自分が開いている共有タブだけを上書き (マージ)
// - 開いていない他人のタブ (china等) は土台から引き継がれるので消えない
// - 書き込みが1回なので、1個ずつ反映するより競合が激減する
async function pushAllSharedTabs() {
  const sharedTabs = state.tabs.filter(t => t.type === 'shared' && t.code);
  if (sharedTabs.length === 0) {
    showToast('共有タブがありません', true);
    return;
  }
  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  showConfirm(`開いている共有タブ ${sharedTabs.length}個 をまとめてGitHubに反映します。\n(自分が開いていない他メンバーのタブは消えません)`, async () => {
    try {
      showToast('反映中...');
      // 土台として現在のGitHub全体を取得 (他メンバーのタブを保持するため)
      const remoteAll = await sharedStorage.fetchAll();
      // 自分が開いている共有タブだけを上書き
      for (const tab of sharedTabs) {
        remoteAll[tab.code] = { name: tab.name, tiles: tab.tiles };
      }
      // 1回だけ書き込む
      await sharedStorage.saveAll(remoteAll);
      const now = Date.now();
      sharedTabs.forEach(t => { lastSyncTimes[t.id] = now; });
      await personalStorage.saveLastSyncTimes(lastSyncTimes);
      sharedDirty = false;
      appLog('info', 'sync', `反映-全タブ: ${sharedTabs.length}個を一括反映`, { codes: sharedTabs.map(t => t.code) });
      showToast(`${sharedTabs.length}個の共有タブを反映しました`);
    } catch (err) {
      appLog('error', 'sync', '反映-全タブ 失敗', err.message);
      showToast('反映に失敗しました: ' + err.message, true);
    }
  }, { okLabel: '反映する', danger: false });
}

// 反映 (アップロード): ローカルの状態をGitHubに送信
async function pushActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) syncBtn.classList.add('syncing');

  try {
    await saveSharedTab(activeTab, true); // 手動反映は同期OFF中でも送信
    appLog('info', 'sync', `反映-当タブ: 「${activeTab.name}」(${activeTab.code})`);
    showToast(`反映しました: 「${activeTab.name}」をGitHubに送信`);
  } catch (err) {
    appLog('error', 'sync', `反映-当タブ失敗: 「${activeTab.name}」`, err.message);
  } finally {
    if (syncBtn) syncBtn.classList.remove('syncing');
  }
}


// 取得 (ダウンロード): GitHubから最新を取得してローカルに上書き
async function pullActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) syncBtn.classList.add('syncing');

  try {
    await syncActiveSharedTab();
    renderTiles();
    appLog('info', 'sync', `取得-当タブ: 「${activeTab.name}」(${activeTab.code})`);
    showToast(`取得しました: 「${activeTab.name}」をGitHubから読み込み`);
  } catch (err) {
    appLog('error', 'sync', `取得-当タブ失敗: 「${activeTab.name}」`, err.message);
  } finally {
    if (syncBtn) syncBtn.classList.remove('syncing');
  }
}

// 取得-全タブ: 開いている全共有タブをGitHubから取得
async function pullAllSharedTabs() {
  const sharedTabs = state.tabs.filter(t => t.type === 'shared' && t.code);
  if (sharedTabs.length === 0) {
    showToast('共有タブがありません', true);
    return;
  }

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から入力してください', true);
    return;
  }

  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) syncBtn.classList.add('syncing');

  appLog('info', 'sync', `取得-全タブ開始: ${sharedTabs.length} 個`);

  try {
    const remoteAll = await sharedStorage.fetchAll();
    let updated = 0;
    let missing = 0;

    sharedTabs.forEach(tab => {
      const remote = remoteAll[tab.code];
      if (remote && Array.isArray(remote.tiles)) {
        tab.tiles = remote.tiles;
        if (remote.name) tab.name = remote.name;
        lastSyncTimes[tab.id] = Date.now();
        updated++;
      } else {
        missing++;
      }
    });

    await personalStorage.save(state);
    await personalStorage.saveLastSyncTimes(lastSyncTimes);
    render();

    appLog('info', 'sync', `取得-全タブ完了: 更新${updated}個 / GitHub未登録${missing}個`);
    if (missing > 0) {
      showToast(`取得しました: ${updated} 個更新 (${missing} 個はGitHub未登録)`, false, 5000);
    } else {
      showToast(`取得しました: ${updated} 個の共有タブをGitHubから読み込み`);
    }
  } catch (err) {
    appLog('error', 'sync', '取得-全タブ失敗', err.message);
    showToast('取得に失敗: ' + err.message, true);
  } finally {
    if (syncBtn) syncBtn.classList.remove('syncing');
  }
}

function showSettingsMenu(btnEl) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.innerHTML = `
    <button data-action="layout">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="7" height="7"/>
        <rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/>
        <rect x="3" y="14" width="7" height="7"/>
      </svg>
      レイアウト設定
    </button>
    <button data-action="sync-settings">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="23 4 23 10 17 10"/>
        <polyline points="1 20 1 14 7 14"/>
        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
      </svg>
      同期設定 (PAT)
    </button>
    <button data-action="manage-shared">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z"/>
        <path d="M2 17l10 5 10-5"/>
        <path d="M2 12l10 5 10-5"/>
      </svg>
      共有タブの管理
    </button>
    <button data-action="logs">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
        <polyline points="10 9 9 9 8 9"/>
      </svg>
      ログ
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="export">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      全データをエクスポート
    </button>
    <button data-action="import">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      インポート
    </button>
  `;

  btnEl.parentElement.appendChild(menu);

  menu.querySelector('[data-action="layout"]').addEventListener('click', () => {
    menu.remove();
    showLayoutModal();
  });
  menu.querySelector('[data-action="sync-settings"]').addEventListener('click', () => {
    menu.remove();
    showSyncModal();
  });
  menu.querySelector('[data-action="manage-shared"]').addEventListener('click', () => {
    menu.remove();
    showManageSharedModal();
  });
  menu.querySelector('[data-action="logs"]').addEventListener('click', () => {
    menu.remove();
    showLogModal();
  });
  menu.querySelector('[data-action="export"]').addEventListener('click', () => {
    menu.remove();
    exportData();
  });
  menu.querySelector('[data-action="import"]').addEventListener('click', () => {
    menu.remove();
    showImportModal();
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 0);
}

// ============================================
// Tab operations
// ============================================
async function selectTab(tabId) {
  state.activeTabId = tabId;
  bulkSelected.clear(); // タブを切り替えたら選択はリセット (選択はタブ内のみ有効)
  await personalStorage.save(state);
  // タブごとのレイアウトを適用
  loadLayoutForActiveTab();
  render();

  const activeTab = state.tabs.find(t => t.id === tabId);
  // 同期ONのときだけ、共有タブに切り替えた際にGitHubから最新を取得する。
  // OFF中は取得しない (OFFで編集したのにタブ切替で元に戻る不具合の対策)。
  if (activeTab && activeTab.type === 'shared' && sharedStorage.isConfigured() && syncEnabled) {
    await syncActiveSharedTab();
    renderTiles();
  }
}

// ============================================
// タイルのドラッグ&ドロップ処理
// ============================================
async function handleTileDrop(dragged, targetTabId, anchorTileId, insertAfter) {
  const sourceTab = state.tabs.find(t => t.id === dragged.sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const tileIndex = sourceTab.tiles.findIndex(t => t.id === dragged.tileId);
  if (tileIndex < 0) return;

  // ソースから取り出し
  const [tile] = sourceTab.tiles.splice(tileIndex, 1);

  // ターゲット側の挿入位置を決定
  let insertIndex;
  if (anchorTileId === null) {
    insertIndex = targetTab.tiles.length;
  } else {
    const anchorIndex = targetTab.tiles.findIndex(t => t.id === anchorTileId);
    if (anchorIndex < 0) {
      insertIndex = targetTab.tiles.length;
    } else {
      insertIndex = insertAfter ? anchorIndex + 1 : anchorIndex;
    }
  }

  targetTab.tiles.splice(insertIndex, 0, tile);

  // 画面はすぐ更新 (タイルグリッドのみ)
  renderTiles();

  // ストレージへの保存はバックグラウンドで (awaitしない)
  personalStorage.save(state).catch(err => console.error('save failed:', err));

  // 共有タブの場合もバックグラウンドで同期
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error('shared save failed:', err));
  }
  if (targetTab.id !== sourceTab.id && targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error('shared save failed:', err));
  }
}

// ============================================
// タブホバーでの自動切替 (ドラッグ中)
// ============================================
function setupTabDropZones() {
  document.querySelectorAll('.tab').forEach((tabEl) => {
    const tabId = tabEl.dataset.tabId;
    if (!tabId) return;

    tabEl.addEventListener('dragover', (e) => {
      // タイルのドラッグ中だけ反応
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      tabEl.classList.add('tile-drag-over-tab');

      // 既にアクティブなタブなら切替処理不要
      if (tabId === state.activeTabId) return;

      // タイマーが既に動いていれば何もしない
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) return;

      // 既存タイマーをクリア
      if (tabHoverTimer) clearTimeout(tabHoverTimer.timer);

      // 500ms 後にそのタブに切り替え
      const timer = setTimeout(() => {
        if (draggedTile) {
          selectTab(tabId);
        }
        tabHoverTimer = null;
      }, 500);
      tabHoverTimer = { tabId, timer };
    });

    tabEl.addEventListener('dragleave', () => {
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
    });

    tabEl.addEventListener('drop', (e) => {
      // タブ自体への drop は「そのタブに切り替え」のみ (タイルのドロップ先はグリッド)
      if (!draggedTile) return;
      e.preventDefault();
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
      // まだそのタブに切り替わってない場合は切替
      if (tabId !== state.activeTabId) {
        selectTab(tabId);
      }
    });
  });
}

function showTileMenu(tile, x, y) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="edit">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      編集
    </button>
    <button data-action="move">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="9 18 15 12 9 6"/>
      </svg>
      別タブへ移動
    </button>
    <button data-action="copy">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
      別タブへコピー
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      削除
    </button>
  `;

  document.body.appendChild(menu);

  // 画面外にはみ出さないように位置調整
  menu.style.position = 'fixed';
  const menuRect = menu.getBoundingClientRect();
  let left = x;
  let top = y;
  if (left + menuRect.width > window.innerWidth) left = window.innerWidth - menuRect.width - 8;
  if (top + menuRect.height > window.innerHeight) top = window.innerHeight - menuRect.height - 8;
  menu.style.top = `${top}px`;
  menu.style.left = `${left}px`;

  menu.querySelector('[data-action="edit"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    openEditTile(tile);
  });

  menu.querySelector('[data-action="move"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'move');
  });

  menu.querySelector('[data-action="copy"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'copy');
  });

  menu.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    confirmDeleteTile(tile);
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
        document.removeEventListener('contextmenu', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
    document.addEventListener('contextmenu', closeMenu);
  }, 10);
}

// ============================================
// タブ編集 (複数選択して一括操作)
// ============================================
function toggleBulkEditMode() {
  bulkEditMode = !bulkEditMode;
  bulkSelected.clear();
  render();
}

function exitBulkEditMode() {
  bulkEditMode = false;
  bulkSelected.clear();
  render();
}

function toggleTileSelection(tileId, tileEl) {
  if (bulkSelected.has(tileId)) {
    bulkSelected.delete(tileId);
    tileEl.classList.remove('bulk-selected');
  } else {
    bulkSelected.add(tileId);
    tileEl.classList.add('bulk-selected');
  }
  updateBulkBar();
}

function bulkSelectAll() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return;
  const allSelected = activeTab.tiles.length > 0 && bulkSelected.size === activeTab.tiles.length;
  bulkSelected.clear();
  if (!allSelected) {
    activeTab.tiles.forEach(t => bulkSelected.add(t.id));
  }
  renderTiles();
  updateBulkBar();
}

// 選択中タイルを、activeタブ内の並び順で返す
function getSelectedTilesInOrder() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return [];
  return activeTab.tiles.filter(t => bulkSelected.has(t.id));
}

function updateBulkBar() {
  const existing = document.getElementById('bulk-action-bar');
  if (!bulkEditMode) {
    if (existing) existing.remove();
    return;
  }
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const count = bulkSelected.size;
  const total = activeTab ? activeTab.tiles.length : 0;
  const allSelected = total > 0 && count === total;
  const disabled = count === 0 ? 'disabled' : '';

  let bar = existing;
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'bulk-action-bar';
    document.body.appendChild(bar);
  }
  bar.innerHTML = `
    <span class="bulk-count">${count}件 選択中</span>
    <button class="bulk-btn" data-bulk="selectall">${allSelected ? '選択解除' : '全選択'}</button>
    <span class="bulk-sep"></span>
    <button class="bulk-btn" data-bulk="move" ${disabled}>別タブへ移動</button>
    <button class="bulk-btn" data-bulk="copy" ${disabled}>別タブへコピー</button>
    <button class="bulk-btn danger" data-bulk="delete" ${disabled}>削除</button>
    <span class="bulk-sep"></span>
    <button class="bulk-btn done" data-bulk="done">完了</button>
  `;
  bar.querySelector('[data-bulk="selectall"]').addEventListener('click', bulkSelectAll);
  bar.querySelector('[data-bulk="move"]').addEventListener('click', () => { if (count) showBulkTabSelector('move'); });
  bar.querySelector('[data-bulk="copy"]').addEventListener('click', () => { if (count) showBulkTabSelector('copy'); });
  bar.querySelector('[data-bulk="delete"]').addEventListener('click', () => { if (count) bulkDelete(); });
  bar.querySelector('[data-bulk="done"]').addEventListener('click', exitBulkEditMode);
}

async function performBulkMove(targetTabId) {
  const sourceTab = state.tabs.find(t => t.id === state.activeTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const moving = getSelectedTilesInOrder();
  if (moving.length === 0) return;
  const movingIds = new Set(moving.map(t => t.id));
  // sourceから取り除く
  sourceTab.tiles = sourceTab.tiles.filter(t => !movingIds.has(t.id));
  // targetの末尾へ (元の並び順を保つ)
  moving.forEach(t => targetTab.tiles.push(t));
  markLocalEdit();

  bulkSelected.clear();
  renderTiles();
  updateBulkBar();

  await personalStorage.save(state);
  if (sourceTab.type === 'shared' && sourceTab.code) saveSharedTab(sourceTab).catch(err => console.error(err));
  if (targetTab.type === 'shared' && targetTab.code) saveSharedTab(targetTab).catch(err => console.error(err));
  appLog('info', 'tab', `一括移動: ${moving.length}件 → 「${targetTab.name}」`);
  showToast(`${moving.length}件を「${targetTab.name}」へ移動しました`);
}

async function performBulkCopy(targetTabId) {
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!targetTab) return;

  const copying = getSelectedTilesInOrder();
  if (copying.length === 0) return;
  copying.forEach(t => targetTab.tiles.push({
    id: generateId('tile'),
    title: t.title,
    url: t.url,
    image: t.image,
    showLabel: t.showLabel,
    label: t.label,
    labelSize: t.labelSize,
    labelColor: t.labelColor,
    labelWeight: t.labelWeight,
    labelPos: t.labelPos,
    contentType: t.contentType,
    contentText: t.contentText,
    contentSize: t.contentSize,
    contentWeight: t.contentWeight,
    contentColor: t.contentColor,
    btn1: t.btn1,
    btn2: t.btn2
  }));
  markLocalEdit();

  bulkSelected.clear();
  renderTiles();
  updateBulkBar();

  await personalStorage.save(state);
  if (targetTab.type === 'shared' && targetTab.code) saveSharedTab(targetTab).catch(err => console.error(err));
  appLog('info', 'tab', `一括コピー: ${copying.length}件 → 「${targetTab.name}」`);
  showToast(`${copying.length}件を「${targetTab.name}」へコピーしました`);
}

function bulkDelete() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return;
  const n = bulkSelected.size;
  if (n === 0) return;
  showConfirm(`選択した ${n}件 のタイルを削除しますか？`, async () => {
    activeTab.tiles = activeTab.tiles.filter(t => !bulkSelected.has(t.id));
    markLocalEdit();
    bulkSelected.clear();
    renderTiles();
    updateBulkBar();
    await personalStorage.save(state);
    if (activeTab.type === 'shared' && activeTab.code) saveSharedTab(activeTab).catch(err => console.error(err));
    appLog('info', 'tab', `一括削除: ${n}件`);
    showToast(`${n}件を削除しました`);
  });
}

// 移動/コピー先タブ選択 (一括用)
function showBulkTabSelector(action) {
  const count = bulkSelected.size;
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>${action === 'move' ? '移動先' : 'コピー先'}のタブを選択（${count}件）</h2>
        <button class="icon-btn" data-action="close">✕</button>
      </div>
      <div class="modal-body">
        <div class="tab-selector-list" id="bulk-tab-selector-list"></div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  const list = modal.querySelector('#bulk-tab-selector-list');
  const sourceTabId = state.activeTabId;

  state.tabs.forEach(tab => {
    if (action === 'move' && tab.id === sourceTabId) return; // 移動元は除外
    const item = document.createElement('button');
    item.className = 'tab-selector-item';
    const sharedBadge = tab.type === 'shared' ? '<span class="tab-badge" style="margin-left:6px;">共有</span>' : '';
    const currentBadge = tab.id === sourceTabId ? '<span class="tab-badge" style="margin-left:6px;background:#fef3c7;color:#92400e;">現在</span>' : '';
    item.innerHTML = `
      <span>${escapeHtml(tab.name)}${sharedBadge}${currentBadge}</span>
      <span class="tab-selector-count">${tab.tiles.length} タイル</span>
    `;
    item.addEventListener('click', async () => {
      modal.remove();
      if (action === 'move') await performBulkMove(tab.id);
      else await performBulkCopy(tab.id);
    });
    list.appendChild(item);
  });

  if (list.children.length === 0) {
    list.innerHTML = '<div style="color:#999;padding:20px;text-align:center;font-size:13px;">他のタブがありません</div>';
  }

  modal.querySelector('[data-action="close"]').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
}

// タブ選択モーダル (移動/コピー用)
function showTabSelector(tile, action) {
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>${action === 'move' ? '移動先のタブを選択' : 'コピー先のタブを選択'}</h2>
        <button class="icon-btn" data-action="close">✕</button>
      </div>
      <div class="modal-body">
        <div class="tab-selector-list" id="tab-selector-list"></div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  const list = modal.querySelector('#tab-selector-list');
  const sourceTabId = state.activeTabId;

  state.tabs.forEach(tab => {
    // 移動の場合、現在のタブは選択肢から除外
    if (action === 'move' && tab.id === sourceTabId) return;

    const item = document.createElement('button');
    item.className = 'tab-selector-item';
    const sharedBadge = tab.type === 'shared' ? '<span class="tab-badge" style="margin-left:6px;">共有</span>' : '';
    const currentBadge = tab.id === sourceTabId ? '<span class="tab-badge" style="margin-left:6px;background:#fef3c7;color:#92400e;">現在</span>' : '';
    item.innerHTML = `
      <span>${escapeHtml(tab.name)}${sharedBadge}${currentBadge}</span>
      <span class="tab-selector-count">${tab.tiles.length} タイル</span>
    `;
    item.addEventListener('click', async () => {
      modal.remove();
      if (action === 'move') {
        await moveTile(tile, sourceTabId, tab.id);
      } else {
        await copyTile(tile, tab.id);
      }
    });
    list.appendChild(item);
  });

  if (list.children.length === 0) {
    list.innerHTML = '<div style="color:#999;padding:20px;text-align:center;font-size:13px;">他のタブがありません</div>';
  }

  modal.querySelector('[data-action="close"]').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

async function moveTile(tile, sourceTabId, targetTabId) {
  const sourceTab = state.tabs.find(t => t.id === sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const idx = sourceTab.tiles.findIndex(t => t.id === tile.id);
  if (idx < 0) return;

  const [moved] = sourceTab.tiles.splice(idx, 1);
  targetTab.tiles.push(moved);
  markLocalEdit();

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error(err));
  }
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へ移動しました`);
}

async function copyTile(tile, targetTabId) {
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!targetTab) return;

  const copy = {
    id: generateId('tile'),
    title: tile.title,
    url: tile.url,
    image: tile.image,
    showLabel: tile.showLabel,
    label: tile.label,
    labelSize: tile.labelSize,
    labelColor: tile.labelColor,
    labelWeight: tile.labelWeight,
    labelPos: tile.labelPos,
    contentType: tile.contentType,
    contentText: tile.contentText,
    contentSize: tile.contentSize,
    contentWeight: tile.contentWeight,
    contentColor: tile.contentColor,
    btn1: tile.btn1,
    btn2: tile.btn2
  };
  targetTab.tiles.push(copy);
  markLocalEdit();

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へコピーしました`);
}

function showTabMenu(tabId, btnEl) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const convertAction = tab.type === 'shared' ? `
    <button data-action="convert-to-personal">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
      個人タブに変換
    </button>
  ` : `
    <button data-action="convert-to-shared">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="18" cy="5" r="3"/>
        <circle cx="6" cy="12" r="3"/>
        <circle cx="18" cy="19" r="3"/>
        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
      </svg>
      共有タブに変換
    </button>
  `;

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="rename">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      名前を変更
    </button>
    ${convertAction}
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      タブを削除
    </button>
  `;

  document.body.appendChild(menu);

  const rect = btnEl.getBoundingClientRect();
  menu.style.position = 'fixed';
  menu.style.top = `${rect.bottom + 4}px`;
  menu.style.left = `${rect.left}px`;

  menu.querySelector('[data-action="rename"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    startRenameTab(tabId);
  });

  const convertSharedBtn = menu.querySelector('[data-action="convert-to-shared"]');
  if (convertSharedBtn) {
    convertSharedBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      showConvertToSharedModal(tabId);
    });
  }

  const convertPersonalBtn = menu.querySelector('[data-action="convert-to-personal"]');
  if (convertPersonalBtn) {
    convertPersonalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmConvertToPersonal(tabId);
    });
  }

  const deleteBtn = menu.querySelector('[data-action="delete"]');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmDeleteTab(tabId);
    });
  }

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 10);
}

function startRenameTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const tabBtn = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
  if (!tabBtn) return;

  const nameSpan = tabBtn.querySelector('.tab-name');
  const originalName = tab.name;

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tab-name-input';
  input.value = originalName;
  nameSpan.replaceWith(input);
  input.focus();
  input.select();

  const finish = async (save) => {
    const newName = input.value.trim();
    if (save && newName && newName !== originalName) {
      tab.name = newName;
      await saveActiveTab();
      if (tab.type === 'shared' && tab.id !== state.activeTabId) {
        try { await saveSharedTab(tab); } catch {}
      }
    }
    render();
  };

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// ============================================
// タブの種類変換
// ============================================
function showConvertToSharedModal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }

  // 合言葉コードを入力させる (簡易プロンプト)
  const code = prompt(
    `「${tab.name}」を共有タブに変換します。\n\n合言葉コードを入力してください (3文字以上、半角英数字・ハイフン推奨):`,
    ''
  );

  if (code === null) return;  // キャンセル
  const trimmedCode = code.trim();
  if (!trimmedCode || trimmedCode.length < 3) {
    showToast('合言葉コードは3文字以上で入力してください', true);
    return;
  }

  (async () => {
    try {
      const remote = await sharedStorage.getByCode(trimmedCode);
      if (remote && Array.isArray(remote.tiles) && remote.tiles.length > 0) {
        const useExisting = confirm(
          `コード「${trimmedCode}」には既に ${remote.tiles.length} 個のタイルを持つ共有タブが存在します。\n\n「OK」で既存の共有タブに参加 (このタブの ${tab.tiles.length} 個のタイルは破棄)。\n「キャンセル」で中止。`
        );
        if (!useExisting) return;
        tab.tiles = remote.tiles;
        if (remote.name) tab.name = remote.name;
      }

      tab.type = 'shared';
      tab.code = trimmedCode;

      await personalStorage.save(state);
      await saveSharedTab(tab);

      render();
      showToast('共有タブに変換しました');
    } catch (err) {
      showToast('変換に失敗: ' + err.message, true);
    }
  })();
}

function restoreDefaultTabSaveHandler() {
  // モーダルを閉じたら、元の「新しいタブ」用のハンドラに戻す
  const saveBtn = document.getElementById('tab-save');
  saveBtn.textContent = '作成';
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
  newSaveBtn.addEventListener('click', handleAddTab);
}

function confirmConvertToPersonal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab || tab.type !== 'shared') return;

  showConfirm(
    `「${tab.name}」を個人タブに変換しますか？\n\nタブの内容(現在のタイル)はそのまま残り、このブラウザだけで編集・表示するようになります。\n\n※共有データ自体はGitHub上に残ります。他のメンバーには影響しません。`,
    async () => {
      tab.type = 'personal';
      delete tab.code;
      await personalStorage.save(state);
      render();
      showToast('個人タブに変換しました');
    }
  );
}

function confirmDeleteTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  showConfirm(
    `「${tab.name}」タブを削除しますか？${tab.type === 'shared' ? '\n※共有データは残ります(他の人の画面からは消えません)。' : '\n中のタイルも全て削除されます。'}`,
    async () => {
      state.tabs = state.tabs.filter(t => t.id !== tabId);
      if (state.activeTabId === tabId) {
        state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
      }
      // このタブのレイアウト設定も削除
      if (allLayouts[tabId]) {
        delete allLayouts[tabId];
        await personalStorage.saveLayout(allLayouts);
      }
      await personalStorage.save(state);
      loadLayoutForActiveTab();
      render();
      showToast('タブを削除しました');
    }
  );
}

// ============================================
// Add Tab Modal
// ============================================
let selectedSharedCode = null;  // 参加で選択中の共有コード

function showAddTabModal() {
  const modal = document.getElementById('tab-modal');
  document.getElementById('tab-name').value = '';
  document.getElementById('tab-code').value = '';
  document.getElementById('tab-shared-new-name').value = '';
  document.querySelector('input[name="tab-type"][value="personal"]').checked = true;
  document.querySelector('input[name="shared-mode"][value="join"]').checked = true;
  selectedSharedCode = null;

  // 表示状態を初期化 (個人用)
  updateTabModalVisibility();

  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();

  modal.classList.remove('hidden');
  setTimeout(() => document.getElementById('tab-name').focus(), 50);
}

// タブモーダルの表示切替 (個人/共有、参加/新規)
function updateTabModalVisibility() {
  const type = document.querySelector('input[name="tab-type"]:checked').value;
  const sharedMode = document.querySelector('input[name="shared-mode"]:checked')?.value || 'join';

  const nameGroup = document.getElementById('tab-name-group');
  const sharedModeGroup = document.getElementById('tab-shared-mode-group');
  const sharedListGroup = document.getElementById('tab-shared-list-group');
  const sharedNewGroup = document.getElementById('tab-shared-new-group');

  if (type === 'personal') {
    nameGroup.classList.remove('hidden');
    sharedModeGroup.classList.add('hidden');
    sharedListGroup.classList.add('hidden');
    sharedNewGroup.classList.add('hidden');
    document.getElementById('tab-modal-content')?.classList.remove('wide');
  } else {
    // 共有用
    nameGroup.classList.add('hidden');
    sharedModeGroup.classList.remove('hidden');

    if (sharedMode === 'join') {
      sharedListGroup.classList.remove('hidden');
      sharedNewGroup.classList.add('hidden');
      document.getElementById('tab-modal-content')?.classList.add('wide'); // 一覧を広く見せる
      loadSharedListForModal();
    } else {
      sharedListGroup.classList.add('hidden');
      sharedNewGroup.classList.remove('hidden');
      document.getElementById('tab-modal-content')?.classList.remove('wide');
    }
  }
}

// GitHub から共有リストを取得してモーダルに表示
async function loadSharedListForModal() {
  const listEl = document.getElementById('tab-shared-list');

  if (!sharedStorage.isConfigured()) {
    listEl.innerHTML = '<div class="shared-list-empty">PATが未設定です。<br>歯車 → 同期設定 (PAT) から設定してください。</div>';
    return;
  }

  listEl.innerHTML = '<div class="shared-list-loading">読み込み中...</div>';

  try {
    const all = await sharedStorage.fetchAll();
    const codes = Object.keys(all);

    // 既に開いている共有タブのコードを除外
    const existingCodes = new Set(state.tabs.filter(t => t.type === 'shared').map(t => t.code));

    const available = codes.filter(code => !existingCodes.has(code));

    if (available.length === 0) {
      if (codes.length === 0) {
        listEl.innerHTML = '<div class="shared-list-empty">共有タブがまだありません。<br>「新規作成」から作ってください。</div>';
      } else {
        listEl.innerHTML = '<div class="shared-list-empty">参加できる共有タブはありません。<br>(すべて追加済みです)</div>';
      }
      return;
    }

    listEl.innerHTML = '';
    available.forEach(code => {
      const data = all[code];
      const name = data.name || code;
      const tileCount = Array.isArray(data.tiles) ? data.tiles.length : 0;

      const item = document.createElement('button');
      item.className = 'shared-list-item';
      item.dataset.code = code;
      item.innerHTML = `
        <div class="shared-list-item-info">
          <span class="shared-list-item-name">${escapeHtml(name)}</span>
          <span class="shared-list-item-meta">${escapeHtml(code)}</span>
        </div>
        <span class="shared-list-item-count">${tileCount} タイル</span>
      `;
      item.addEventListener('click', () => {
        // 選択状態を更新
        listEl.querySelectorAll('.shared-list-item').forEach(el => el.classList.remove('selected'));
        item.classList.add('selected');
        selectedSharedCode = code;
      });
      listEl.appendChild(item);
    });
  } catch (err) {
    listEl.innerHTML = `<div class="shared-list-empty">取得に失敗しました。<br>${escapeHtml(err.message)}</div>`;
  }
}

function hideAddTabModal() {
  document.getElementById('tab-modal').classList.add('hidden');
  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();
}

async function handleAddTab() {
  const type = document.querySelector('input[name="tab-type"]:checked').value;

  // ===== 個人タブ =====
  if (type === 'personal') {
    const name = document.getElementById('tab-name').value.trim();
    if (!name) {
      showToast('タブ名を入力してください', true);
      return;
    }
    const newTab = {
      id: generateId('tab'),
      name,
      type: 'personal',
      tiles: []
    };
    state.tabs.push(newTab);
    state.activeTabId = newTab.id;
    await personalStorage.save(state);
    hideAddTabModal();
    render();
    return;
  }

  // ===== 共有タブ =====
  if (!sharedStorage.isConfigured()) {
    showToast('PATが未設定です。歯車 → 同期設定 (PAT) から設定してください', true);
    return;
  }

  const sharedMode = document.querySelector('input[name="shared-mode"]:checked').value;

  // --- 既存から参加 ---
  if (sharedMode === 'join') {
    if (!selectedSharedCode) {
      showToast('参加する共有タブを選んでください', true);
      return;
    }

    try {
      const remote = await sharedStorage.getByCode(selectedSharedCode);
      const newTab = {
        id: generateId('tab'),
        name: (remote && remote.name) ? remote.name : selectedSharedCode,
        type: 'shared',
        code: selectedSharedCode,
        tiles: (remote && Array.isArray(remote.tiles)) ? remote.tiles : []
      };
      state.tabs.push(newTab);
      state.activeTabId = newTab.id;
      lastSyncTimes[newTab.id] = Date.now();
      await personalStorage.save(state);
      await personalStorage.saveLastSyncTimes(lastSyncTimes);

      hideAddTabModal();
      render();
      showToast(`「${newTab.name}」に参加しました`);
    } catch (err) {
      showToast('共有データの取得に失敗: ' + err.message, true);
    }
    return;
  }

  // --- 新規作成 ---
  const name = document.getElementById('tab-shared-new-name').value.trim();
  const code = document.getElementById('tab-code').value.trim();

  if (!name) {
    showToast('タブ名を入力してください', true);
    return;
  }
  if (!code || code.length < 3) {
    showToast('合言葉コードは3文字以上で入力してください', true);
    return;
  }

  try {
    // 既存コードと衝突してないかチェック
    const existing = await sharedStorage.getByCode(code);
    if (existing) {
      showToast(`コード「${code}」は既に使われています。別のコードにするか、参加から選んでください`, true);
      return;
    }

    const newTab = {
      id: generateId('tab'),
      name,
      type: 'shared',
      code,
      tiles: []
    };
    state.tabs.push(newTab);
    state.activeTabId = newTab.id;
    await personalStorage.save(state);
    await saveSharedTab(newTab);

    hideAddTabModal();
    render();
    showToast(`共有タブ「${name}」を作成しました`);
  } catch (err) {
    showToast('共有タブの作成に失敗: ' + err.message, true);
  }
}

// ============================================
// Tile Modal
// ============================================
function openAddTile() {
  currentEditingTile = null;
  document.getElementById('tile-modal-title').textContent = '新しいタイル';
  document.getElementById('tile-url').value = '';
  document.getElementById('tile-image-url').value = '';
  setImagePreview('');
  setLabelControls(false, '', 'medium', DEFAULT_LABEL_COLOR, 'bold', 'br');
  setContentControls(null);
  setSubButtonControls(null);
  document.getElementById('tile-modal').classList.remove('hidden');
  autoGrowUrl();
  ['tile-btn1-url','tile-btn2-url'].forEach(id => { const el=document.getElementById(id); if(el){ el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,200)+'px'; } });
  renderTilePreview();
  setTimeout(() => document.getElementById('tile-url').focus(), 50);
}

function openEditTile(tile) {
  currentEditingTile = tile;
  document.getElementById('tile-modal-title').textContent = 'タイルを編集';
  document.getElementById('tile-url').value = tile.url;
  const image = tile.image || '';
  document.getElementById('tile-image-url').value = image.startsWith('data:') ? '' : image;
  setImagePreview(image);
  setLabelControls(!!tile.showLabel, tile.label || '', tile.labelSize || 'medium', tile.labelColor || DEFAULT_LABEL_COLOR, tile.labelWeight || 'bold', tile.labelPos || 'br');
  setContentControls(tile);
  setSubButtonControls(tile);
  document.getElementById('tile-modal').classList.remove('hidden');
  autoGrowUrl();
  ['tile-btn1-url','tile-btn2-url'].forEach(id => { const el=document.getElementById(id); if(el){ el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,200)+'px'; } });
  renderTilePreview();
}

// 右下テキストの入力欄を初期化 (ON/OFF・文字・サイズ・色)
function setLabelControls(on, text, size, color, weight, pos) {
  document.getElementById('tile-label-toggle').checked = !!on;
  document.getElementById('tile-label-text').value = text || '';
  const group = document.getElementById('tile-label-size-group');
  group.querySelectorAll('.size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.size === (size || 'medium'));
  });
  const pgroup = document.getElementById('tile-label-pos-group');
  pgroup.querySelectorAll('.size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.pos === (pos || 'br'));
  });
  const wgroup = document.getElementById('tile-label-weight-group');
  wgroup.querySelectorAll('.size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.weight === (weight || 'bold'));
  });
  buildColorSwatches(color || DEFAULT_LABEL_COLOR);
  updateLabelOptionsVisibility();
}

// ONのときだけ入力欄を表示
function updateLabelOptionsVisibility() {
  const on = document.getElementById('tile-label-toggle').checked;
  document.getElementById('tile-label-options').classList.toggle('hidden', !on);
}

// 現在の右下テキスト設定を読み取る
function getLabelValues() {
  const on = document.getElementById('tile-label-toggle').checked;
  const text = document.getElementById('tile-label-text').value.trim();
  const selectedBtn = document.querySelector('#tile-label-size-group .size-btn.selected');
  const size = selectedBtn ? selectedBtn.dataset.size : 'medium';
  const selectedSwatch = document.querySelector('#tile-label-color-group .color-swatch.selected');
  const labelColor = selectedSwatch ? selectedSwatch.dataset.color : DEFAULT_LABEL_COLOR;
  const selectedWeight = document.querySelector('#tile-label-weight-group .size-btn.selected');
  const labelWeight = selectedWeight ? selectedWeight.dataset.weight : 'bold';
  const selectedPos = document.querySelector('#tile-label-pos-group .size-btn.selected');
  const labelPos = selectedPos ? selectedPos.dataset.pos : 'br';
  return { showLabel: on, label: text, labelSize: size, labelColor, labelWeight, labelPos };
}

// 文字色パレット (代表的な30色 + ゆかい屋レッド)
const DEFAULT_LABEL_COLOR = '#1A1A1A';
const LABEL_COLORS = [
  { c: '#1A1A1A', n: '黒' },
  { c: '#5A5A5A', n: 'こいグレー' },
  { c: '#8A8A8A', n: 'グレー' },
  { c: '#BEBEBE', n: 'うすグレー' },
  { c: '#FFFFFF', n: '白' },
  { c: '#C00000', n: 'ゆかい屋レッド' },
  { c: '#E60000', n: '赤' },
  { c: '#FF3B30', n: 'あかるい赤' },
  { c: '#FF6B6B', n: 'サーモン' },
  { c: '#FF2D78', n: 'ローズ' },
  { c: '#E91E63', n: 'ピンク' },
  { c: '#FF7A00', n: 'オレンジ' },
  { c: '#FF9F1C', n: 'あかるいオレンジ' },
  { c: '#D2691E', n: 'テラコッタ' },
  { c: '#8B5E3C', n: '茶' },
  { c: '#FFC400', n: '黄' },
  { c: '#F4B400', n: 'ゴールド' },
  { c: '#B8A600', n: 'からし' },
  { c: '#2E7D32', n: '緑' },
  { c: '#34C759', n: 'あかるい緑' },
  { c: '#7CB342', n: '黄緑' },
  { c: '#00A86B', n: 'ひすい' },
  { c: '#009688', n: 'ティール' },
  { c: '#00BCD4', n: 'シアン' },
  { c: '#0A66C2', n: 'こい青' },
  { c: '#1967D2', n: '青' },
  { c: '#2196F3', n: 'あかるい青' },
  { c: '#3F51B5', n: 'インディゴ' },
  { c: '#6A1B9A', n: '紫' },
  { c: '#7C4DFF', n: 'バイオレット' },
  { c: '#9C27B0', n: 'マゼンタ' }
];

// パレットを描画し、指定色を選択状態にする
function buildColorSwatches(selectedColor) {
  const group = document.getElementById('tile-label-color-group');
  if (!group) return;
  const sel = (selectedColor || DEFAULT_LABEL_COLOR).toUpperCase();
  group.innerHTML = '';
  LABEL_COLORS.forEach(({ c, n }) => {
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'color-swatch' + (c.toUpperCase() === sel ? ' selected' : '');
    sw.dataset.color = c;
    sw.title = `${n} (${c})`;
    sw.style.background = c;
    group.appendChild(sw);
  });
  // 保存されている色がパレットに無い場合は、先頭(黒)を選択扱いにしておく
  if (!group.querySelector('.color-swatch.selected')) {
    const first = group.querySelector('.color-swatch');
    if (first) first.classList.add('selected');
  }
}

// ===== タイルの中身(画像 or 文字列) =====
function buildContentColorSwatches(selectedColor) {
  const group = document.getElementById('tile-content-color-group');
  if (!group) return;
  const sel = (selectedColor || DEFAULT_LABEL_COLOR).toUpperCase();
  group.innerHTML = '';
  LABEL_COLORS.forEach(({ c, n }) => {
    const sw = document.createElement('button');
    sw.type = 'button';
    sw.className = 'color-swatch' + (c.toUpperCase() === sel ? ' selected' : '');
    sw.dataset.color = c;
    sw.title = `${n} (${c})`;
    sw.style.background = c;
    group.appendChild(sw);
  });
  if (!group.querySelector('.color-swatch.selected')) {
    const first = group.querySelector('.color-swatch');
    if (first) first.classList.add('selected');
  }
}

// モードに応じて画像欄/文字欄を出し分け
function updateContentModeVisibility() {
  const mode = document.querySelector('#tile-content-mode-group .size-btn.selected')?.dataset.mode || 'image';
  document.getElementById('tile-content-image-group').classList.toggle('hidden', mode !== 'image');
  document.getElementById('tile-content-text-group').classList.toggle('hidden', mode !== 'text');
}

// 中身の入力欄を初期化
function setContentControls(tile) {
  const mode = (tile && tile.contentType === 'text') ? 'text' : 'image';
  document.querySelectorAll('#tile-content-mode-group .size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.mode === mode);
  });
  document.getElementById('tile-content-text').value = (tile && tile.contentText) || '';
  const size = (tile && tile.contentSize) || 'medium';
  document.querySelectorAll('#tile-content-size-group .size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.size === size);
  });
  const weight = (tile && tile.contentWeight) || 'bold';
  document.querySelectorAll('#tile-content-weight-group .size-btn').forEach(b => {
    b.classList.toggle('selected', b.dataset.weight === weight);
  });
  buildContentColorSwatches((tile && tile.contentColor) || DEFAULT_LABEL_COLOR);
  updateContentModeVisibility();
}

// 中身の設定を読み取る
function getContentValues() {
  const mode = document.querySelector('#tile-content-mode-group .size-btn.selected')?.dataset.mode || 'image';
  const contentText = document.getElementById('tile-content-text').value.replace(/\r\n/g, '\n');
  const sizeBtn = document.querySelector('#tile-content-size-group .size-btn.selected');
  const weightBtn = document.querySelector('#tile-content-weight-group .size-btn.selected');
  const colorSw = document.querySelector('#tile-content-color-group .color-swatch.selected');
  return {
    contentType: mode,
    contentText: mode === 'text' ? contentText : '',
    contentSize: sizeBtn ? sizeBtn.dataset.size : 'medium',
    contentWeight: weightBtn ? weightBtn.dataset.weight : 'bold',
    contentColor: colorSw ? colorSw.dataset.color : DEFAULT_LABEL_COLOR
  };
}

// ===== タイル内サブボタン(左下/右下) =====
// ボタンの色 (白地＋色枠) 10種類。'#333'は枠・文字の色。
const SUBBTN_DEFAULT_COLOR = '#202124';
const SUBBTN_COLORS = [
  { c: '#202124', n: '黒' },
  { c: '#5A5A5A', n: 'グレー' },
  { c: '#C00000', n: 'ゆかい屋レッド' },
  { c: '#E60000', n: '赤' },
  { c: '#FF7A00', n: 'オレンジ' },
  { c: '#F4B400', n: 'ゴールド' },
  { c: '#2E7D32', n: '緑' },
  { c: '#009688', n: 'ティール' },
  { c: '#1967D2', n: '青' },
  { c: '#6A1B9A', n: '紫' }
];

function buildSubBtnSwatches(groupId, selectedColor, selectedStyle) {
  const group = document.getElementById(groupId);
  if (!group) return;
  const sel = (selectedColor || SUBBTN_DEFAULT_COLOR).toUpperCase();
  const selStyle = selectedStyle || 'outline';
  group.innerHTML = '';
  // 上段: 白地＋色枠 (outline)、下段: 塗りつぶし＋白文字 (fill)
  ['outline', 'fill'].forEach(style => {
    SUBBTN_COLORS.forEach(({ c, n }) => {
      const sw = document.createElement('button');
      sw.type = 'button';
      const isSel = (c.toUpperCase() === sel && style === selStyle);
      sw.className = 'color-swatch outline' + (isSel ? ' selected' : '');
      sw.dataset.color = c;
      sw.dataset.style = style;
      sw.title = n + (style === 'fill' ? '(塗り)' : '(枠)');
      if (style === 'fill') {
        sw.style.background = c;
        sw.style.borderColor = c;
        sw.style.color = '#fff';
      } else {
        sw.style.background = '#fff';
        sw.style.borderColor = c;
        sw.style.color = c;
      }
      sw.textContent = 'A';
      group.appendChild(sw);
    });
  });
  if (!group.querySelector('.color-swatch.selected')) {
    const first = group.querySelector('.color-swatch');
    if (first) first.classList.add('selected');
  }
}

// ボタン欄の表示/非表示 (トグル)
function updateSubBtnVisibility() {
  document.getElementById('tile-btn1-box').classList.toggle('hidden', !document.getElementById('tile-btn1-toggle').checked);
  document.getElementById('tile-btn2-box').classList.toggle('hidden', !document.getElementById('tile-btn2-toggle').checked);
}

function setSubButtonControls(tile) {
  const b1 = (tile && tile.btn1) || null;
  const b2 = (tile && tile.btn2) || null;
  document.getElementById('tile-btn1-toggle').checked = !!b1;
  document.getElementById('tile-btn2-toggle').checked = !!b2;
  document.getElementById('tile-btn1-text').value = (b1 && b1.text) || '';
  document.getElementById('tile-btn1-url').value = (b1 && b1.url) || '';
  document.getElementById('tile-btn2-text').value = (b2 && b2.text) || '';
  document.getElementById('tile-btn2-url').value = (b2 && b2.url) || '';
  buildSubBtnSwatches('tile-btn1-color-group', (b1 && b1.color) || SUBBTN_DEFAULT_COLOR, (b1 && b1.style) || 'outline');
  buildSubBtnSwatches('tile-btn2-color-group', (b2 && b2.color) || SUBBTN_DEFAULT_COLOR, (b2 && b2.style) || 'outline');
  const setSize = (gid, val) => document.querySelectorAll('#' + gid + ' .size-btn').forEach(b => b.classList.toggle('selected', b.dataset.size === String(val || 50)));
  setSize('tile-btn1-size-group', (b1 && b1.size) || 50);
  setSize('tile-btn2-size-group', (b2 && b2.size) || 50);
  const setH = (gid, val) => document.querySelectorAll('#' + gid + ' .size-btn').forEach(b => b.classList.toggle('selected', b.dataset.height === (val || 's')));
  setH('tile-btn1-height-group', (b1 && b1.height) || 's');
  setH('tile-btn2-height-group', (b2 && b2.height) || 's');
  updateSubBtnVisibility();
}

function getSubButtonValues() {
  const on1 = document.getElementById('tile-btn1-toggle').checked;
  const on2 = document.getElementById('tile-btn2-toggle').checked;
  const b1t = document.getElementById('tile-btn1-text').value.trim();
  const b1u = document.getElementById('tile-btn1-url').value.trim();
  const b2t = document.getElementById('tile-btn2-text').value.trim();
  const b2u = document.getElementById('tile-btn2-url').value.trim();
  const sw1 = document.querySelector('#tile-btn1-color-group .color-swatch.selected');
  const sw2 = document.querySelector('#tile-btn2-color-group .color-swatch.selected');
  const c1 = sw1?.dataset.color || SUBBTN_DEFAULT_COLOR;
  const c2 = sw2?.dataset.color || SUBBTN_DEFAULT_COLOR;
  const st1 = sw1?.dataset.style || 'outline';
  const st2 = sw2?.dataset.style || 'outline';
  const sz1 = parseInt(document.querySelector('#tile-btn1-size-group .size-btn.selected')?.dataset.size || '50', 10);
  const sz2 = parseInt(document.querySelector('#tile-btn2-size-group .size-btn.selected')?.dataset.size || '50', 10);
  const h1 = document.querySelector('#tile-btn1-height-group .size-btn.selected')?.dataset.height || 's';
  const h2 = document.querySelector('#tile-btn2-height-group .size-btn.selected')?.dataset.height || 's';
  // トグルON かつ 文字ありのものだけ有効
  const btn1 = (on1 && b1t) ? { text: b1t, url: b1u ? normalizeUrl(b1u) : '', color: c1, style: st1, size: sz1, height: h1 } : null;
  const btn2 = (on2 && b2t) ? { text: b2t, url: b2u ? normalizeUrl(b2u) : '', color: c2, style: st2, size: sz2, height: h2 } : null;
  return { btn1, btn2 };
}

// URL欄(textarea)を内容に合わせて下に伸ばす
function autoGrowUrl() {
  const el = document.getElementById('tile-url');
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 200) + 'px';
}

// 編集中のタイルプレビューを描画 (実際のタイルと同じ見た目)
function renderTilePreview() {
  const el = document.getElementById('tile-live-preview');
  if (!el) return;
  el.innerHTML = '';

  const content = getContentValues();
  const url = document.getElementById('tile-url').value.trim();

  if (content.contentType === 'text' && content.contentText) {
    const txt = document.createElement('div');
    txt.className = 'tile-content-text size-' + content.contentSize + ' weight-' + content.contentWeight;
    txt.style.color = content.contentColor;
    txt.textContent = content.contentText;
    el.appendChild(txt);
  } else {
    const img = getTileImageValue();
    const primaryUrl = img || (url ? getFaviconUrl(normalizeUrl(url)) : '');
    const imgEl = document.createElement('img');
    if (primaryUrl) imgEl.src = getDisplayImageSrc(primaryUrl);
    if (!img) imgEl.className = 'favicon';
    el.appendChild(imgEl);
  }

  // 右下ラベル
  const lab = getLabelValues();
  if (lab.showLabel && lab.label) {
    const lbl = document.createElement('div');
    lbl.className = 'tile-label-text size-' + lab.labelSize + ' weight-' + lab.labelWeight + ' pos-' + lab.labelPos;
    lbl.style.color = lab.labelColor;
    lbl.textContent = lab.label;
    el.appendChild(lbl);
  }

  // 左下/右下ボタン
  const { btn1, btn2 } = getSubButtonValues();
  [[btn1, 'left'], [btn2, 'right']].forEach(([b, side]) => {
    if (b && b.text) {
      const sb = document.createElement('span');
      sb.className = 'tile-subbtn tile-subbtn-' + side + ' h-' + (b.height || 's');
      const bc = b.color || '#202124';
      sb.style.borderColor = bc;
      if (b.style === 'fill') { sb.style.background = bc; sb.style.color = '#fff'; }
      else { sb.style.background = '#fff'; sb.style.color = bc; }
      sb.style.width = 'calc(' + (b.size || 50) + '% - 9px)';
      sb.textContent = b.text;
      el.appendChild(sb);
    }
  });
}

function hideTileModal() {
  document.getElementById('tile-modal').classList.add('hidden');
  currentEditingTile = null;
}

function setImagePreview(src) {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (src) {
    img.src = src;
    preview.classList.remove('hidden');
  } else {
    img.src = '';
    preview.classList.add('hidden');
  }
}

function getTileImageValue() {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (!preview.classList.contains('hidden') && img.src) {
    if (img.src.startsWith('data:')) return img.src;
  }
  const urlInput = document.getElementById('tile-image-url').value.trim();
  return urlInput;
}

async function handleSaveTile() {
  const title = '';
  const rawUrl = document.getElementById('tile-url').value.trim();

  // タイトルは任意に変更。URLのみ必須。
  if (!rawUrl) {
    showToast('URLは必須です', true);
    return;
  }

  const url = normalizeUrl(rawUrl);
  const image = getTileImageValue();
  const { showLabel, label, labelSize, labelColor, labelWeight, labelPos } = getLabelValues();
  const { contentType, contentText, contentSize, contentWeight, contentColor } = getContentValues();

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return;

  const contentFields = { contentType, contentText, contentSize, contentWeight, contentColor };
  const { btn1, btn2 } = getSubButtonValues();

  if (currentEditingTile) {
    const idx = activeTab.tiles.findIndex(t => t.id === currentEditingTile.id);
    if (idx >= 0) {
      activeTab.tiles[idx] = { ...activeTab.tiles[idx], title, url, image, showLabel, label, labelSize, labelColor, labelWeight, labelPos, ...contentFields, btn1, btn2 };
    }
  } else {
    activeTab.tiles.push({
      id: generateId('tile'),
      title,
      url,
      image,
      showLabel,
      label,
      labelSize,
      labelColor,
      labelWeight,
      labelPos,
      ...contentFields,
      btn1,
      btn2
    });
  }

  try {
    await saveActiveTab();
    hideTileModal();
    renderTiles();
    // 追加・編集したタイルの画像を即キャッシュ (初回から高速表示)
    const primaryUrl = image || getFaviconUrl(url);
    fetchAndCacheImage(primaryUrl);
    if (image) {
      // tile.imageがある場合もfaviconを予備でキャッシュ
      fetchAndCacheImage(getFaviconUrl(url));
    }
  } catch (err) {
    hideTileModal();
    renderTiles();
  }
}

function confirmDeleteTile(tile) {
  showConfirm(`「${tile.title}」を削除しますか？`, async () => {
    const activeTab = state.tabs.find(t => t.id === state.activeTabId);
    if (!activeTab) return;
    activeTab.tiles = activeTab.tiles.filter(t => t.id !== tile.id);
    await saveActiveTab();
    renderTiles();
    showToast('削除しました');
  });
}

// ============================================
// Import Modal
// ============================================
function showImportModal() {
  pendingImportData = null;
  document.getElementById('import-preview-container').classList.add('hidden');
  document.getElementById('import-execute').disabled = true;
  document.getElementById('import-file').value = '';
  document.querySelector('input[name="import-mode"][value="merge"]').checked = true;
  document.getElementById('import-modal').classList.remove('hidden');
}

function hideImportModal() {
  document.getElementById('import-modal').classList.add('hidden');
  pendingImportData = null;
}

// ============================================
// Confirm dialog
// ============================================
function showConfirm(message, onOk, opts = {}) {
  document.getElementById('confirm-message').textContent = message;
  const okBtn = document.getElementById('confirm-ok');
  okBtn.textContent = opts.okLabel || '削除';
  const danger = opts.danger !== false; // 既定は削除想定なので赤(danger)
  okBtn.classList.toggle('btn-danger', danger);
  okBtn.classList.toggle('btn-primary', !danger);
  pendingConfirmAction = onOk;
  document.getElementById('confirm-modal').classList.remove('hidden');
}

function hideConfirm() {
  document.getElementById('confirm-modal').classList.add('hidden');
  pendingConfirmAction = null;
}

// ============================================
// Init
// ============================================
async function init() {
  appLog('info', 'general', `Speed Access v${chrome.runtime?.getManifest?.()?.version || '?'} 起動`);
  state = await personalStorage.load();
  allLayouts = await personalStorage.loadLayout();
  // 画像キャッシュをメモリに展開 (並列で開始、awaitして完了待ち)
  await loadImageCacheToMemory();

  // 保存されたPATをロード (OWNER/REPOは固定なので読まない)
  const savedConfig = await personalStorage.loadSyncConfig();
  if (savedConfig && savedConfig.TOKEN) {
    GITHUB_CONFIG.TOKEN = savedConfig.TOKEN;
  }
  lastSyncTimes = await personalStorage.loadLastSyncTimes();
  // 同期ON/OFFの状態を復元 (既定はON)
  syncEnabled = await new Promise((r) => {
    chrome.storage.local.get(['speedAccessSyncEnabled'], (x) => r(x.speedAccessSyncEnabled !== false));
  });
  if (!syncEnabled) appLog('info', 'sync', '同期はOFFの状態で起動しました');

  // 旧Homeタブがあれば、通常のタブとして扱う
  const oldHome = state.tabs.find(t => t.id === 'home');
  if (oldHome) {
    oldHome.id = generateId('tab');  // 新しいIDを付与
    // 既存のレイアウト設定を引き継ぐ
    if (allLayouts.home) {
      allLayouts[oldHome.id] = allLayouts.home;
      delete allLayouts.home;
      await personalStorage.saveLayout(allLayouts);
    }
    if (state.activeTabId === 'home') {
      state.activeTabId = oldHome.id;
    }
    await personalStorage.save(state);
  }

  // activeTabId の整合性チェック
  if (state.tabs.length > 0 && (!state.activeTabId || !state.tabs.find(t => t.id === state.activeTabId))) {
    state.activeTabId = state.tabs[0].id;
  }

  loadLayoutForActiveTab();
  render();

  // 全タブの全タイル画像をバックグラウンドでプリフェッチ (タブ切替時の高速化)
  setTimeout(() => {
    const allUrls = [];
    state.tabs.forEach(tab => {
      tab.tiles.forEach(t => {
        allUrls.push(t.image || getFaviconUrl(t.url));
      });
    });
    prefetchImages(allUrls);
  }, 500);

  // 起動時の自動取得: 全共有タブを並列で取得 (バックグラウンド)
  // - アクティブな共有タブは結果を即反映
  // - 非アクティブな共有タブは結果をstateに保存だけ
  // - エラーが出ても続行 (オフライン等)
  if (sharedStorage.isConfigured()) {
    silentAutoPullAllSharedTabs();
  }
}

// 起動時の自動取得 (静かに実行、トースト出さない)
async function silentAutoPullAllSharedTabs() {
  if (!syncEnabled) {
    appLog('info', 'sync', '同期OFFのため起動時の自動取得をスキップ');
    return;
  }
  const sharedTabs = state.tabs.filter(t => t.type === 'shared' && t.code);
  if (sharedTabs.length === 0) return;

  appLog('info', 'sync', `自動取得開始: ${sharedTabs.length} 個の共有タブをチェック`);

  // 取得開始時点の編集世代を記録 (取得中に編集が入ったら上書きしない)
  const seqAtStart = localEditSeq;

  // まず一度fetchAllして「GitHubに存在するコード」のセットを作る
  let remoteAll = {};
  try {
    remoteAll = await sharedStorage.fetchAll();
  } catch (err) {
    appLog('warn', 'sync', '自動取得: fetchAll失敗', err.message);
    // パースエラー等の場合は、誤判定を避けるため検出処理をスキップ
    if (err.message && err.message.includes('壊れています')) {
      setTimeout(() => {
        showToast(
          '⚠️ GitHub上のshared-tabs.jsonが壊れている可能性があります。\nログを確認してください。',
          true,
          10000
        );
      }, 1000);
    }
    return;
  }
  const remoteCodes = new Set(Object.keys(remoteAll));

  // ★上書き防止ガード: 取得している数秒の間に、ユーザーが同期をOFFにした
  //   / ローカルでタイルを編集した場合は、取得結果でローカルを上書きしない。
  //   (OFFにして一括移動したのに、遅れて届いた取得で元に戻る不具合の対策)
  if (!syncEnabled) {
    appLog('info', 'sync', '自動取得: 取得完了時に同期OFF → 適用をスキップ (上書き防止)');
    return;
  }
  if (localEditSeq !== seqAtStart) {
    appLog('warn', 'sync', '自動取得: 取得中にローカル編集あり → 適用をスキップ (上書き防止)');
    return;
  }

  // GitHubに存在しない共有タブを検出
  const missing = sharedTabs.filter(t => !remoteCodes.has(t.code));

  if (missing.length > 0) {
    const missingInfo = missing.map(t => ({ name: t.name, code: t.code }));
    appLog('warn', 'sync', `GitHub上に存在しない共有タブ: ${missing.length} 個`, missingInfo);
    // 画面にも警告 (まとめて1回だけ)
    const names = missing.map(t => `「${t.name}」`).join('、');
    setTimeout(() => {
      showToast(
        `⚠️ 共有タブ ${names} がGitHubに存在しません。\n反映ボタンで再登録、または個人タブに変換してください。`,
        true,
        8000
      );
    }, 1000);
  }

  // GitHubに存在するタブだけpullを適用
  let updatedCount = 0;
  sharedTabs.forEach(tab => {
    if (!remoteCodes.has(tab.code)) return;
    const remote = remoteAll[tab.code];
    if (remote && Array.isArray(remote.tiles)) {
      tab.tiles = remote.tiles;
      if (remote.name) tab.name = remote.name;
      lastSyncTimes[tab.id] = Date.now();
      updatedCount++;
      if (tab.id === state.activeTabId) {
        renderTiles();
      }
    }
  });

  appLog('info', 'sync', `自動取得完了: ${updatedCount} 個のタブを更新`);

  await personalStorage.save(state);
  await personalStorage.saveLastSyncTimes(lastSyncTimes);
}

// ============================================
// Event listeners
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  // 複数の「新しいタブ」ページ間で状態を揃える。
  // 特に、あるページで同期をOFF/ONしたら全ページに即反映し、
  // 別ページが古い状態のまま自動取得でローカルを上書きするのを防ぐ。
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.speedAccessSyncEnabled) {
        const v = changes.speedAccessSyncEnabled.newValue !== false;
        if (v !== syncEnabled) {
          syncEnabled = v;
          appLog('info', 'sync', `他のページで同期が ${v ? 'ON' : 'OFF'} に変更 → このページも追従`);
          const modalOpen = !!document.querySelector('.modal:not(.hidden)');
          if (!bulkEditMode && !modalOpen) render();
        }
      }
    });
  }

  document.getElementById('tile-modal-close').addEventListener('click', hideTileModal);
  document.getElementById('tile-cancel').addEventListener('click', hideTileModal);
  document.getElementById('tile-save').addEventListener('click', handleSaveTile);

  // 右下テキスト: ON/OFFトグルで入力欄の表示切替、サイズボタンの選択
  document.getElementById('tile-label-toggle').addEventListener('change', updateLabelOptionsVisibility);
  document.getElementById('tile-label-size-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-label-size-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
  document.getElementById('tile-label-weight-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-label-weight-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
  document.getElementById('tile-label-pos-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-label-pos-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
  document.getElementById('tile-label-color-group').addEventListener('click', (e) => {
    const sw = e.target.closest('.color-swatch');
    if (!sw) return;
    document.querySelectorAll('#tile-label-color-group .color-swatch').forEach(b => b.classList.remove('selected'));
    sw.classList.add('selected');
  });

  // タイルの中身: モード切替(画像/文字列)
  document.getElementById('tile-content-mode-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-content-mode-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    updateContentModeVisibility();
  });
  document.getElementById('tile-content-size-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-content-size-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
  document.getElementById('tile-content-weight-group').addEventListener('click', (e) => {
    const btn = e.target.closest('.size-btn');
    if (!btn) return;
    document.querySelectorAll('#tile-content-weight-group .size-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
  document.getElementById('tile-content-color-group').addEventListener('click', (e) => {
    const sw = e.target.closest('.color-swatch');
    if (!sw) return;
    document.querySelectorAll('#tile-content-color-group .color-swatch').forEach(b => b.classList.remove('selected'));
    sw.classList.add('selected');
  });
  // 左下/右下ボタンの色選択
  ['tile-btn1-color-group', 'tile-btn2-color-group'].forEach(gid => {
    document.getElementById(gid).addEventListener('click', (e) => {
      const sw = e.target.closest('.color-swatch');
      if (!sw) return;
      document.querySelectorAll('#' + gid + ' .color-swatch').forEach(b => b.classList.remove('selected'));
      sw.classList.add('selected');
    });
  });
  // 左下/右下ボタンの横幅選択
  ['tile-btn1-size-group', 'tile-btn2-size-group'].forEach(gid => {
    document.getElementById(gid).addEventListener('click', (e) => {
      const btn = e.target.closest('.size-btn');
      if (!btn) return;
      document.querySelectorAll('#' + gid + ' .size-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
    });
  });
  // 左下/右下ボタンの高さ選択
  ['tile-btn1-height-group', 'tile-btn2-height-group'].forEach(gid => {
    document.getElementById(gid).addEventListener('click', (e) => {
      const btn = e.target.closest('.size-btn');
      if (!btn) return;
      document.querySelectorAll('#' + gid + ' .size-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
    });
  });

  document.getElementById('tile-image-url').addEventListener('input', (e) => {
    setImagePreview(e.target.value.trim());
  });

  // モーダル内のあらゆる操作でプレビューを更新 (委譲)
  const tileModalEl = document.getElementById('tile-modal');
  tileModalEl.addEventListener('input', renderTilePreview);
  tileModalEl.addEventListener('click', (e) => {
    if (e.target.closest('.size-btn, .color-swatch')) renderTilePreview();
  });
  // URL欄は入力のたびに高さ調整
  document.getElementById('tile-url').addEventListener('input', autoGrowUrl);

  // サブボタン: トグルで表示切替、URL欄の自動伸長
  document.getElementById('tile-btn1-toggle').addEventListener('change', () => { updateSubBtnVisibility(); renderTilePreview(); });
  document.getElementById('tile-btn2-toggle').addEventListener('change', () => { updateSubBtnVisibility(); renderTilePreview(); });
  const autoGrowEl = (id) => { const el = document.getElementById(id); if (!el) return; el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 200) + 'px'; };
  document.getElementById('tile-btn1-url').addEventListener('input', () => autoGrowEl('tile-btn1-url'));
  document.getElementById('tile-btn2-url').addEventListener('input', () => autoGrowEl('tile-btn2-url'));

  document.getElementById('tile-upload-btn').addEventListener('click', () => {
    document.getElementById('tile-image-file').click();
  });
  document.getElementById('tile-image-file').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      showToast('画像は500KB以下にしてください', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      document.getElementById('tile-image-url').value = '';
      setImagePreview(ev.target.result);
      renderTilePreview();
    };
    reader.readAsDataURL(file);
  });

  document.getElementById('tile-image-remove').addEventListener('click', () => {
    document.getElementById('tile-image-url').value = '';
    document.getElementById('tile-image-file').value = '';
    setImagePreview('');
    renderTilePreview();
  });

  document.getElementById('tab-modal-close').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-cancel').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-save').addEventListener('click', handleAddTab);

  // タブ種類 (個人/共有) の切替
  document.querySelectorAll('input[name="tab-type"]').forEach(radio => {
    radio.addEventListener('change', updateTabModalVisibility);
  });
  // 共有モード (参加/新規) の切替
  document.querySelectorAll('input[name="shared-mode"]').forEach(radio => {
    radio.addEventListener('change', updateTabModalVisibility);
  });

  document.getElementById('import-modal-close').addEventListener('click', hideImportModal);
  document.getElementById('import-cancel').addEventListener('click', hideImportModal);
  document.getElementById('import-execute').addEventListener('click', executeImport);

  const dropZone = document.getElementById('import-drop-zone');
  const fileInput = document.getElementById('import-file');

  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) handleImportFile(file);
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const file = e.dataTransfer.files?.[0];
    if (file) handleImportFile(file);
  });

  document.getElementById('confirm-cancel').addEventListener('click', hideConfirm);
  document.getElementById('confirm-ok').addEventListener('click', () => {
    if (pendingConfirmAction) pendingConfirmAction();
    hideConfirm();
  });

  // Layout modal
  document.getElementById('layout-modal-close').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-done').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-reset').addEventListener('click', resetLayout);
  document.getElementById('layout-recommended').addEventListener('click', applyRecommendedLayout);
  document.getElementById('layout-apply-all').addEventListener('click', applyLayoutToAllTabs);

  // Sync modal
  document.getElementById('sync-modal-close').addEventListener('click', hideSyncModal);
  document.getElementById('sync-cancel').addEventListener('click', hideSyncModal);
  document.getElementById('sync-save').addEventListener('click', saveSyncSettings);
  document.getElementById('sync-test').addEventListener('click', testSyncConnection);

  // Manage shared modal
  document.getElementById('manage-shared-close').addEventListener('click', hideManageSharedModal);
  document.getElementById('manage-shared-done').addEventListener('click', hideManageSharedModal);
  document.getElementById('manage-shared-refresh').addEventListener('click', loadManageSharedList);

  // Log modal
  document.getElementById('log-modal-close').addEventListener('click', hideLogModal);
  document.getElementById('log-done').addEventListener('click', hideLogModal);
  document.getElementById('sync-info-close').addEventListener('click', hideSyncInfoModal);
  document.getElementById('sync-info-done').addEventListener('click', hideSyncInfoModal);
  document.getElementById('log-refresh').addEventListener('click', renderLogs);
  document.getElementById('log-clear').addEventListener('click', clearLogs);
  document.getElementById('log-copy').addEventListener('click', copyLogsToClipboard);
  document.getElementById('log-filter-level').addEventListener('change', renderLogs);
  document.getElementById('log-filter-category').addEventListener('change', renderLogs);

  document.getElementById('columns-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('width-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('height-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('gap-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('header-spacing-slider').addEventListener('input', updateLayoutFromSliders);

  document.getElementById('tile-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleSaveTile(); }
  });
  document.getElementById('tab-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddTab(); }
  });
  document.getElementById('tab-code').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddTab(); }
  });
  document.getElementById('tab-shared-new-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('tab-code').focus(); }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      hideTileModal();
      hideAddTabModal();
      hideImportModal();
      hideLayoutModal();
      hideSyncModal();
      hideManageSharedModal();
      hideLogModal();
      hideConfirm();
    }
  });

  init();
});

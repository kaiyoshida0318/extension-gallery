@echo off
rem BulkRename launcher - double-click to start. You can also drop files onto this file.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0BulkRename.ps1" %*

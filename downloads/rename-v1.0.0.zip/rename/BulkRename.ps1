﻿<#
  まとめてリネーム (BulkRename)
  ファイルをドラッグ＆ドロップして、名前をまとめて編集・変更するツール。
  起動：同じフォルダの「BulkRename.bat」をダブルクリック。
#>
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Paths
)

$ErrorActionPreference = 'Stop'
$script:SelfPath = $PSCommandPath
$script:SelfDir  = $PSScriptRoot

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

try {
if (-not ('BR.Native' -as [type])) {
Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace BR {
    public static class Native {
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("shlwapi.dll", CharSet = CharSet.Unicode)] public static extern int StrCmpLogicalW(string a, string b);
    }
    // 一覧の並べ替え（Explorer と同じ自然順）
    public class RowComparer : System.Collections.IComparer {
        private readonly int mode;
        public RowComparer(int mode) { this.mode = mode; }
        public int Compare(object x, object y) {
            DataGridViewRow a = (DataGridViewRow)x, b = (DataGridViewRow)y;
            int c;
            if (mode == 1) {
                c = Convert.ToInt64(a.Cells["Mtime"].Value).CompareTo(Convert.ToInt64(b.Cells["Mtime"].Value));
                if (c != 0) return c;
            } else {
                c = Native.StrCmpLogicalW(Convert.ToString(a.Cells["Dir"].Value), Convert.ToString(b.Cells["Dir"].Value));
                if (c != 0) return c;
            }
            return Native.StrCmpLogicalW(Convert.ToString(a.Cells["Orig"].Value), Convert.ToString(b.Cells["Orig"].Value));
        }
    }
}
'@
}

try { [void][BR.Native]::SetProcessDPIAware() } catch {}
[System.Windows.Forms.Application]::EnableVisualStyles()
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch {}
try { [System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException) } catch {}

# ---------------------------------------------------------------- 見た目の基本
$g0 = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
$script:Scale = $g0.DpiX / 96.0
$g0.Dispose()
function Px([double]$v) { return [int][Math]::Round($v * $script:Scale) }
function New-Pad([int]$l, [int]$t, [int]$r, [int]$b) { return New-Object System.Windows.Forms.Padding((Px $l), (Px $t), (Px $r), (Px $b)) }
function New-Size([int]$w, [int]$h) { return New-Object System.Drawing.Size((Px $w), (Px $h)) }

$fontName = 'Yu Gothic UI'
$installed = @((New-Object System.Drawing.Text.InstalledFontCollection).Families | ForEach-Object { $_.Name })
if ($installed -notcontains $fontName) { $fontName = 'Meiryo UI' }
$script:UIFont   = New-Object System.Drawing.Font($fontName, 9.75)
$script:BoldFont = New-Object System.Drawing.Font($fontName, 9.75, [System.Drawing.FontStyle]::Bold)
$script:BigFont  = New-Object System.Drawing.Font($fontName, 14)

function Rgb([int]$r, [int]$g, [int]$b) { return [System.Drawing.Color]::FromArgb($r, $g, $b) }
$C = @{
    Accent    = Rgb 37 99 235
    AccentOff = Rgb 170 182 200
    Muted     = Rgb 107 114 128
    ErrBack   = Rgb 254 226 226
    ErrSel    = Rgb 252 200 200
    ErrFore   = Rgb 185 28 28
    OkBack    = Rgb 220 252 231
    OkSel     = Rgb 185 240 205
    OkFore    = Rgb 21 128 61
    NewBack   = Rgb 255 252 235
    Head      = Rgb 243 244 246
    Sel       = Rgb 219 234 254
    Hint      = Rgb 249 250 251
    HintOver  = Rgb 232 240 254
}

# ---------------------------------------------------------------- 状態
$script:AllTags   = New-Object 'System.Collections.Generic.List[object]'
$script:UndoList  = New-Object 'System.Collections.Generic.List[object]'
$script:LastBatch = @()
$script:Busy      = $false
$script:EditBefore = $null
$script:BadChars  = [System.IO.Path]::GetInvalidFileNameChars()
$script:JustEdited = $false
$script:JustEditedRow = -1

# 設定（自動連番の書式など）。ツールと同じフォルダに保存
$script:SettingsPath = Join-Path $script:SelfDir 'BulkRename.settings.json'
$script:Settings = @{ AutoNumber = $true; Prefix = 'b-'; Digits = 2; Start = 1; Version = 2 }
try {
    if (Test-Path -LiteralPath $script:SettingsPath) {
        $j = Get-Content -LiteralPath $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @($script:Settings.Keys)) { if ($null -ne $j.$k) { $script:Settings[$k] = $j.$k } }
        if ($null -eq $j.Version) { $script:Settings.Prefix = 'b-'; $script:Settings.Version = 2 }   # 旧版の既定「B」から切り替え
    }
} catch {}
function Save-Settings {
    try {
        [pscustomobject]@{
            AutoNumber = [bool]$chkAuto.Checked
            Prefix     = [string]$txtAutoPrefix.Text
            Digits     = [int]$numAutoDigits.Value
            Start      = [int]$numAutoStart.Value
            Version    = 2
        } | ConvertTo-Json | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    } catch {}
}

# ---------------------------------------------------------------- 部品を作る関数
function New-Button([string]$text, [scriptblock]$onClick) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.AutoSize = $true
    $b.AutoSizeMode = 'GrowAndShrink'
    $b.Padding = New-Pad 8 3 8 3
    $b.Margin = New-Pad 0 0 6 6
    $b.UseVisualStyleBackColor = $true
    if ($onClick) { $b.Add_Click($onClick) }
    return $b
}
function New-Label([string]$text, [switch]$Muted, [switch]$Bold) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.AutoSize = $true
    $l.MaximumSize = New-Size 300 0
    $l.Margin = New-Pad 0 8 0 3
    if ($Muted) { $l.ForeColor = $C.Muted }
    if ($Bold) { $l.Font = $script:BoldFont }
    return $l
}
function New-InlineLabel([string]$text) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.AutoSize = $true
    $l.Margin = New-Pad 0 6 4 0
    return $l
}
function New-TextBox([string]$text = '') {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Width = Px 300
    $t.Text = $text
    $t.Margin = New-Pad 0 0 0 4
    return $t
}
function New-Num([int]$min, [int]$max, [int]$val, [int]$w = 64) {
    $n = New-Object System.Windows.Forms.NumericUpDown
    $n.Minimum = $min
    $n.Maximum = $max
    $n.Value = $val
    $n.Width = Px $w
    $n.TextAlign = 'Right'
    $n.Margin = New-Pad 0 2 8 4
    return $n
}
function New-Check([string]$text, [bool]$checked = $false) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $text
    $c.AutoSize = $true
    $c.Checked = $checked
    $c.Margin = New-Pad 0 3 0 3
    return $c
}
function New-Flow([string]$dir = 'TopDown') {
    $f = New-Object System.Windows.Forms.FlowLayoutPanel
    $f.FlowDirection = $dir
    $f.WrapContents = $false
    $f.AutoSize = $true
    $f.AutoSizeMode = 'GrowAndShrink'
    $f.Margin = New-Pad 0 0 0 0
    return $f
}
function New-Row([System.Windows.Forms.Control[]]$ctrls) {
    $f = New-Flow 'LeftToRight'
    $f.Controls.AddRange($ctrls)
    $f.Margin = New-Pad 0 2 0 2
    return $f
}
function Set-EnterAction($tb, [scriptblock]$action) {
    $tb.Tag = $action
    $tb.Add_KeyDown({
        param($s, $e)
        if ($e.KeyCode -eq 'Enter') { $e.SuppressKeyPress = $true; & $s.Tag }
    })
}
function Show-Info([string]$m, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($form, $m, 'まとめてリネーム', 'OK', $icon)
}
function Show-Confirm([string]$m) {
    return ([System.Windows.Forms.MessageBox]::Show($form, $m, 'まとめてリネーム', 'OKCancel', 'Question') -eq 'OK')
}

# ---------------------------------------------------------------- アイコン
function New-RoundPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = [float]($r * 2)
    if ($d -gt $w) { $d = $w }
    if ($d -gt $h) { $d = $h }
    if ($d -lt 1) {
        $p.AddRectangle((New-Object System.Drawing.RectangleF($x, $y, $w, $h)))
        return $p
    }
    $p.AddArc($x, $y, $d, $d, [float]180, [float]90)
    $p.AddArc([float]($x + $w - $d), $y, $d, $d, [float]270, [float]90)
    $p.AddArc([float]($x + $w - $d), [float]($y + $h - $d), $d, $d, [float]0, [float]90)
    $p.AddArc($x, [float]($y + $h - $d), $d, $d, [float]90, [float]90)
    $p.CloseFigure()
    return $p
}

# ロゴ：青い角丸の中に「名前の入力欄」と黄色の文字カーソル（= rename）
function New-AppBitmap([int]$size) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.PixelOffsetMode = 'HighQuality'
    $g.TextRenderingHint = 'AntiAlias'
    $u = [float]$size

    # 背景（上から下へ青のグラデーション）
    $bg = New-RoundPath 0 0 ($u - 1) ($u - 1) ($u * 0.22)
    $p0 = New-Object System.Drawing.PointF([float]0, [float]0)
    $p1 = New-Object System.Drawing.PointF([float]0, [float]($u + 1))
    $lg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($p0, $p1, (Rgb 59 130 246), (Rgb 29 78 216))
    $g.FillPath($lg, $bg)

    # 白い入力欄
    $field = New-RoundPath ($u * 0.13) ($u * 0.35) ($u * 0.74) ($u * 0.30) ($u * 0.08)
    $g.FillPath([System.Drawing.Brushes]::White, $field)

    # 欄の中の文字（小さいサイズでは棒で表現）
    $dark = New-Object System.Drawing.SolidBrush((Rgb 30 58 138))
    if ($size -ge 32) {
        $f = New-Object System.Drawing.Font('Segoe UI', [float]($u * 0.25), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
        $sf = New-Object System.Drawing.StringFormat
        $sf.Alignment = 'Near'
        $sf.LineAlignment = 'Center'
        $rect = New-Object System.Drawing.RectangleF([float]($u * 0.17), [float]($u * 0.35), [float]($u * 0.45), [float]($u * 0.30))
        $g.DrawString('ab', $f, $dark, $rect, $sf)
        $f.Dispose()
    } else {
        $bar = New-RoundPath ($u * 0.21) ($u * 0.455) ($u * 0.34) ($u * 0.09) ($u * 0.03)
        $g.FillPath($dark, $bar)
    }

    # 黄色の文字カーソル（I）
    $amber = New-Object System.Drawing.SolidBrush((Rgb 251 191 36))
    $cx = [float]($u * 0.68)
    $cw = [float]([Math]::Max(1.5, $u * 0.065))
    $g.FillRectangle($amber, [float]($cx - $cw / 2), [float]($u * 0.22), $cw, [float]($u * 0.56))
    $capW = [float]($u * 0.18)
    $capH = [float]([Math]::Max(1.5, $u * 0.055))
    $g.FillPath($amber, (New-RoundPath ($cx - $capW / 2) ($u * 0.20) $capW $capH ($u * 0.02)))
    $g.FillPath($amber, (New-RoundPath ($cx - $capW / 2) ($u * 0.80 - $capH) $capW $capH ($u * 0.02)))

    $g.Dispose(); $lg.Dispose(); $dark.Dispose(); $amber.Dispose()
    return $bmp
}

# 複数サイズ入りの .ico を書き出す（16px でもくっきり）
function Save-Ico([string]$path, [int[]]$sizes = @(16, 20, 24, 32, 40, 48, 64, 256)) {
    $pngs = New-Object 'System.Collections.Generic.List[byte[]]'
    foreach ($sz in $sizes) {
        $b = New-AppBitmap $sz
        $ms = New-Object System.IO.MemoryStream
        $b.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
        $b.Dispose()
        $pngs.Add($ms.ToArray())
    }
    $fs = [System.IO.File]::Create($path)
    $bw = New-Object System.IO.BinaryWriter($fs)
    try {
        $bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$sizes.Count)
        $offset = 6 + 16 * $sizes.Count
        for ($i = 0; $i -lt $sizes.Count; $i++) {
            $dim = $(if ($sizes[$i] -ge 256) { 0 } else { $sizes[$i] })
            $bw.Write([byte]$dim); $bw.Write([byte]$dim); $bw.Write([byte]0); $bw.Write([byte]0)
            $bw.Write([uint16]1); $bw.Write([uint16]32)
            $bw.Write([uint32]$pngs[$i].Length); $bw.Write([uint32]$offset)
            $offset += $pngs[$i].Length
        }
        foreach ($png in $pngs) { $bw.Write($png) }
    } finally {
        $bw.Close()
    }
}
function Get-IconPath {
    $ico = Join-Path $script:SelfDir 'BulkRename-logo.ico'
    Save-Ico $ico
    return $ico
}
function Get-ShortcutPath { return (Join-Path ([Environment]::GetFolderPath('Desktop')) 'まとめてリネーム.lnk') }

# 既にデスクトップのショートカットがあれば、アイコンを新しいロゴに差し替える
function Update-ShortcutIcon {
    try {
        $lnkPath = Get-ShortcutPath
        if (-not (Test-Path -LiteralPath $lnkPath)) { return }
        $ico = Get-IconPath
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut($lnkPath)
        if ($lnk.IconLocation -ne ($ico + ',0')) {
            $lnk.IconLocation = $ico + ',0'
            $lnk.Save()
        }
    } catch {}
}

function New-DesktopShortcut {
    try { $ico = Get-IconPath } catch { $ico = $null }
    $ws = New-Object -ComObject WScript.Shell
    $lnkPath = Get-ShortcutPath
    $lnk = $ws.CreateShortcut($lnkPath)
    $lnk.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $lnk.Arguments = ('-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $script:SelfPath)
    $lnk.WorkingDirectory = $script:SelfDir
    $lnk.WindowStyle = 7
    $lnk.Description = 'ファイル名をまとめて変更'
    if ($ico) { $lnk.IconLocation = $ico + ',0' }
    $lnk.Save()
    Show-Info "デスクトップに「まとめてリネーム」のショートカットを作りました。`n`nファイルやフォルダをこのアイコンに直接ドロップしても起動できます。"
}

# ---------------------------------------------------------------- 名前まわりの処理
function Join-Name([string]$dir, [string]$name) {
    if ($dir.EndsWith('\')) { return $dir + $name }
    return $dir + '\' + $name
}

function Get-TargetRows {
    $sel = @($grid.SelectedRows)
    if ($sel.Count -ge 2) { return @($sel | Sort-Object Index) }
    return @($grid.Rows)
}

function Set-NewBase($row, [string]$value) {
    # 拡張子つきで入力・貼り付けされたら、拡張子部分は外す
    $ext = [string]$row.Cells[$script:iExt].Value
    if ($ext.Length -gt 0 -and $value.Length -gt $ext.Length -and $value.EndsWith($ext, [StringComparison]::OrdinalIgnoreCase)) {
        $value = $value.Substring(0, $value.Length - $ext.Length)
    }
    $row.Cells[$script:iNew].Value = $value
}

function Push-Undo {
    $snap = New-Object 'System.Collections.Generic.List[object]'
    foreach ($row in $grid.Rows) {
        $snap.Add([pscustomobject]@{ Row = $row; B = [string]$row.Cells[$script:iNew].Value; E = [string]$row.Cells[$script:iExt].Value })
    }
    $script:UndoList.Add($snap)
    if ($script:UndoList.Count -gt 200) { $script:UndoList.RemoveAt(0) }
    $btnUndo.Enabled = $true
}

function Undo-Edit {
    if ($script:UndoList.Count -eq 0) { return }
    [void]$grid.EndEdit()
    $snap = $script:UndoList[$script:UndoList.Count - 1]
    $script:UndoList.RemoveAt($script:UndoList.Count - 1)
    foreach ($s in $snap) {
        if ($s.Row.DataGridView) {
            $s.Row.Cells[$script:iNew].Value = $s.B
            $s.Row.Cells[$script:iExt].Value = $s.E
        }
    }
    $btnUndo.Enabled = ($script:UndoList.Count -gt 0)
    Update-Validation
}

# 自動連番：上から b-01, b-02 … と振る。手で書き換えた行はそのまま残す
function Get-AutoName([int]$i) {
    return [string]$txtAutoPrefix.Text + ([int]$numAutoStart.Value + $i).ToString().PadLeft([int]$numAutoDigits.Value, '0')
}
function Update-AutoNames {
    if (-not $chkAuto.Checked) { return }
    $i = 0
    foreach ($row in $grid.Rows) {
        $t = $row.Tag
        $cur = [string]$row.Cells[$script:iNew].Value
        if ($null -ne $t.AutoName -and $cur -ceq $t.AutoName) {
            $nm = Get-AutoName $i
            if ($cur -cne $nm) { $row.Cells[$script:iNew].Value = $nm }
            $t.AutoName = $nm
        }
        $i++
    }
}
function Update-AutoPreview {
    if ($chkAuto.Checked) {
        $lblAutoPreview.Text = ('→ {0}, {1}, {2} …' -f (Get-AutoName 0), (Get-AutoName 1), (Get-AutoName 2))
    } else {
        $lblAutoPreview.Text = '（オフ：元の名前のまま追加されます）'
    }
    foreach ($c in @($txtAutoPrefix, $numAutoDigits, $numAutoStart)) { $c.Enabled = $chkAuto.Checked }
}
function Set-AutoMode {
    [void]$grid.EndEdit()
    if ($chkAuto.Checked) {
        # 元の名前のまま（まだ手を付けていない）行に連番を振る
        foreach ($row in $grid.Rows) {
            $cur = [string]$row.Cells[$script:iNew].Value
            if ($cur -ceq $row.Tag.OrigBase -or ($null -ne $row.Tag.AutoName -and $cur -ceq $row.Tag.AutoName)) { $row.Tag.AutoName = $cur }
        }
        Update-AutoNames
    } else {
        # 自動で振った名前は元に戻す
        foreach ($row in $grid.Rows) {
            $t = $row.Tag
            if ($null -ne $t.AutoName -and [string]$row.Cells[$script:iNew].Value -ceq $t.AutoName) { $row.Cells[$script:iNew].Value = $t.OrigBase }
            $t.AutoName = $null
        }
    }
    Update-AutoPreview
    Update-Validation
}

# 「以下連番」：押した行の名前の末尾の数字から、下の行へ +1 ずつ振る
function Invoke-SeqFrom([int]$rowIndex) {
    [void]$grid.EndEdit()
    if ($rowIndex -lt 0 -or $rowIndex -ge $grid.Rows.Count) { return }
    $name = [string]$grid.Rows[$rowIndex].Cells[$script:iNew].Value
    $m = [regex]::Match($name, '^(.*?)(\d+)$')
    if ($m.Success) {
        $pre = $m.Groups[1].Value
        $n = [long]$m.Groups[2].Value
        $digits = $m.Groups[2].Value.Length
    } else {
        $pre = $name
        $n = [long]$numAutoStart.Value
        $digits = [int]$numAutoDigits.Value
    }
    Push-Undo
    for ($k = $rowIndex; $k -lt $grid.Rows.Count; $k++) {
        $grid.Rows[$k].Cells[$script:iNew].Value = $pre + ($n + ($k - $rowIndex)).ToString().PadLeft($digits, '0')
    }
    Update-Validation
}

function Update-Hint { $hint.Visible = ($grid.Rows.Count -eq 0) }

function Update-Scope {
    $n = $grid.SelectedRows.Count
    if ($n -ge 2) {
        $lblScope.Text = ('操作の対象：選択中の {0} 件' -f $n)
        $lblScope.ForeColor = $C.Accent
    } else {
        $lblScope.Text = '操作の対象：すべて（2件以上選ぶと選択分だけ）'
        $lblScope.ForeColor = $C.Muted
    }
}

function Update-Validation {
    if ($script:Busy) { return }
    $script:Busy = $true
    try {
        $rows = @($grid.Rows)
        $count = @{}
        $leaving = @{}
        foreach ($row in $rows) {
            $t = $row.Tag
            $new = [string]$row.Cells[$script:iNew].Value + [string]$row.Cells[$script:iExt].Value
            $orig = $t.OrigBase + $t.OrigExt
            $k = (Join-Name $t.Dir $new).ToLowerInvariant()
            $count[$k] = [int]$count[$k] + 1
            if ($new -cne $orig) { $leaving[(Join-Name $t.Dir $orig).ToLowerInvariant()] = $true }
        }
        $nOk = 0; $nErr = 0
        foreach ($row in $rows) {
            $t = $row.Tag
            $new = [string]$row.Cells[$script:iNew].Value + [string]$row.Cells[$script:iExt].Value
            $orig = $t.OrigBase + $t.OrigExt
            $target = Join-Name $t.Dir $new
            $kind = 2; $msg = ''
            if ($new -ceq $orig) { $kind = 0 }
            elseif ($new.Trim().Length -eq 0) { $msg = '× 名前が空です' }
            elseif ($new.IndexOfAny($script:BadChars) -ge 0) { $msg = '× 使えない文字があります  \ / : * ? " < > |' }
            elseif ($new -match '[. ]$') { $msg = '× 最後に「.」や空白は使えません' }
            elseif ($new.Length -gt 255) { $msg = '× 名前が長すぎます' }
            elseif ($new.Split('.')[0].Trim() -match '^(CON|PRN|AUX|NUL|COM\d|LPT\d)$') { $msg = '× Windows で使えない名前です' }
            elseif ($count[$target.ToLowerInvariant()] -gt 1) { $msg = '× 一覧の中で名前が重複しています' }
            elseif (($target -ne (Join-Name $t.Dir $orig)) -and -not $leaving.ContainsKey($target.ToLowerInvariant()) -and
                    ([System.IO.File]::Exists($target) -or [System.IO.Directory]::Exists($target))) {
                $msg = '× 同じ名前のファイルが既にあります'
            }
            else { $kind = 1; $msg = '変更します' }

            if ($kind -eq 1) { $nOk++ } elseif ($kind -eq 2) { $nErr++ }
            $t.Kind = $kind
            if ([string]$row.Cells[$script:iStatus].Value -cne $msg) { $row.Cells[$script:iStatus].Value = $msg }
        }
        $lblInfo.Text = ('全 {0} 件　／　変更 {1} 件　／　エラー {2} 件' -f $rows.Count, $nOk, $nErr)
        $lblInfo.ForeColor = $(if ($nErr -gt 0) { $C.ErrFore } else { [System.Drawing.Color]::Black })
        $btnRun.Enabled = ($nOk -gt 0)
        $grid.Invalidate()
    } finally {
        $script:Busy = $false
    }
}

function Add-Paths([string[]]$inPaths) {
    if (-not $inPaths) { return }
    [void]$grid.EndEdit()
    $known = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($row in $grid.Rows) { [void]$known.Add((Join-Name $row.Tag.Dir ($row.Tag.OrigBase + $row.Tag.OrigExt))) }

    $form.Cursor = 'WaitCursor'
    try {
        $found = New-Object 'System.Collections.Generic.List[object]'
        foreach ($p in $inPaths) {
            if ([string]::IsNullOrWhiteSpace($p)) { continue }
            $p = $p.Trim().Trim('"')
            if ([System.IO.Directory]::Exists($p)) {
                if ($chkExpand.Checked) {
                    $gci = @{ LiteralPath = $p; File = $true; ErrorAction = 'SilentlyContinue' }
                    if ($chkSub.Checked) { $gci.Recurse = $true }
                    foreach ($fi in @(Get-ChildItem @gci)) { $found.Add($fi) }
                } else {
                    $di = [System.IO.DirectoryInfo]::new($p)
                    if ($di.Parent) { $found.Add($di) }
                }
            } elseif ([System.IO.File]::Exists($p)) {
                $found.Add([System.IO.FileInfo]::new($p))
            }
        }

        $recs = New-Object 'System.Collections.Generic.List[object]'
        foreach ($it in $found) {
            if (-not $known.Add($it.FullName)) { continue }
            $isDir = $it -is [System.IO.DirectoryInfo]
            $dir = $(if ($isDir) { $it.Parent.FullName } else { $it.DirectoryName })
            $recs.Add([pscustomobject]@{ Dir = $dir; Name = $it.Name; IsDir = $isDir; Mtime = $it.LastWriteTime })
        }
        if ($recs.Count -eq 0) {
            if ($found.Count -eq 0) { Show-Info '追加できるファイルが見つかりませんでした。' }
            return
        }
        # 同じフォルダ内は Explorer と同じ自然順（1, 2, 10 …）で並べる
        $recs.Sort([System.Comparison[object]]{
            param($x, $y)
            $c = [BR.Native]::StrCmpLogicalW($x.Dir, $y.Dir)
            if ($c -ne 0) { return $c }
            return [BR.Native]::StrCmpLogicalW($x.Name, $y.Name)
        })

        $grid.SuspendLayout()
        foreach ($rec in $recs) {
            if ($rec.IsDir) {
                $base = $rec.Name; $ext = ''
            } else {
                $ext = [System.IO.Path]::GetExtension($rec.Name)
                $base = $rec.Name.Substring(0, $rec.Name.Length - $ext.Length)
            }
            $tag = [pscustomobject]@{ Dir = $rec.Dir; OrigBase = $base; OrigExt = $ext; IsDir = $rec.IsDir; Mtime = $rec.Mtime; Kind = 0; Row = $null; AutoName = $null }
            if ($chkAuto.Checked) { $tag.AutoName = $base }
            $idx = $grid.Rows.Add([object[]]@($null, $rec.Name, $base, $null, $ext, '', $rec.Dir, $rec.Mtime.Ticks))
            $row = $grid.Rows[$idx]
            $row.Tag = $tag
            $tag.Row = $row
            if ($rec.IsDir) { $row.Cells[$script:iExt].ReadOnly = $true }
            $script:AllTags.Add($tag)
        }
        $grid.ResumeLayout()
    } finally {
        $form.Cursor = 'Default'
    }
    Update-AutoNames
    Update-Hint
    Update-Validation
    Update-Scope
}

function Remove-SelectedRows {
    [void]$grid.EndEdit()
    $sel = @($grid.SelectedRows)
    if ($sel.Count -eq 0) { return }
    foreach ($r in $sel) { $grid.Rows.Remove($r) }
    Update-AutoNames
    Update-Hint; Update-Validation; Update-Scope
}

function Clear-Rows {
    if ($grid.Rows.Count -eq 0) { return }
    [void]$grid.EndEdit()
    $grid.Rows.Clear()
    $script:UndoList.Clear(); $btnUndo.Enabled = $false
    Update-Hint; Update-Validation; Update-Scope
}

function Clear-SortGlyph {
    foreach ($col in $grid.Columns) { $col.HeaderCell.SortGlyphDirection = 'None' }
}

function Move-Selected([int]$delta) {
    [void]$grid.EndEdit()
    $idxs = @($grid.SelectedRows | ForEach-Object { $_.Index } | Sort-Object)
    if ($idxs.Count -eq 0) { return }
    if ($delta -gt 0) { [array]::Reverse($idxs) }
    $last = $grid.Rows.Count - 1
    $newSel = New-Object 'System.Collections.Generic.HashSet[int]'
    foreach ($i in $idxs) {
        $j = $i + $delta
        if ($j -lt 0 -or $j -gt $last -or $newSel.Contains($j)) { [void]$newSel.Add($i); continue }
        $row = $grid.Rows[$i]
        $grid.Rows.RemoveAt($i)
        $grid.Rows.Insert($j, $row)
        [void]$newSel.Add($j)
    }
    Clear-SortGlyph
    $first = ($newSel | Sort-Object)[0]
    $grid.CurrentCell = $grid.Rows[$first].Cells[$script:iNew]
    $grid.ClearSelection()
    foreach ($i in $newSel) { $grid.Rows[$i].Selected = $true }
    Update-AutoNames
    Update-Validation
    Update-Scope
}

function Sort-Rows([int]$mode) {
    [void]$grid.EndEdit()
    if ($grid.Rows.Count -lt 2) { return }
    $grid.Sort((New-Object BR.RowComparer($mode)))
    Clear-SortGlyph
    Update-AutoNames
    Update-Validation
}

# 対象の行に処理をかける（元に戻せるよう事前に記録）
function Invoke-RowOp([scriptblock]$fn) {
    [void]$grid.EndEdit()
    $targets = @(Get-TargetRows)
    if ($targets.Count -eq 0) { Show-Info '先にファイルを追加してください。'; return }
    Push-Undo
    $idx = 0
    foreach ($tr in $targets) { & $fn $tr $idx; $idx++ }
    Update-Validation
}
function Invoke-NameOp([scriptblock]$nameFn) {
    Invoke-RowOp {
        param($row, $i)
        $row.Cells[$script:iNew].Value = [string](& $nameFn $row ([string]$row.Cells[$script:iNew].Value) $i)
    }
}

function Convert-ToHalfWidth([string]$s) {
    $sb = New-Object System.Text.StringBuilder $s.Length
    foreach ($ch in $s.ToCharArray()) {
        $code = [int]$ch
        if ($code -ge 0xFF01 -and $code -le 0xFF5E) {
            $h = [char]($code - 0xFEE0)
            if ('\/:*?"<>|'.IndexOf($h) -ge 0) { [void]$sb.Append($ch) } else { [void]$sb.Append($h) }
        } elseif ($code -eq 0x3000) {
            [void]$sb.Append(' ')
        } else {
            [void]$sb.Append($ch)
        }
    }
    return $sb.ToString()
}

function Invoke-Paste {
    $txt = [System.Windows.Forms.Clipboard]::GetText()
    if ([string]::IsNullOrEmpty($txt)) { return }
    $lines = @($txt -split "`r?`n")
    if ($lines.Count -gt 1 -and $lines[-1] -eq '') { $lines = @($lines[0..($lines.Count - 2)]) }
    $sel = @($grid.SelectedRows | Sort-Object Index)
    if ($sel.Count -ge 2) {
        $targets = $sel
    } else {
        $start = 0
        if ($grid.CurrentCell) { $start = $grid.CurrentCell.RowIndex }
        $targets = @(for ($k = $start; $k -lt $grid.Rows.Count; $k++) { $grid.Rows[$k] })
    }
    if ($targets.Count -eq 0) { return }
    Push-Undo
    for ($k = 0; $k -lt $lines.Count -and $k -lt $targets.Count; $k++) {
        Set-NewBase $targets[$k] (($lines[$k] -split "`t")[0])
    }
    Update-Validation
}

function Show-TextEditor {
    [void]$grid.EndEdit()
    $targets = @(Get-TargetRows)
    if ($targets.Count -eq 0) { Show-Info '先にファイルを追加してください。'; return }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'テキストでまとめて編集'
    $dlg.Font = $script:UIFont
    $dlg.ClientSize = New-Size 640 540
    $dlg.MinimumSize = New-Size 420 300
    $dlg.StartPosition = 'CenterParent'
    $dlg.MinimizeBox = $false
    $dlg.ShowInTaskbar = $false
    $dlg.Icon = $form.Icon

    $top = New-Object System.Windows.Forms.Label
    $top.Dock = 'Top'
    $top.AutoSize = $false
    $top.Height = Px 58
    $top.Padding = New-Pad 10 8 10 0
    $top.Text = ("1行 ＝ 1ファイルの新しい名前です（拡張子は含みません）。対象 {0} 件。`n行の数と順番はそのままで書き換えてください。Excel やメモ帳とのコピペにも使えます。" -f $targets.Count)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Multiline = $true
    $tb.ScrollBars = 'Both'
    $tb.WordWrap = $false
    $tb.AcceptsReturn = $true
    $tb.MaxLength = 0
    $tb.Dock = 'Fill'
    $tb.Font = New-Object System.Drawing.Font($script:UIFont.FontFamily, 11)
    $tb.Text = (@($targets | ForEach-Object { [string]$_.Cells[$script:iNew].Value }) -join "`r`n")

    $bar = New-Object System.Windows.Forms.FlowLayoutPanel
    $bar.Dock = 'Bottom'
    $bar.FlowDirection = 'RightToLeft'
    $bar.AutoSize = $true
    $bar.Padding = New-Pad 10 8 10 8
    $ok = New-Button 'この内容で反映' $null
    $ok.Font = $script:BoldFont
    $cancel = New-Button 'キャンセル' $null
    $cancel.DialogResult = 'Cancel'
    $bar.Controls.Add($ok)
    $bar.Controls.Add($cancel)
    $dlg.CancelButton = $cancel

    $script:EditLines = $null
    $ok.Add_Click({
        $lines = @($tb.Text -split "`r?`n")
        if ($lines.Count -eq $targets.Count + 1 -and $lines[-1] -eq '') { $lines = @($lines[0..($lines.Count - 2)]) }
        if ($lines.Count -ne $targets.Count) {
            [void][System.Windows.Forms.MessageBox]::Show($dlg, ("行の数が合いません。`n今 {0} 行 ／ 対象 {1} 件" -f $lines.Count, $targets.Count), 'まとめてリネーム', 'OK', 'Warning')
            return
        }
        $script:EditLines = $lines
        $dlg.DialogResult = 'OK'
    })

    $dlg.Controls.Add($tb)
    $dlg.Controls.Add($bar)
    $dlg.Controls.Add($top)
    $tb.Select(0, 0)

    if ($dlg.ShowDialog($form) -eq 'OK' -and $null -ne $script:EditLines) {
        Push-Undo
        for ($k = 0; $k -lt $targets.Count; $k++) { Set-NewBase $targets[$k] $script:EditLines[$k] }
        Update-Validation
    }
    $dlg.Dispose()
}

# ---------------------------------------------------------------- 実際のリネーム
function Move-Path([string]$src, [string]$dst, [bool]$isDir) {
    if ($isDir) { [System.IO.Directory]::Move($src, $dst) } else { [System.IO.File]::Move($src, $dst) }
}

function Update-DirPrefix([string]$old, [string]$new) {
    foreach ($t in $script:AllTags) {
        if ($t.Dir -eq $old) { $nd = $new }
        elseif ($t.Dir.StartsWith($old + '\', [StringComparison]::OrdinalIgnoreCase)) { $nd = $new + $t.Dir.Substring($old.Length) }
        else { continue }
        $t.Dir = $nd
        if ($t.Row -and $t.Row.DataGridView) { $t.Row.Cells[$script:iDir].Value = $nd }
    }
}

function Invoke-RenameGroup($ops) {
    if (-not $ops -or $ops.Count -eq 0) { return }
    $dstSet = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($op in $ops) {
        $op.Src = Join-Name $op.Tag.Dir ($op.Tag.OrigBase + $op.Tag.OrigExt)
        $op.Dst = Join-Name $op.Tag.Dir ($op.ToBase + $op.ToExt)
        [void]$dstSet.Add($op.Dst)
    }
    # 1) 他のファイルの「行き先」になっているものは、いったん仮の名前へ（入れ替え・大文字小文字だけの変更に対応）
    foreach ($op in $ops) {
        if ($dstSet.Contains($op.Src)) {
            $tmp = Join-Name $op.Tag.Dir ('~rn_' + [guid]::NewGuid().ToString('N').Substring(0, 12) + '.tmp')
            try { Move-Path $op.Src $tmp $op.Tag.IsDir; $op.Tmp = $tmp }
            catch { $op.Error = $_.Exception.GetBaseException().Message }
        }
    }
    # 2) 新しい名前へ
    foreach ($op in $ops) {
        if ($op.Error) { continue }
        $from = $(if ($op.Tmp) { $op.Tmp } else { $op.Src })
        try {
            Move-Path $from $op.Dst $op.Tag.IsDir
            $op.Done = $true
        } catch {
            $op.Error = $_.Exception.GetBaseException().Message
            if ($op.Tmp) {
                try { Move-Path $op.Tmp $op.Src $op.Tag.IsDir }
                catch { $op.Error += ('（仮の名前 {0} のまま残っています）' -f (Split-Path -Leaf $op.Tmp)) }
            }
        }
    }
    # 3) 一覧を新しい状態に更新
    foreach ($op in $ops) {
        if (-not $op.Done) { continue }
        $op.Tag.OrigBase = $op.ToBase
        $op.Tag.OrigExt = $op.ToExt
        $r = $op.Tag.Row
        if ($r -and $r.DataGridView) {
            $r.Cells[$script:iOrig].Value = $op.ToBase + $op.ToExt
            $r.Cells[$script:iNew].Value = $op.ToBase
            $r.Cells[$script:iExt].Value = $op.ToExt
        }
        if ($op.Tag.IsDir) { Update-DirPrefix $op.Src $op.Dst }
    }
}

function Invoke-RenameAll($ops) {
    $files = @($ops | Where-Object { -not $_.Tag.IsDir })
    $dirs = @($ops | Where-Object { $_.Tag.IsDir } | Sort-Object -Descending -Property @{ Expression = { $_.Tag.Dir.Length + $_.Tag.OrigBase.Length } })
    Invoke-RenameGroup $files
    # フォルダは深いものから 1 つずつ
    foreach ($d in $dirs) { Invoke-RenameGroup @($d) }
}

function New-Op($tag, [string]$toBase, [string]$toExt) {
    return [pscustomobject]@{
        Tag = $tag; ToBase = $toBase; ToExt = $toExt
        FromBase = $tag.OrigBase; FromExt = $tag.OrigExt
        Src = $null; Dst = $null; Tmp = $null; Done = $false; Error = $null
    }
}

function Show-Result($ops, [string]$okFormat) {
    $done = @($ops | Where-Object { $_.Done }).Count
    $fail = @($ops | Where-Object { -not $_.Done })
    if ($fail.Count -eq 0) {
        Show-Info ($okFormat -f $done)
        return
    }
    $lines = @($fail | Select-Object -First 10 | ForEach-Object { '・{0}：{1}' -f ($_.FromBase + $_.FromExt), $_.Error })
    $more = $(if ($fail.Count -gt 10) { "`n…ほか {0} 件" -f ($fail.Count - 10) } else { '' })
    Show-Info (("{0}`n`nうまくいかなかったもの {1} 件：`n" -f ($okFormat -f $done), $fail.Count) + ($lines -join "`n") + $more) 'Warning'
}

function Invoke-Run {
    [void]$grid.EndEdit()
    Update-Validation
    $rows = @($grid.Rows)
    $ok = @($rows | Where-Object { $_.Tag.Kind -eq 1 })
    $bad = @($rows | Where-Object { $_.Tag.Kind -eq 2 })
    if ($ok.Count -eq 0) { Show-Info '名前が変わるファイルがありません。'; return }
    $msg = ('{0} 件の名前を変更します。よろしいですか？' -f $ok.Count)
    if ($bad.Count -gt 0) { $msg = ('エラーのある {0} 件は変更せずにスキップします。' -f $bad.Count) + "`n`n" + $msg }
    if (-not (Show-Confirm $msg)) { return }

    $ops = @(foreach ($r in $ok) { New-Op $r.Tag ([string]$r.Cells[$script:iNew].Value) ([string]$r.Cells[$script:iExt].Value) })
    $form.Cursor = 'WaitCursor'
    try { Invoke-RenameAll $ops } finally { $form.Cursor = 'Default' }

    $script:LastBatch = @($ops | Where-Object { $_.Done } | ForEach-Object { [pscustomobject]@{ Tag = $_.Tag; Base = $_.FromBase; Ext = $_.FromExt } })
    $btnRevert.Enabled = ($script:LastBatch.Count -gt 0)
    $script:UndoList.Clear(); $btnUndo.Enabled = $false
    Update-Validation
    Show-Result $ops '{0} 件の名前を変更しました。'
}

function Invoke-Revert {
    if (-not $script:LastBatch -or $script:LastBatch.Count -eq 0) { return }
    if (-not (Show-Confirm ('直前に変更した {0} 件を、元の名前に戻しますか？' -f $script:LastBatch.Count))) { return }
    [void]$grid.EndEdit()
    $ops = @(foreach ($h in $script:LastBatch) { New-Op $h.Tag $h.Base $h.Ext })
    $form.Cursor = 'WaitCursor'
    try { Invoke-RenameAll $ops } finally { $form.Cursor = 'Default' }
    $script:LastBatch = @()
    $btnRevert.Enabled = $false
    $script:UndoList.Clear(); $btnUndo.Enabled = $false
    Update-Validation
    Show-Result $ops '{0} 件を元の名前に戻しました。'
}

# ---------------------------------------------------------------- 編集操作（右側パネルのボタン）
$applyReplace = {
    $find = $txtFind.Text
    if ($find -eq '') { Show-Info '「探す文字」を入力してください。'; return }
    $opt = [System.Text.RegularExpressions.RegexOptions]::None
    if (-not $chkCase.Checked) { $opt = [System.Text.RegularExpressions.RegexOptions]::IgnoreCase }
    if ($chkRegex.Checked) {
        try { $rx = [regex]::new($find, $opt) }
        catch { Show-Info ("正規表現の書き方が正しくありません。`n`n" + $_.Exception.GetBaseException().Message) 'Warning'; return }
        $rp = $txtRepl.Text
    } else {
        $rx = [regex]::new([regex]::Escape($find), $opt)
        $rp = $txtRepl.Text.Replace('$', '$$')
    }
    Invoke-NameOp { param($row, $base, $i) $rx.Replace($base, $rp) }
}

$applyAdd = {
    $pre = $txtPrefix.Text; $suf = $txtSuffix.Text
    if ($pre -eq '' -and $suf -eq '') { Show-Info '付ける文字を入力してください。'; return }
    Invoke-NameOp { param($row, $base, $i) $pre + $base + $suf }
}

$applyInsert = {
    $ins = $txtInsert.Text
    if ($ins -eq '') { Show-Info '挿入する文字を入力してください。'; return }
    $pos = [int]$numPos.Value
    $fromEnd = $chkFromEnd.Checked
    Invoke-NameOp {
        param($row, $base, $i)
        if ($fromEnd) { $p = [Math]::Max(0, $base.Length - $pos) } else { $p = [Math]::Min($pos, $base.Length) }
        $base.Insert($p, $ins)
    }
}

$applyNumber = {
    $tpl = $cmbTpl.Text
    if ($tpl -eq '') { Show-Info '書式を入力してください。例：{name}_{n}'; return }
    if ($tpl -notmatch '\{n\}') {
        if (-not (Show-Confirm '書式に {n}（番号）が入っていません。このまま適用しますか？')) { return }
    }
    $start = [int]$numStart.Value
    $digits = [int]$numDigits.Value
    $step = [int]$numStep.Value
    $perFolder = $chkPerFolder.Checked
    $ctr = @{}
    Invoke-NameOp {
        param($row, $base, $i)
        $t = $row.Tag
        if ($perFolder) {
            $key = $t.Dir.ToLowerInvariant()
            $c = [int]$ctr[$key]
            $ctr[$key] = $c + 1
        } else { $c = $i }
        $num = $start + $c * $step
        $ns = ([Math]::Abs($num)).ToString().PadLeft($digits, '0')
        if ($num -lt 0) { $ns = '-' + $ns }
        $folder = Split-Path -Leaf $t.Dir
        $tpl.Replace('{n}', $ns).Replace('{orig}', $t.OrigBase).Replace('{folder}', $folder).Replace('{date}', $t.Mtime.ToString('yyyyMMdd')).Replace('{name}', $base)
    }
}

$opCutHead = {
    $n = [int]$numCutHead.Value
    Invoke-NameOp { param($row, $base, $i) if ($n -ge $base.Length) { '' } else { $base.Substring($n) } }
}
$opCutTail = {
    $n = [int]$numCutTail.Value
    Invoke-NameOp { param($row, $base, $i) if ($n -ge $base.Length) { '' } else { $base.Substring(0, $base.Length - $n) } }
}
$opHalf      = { Invoke-NameOp { param($row, $base, $i) Convert-ToHalfWidth $base } }
$opSpaceToUs = { Invoke-NameOp { param($row, $base, $i) $base -replace '[ 　]+', '_' } }
$opTidy      = { Invoke-NameOp { param($row, $base, $i) ($base -replace '[ 　]+', ' ').Trim() } }
$opBrackets  = { Invoke-NameOp { param($row, $base, $i) ($base -replace '\s*[\(\[（【［][^\)\]）】］]*[\)\]）】］]', '').Trim() } }
$opUpper     = { Invoke-NameOp { param($row, $base, $i) $base.ToUpperInvariant() } }
$opLower     = { Invoke-NameOp { param($row, $base, $i) $base.ToLowerInvariant() } }
$opExtLower  = { Invoke-RowOp { param($row, $i) $row.Cells[$script:iExt].Value = ([string]$row.Cells[$script:iExt].Value).ToLowerInvariant() } }
$opRestore   = {
    Invoke-RowOp {
        param($row, $i)
        $row.Cells[$script:iNew].Value = $row.Tag.OrigBase
        $row.Cells[$script:iExt].Value = $row.Tag.OrigExt
    }
}
$addFiles = {
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Multiselect = $true
    $dlg.Title = '名前を変えたいファイルを選ぶ（複数選択できます）'
    if ($dlg.ShowDialog($form) -eq 'OK') { Add-Paths $dlg.FileNames }
}
$addFolder = {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'このフォルダの中のファイルを一覧に追加します'
    if ($dlg.ShowDialog($form) -eq 'OK') { Add-Paths @($dlg.SelectedPath) }
}

# ---------------------------------------------------------------- 画面
$form = New-Object System.Windows.Forms.Form
$form.Text = 'まとめてリネーム'
$form.Font = $script:UIFont
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.ClientSize = New-Object System.Drawing.Size([Math]::Min((Px 1200), [int]($wa.Width * 0.94)), [Math]::Min((Px 720), [int]($wa.Height * 0.9)))
$form.MinimumSize = New-Size 900 520
$form.StartPosition = 'CenterScreen'
$form.AllowDrop = $true
$form.KeyPreview = $true
try { $form.Icon = [System.Drawing.Icon]::FromHandle((New-AppBitmap 32).GetHicon()) } catch {}

$tip = New-Object System.Windows.Forms.ToolTip

# --- 一覧
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.AllowDrop = $true
$grid.RowHeadersVisible = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $true
$grid.EditMode = 'EditOnKeystrokeOrF2'
$grid.BackgroundColor = [System.Drawing.Color]::White
$grid.BorderStyle = 'FixedSingle'
$grid.CellBorderStyle = 'SingleHorizontal'
$grid.GridColor = Rgb 232 232 232
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersDefaultCellStyle.BackColor = $C.Head
$grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = $C.Head
$grid.ColumnHeadersDefaultCellStyle.Font = $script:BoldFont
$grid.ColumnHeadersDefaultCellStyle.Padding = New-Pad 4 0 0 0
$grid.ColumnHeadersHeightSizeMode = 'DisableResizing'
$grid.ColumnHeadersHeight = Px 32
$grid.RowTemplate.Height = Px 28
$grid.DefaultCellStyle.SelectionBackColor = $C.Sel
$grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::Black
$grid.DefaultCellStyle.Padding = New-Pad 3 0 3 0

function Add-Col([string]$name, [string]$header, [bool]$ro, [double]$fill, [int]$width) {
    $c = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $c.Name = $name
    $c.HeaderText = $header
    $c.ReadOnly = $ro
    if ($fill -gt 0) { $c.AutoSizeMode = 'Fill'; $c.FillWeight = $fill; $c.MinimumWidth = Px 80 }
    else { $c.Width = Px $width }
    $c.SortMode = 'Automatic'
    [void]$grid.Columns.Add($c)
    return $c
}
$colNo = Add-Col 'No' '#' $true 0 46
$colNo.SortMode = 'NotSortable'
$colNo.DefaultCellStyle.Alignment = 'MiddleRight'
$colNo.DefaultCellStyle.ForeColor = $C.Muted
$colOrig = Add-Col 'Orig' '元の名前' $true 34 0
$colOrig.DefaultCellStyle.ForeColor = Rgb 85 85 85
$colNew = Add-Col 'NewBase' '新しい名前（クリックで編集）' $false 38 0
$colNew.DefaultCellStyle.BackColor = $C.NewBack
$colNew.DefaultCellStyle.DataSourceNullValue = ''
$colSeq = New-Object System.Windows.Forms.DataGridViewButtonColumn
$colSeq.Name = 'Seq'
$colSeq.HeaderText = ''
$colSeq.Text = '以下連番'
$colSeq.UseColumnTextForButtonValue = $true
$colSeq.Width = Px 84
$colSeq.SortMode = 'NotSortable'
$colSeq.ReadOnly = $true
$colSeq.FlatStyle = 'System'
$colSeq.ToolTipText = 'この行から下を連番にします（この行の名前の番号から +1 ずつ。例：b-05 → b-06, b-07 …）'
[void]$grid.Columns.Add($colSeq)
$colExt = Add-Col 'NewExt' '拡張子' $false 0 78
$colExt.DefaultCellStyle.BackColor = $C.NewBack
$colExt.DefaultCellStyle.DataSourceNullValue = ''
$colStatus = Add-Col 'Status' '状態' $true 0 200
$colDir = Add-Col 'Dir' 'フォルダ' $true 26 0
$colDir.DefaultCellStyle.ForeColor = $C.Muted
$colMtime = Add-Col 'Mtime' 'mtime' $true 0 10
$colMtime.Visible = $false

$script:iNo = $colNo.Index; $script:iOrig = $colOrig.Index; $script:iNew = $colNew.Index
$script:iExt = $colExt.Index; $script:iStatus = $colStatus.Index; $script:iDir = $colDir.Index; $script:iSeq = $colSeq.Index

$grid.Add_CellFormatting({
    param($s, $e)
    if ($e.RowIndex -lt 0) { return }
    if ($e.ColumnIndex -eq $script:iNo) {
        $e.Value = ($e.RowIndex + 1).ToString()
        $e.FormattingApplied = $true
        return
    }
    $t = $grid.Rows[$e.RowIndex].Tag
    if ($null -eq $t) { return }
    $ci = $e.ColumnIndex
    if ($t.Kind -eq 2) {
        $e.CellStyle.BackColor = $C.ErrBack
        $e.CellStyle.SelectionBackColor = $C.ErrSel
        if ($ci -eq $script:iStatus) { $e.CellStyle.ForeColor = $C.ErrFore; $e.CellStyle.SelectionForeColor = $C.ErrFore }
    } elseif ($t.Kind -eq 1) {
        if ($ci -eq $script:iNew -or $ci -eq $script:iExt -or $ci -eq $script:iStatus) {
            $e.CellStyle.BackColor = $C.OkBack
            $e.CellStyle.SelectionBackColor = $C.OkSel
        }
        if ($ci -eq $script:iStatus) { $e.CellStyle.ForeColor = $C.OkFore; $e.CellStyle.SelectionForeColor = $C.OkFore }
        if ($ci -eq $script:iNew) { $e.CellStyle.Font = $script:BoldFont }
    }
})
$grid.Add_SortCompare({
    param($s, $e)
    $e.SortResult = [BR.Native]::StrCmpLogicalW([string]$e.CellValue1, [string]$e.CellValue2)
    $e.Handled = $true
})
$grid.Add_CellBeginEdit({
    param($s, $e)
    $script:EditBefore = [string]$grid.Rows[$e.RowIndex].Cells[$e.ColumnIndex].Value
    Push-Undo
})
$grid.Add_CellEndEdit({
    param($s, $e)
    $row = $grid.Rows[$e.RowIndex]
    $cell = $row.Cells[$e.ColumnIndex]
    $v = [string]$cell.Value
    if ($e.ColumnIndex -eq $script:iNew) {
        Set-NewBase $row $v
    } elseif ($e.ColumnIndex -eq $script:iExt) {
        $v = $v.Trim()
        if ($v -ne '' -and -not $v.StartsWith('.')) { $v = '.' + $v }
        $cell.Value = $v
    }
    # 何も変わらなかった編集は「元に戻す」の履歴に残さない
    if ([string]$cell.Value -ceq $script:EditBefore -and $script:UndoList.Count -gt 0) {
        $script:UndoList.RemoveAt($script:UndoList.Count - 1)
        $btnUndo.Enabled = ($script:UndoList.Count -gt 0)
    }
    $script:JustEdited = ($e.ColumnIndex -eq $script:iNew)
    $script:JustEditedRow = $e.RowIndex
    Update-Validation
})
$grid.Add_CellDoubleClick({
    param($s, $e)
    if ($e.ColumnIndex -lt 0) { return }
    if ($e.RowIndex -ge 0 -and -not $grid.Rows[$e.RowIndex].Cells[$e.ColumnIndex].ReadOnly) { [void]$grid.BeginEdit($true) }
    elseif ($e.RowIndex -ge 0) {
        $grid.CurrentCell = $grid.Rows[$e.RowIndex].Cells[$script:iNew]
        [void]$grid.BeginEdit($true)
    }
})
# 新しい名前・拡張子は 1 クリックで編集開始
$grid.Add_CellClick({
    param($s, $e)
    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
    if ($e.ColumnIndex -ne $script:iNew -and $e.ColumnIndex -ne $script:iExt) { return }
    if ([System.Windows.Forms.Control]::ModifierKeys -ne [System.Windows.Forms.Keys]::None) { return }
    $cell = $grid.Rows[$e.RowIndex].Cells[$e.ColumnIndex]
    if ($cell.ReadOnly -or $grid.IsCurrentCellInEditMode) { return }
    $grid.CurrentCell = $cell
    [void]$grid.BeginEdit($true)
})
$grid.Add_CellContentClick({
    param($s, $e)
    if ($e.RowIndex -ge 0 -and $e.ColumnIndex -eq $script:iSeq) { Invoke-SeqFrom $e.RowIndex }
})
$grid.Add_CellMouseEnter({
    param($s, $e)
    if ($e.RowIndex -ge 0 -and ($e.ColumnIndex -eq $script:iNew -or $e.ColumnIndex -eq $script:iExt)) { $grid.Cursor = 'IBeam' } else { $grid.Cursor = 'Default' }
})
$grid.Add_CellMouseLeave({ $grid.Cursor = 'Default' })
# 編集中に Enter → 次の行の名前をそのまま編集
$grid.Add_KeyUp({
    param($s, $e)
    if ($e.KeyCode -eq 'Enter' -and $script:JustEdited -and -not $grid.IsCurrentCellInEditMode -and $grid.CurrentCell -and $grid.CurrentCell.ColumnIndex -eq $script:iNew -and $grid.CurrentCell.RowIndex -ne $script:JustEditedRow) {
        $script:JustEdited = $false
        [void]$grid.BeginEdit($true)
    }
    $script:JustEdited = $false
})
$grid.Add_Sorted({ Update-AutoNames; Update-Validation })
$grid.Add_DataError({ param($s, $e) $e.ThrowException = $false })
$grid.Add_SelectionChanged({ Update-Scope })
$grid.Add_KeyDown({
    param($s, $e)
    if ($grid.IsCurrentCellInEditMode) { return }
    if ($e.KeyCode -eq 'Delete') { Remove-SelectedRows; $e.Handled = $true }
    elseif ($e.Control -and $e.KeyCode -eq 'V') { Invoke-Paste; $e.Handled = $true }
})

# --- ドロップ案内
$hint = New-Object System.Windows.Forms.Label
$hint.Dock = 'Fill'
$hint.TextAlign = 'MiddleCenter'
$hint.Font = $script:BigFont
$hint.ForeColor = Rgb 140 140 140
$hint.BackColor = $C.Hint
$hint.AllowDrop = $true
$hint.Cursor = 'Hand'
$hint.Text = "ここにファイルやフォルダをドラッグ＆ドロップ`n`n（クリックしてファイルを選ぶこともできます）"
$hint.Add_Paint({
    param($s, $e)
    $pen = New-Object System.Drawing.Pen((Rgb 190 196 206), [float](Px 2))
    $pen.DashStyle = 'Dash'
    $m = Px 14
    $e.Graphics.DrawRectangle($pen, $m, $m, $s.Width - $m * 2 - 1, $s.Height - $m * 2 - 1)
    $pen.Dispose()
})
$hint.Add_Click($addFiles)

$onDragEnter = {
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::Copy
        $hint.BackColor = $C.HintOver
    } else {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::None
    }
}
$onDragLeave = { $hint.BackColor = $C.Hint }
$onDragDrop = {
    param($s, $e)
    $hint.BackColor = $C.Hint
    $dropped = $e.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
    if ($dropped) {
        $form.Activate()
        Add-Paths ([string[]]$dropped)
    }
}
foreach ($ctl in @($form, $grid, $hint)) {
    $ctl.Add_DragEnter($onDragEnter)
    $ctl.Add_DragLeave($onDragLeave)
    $ctl.Add_DragDrop($onDragDrop)
}

# --- 一覧の上：自動連番の設定
$autoBar = New-Object System.Windows.Forms.FlowLayoutPanel
$autoBar.Dock = 'Top'
$autoBar.AutoSize = $true
$autoBar.AutoSizeMode = 'GrowAndShrink'
$autoBar.WrapContents = $false
$autoBar.Padding = New-Pad 8 4 8 2
$autoBar.Margin = New-Pad 0 0 0 0
$autoBar.BackColor = Rgb 239 246 255
$chkAuto = New-Check '追加したら自動で連番をつける' ([bool]$script:Settings.AutoNumber)
$chkAuto.Font = $script:BoldFont
$chkAuto.Margin = New-Pad 0 5 14 0
$txtAutoPrefix = New-Object System.Windows.Forms.TextBox
$txtAutoPrefix.Width = Px 70
$txtAutoPrefix.Text = [string]$script:Settings.Prefix
$txtAutoPrefix.Margin = New-Pad 0 2 10 2
$numAutoDigits = New-Num 1 6 ([int]$script:Settings.Digits) 48
$numAutoStart = New-Num 0 99999 ([int]$script:Settings.Start) 64
$lblAutoPreview = New-InlineLabel ''
$lblAutoPreview.ForeColor = $C.Accent
$lblAutoPreview.Margin = New-Pad 6 6 0 0
$autoBar.Controls.AddRange([System.Windows.Forms.Control[]]@(
    $chkAuto, (New-InlineLabel '頭の文字'), $txtAutoPrefix, (New-InlineLabel '桁数'), $numAutoDigits,
    (New-InlineLabel '開始'), $numAutoStart, $lblAutoPreview
))
$tip.SetToolTip($chkAuto, '上から順に b-01, b-02 … と名前を振ります。手で書き換えた行はそのまま残ります。')
$onAutoSetting = { Update-AutoPreview; Update-AutoNames; Update-Validation }
$txtAutoPrefix.Add_TextChanged($onAutoSetting)
$numAutoDigits.Add_ValueChanged($onAutoSetting)
$numAutoStart.Add_ValueChanged($onAutoSetting)
$chkAuto.Add_CheckedChanged({ Set-AutoMode })
$autoSpacer = New-Object System.Windows.Forms.Panel
$autoSpacer.Dock = 'Top'
$autoSpacer.Height = Px 6

$panelMain = New-Object System.Windows.Forms.Panel
$panelMain.Dock = 'Fill'
$panelMain.Padding = New-Pad 10 2 6 0
$panelMain.Controls.Add($grid)
$panelMain.Controls.Add($hint)
$panelMain.Controls.Add($autoSpacer)
$panelMain.Controls.Add($autoBar)
$hint.BringToFront()

# --- 右側：編集パネル
$panelRight = New-Object System.Windows.Forms.Panel
$panelRight.Dock = 'Right'
$panelRight.Width = Px 360
$panelRight.Padding = New-Pad 4 0 10 0

$lblScope = New-Object System.Windows.Forms.Label
$lblScope.Dock = 'Top'
$lblScope.AutoSize = $false
$lblScope.Height = Px 26
$lblScope.TextAlign = 'MiddleLeft'

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'Fill'
$tabs.Padding = New-Object System.Drawing.Point((Px 10), (Px 4))

function New-Page([string]$title) {
    $p = New-Object System.Windows.Forms.TabPage
    $p.Text = $title
    $p.Padding = New-Pad 10 4 6 6
    $p.UseVisualStyleBackColor = $true
    $f = New-Flow 'TopDown'
    $f.Dock = 'Fill'
    $f.AutoSize = $false
    $f.AutoScroll = $true
    $p.Controls.Add($f)
    $tabs.TabPages.Add($p)
    return $f
}

# 置換
$pg = New-Page '置換'
$pg.Controls.Add((New-Label '探す文字'))
$txtFind = New-TextBox; $pg.Controls.Add($txtFind)
$pg.Controls.Add((New-Label '置き換える文字（空欄なら「削除」になります）'))
$txtRepl = New-TextBox; $pg.Controls.Add($txtRepl)
$chkCase = New-Check '大文字・小文字を区別する'; $pg.Controls.Add($chkCase)
$chkRegex = New-Check '正規表現を使う（上級者向け）'; $pg.Controls.Add($chkRegex)
$b = New-Button '置換する' $applyReplace; $b.Font = $script:BoldFont; $b.Margin = New-Pad 0 8 0 6; $pg.Controls.Add($b)
$pg.Controls.Add((New-Label "例）「IMG_」→「旅行_」`n例）「 - コピー」→ 空欄 で削除`n`n※ 拡張子は変わりません。入力後に Enter キーでも実行できます。" -Muted))
Set-EnterAction $txtFind $applyReplace
Set-EnterAction $txtRepl $applyReplace

# 追加
$pg = New-Page '追加'
$pg.Controls.Add((New-Label '先頭に付ける'))
$txtPrefix = New-TextBox; $pg.Controls.Add($txtPrefix)
$pg.Controls.Add((New-Label '末尾に付ける（拡張子の前）'))
$txtSuffix = New-TextBox; $pg.Controls.Add($txtSuffix)
$b = New-Button '付ける' $applyAdd; $b.Font = $script:BoldFont; $b.Margin = New-Pad 0 8 0 6; $pg.Controls.Add($b)
Set-EnterAction $txtPrefix $applyAdd
Set-EnterAction $txtSuffix $applyAdd
$pg.Controls.Add((New-Label '位置を決めて挿入' -Bold))
$numPos = New-Num 0 999 0
$pg.Controls.Add((New-Row @((New-InlineLabel '先頭から'), $numPos, (New-InlineLabel '文字目の後ろに'))))
$chkFromEnd = New-Check '後ろから数える'; $pg.Controls.Add($chkFromEnd)
$txtInsert = New-TextBox; $pg.Controls.Add($txtInsert)
$b = New-Button '挿入する' $applyInsert; $b.Margin = New-Pad 0 6 0 6; $pg.Controls.Add($b)
Set-EnterAction $txtInsert $applyInsert

# 連番
$pg = New-Page '連番'
$pg.Controls.Add((New-Label '書式（選ぶか、自由に入力）'))
$cmbTpl = New-Object System.Windows.Forms.ComboBox
$cmbTpl.DropDownStyle = 'DropDown'
$cmbTpl.Width = Px 300
$cmbTpl.Margin = New-Pad 0 0 0 4
[void]$cmbTpl.Items.AddRange([object[]]@('b-{n}', '{name}_{n}', '{n}_{name}', '{n}', '{folder}_{n}', '{date}_{n}', '{date}_{name}'))
$cmbTpl.Text = 'b-{n}'
$pg.Controls.Add($cmbTpl)
Set-EnterAction $cmbTpl $applyNumber
$numStart = New-Num 0 99999999 1 76
$numDigits = New-Num 1 12 2 52
$numStep = New-Num 1 10000 1 52
$pg.Controls.Add((New-Row @((New-InlineLabel '開始'), $numStart, (New-InlineLabel '桁数'), $numDigits, (New-InlineLabel '増分'), $numStep)))
$chkPerFolder = New-Check 'フォルダごとに番号を振り直す'; $pg.Controls.Add($chkPerFolder)
$b = New-Button '番号を振る' $applyNumber; $b.Font = $script:BoldFont; $b.Margin = New-Pad 0 8 0 6; $pg.Controls.Add($b)
$pg.Controls.Add((New-Label "使える記号`n{n}　番号（桁数は上で指定）`n{name}　今の新しい名前`n{orig}　元の名前`n{folder}　フォルダ名`n{date}　更新日（例 20261127）`n`n番号は一覧の上から順に振られます。並び順は「↑ ↓」「名前順」「日付順」や、列の見出しクリックで変えられます。" -Muted))

# 整形
$pg = New-Page '整形'
$numCutHead = New-Num 1 999 1 56
$pg.Controls.Add((New-Row @((New-InlineLabel '先頭から'), $numCutHead, (New-InlineLabel '文字'), (New-Button '削除' $opCutHead))))
$numCutTail = New-Num 1 999 1 56
$pg.Controls.Add((New-Row @((New-InlineLabel '末尾から'), $numCutTail, (New-InlineLabel '文字'), (New-Button '削除' $opCutTail))))
$pg.Controls.Add((New-Label 'ワンクリック変換' -Bold))
$wrap = New-Object System.Windows.Forms.FlowLayoutPanel
$wrap.FlowDirection = 'LeftToRight'
$wrap.WrapContents = $true
$wrap.AutoSize = $true
$wrap.AutoSizeMode = 'GrowAndShrink'
$wrap.MaximumSize = New-Size 310 0
$wrap.Margin = New-Pad 0 2 0 2
$quick = @(
    @('全角英数 → 半角', $opHalf, 'ＡＢＣ１２３ → ABC123（カタカナはそのまま）'),
    @('空白 → _', $opSpaceToUs, '半角・全角スペースを「_」に'),
    @('空白を整理', $opTidy, '連続した空白を1つにし、前後の空白を消す'),
    @('カッコごと削除', $opBrackets, '(1)  [abc]  【xx】  （コピー） などをカッコごと消す'),
    @('大文字に', $opUpper, ''),
    @('小文字に', $opLower, ''),
    @('拡張子を小文字に', $opExtLower, '.JPG → .jpg'),
    @('元の名前に戻す', $opRestore, '編集内容を取り消して元の名前に')
)
foreach ($q in $quick) {
    $qb = New-Button $q[0] $q[1]
    if ($q[2]) { $tip.SetToolTip($qb, $q[2]) }
    $wrap.Controls.Add($qb)
}
$pg.Controls.Add($wrap)

$panelRight.Controls.Add($tabs)
$panelRight.Controls.Add($lblScope)

# --- 上：ツールバー
$toolbar = New-Object System.Windows.Forms.FlowLayoutPanel
$toolbar.Dock = 'Top'
$toolbar.AutoSize = $true
$toolbar.AutoSizeMode = 'GrowAndShrink'
$toolbar.WrapContents = $true
$toolbar.Padding = New-Pad 10 10 10 2

function New-Gap { $l = New-Object System.Windows.Forms.Label; $l.AutoSize = $false; $l.Width = Px 10; $l.Height = Px 4; return $l }

$logoBox = New-Object System.Windows.Forms.PictureBox
$logoBox.Size = New-Size 30 30
$logoBox.SizeMode = 'Zoom'
$logoBox.Image = New-AppBitmap (Px 30)
$logoBox.Margin = New-Pad 0 0 6 6
$brand = New-Object System.Windows.Forms.Label
$brand.Text = 'Rename'
$brand.AutoSize = $true
$brand.Font = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$brand.ForeColor = Rgb 29 78 216
$brand.Margin = New-Pad 0 0 14 0
$btnAddFiles = New-Button '＋ ファイルを追加' $addFiles
$btnAddFolder = New-Button '＋ フォルダを追加' $addFolder
$btnRemove = New-Button '一覧から外す' { Remove-SelectedRows }
$btnClear = New-Button '全部クリア' { Clear-Rows }
$btnUp = New-Button '↑' { Move-Selected -1 }
$btnDown = New-Button '↓' { Move-Selected 1 }
$btnSortName = New-Button '名前順' { Sort-Rows 0 }
$btnSortDate = New-Button '日付順' { Sort-Rows 1 }
$btnText = New-Button 'テキストで編集…' { Show-TextEditor }
$btnText.Font = $script:BoldFont
$btnUndo = New-Button '元に戻す' { Undo-Edit }
$btnUndo.Enabled = $false
$chkExpand = New-Check 'フォルダは中のファイルを追加' $true
$chkExpand.Margin = New-Pad 6 5 8 0
$chkSub = New-Check 'サブフォルダも' $false
$chkSub.Margin = New-Pad 0 5 8 0
$chkExpand.Add_CheckedChanged({ $chkSub.Enabled = $chkExpand.Checked })
$btnShortcut = New-Button 'デスクトップにショートカット' { New-DesktopShortcut }

$tip.SetToolTip($btnRemove, '選んだ行を一覧から外します（ファイルは消えません）。Delete キーでも可')
$tip.SetToolTip($btnUp, '選んだ行を上へ（連番の順番が変わります）')
$tip.SetToolTip($btnDown, '選んだ行を下へ')
$tip.SetToolTip($btnSortName, 'Explorer と同じ並び（1, 2, 10 …）に並べ替え')
$tip.SetToolTip($btnSortDate, '更新日時の古い順に並べ替え')
$tip.SetToolTip($btnText, '新しい名前をメモ帳のように1行ずつまとめて編集')
$tip.SetToolTip($btnUndo, '直前の編集を取り消します（Ctrl+Z）')
$tip.SetToolTip($chkExpand, 'オフにすると、フォルダ自体の名前を変える対象になります')

$toolbar.Controls.AddRange([System.Windows.Forms.Control[]]@(
    $logoBox, $brand,
    $btnAddFiles, $btnAddFolder, (New-Gap),
    $btnRemove, $btnClear, (New-Gap),
    $btnUp, $btnDown, $btnSortName, $btnSortDate, (New-Gap),
    $btnText, $btnUndo, (New-Gap),
    $chkExpand, $chkSub, $btnShortcut
))

# --- 下：状態と実行ボタン
$bottom = New-Object System.Windows.Forms.TableLayoutPanel
$bottom.Dock = 'Bottom'
$bottom.AutoSize = $true
$bottom.AutoSizeMode = 'GrowAndShrink'
$bottom.ColumnCount = 3
$bottom.RowCount = 1
$bottom.Padding = New-Pad 10 8 10 10
[void]$bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$bottom.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))

$infoBox = New-Flow 'TopDown'
$infoBox.Anchor = 'Left'
$lblInfo = New-Object System.Windows.Forms.Label
$lblInfo.AutoSize = $true
$lblInfo.Font = $script:BoldFont
$lblInfo.Text = '全 0 件'
$lblHelp = New-Object System.Windows.Forms.Label
$lblHelp.AutoSize = $true
$lblHelp.ForeColor = $C.Muted
$lblHelp.Margin = New-Pad 0 3 0 0
$lblHelp.Text = '名前をクリック：その場で編集（Enter で次の行へ）　　以下連番：その行から下を番号順に　　Ctrl+V：まとめて貼り付け　　Ctrl+Z：元に戻す　　Delete：一覧から外す'
$infoBox.Controls.Add($lblInfo)
$infoBox.Controls.Add($lblHelp)

$btnRevert = New-Button '直前のリネームを取り消す' { Invoke-Revert }
$btnRevert.Enabled = $false
$btnRevert.Anchor = 'Right'
$btnRevert.Margin = New-Pad 0 0 10 0

$btnRun = New-Object System.Windows.Forms.Button
$btnRun.Text = '名前を変更する'
$btnRun.Font = New-Object System.Drawing.Font($script:UIFont.FontFamily, 11, [System.Drawing.FontStyle]::Bold)
$btnRun.AutoSize = $true
$btnRun.AutoSizeMode = 'GrowAndShrink'
$btnRun.Padding = New-Pad 22 7 22 7
$btnRun.FlatStyle = 'Flat'
$btnRun.FlatAppearance.BorderSize = 0
$btnRun.ForeColor = [System.Drawing.Color]::White
$btnRun.BackColor = $C.AccentOff
$btnRun.Cursor = 'Hand'
$btnRun.Anchor = 'Right'
$btnRun.Margin = New-Pad 0 0 0 0
$btnRun.Enabled = $false
$btnRun.Add_EnabledChanged({ $btnRun.BackColor = $(if ($btnRun.Enabled) { $C.Accent } else { $C.AccentOff }) })
$btnRun.Add_Click({ Invoke-Run })

$bottom.Controls.Add($infoBox, 0, 0)
$bottom.Controls.Add($btnRevert, 1, 0)
$bottom.Controls.Add($btnRun, 2, 0)

# Fill を先に、端に付くものを後から追加（Windows Forms のドッキング順）
$form.Controls.Add($panelMain)
$form.Controls.Add($panelRight)
$form.Controls.Add($bottom)
$form.Controls.Add($toolbar)

$form.Add_KeyDown({
    param($s, $e)
    if ($e.Control -and $e.KeyCode -eq 'Z') {
        if ($grid.IsCurrentCellInEditMode) { return }
        $ac = $form.ActiveControl
        if ($ac -is [System.Windows.Forms.TextBoxBase] -or $ac -is [System.Windows.Forms.ComboBox] -or $ac -is [System.Windows.Forms.UpDownBase]) { return }
        Undo-Edit
        $e.Handled = $true
        $e.SuppressKeyPress = $true
    }
})
$form.Add_FormClosing({ Save-Settings })
$form.Add_Shown({
    Update-ShortcutIcon
    Update-AutoPreview
    Update-Scope
    Update-Validation
    if ($Paths) { Add-Paths $Paths }
})

[System.Windows.Forms.Application]::add_ThreadException({
    param($s, $e)
    [void][System.Windows.Forms.MessageBox]::Show(("思わぬエラーが起きました。`n`n" + $e.Exception.Message), 'まとめてリネーム', 'OK', 'Error')
})

[System.Windows.Forms.Application]::Run($form)

} catch {
    [void][System.Windows.Forms.MessageBox]::Show(("起動中にエラーが起きました。`n`n" + $_.Exception.Message + "`n`n" + $_.InvocationInfo.PositionMessage), 'まとめてリネーム', 'OK', 'Error')
}

#Requires AutoHotkey v2.0
#SingleInstance Off
; 画面の一番右端をダブルクリック、またはタスクバーのボタンで
; 2つのフォルダを画面の右上・右下に開く
;   通常起動     … 常駐して右端ダブルクリックを待つ
;   /open 付き起動 … フォルダを開いてすぐ終了（タスクバーのボタン用）

; ================= 設定 =================
FOLDER_TOP    := "C:\Users\user\chrome-extensions"            ; 右上に出すフォルダ
FOLDER_BOTTOM := "C:\Users\user\OneDrive\Desktop\999-GPT画像用"  ; 右下に出すフォルダ
EDGE_WIDTH    := 2      ; 右端とみなす幅（px）
WIDTH_RATIO   := 0.5    ; 画面幅に対するウィンドウ幅（0.5 = 半分）
; ========================================

; 高DPI・複数モニターでも座標がずれないようにする
DllCall("SetThreadDpiAwarenessContext", "ptr", -4, "ptr")
CoordMode "Mouse", "Screen"
SetWinDelay -1          ; ウィンドウ操作ごとの待ち時間（標準0.1秒）をなくす
Shell := ComObject("Shell.Application")   ; 毎回作らず使い回す

; ---- タスクバーのボタンから起動されたとき：開いてすぐ終了 ----
if (A_Args.Length && A_Args[1] = "/open") {
    A_IconHidden := true
    MouseGetPos &x, &y      ; クリックしたタスクバーがあるモニターに開く
    OpenFolders(x, y)
    ExitApp
}

; ---- 常駐モード ----
; すでに常駐している自分（同じファイル）がいれば終了させて入れ替わる
DetectHiddenWindows true
for hwnd in WinGetList(A_ScriptFullPath " - AutoHotkey ahk_class AutoHotkey")
    if (hwnd != A_ScriptHwnd)
        PostMessage 0x0111, 65307, , , hwnd
DetectHiddenWindows false

ICON_FILE := A_ScriptDir "\RightEdgeFolders.ico"   ; このファイルと同じフォルダに置く
if FileExist(ICON_FILE)
    TraySetIcon ICON_FILE
A_IconTip := "右端ダブルクリックでフォルダを開く"
lastClickTime := 0

; PC起動時に自動で実行（未登録、または別の場所のコピーを指していたら登録し直す）
STARTUP_LNK := A_Startup "\RightEdgeFolders.lnk"
oldTarget := ""
if FileExist(STARTUP_LNK)
    try FileGetShortcut STARTUP_LNK, &oldTarget
if (oldTarget != A_ScriptFullPath) {
    FileCreateShortcut A_ScriptFullPath, STARTUP_LNK, A_ScriptDir, , , ICON_FILE
    TrayTip "PC起動時に自動で実行されるよう登録しました", "RightEdgeFolders"
}
A_TrayMenu.Add()
A_TrayMenu.Add("起動時に自動で実行", ToggleStartup)
if FileExist(STARTUP_LNK)
    A_TrayMenu.Check("起動時に自動で実行")

ToggleStartup(name, *) {
    if FileExist(STARTUP_LNK) {
        FileDelete STARTUP_LNK
        A_TrayMenu.Uncheck(name)
    } else {
        FileCreateShortcut A_ScriptFullPath, STARTUP_LNK, A_ScriptDir
        A_TrayMenu.Check(name)
    }
}

; タスクバーにピン留めできるショートカットを、このファイルと同じフォルダに用意する
; （起動のたびに作り直すので、ファイルを移動してもアイコンや場所が自動で合う）
if FileExist(ICON_FILE)
    lnkIcon := ICON_FILE, lnkIconNo := 1
else
    lnkIcon := A_WinDir "\System32\shell32.dll", lnkIconNo := 4
FileCreateShortcut A_AhkPath, A_ScriptDir "\フォルダ2つを開く.lnk", A_ScriptDir
    , '"' A_ScriptFullPath '" /open'
    , "2つのフォルダを画面の右上・右下に開く"
    , lnkIcon, , lnkIconNo

; ---- 右端ダブルクリック ----
; ~ を付けているので、クリック自体は下にあるウィンドウにもそのまま届く
~LButton:: {
    global lastClickTime
    MouseGetPos &x, &y
    if !IsAtRightEdge(x, y) {
        lastClickTime := 0
        return
    }
    now := A_TickCount
    if (now - lastClickTime <= DllCall("GetDoubleClickTime")) {
        lastClickTime := 0
        OpenFolders(x, y)
    } else {
        lastClickTime := now
    }
}

; カーソルが「一番右端」にあるか（右隣に別モニターがある境目は除外）
IsAtRightEdge(x, y) {
    m := GetMonitorAt(x, y)
    if !m
        return false
    MonitorGet m, , , &r
    if (x < r - EDGE_WIDTH)
        return false
    return GetMonitorAt(r, y) = 0
}

GetMonitorAt(x, y) {
    Loop MonitorGetCount() {
        MonitorGet A_Index, &l, &t, &r, &b
        if (x >= l && x < r && y >= t && y < b)
            return A_Index
    }
    return 0
}

; (x, y) があるモニターの右上・右下に2つのフォルダを並べる
OpenFolders(x, y) {
    m := GetMonitorAt(x, y)
    if !m
        m := MonitorGetPrimary()
    MonitorGetWorkArea m, &l, &t, &r, &b   ; タスクバーを除いた領域
    w := Round((r - l) * WIDTH_RATIO)
    h := (b - t) // 2
    slots := [
        {path: FOLDER_TOP,    x: r - w, y: t,     w: w, h: h,           hwnd: 0},
        {path: FOLDER_BOTTOM, x: r - w, y: t + h, w: w, h: (b - t) - h, hwnd: 0}
    ]

    ; ① すでに開いているものはすぐ配置、開いていないものは2つ同時に開き始める
    waiting := 0
    for s in slots {
        if !DirExist(s.path) {
            MsgBox "フォルダが見つかりません：`n" s.path, "RightEdgeFolders", "Icon!"
            s.hwnd := -1
            continue
        }
        if (s.hwnd := FindExplorer(s.path, slots)) {
            PlaceWindow(s)
        } else {
            Run 'explorer.exe "' s.path '"'
            waiting++
        }
    }

    ; ② 開いたウィンドウから順に、見つかった瞬間に配置する
    deadline := A_TickCount + 5000
    while (waiting > 0 && A_TickCount < deadline) {
        Sleep 20
        for s in slots {
            if (s.hwnd = 0 && (s.hwnd := FindExplorer(s.path, slots))) {
                PlaceWindow(s)
                waiting--
            }
        }
    }
}

; 指定フォルダを表示しているエクスプローラーを探す（もう一方に使ったウィンドウは除く）
FindExplorer(path, slots) {
    target := RTrim(path, "\")
    for win in Shell.Windows {
        try {
            hwnd := win.HWND
            if (hwnd = slots[1].hwnd || hwnd = slots[2].hwnd)
                continue
            if (RTrim(win.Document.Folder.Self.Path, "\") = target)
                return hwnd
        }
    }
    return 0
}

; ウィンドウを指定位置に移動（Windows 10/11 の見えない枠のぶんを補正）
PlaceWindow(s) {
    hwnd := s.hwnd
    if (WinGetMinMax(hwnd) != 0)
        WinRestore hwnd
    WinMove s.x, s.y, s.w, s.h, hwnd

    rect := Buffer(16)
    if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", hwnd, "uint", 9, "ptr", rect, "uint", 16) {
        WinGetPos &wx, &wy, &ww, &wh, hwnd
        bl := NumGet(rect, 0, "int") - wx
        bt := NumGet(rect, 4, "int") - wy
        br := (wx + ww) - NumGet(rect, 8, "int")
        bb := (wy + wh) - NumGet(rect, 12, "int")
        if (bl || bt || br || bb)
            WinMove s.x - bl, s.y - bt, s.w + bl + br, s.h + bt + bb, hwnd
    }
    WinActivate hwnd
}

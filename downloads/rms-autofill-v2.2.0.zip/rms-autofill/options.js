// ========== ユーティリティ ==========
function formatDate(ts) {
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function maskPassword(p) {
  if (!p) return '';
  return '•'.repeat(p.length);
}

function showStatus(elId, message, type) {
  const el = document.getElementById(elId);
  el.classList.remove('show', 'success', 'error');
  el.textContent = message;
  el.classList.add('show', type || 'success');
  setTimeout(() => el.classList.remove('show'), 2500);
}

// ========== 設定の読み込み・保存 ==========
async function loadSettings() {
  const data = await chrome.storage.local.get(['loginId', 'loginPass']);
  document.getElementById('loginId').value = data.loginId || '';
  document.getElementById('loginPass').value = data.loginPass || '';
}

async function saveSettings() {
  const newId = document.getElementById('loginId').value.trim();
  const newPass = document.getElementById('loginPass').value;

  const old = await chrome.storage.local.get(['loginId', 'loginPass', 'passLog']);
  const log = old.passLog || [];

  // パスワード変更を検知してログ追加
  if (newPass && newPass !== old.loginPass) {
    log.unshift({
      ts: Date.now(),
      pass: newPass
    });
  }

  await chrome.storage.local.set({
    loginId: newId,
    loginPass: newPass,
    passLog: log
  });

  showStatus('saveStatus', '✓ 保存しました', 'success');
  renderLog();
}

// ========== ログ描画 ==========
async function renderLog() {
  const data = await chrome.storage.local.get(['passLog']);
  const log = data.passLog || [];
  const list = document.getElementById('logList');

  if (log.length === 0) {
    list.innerHTML = '<div class="empty">変更ログはまだありません</div>';
    return;
  }

  list.innerHTML = '';
  log.forEach((entry, idx) => {
    const item = document.createElement('div');
    item.className = 'log-item';

    const date = document.createElement('div');
    date.className = 'log-date';
    date.textContent = formatDate(entry.ts);

    const pass = document.createElement('div');
    pass.className = 'log-pass';
    pass.dataset.shown = 'true';
    pass.dataset.value = entry.pass;
    pass.textContent = entry.pass;

    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'secondary';
    toggleBtn.textContent = '隠す';
    toggleBtn.addEventListener('click', () => {
      if (pass.dataset.shown === 'false') {
        pass.textContent = pass.dataset.value;
        pass.dataset.shown = 'true';
        toggleBtn.textContent = '隠す';
      } else {
        pass.textContent = maskPassword(pass.dataset.value);
        pass.dataset.shown = 'false';
        toggleBtn.textContent = '表示';
      }
    });

    const copyBtn = document.createElement('button');
    copyBtn.className = 'secondary';
    copyBtn.textContent = 'コピー';
    copyBtn.addEventListener('click', async () => {
      await navigator.clipboard.writeText(entry.pass);
      copyBtn.textContent = '✓';
      setTimeout(() => (copyBtn.textContent = 'コピー'), 1200);
    });

    const delBtn = document.createElement('button');
    delBtn.className = 'secondary';
    delBtn.textContent = '削除';
    delBtn.addEventListener('click', async () => {
      const cur = await chrome.storage.local.get(['passLog']);
      const updated = (cur.passLog || []).filter((_, i) => i !== idx);
      await chrome.storage.local.set({ passLog: updated });
      renderLog();
    });

    item.appendChild(date);
    item.appendChild(pass);
    item.appendChild(toggleBtn);
    item.appendChild(copyBtn);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
}

// ========== イベント ==========
document.getElementById('saveBtn').addEventListener('click', saveSettings);

document.getElementById('togglePass').addEventListener('click', () => {
  const input = document.getElementById('loginPass');
  const btn = document.getElementById('togglePass');
  if (input.type === 'text') {
    input.type = 'password';
    btn.textContent = '表示';
  } else {
    input.type = 'text';
    btn.textContent = '隠す';
  }
});

document.getElementById('clearLogBtn').addEventListener('click', async () => {
  if (!confirm('変更ログをすべて削除しますか?')) return;
  await chrome.storage.local.set({ passLog: [] });
  renderLog();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.passLog || changes.loginId || changes.loginPass) {
    loadSettings();
    renderLog();
  }
});

// 初期化
loadSettings();
renderLog();

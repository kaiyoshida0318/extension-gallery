(() => {
  'use strict';

  // URLに sp_id=1 が付いている場合のみ動作する
  // (RMSログインページ以外の glogin.rms.rakuten.co.jp 配下では何もしない)
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get('sp_id') !== '1') {
      return;
    }
  } catch (e) {
    return;
  }

  // ========== ユーティリティ ==========
  function formatDate(ts) {
    const d = new Date(ts);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function maskPassword(p) {
    if (!p) return '';
    return '•'.repeat(p.length);
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ========== 入力フィールドの検出 ==========
  // RMSログインページの実際のHTML構造に合わせて、id/name属性で確実に検出する。
  //   <input id="rlogin-username-ja" name="login_id" type="text">
  //   <input id="rlogin-password-ja" name="passwd"   type="password">
  function findRLoginFields() {
    let idField = document.getElementById('rlogin-username-ja');
    let passField = document.getElementById('rlogin-password-ja');

    if (!idField) {
      idField = document.querySelector('input[name="login_id"]');
    }
    if (!passField) {
      passField = document.querySelector('input[name="passwd"]');
    }

    // フォールバック
    if (!idField || !passField) {
      const form = document.querySelector('form.rf-form-login--form, form');
      if (form) {
        if (!idField) idField = form.querySelector('input[type="text"]');
        if (!passField) passField = form.querySelector('input[type="password"]');
      }
    }
    if (!passField) {
      passField = document.querySelector('input[type="password"]');
    }
    if (!idField) {
      const candidates = Array.from(document.querySelectorAll('input')).filter((i) => {
        const t = (i.type || '').toLowerCase();
        return t === 'text' || t === 'email' || t === '';
      });
      idField = candidates[0] || null;
    }

    return { idField, passField };
  }

  // 値を入力して保持されているか確認、消えていれば再入力(autocomplete=off対策)
  async function fillAndVerify(el, value) {
    setNativeValue(el, value);
    await new Promise((r) => setTimeout(r, 80));
    if (el.value !== value) {
      setNativeValue(el, value);
    }
    try {
      el.focus();
      el.blur();
    } catch (e) {}
    return el.value === value;
  }

  // Chrome本体の自動入力を抑制するため、autocomplete属性を書き換える
  function disableAutofillAttrs(el) {
    if (!el) return;
    try {
      // ランダムな名前にしてChromeの記憶している値とのマッチを外す
      el.setAttribute('autocomplete', 'off');
      el.setAttribute('autocorrect', 'off');
      el.setAttribute('autocapitalize', 'off');
      el.setAttribute('spellcheck', 'false');
      // data-form-type="other" を付けてフォーム検出を回避
      el.setAttribute('data-form-type', 'other');
      el.setAttribute('data-lpignore', 'true'); // LastPass無効化
      el.setAttribute('data-1p-ignore', 'true'); // 1Password無効化
    } catch (e) {}
  }

  // ========== 自動入力 ==========
  // 期待値を保持し、上書きされたら再入力する
  let _expected = { id: '', pass: '' };
  let _watcherInstalled = false;

  async function autoFill() {
    const data = await chrome.storage.local.get(['loginId', 'loginPass']);
    if (!data.loginId && !data.loginPass) {
      return { ok: false, reason: '設定が未登録です。「設定を開く」から登録してください。' };
    }

    _expected.id = data.loginId || '';
    _expected.pass = data.loginPass || '';

    const { idField, passField } = findRLoginFields();

    // autofill抑制属性を付与
    disableAutofillAttrs(idField);
    disableAutofillAttrs(passField);

    let filled = [];
    let warnings = [];

    if (idField && data.loginId) {
      const ok = await fillAndVerify(idField, data.loginId);
      if (ok) filled.push('ID');
      else warnings.push('ID欄に書き込めませんでした');
    }
    if (passField && data.loginPass) {
      const ok = await fillAndVerify(passField, data.loginPass);
      if (ok) filled.push('パスワード');
      else warnings.push('パスワード欄に書き込めませんでした');
    }

    // 監視を仕掛ける(Chrome自動入力が後から上書きしてきたら戻す)
    installAutofillWatcher(idField, passField);

    if (filled.length === 0) {
      return { ok: false, reason: warnings.length > 0 ? warnings.join(' / ') : 'R-loginの入力欄が見つかりませんでした。' };
    }
    return { ok: true, filled };
  }

  // Chromeの自動入力が後から書き込んでくる場合に備えて、何度か遅延チェックして上書きを訂正する
  function installAutofillWatcher(idField, passField) {
    if (_watcherInstalled) return;
    _watcherInstalled = true;

    const checkpoints = [200, 500, 1000, 2000, 3500];
    checkpoints.forEach((ms) => {
      setTimeout(() => {
        const fields = findRLoginFields();
        const id = fields.idField || idField;
        const pass = fields.passField || passField;

        if (id && _expected.id && id.value !== _expected.id) {
          setNativeValue(id, _expected.id);
        }
        if (pass && _expected.pass && pass.value !== _expected.pass) {
          setNativeValue(pass, _expected.pass);
        }
      }, ms);
    });

    // MutationObserverでvalue属性の変更も検知
    const observerTarget = document.body;
    if (observerTarget) {
      const obs = new MutationObserver(() => {
        const fields = findRLoginFields();
        if (fields.idField && _expected.id && fields.idField.value && fields.idField.value !== _expected.id) {
          setNativeValue(fields.idField, _expected.id);
        }
        if (fields.passField && _expected.pass && fields.passField.value && fields.passField.value !== _expected.pass) {
          setNativeValue(fields.passField, _expected.pass);
        }
      });
      obs.observe(observerTarget, { attributes: true, subtree: true, attributeFilter: ['value'] });
      // 5秒後に監視停止(無限に動かさない)
      setTimeout(() => obs.disconnect(), 5000);
    }
  }

  // ========== UIパネル ==========
  function buildPanel() {
    if (document.getElementById('rms-autofill-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'rms-autofill-panel';
    panel.innerHTML = `
      <div class="rms-header">
        <span>🔐 RMS Login AutoFill</span>
        <div class="rms-header-actions">
          <button data-action="toggle" title="折りたたみ">－</button>
          <button data-action="close" title="閉じる">×</button>
        </div>
      </div>
      <div class="rms-status" id="rms-status">読み込み中...</div>
      <div class="rms-id-display">
        <div class="rms-id-label">R-Login ID</div>
        <div class="rms-id-value" id="rms-id-value">―</div>
        <div class="rms-id-hint">編集はオプション画面から</div>
      </div>
      <div class="rms-actions">
        <button class="primary" data-action="fill">入力欄へ再反映</button>
        <button data-action="options">設定を開く</button>
      </div>
      <div class="rms-log-title">
        <span>📜 パスワード変更ログ</span>
        <span id="rms-log-count" style="font-weight: normal; color: #999; font-size: 11px;"></span>
      </div>
      <div class="rms-log-list" id="rms-log-list"></div>
    `;
    document.documentElement.appendChild(panel);

    panel.querySelector('[data-action="close"]').addEventListener('click', () => {
      panel.remove();
    });
    panel.querySelector('[data-action="toggle"]').addEventListener('click', (e) => {
      panel.classList.toggle('collapsed');
      e.currentTarget.textContent = panel.classList.contains('collapsed') ? '＋' : '－';
    });
    panel.querySelector('[data-action="fill"]').addEventListener('click', async () => {
      const r = await autoFill();
      setStatus(r);
    });
    panel.querySelector('[data-action="options"]').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'OPEN_OPTIONS' }, (response) => {
        if (chrome.runtime.lastError || !response || !response.ok) {
          window.open(chrome.runtime.getURL('options.html'), '_blank');
        }
      });
    });

    enableDrag(panel, panel.querySelector('.rms-header'));
  }

  function setStatus(result) {
    const el = document.getElementById('rms-status');
    if (!el) return;
    el.classList.remove('success', 'warn', 'error');
    if (result.ok) {
      el.classList.add('success');
      el.textContent = `✓ ${result.filled.join(' / ')} を自動入力しました`;
    } else {
      el.classList.add('warn');
      el.textContent = `⚠ ${result.reason}`;
    }
  }

  async function renderIdDisplay() {
    const el = document.getElementById('rms-id-value');
    if (!el) return;
    const data = await chrome.storage.local.get(['loginId']);
    if (data.loginId) {
      el.textContent = data.loginId;
      el.classList.remove('empty');
    } else {
      el.textContent = '(未登録)';
      el.classList.add('empty');
    }
  }

  async function renderLog() {
    const list = document.getElementById('rms-log-list');
    const count = document.getElementById('rms-log-count');
    if (!list) return;

    const data = await chrome.storage.local.get(['passLog']);
    const log = data.passLog || [];

    if (count) count.textContent = log.length > 0 ? `${log.length}件` : '';

    if (log.length === 0) {
      list.innerHTML = '<div class="rms-empty">変更ログはまだありません</div>';
      return;
    }

    list.innerHTML = '';
    log.forEach((entry) => {
      const item = document.createElement('div');
      item.className = 'rms-log-item';

      const date = document.createElement('div');
      date.className = 'rms-log-date';
      date.textContent = formatDate(entry.ts);

      const row = document.createElement('div');
      row.className = 'rms-log-row';

      const passEl = document.createElement('div');
      passEl.className = 'rms-log-pass';
      passEl.dataset.shown = 'true';
      passEl.textContent = entry.pass;

      const toggleBtn = document.createElement('button');
      toggleBtn.textContent = '隠す';
      toggleBtn.addEventListener('click', () => {
        if (passEl.dataset.shown === 'false') {
          passEl.textContent = entry.pass;
          passEl.dataset.shown = 'true';
          toggleBtn.textContent = '隠す';
        } else {
          passEl.textContent = maskPassword(entry.pass);
          passEl.dataset.shown = 'false';
          toggleBtn.textContent = '表示';
        }
      });

      const copyBtn = document.createElement('button');
      copyBtn.textContent = 'コピー';
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(entry.pass);
          copyBtn.textContent = '✓';
          setTimeout(() => (copyBtn.textContent = 'コピー'), 1200);
        } catch (e) {
          copyBtn.textContent = '失敗';
        }
      });

      row.appendChild(passEl);
      row.appendChild(toggleBtn);
      row.appendChild(copyBtn);

      item.appendChild(date);
      item.appendChild(row);
      list.appendChild(item);
    });
  }

  // ========== ドラッグ ==========
  function enableDrag(panel, handle) {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true;
      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const x = Math.max(0, Math.min(window.innerWidth - 100, e.clientX - offsetX));
      const y = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - offsetY));
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => {
      dragging = false;
    });
  }

  // ========== ストレージ変更の監視 ==========
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.passLog) renderLog();
    if (changes.loginId) renderIdDisplay();
  });

  // ========== 起動 ==========
  async function init() {
    buildPanel();
    await renderIdDisplay();
    await renderLog();

    let attempts = 0;
    const tryFill = async () => {
      const result = await autoFill();
      if (result.ok || attempts >= 6) {
        setStatus(result);
        return;
      }
      attempts++;
      setTimeout(tryFill, 400);
    };
    tryFill();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* ====== offscreen document ======
 * Service Worker では URL.createObjectURL が使えないので、
 * blob URL を作るためだけの隠しページ。
 *
 * なぜ blob URL が要るのか:
 *   chrome.downloads.download() に data: URL を渡すと、Chrome は
 *   filename の指定を無視して "download"(日本語UIでは「ダウンロード」)で
 *   保存してしまう。blob: URL なら filename がそのまま通る。
 */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.target !== 'offscreen') return false;

  if (msg.type === 'toBlobUrl') {
    fetch(msg.dataUrl)
      .then(function (r) { return r.blob(); })
      .then(function (b) { sendResponse({ ok: true, url: URL.createObjectURL(b), size: b.size }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) ? e.message : String(e) }); });
    return true;   // 非同期で返す
  }

  if (msg.type === 'revoke') {
    try { URL.revokeObjectURL(msg.url); } catch (e) {}
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

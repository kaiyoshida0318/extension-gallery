// ChatGPT 画像一括送信 — 裏側の処理
// ・新しいタブを「今の画面のまま」裏で開く
// ・ダウンロードフォルダの中に日時フォルダを作って保存する
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'cgb-open-tab' && typeof msg.url === 'string' && /^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(msg.url)) {
    const opt = { url: msg.url, active: false };
    if (sender.tab) { opt.index = sender.tab.index + 1; opt.openerTabId = sender.tab.id; opt.windowId = sender.tab.windowId; }
    chrome.tabs.create(opt, () => reply({ ok: !chrome.runtime.lastError }));
    return true;
  }
  if (msg && msg.type === 'cgb-download' && typeof msg.url === 'string' && /^data:image\//.test(msg.url) && typeof msg.filename === 'string') {
    // フォルダ名・ファイル名に使えない文字はここでも消しておく
    const safe = msg.filename.split('/').map(p => p.replace(/[\\:*?"<>|\u0000-\u001f]/g, '_').replace(/^\.+/, '_').trim()).filter(Boolean).join('/');
    chrome.downloads.download({ url: msg.url, filename: safe, conflictAction: 'uniquify', saveAs: false }, id => {
      reply({ ok: !chrome.runtime.lastError && id != null, error: chrome.runtime.lastError?.message });
    });
    return true;
  }
});

// content.js: 商品ページに浮かぶDLボタンを表示する

(function() {
  // 多重注入ガード
  if (window.__shopDLFloatingInjected) return;
  window.__shopDLFloatingInjected = true;

  // サイト判定
  const site = detectSite(location.href);
  if (!site) return;

  // 保存済みの位置を読み込む(1〜10, デフォルト1) — サイトごとに別キー
  const STORAGE_KEY = `__shopDL_position_${site}`;
  let currentPosition = 1;
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    if (v) {
      const n = parseInt(v, 10);
      if (n >= 1 && n <= 10) currentPosition = n;
    }
  } catch {}

  // Shadow DOM に浮きボタンを入れる(ホストページのCSSから隔離)
  const host = document.createElement('div');
  host.id = '__shop_dl_floating_host';
  host.style.cssText = `
    position: fixed !important;
    right: 10px !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
  `;
  // 位置を適用: 1=上端, 10=下端
  applyPosition(currentPosition);
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({ mode: 'closed' });

  function applyPosition(pos) {
    // pos: 1-10
    // 1 → top: 10px
    // 10 → top: 下端近く
    // 間を9等分して配分
    // CSS calc で画面高さに追従させる
    const ratio = (pos - 1) / 9; // 0〜1
    // パネル高さは可変なので、上下端から10px余白、残り範囲で位置決め
    // top: 10px + ratio * (100vh - panelHeight - 20px)
    // panelHeight はおよそ180px想定で安全マージン
    host.style.top = `calc(10px + ${ratio} * (100vh - 200px))`;
  }

  const style = document.createElement('style');
  style.textContent = `
    * { box-sizing: border-box; font-family: -apple-system, "Hiragino Sans", sans-serif; }
    .wrap {
      pointer-events: auto;
      background: rgba(255,255,255,0.98);
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      padding: 8px;
      min-width: 240px;
      max-width: 320px;
      font-size: 12px;
      color: #333;
    }
    .header {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 6px;
    }
    .title {
      font-size: 11px;
      font-weight: bold;
      color: ${site === 'rakuten' ? '#bf0000' : '#ff0033'};
      flex-shrink: 0;
    }
    .pos-wrap {
      display: flex;
      align-items: center;
      gap: 3px;
      flex: 1;
      font-size: 10px;
      color: #666;
    }
    .pos-label { white-space: nowrap; }
    .pos-select {
      font-size: 10px;
      padding: 1px 2px;
      border: 1px solid #ccc;
      border-radius: 3px;
      background: white;
      color: #333;
      cursor: pointer;
    }
    .close {
      background: none;
      border: none;
      cursor: pointer;
      color: #999;
      font-size: 16px;
      line-height: 1;
      padding: 0 2px;
    }
    .close:hover { color: #333; }
    .main-btn {
      width: 100%;
      padding: 10px;
      font-size: 13px;
      font-weight: bold;
      color: white;
      background: #bf0000;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-bottom: 4px;
    }
    .main-btn:hover:not(:disabled) { filter: brightness(0.88); }
    .main-btn:disabled { background: #ccc; cursor: not-allowed; }
    .footer-row {
      display: flex;
      gap: 4px;
      margin-top: 4px;
    }
    .footer-row button {
      flex: 1;
      padding: 6px;
      font-size: 11px;
      font-weight: bold;
      border-radius: 3px;
      cursor: pointer;
    }
    .open-dl-folder {
      background: #f0f0f0;
      border: 1px solid #ddd;
      color: #333;
    }
    .open-dl-folder:hover { background: #e0e0e0; }
    .open-last-folder {
      background: #2c7be5;
      border: none;
      color: white;
    }
    .open-last-folder:hover:not(:disabled) { background: #1a5cb8; }
    .open-last-folder:disabled { background: #ccc; cursor: not-allowed; color: #888; }
    .status {
      margin-top: 6px;
      padding: 5px 7px;
      background: #f5f5f5;
      border-radius: 3px;
      font-size: 11px;
      line-height: 1.4;
      min-height: 14px;
      max-height: 80px;
      overflow-y: auto;
      word-break: break-all;
    }
    .status.hidden { display: none; }
    .collapsed-btn {
      pointer-events: auto;
      background: ${site === 'rakuten' ? '#bf0000' : '#ff0033'};
      color: white;
      border: none;
      border-radius: 20px;
      padding: 8px 12px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    .collapsed-btn:hover { filter: brightness(0.9); }
  `;
  shadow.appendChild(style);

  const wrap = document.createElement('div');
  wrap.className = 'wrap';
  // ドロップダウンの選択肢 (1〜10)
  let posOptions = '';
  for (let i = 1; i <= 10; i++) {
    posOptions += `<option value="${i}"${i === currentPosition ? ' selected' : ''}>${i}</option>`;
  }

  wrap.innerHTML = `
    <div class="header">
      <span class="title">${site === 'rakuten' ? '🛍️ 楽天画像DL' : '🅨 Yahoo!画像DL'}</span>
      <span class="pos-wrap">
        <span class="pos-label">位置</span>
        <select class="pos-select" title="1=最上, 10=最下">${posOptions}</select>
      </span>
      <button class="close" title="最小化">×</button>
    </div>
    <button class="main-btn">📥 商品画像を一括DL</button>
    <div class="status hidden"></div>
    <div class="footer-row">
      <button class="open-dl-folder" title="Chromeのダウンロードフォルダを開く">📁 DL</button>
      <button class="open-last-folder" disabled title="直前にDLした画像のフォルダを開く">📂 今回</button>
    </div>
  `;
  // 小さいDLボタン(最小化状態)
  const miniBtn = document.createElement('button');
  miniBtn.className = 'collapsed-btn';
  miniBtn.textContent = site === 'rakuten' ? '🛍️ DL' : '🅨 DL';
  miniBtn.title = 'クリックで展開';
  miniBtn.addEventListener('click', () => {
    miniBtn.remove();
    shadow.appendChild(wrap);
  });
  // 初期状態は小さいDLボタンのみ表示
  shadow.appendChild(miniBtn);

  const mainBtn = wrap.querySelector('.main-btn');
  const statusEl = wrap.querySelector('.status');
  const closeBtn = wrap.querySelector('.close');
  const openDlFolderBtn = wrap.querySelector('.open-dl-folder');
  const openLastFolderBtn = wrap.querySelector('.open-last-folder');
  const posSelect = wrap.querySelector('.pos-select');

  // 位置ドロップダウンの変更ハンドラ
  posSelect.addEventListener('change', () => {
    const pos = parseInt(posSelect.value, 10);
    if (pos >= 1 && pos <= 10) {
      currentPosition = pos;
      applyPosition(pos);
      try { localStorage.setItem(STORAGE_KEY, String(pos)); } catch {}
    }
  });

  let lastDownloadId = null;

  function setStatus(msg, isError) {
    statusEl.classList.remove('hidden');
    statusEl.textContent = msg;
    statusEl.style.color = isError ? '#bf0000' : '#333';
  }

  // ×ボタンで最小化(wrapを外して小ボタンに戻す)
  closeBtn.addEventListener('click', () => {
    wrap.remove();
    shadow.appendChild(miniBtn);
  });

  // DLフォルダ
  openDlFolderBtn.addEventListener('click', async () => {
    try {
      await chrome.runtime.sendMessage({ type: 'SHOW_DEFAULT_FOLDER' });
    } catch (e) { setStatus('⚠️ ' + e.message, true); }
  });

  // 今回のフォルダ
  openLastFolderBtn.addEventListener('click', async () => {
    if (lastDownloadId == null) return;
    try {
      await chrome.runtime.sendMessage({ type: 'SHOW_DOWNLOAD', downloadId: lastDownloadId });
    } catch (e) { setStatus('⚠️ ' + e.message, true); }
  });

  // メインDLボタン
  mainBtn.addEventListener('click', async () => {
    mainBtn.disabled = true;
    try {
      setStatus('画像収集中…');
      const result = site === 'rakuten' ? collectRakuten() : collectYahoo();
      if (!result.urls.length) {
        setStatus(`画像が見つかりません\n${result.debug || ''}`, true);
        return;
      }
      setStatus(`${result.urls.length}件 検出。DL開始…`);
      const res = await chrome.runtime.sendMessage({
        type: 'DOWNLOAD_ALL', urls: result.urls, folder: result.folder
      });
      if (res?.ok) {
        setStatus(`✅ ${res.success}/${result.urls.length}件 DL開始\n→ ${result.folder}`);
        if (res.firstDownloadId != null) {
          lastDownloadId = res.firstDownloadId;
          openLastFolderBtn.disabled = false;
        }
      } else {
        setStatus('⚠️ ' + (res?.error || 'エラー'), true);
      }
    } catch (e) {
      setStatus('⚠️ ' + e.message, true);
    } finally {
      mainBtn.disabled = false;
    }
  });

  // ========================
  // サイト判定
  // ========================
  function detectSite(url) {
    if (!url) return null;
    if (url.includes('item.rakuten.co.jp')) return 'rakuten';
    if (url.includes('store.shopping.yahoo.co.jp') || url.includes('shopping.yahoo.co.jp')) return 'yahoo';
    return null;
  }

  // ========================
  // 日付フォルダ名 shop-images-YY-MMDD
  // ========================
  function makeDateFolder() {
    const d = new Date();
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `shop-images-${yy}-${mm}${dd}`;
  }

  // ========================
  // 楽天: width="100%" の img
  // ========================
  function collectRakuten() {
    try {
      const allImgs = document.querySelectorAll('img');
      const productImgs = [];
      let widthMatched = 0;

      allImgs.forEach(img => {
        const widthAttr = img.getAttribute('width');
        const styleWidth = img.style.width;
        const isFullWidth =
          (widthAttr && widthAttr.trim() === '100%') ||
          (styleWidth && styleWidth.replace(/\s/g, '') === '100%');
        if (!isFullWidth) return;
        widthMatched++;
        const src = img.currentSrc || img.src || img.getAttribute('src');
        if (!src || src.startsWith('data:') || src.startsWith('blob:')) return;
        productImgs.push(src);
      });

      let arr = productImgs.map(u => {
        try { return new URL(u, location.href).toString(); } catch { return null; }
      }).filter(Boolean);

      arr = arr.filter(u => {
        try {
          const url = new URL(u);
          return url.hostname === 'image.rakuten.co.jp' || url.hostname.endsWith('.r10s.jp');
        } catch { return false; }
      });

      arr = arr.map(u => {
        try {
          const url = new URL(u);
          if (url.hostname === 'shop.r10s.jp') url.hostname = 'image.rakuten.co.jp';
          return url.toString();
        } catch { return u; }
      });

      const seen = new Set();
      const ordered = [];
      for (const u of arr) {
        if (!seen.has(u)) { seen.add(u); ordered.push(u); }
      }

      const debug = `全img${allImgs.length} width=100%:${widthMatched} 対象:${ordered.length}`;
      const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+)/);
      const subfolder = 'rakuten_' + (m ? `${m[1]}_${m[2]}` : Date.now());
      const folder = `${makeDateFolder()}/${subfolder}`;
      return { urls: ordered, folder, debug };
    } catch (e) {
      return { urls: [], folder: '', debug: 'エラー: ' + e.message };
    }
  }

  // ========================
  // Yahoo!: メイン+サムネ
  // ========================
  function collectYahoo() {
    try {
      const ogMeta = document.querySelector('meta[property="og:image"]');
      const ogImage = ogMeta?.getAttribute('content') || '';
      const allImgs = document.querySelectorAll('img');
      const found = new Map();

      allImgs.forEach(img => {
        const srcs = [img.currentSrc, img.src, img.getAttribute('src')];
        if (img.srcset) img.srcset.split(',').forEach(p => srcs.push(p.trim().split(' ')[0]));
        srcs.forEach(src => {
          if (!src || src.startsWith('data:') || src.startsWith('blob:')) return;
          try {
            const url = new URL(src, location.href);
            if (!url.hostname.endsWith('.yimg.jp')) return;
            const m = url.pathname.match(/^\/i\/([a-z])\/(.+)$/);
            if (!m) return;
            const identifier = m[2];
            if (!found.has(identifier)) found.set(identifier, url.origin + '/i/n/' + identifier);
          } catch {}
        });
      });

      if (ogImage) {
        try {
          const url = new URL(ogImage, location.href);
          const m = url.pathname.match(/^\/i\/([a-z])\/(.+)$/);
          if (m) {
            const id = m[2];
            if (!found.has(id)) found.set(id, url.origin + '/i/n/' + id);
          }
        } catch {}
      }

      const urls = Array.from(found.values());
      urls.sort((a, b) => {
        const ma = a.match(/_(\d+)_[a-z]_/);
        const mb = b.match(/_(\d+)_[a-z]_/);
        return (ma ? parseInt(ma[1]) : -1) - (mb ? parseInt(mb[1]) : -1);
      });

      const debug = `yimg.jp画像:${urls.length}件`;
      const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+?)(?:\.html)?$/);
      const subfolder = 'yahoo_' + (m ? `${m[1]}_${m[2]}` : Date.now());
      const folder = `${makeDateFolder()}/${subfolder}`;
      return { urls, folder, debug };
    } catch (e) {
      return { urls: [], folder: '', debug: 'エラー: ' + e.message };
    }
  }
})();

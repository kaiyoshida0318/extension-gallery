// background.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'DOWNLOAD_ALL') {
    handleDownloads(msg.urls, msg.folder)
      .then(result => sendResponse({ ok: true, ...result }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === 'SHOW_DEFAULT_FOLDER') {
    try {
      chrome.downloads.showDefaultFolder();
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
  if (msg.type === 'SHOW_DOWNLOAD') {
    try {
      chrome.downloads.show(msg.downloadId);
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
    return true;
  }
});

async function handleDownloads(urls, folder) {
  let success = 0;
  let fail = 0;
  let firstDownloadId = null;

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    const filename = makeFilename(url, i, urls.length);
    const fullPath = `${folder}/${filename}`;
    try {
      const id = await new Promise((resolve, reject) => {
        chrome.downloads.download({
          url, filename: fullPath, conflictAction: 'uniquify', saveAs: false
        }, (downloadId) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(downloadId);
        });
      });
      if (firstDownloadId === null) firstDownloadId = id;
      success++;
    } catch (e) {
      console.error('DL fail', url, e);
      fail++;
    }
    await sleep(50);
  }
  return { success, fail, firstDownloadId };
}

function makeFilename(url, index, total) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split('/').filter(Boolean);
    let base = parts[parts.length - 1] || `image_${index}`;
    if (!/\.(jpe?g|png|gif|webp)$/i.test(base)) base += '.jpg';
    const pad = String(total).length;
    const prefix = String(index + 1).padStart(pad, '0');
    base = base.replace(/[\\/:*?"<>|]/g, '_');
    return `${prefix}_${base}`;
  } catch {
    return `image_${index + 1}.jpg`;
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

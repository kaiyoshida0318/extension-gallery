// =====================================================
// NE Quick Access v2.0 - content script
// バー上にプリセットタブ + 設定ボタン
// 設定は画面内の大画面モーダルで完結（各項目に複数タブのチェック）
// =====================================================

const STORAGE_KEY_ALL = 'ne_quick_all_items';
const STORAGE_KEY_PRESETS = 'ne_quick_presets';
const STORAGE_KEY_ACTIVE = 'ne_quick_active_preset';
const STORAGE_KEY_ICONS = 'ne_quick_icons';
const STORAGE_KEY_GROUPS = 'ne_quick_groups';  // 全タブ共通の行リスト
const STORAGE_KEY_TRACK = 'ne_quick_track_on';   // クリック記録ON/OFF
const STORAGE_KEY_DONE = 'ne_quick_done';        // 実施済み項目 {'type:id': true}
const STORAGE_KEY_ENABLED = 'ne_quick_enabled';  // ツール自体のON/OFF
const STORAGE_KEY_CUSTOM = 'ne_quick_custom';    // 自由項目 [{id, name}]
const STORAGE_KEY_MASTER = 'ne_quick_master_assign'; // 行割り当てマスター {'type:id': groupId}
const STORAGE_KEY_ORDER = 'ne_quick_order';      // 並び順 {'type:id': 数値}
const STORAGE_KEY_SYNC = 'ne_quick_sync_config'; // 同期設定 {token, gistId}

// 同期で共有するキー（実施済みdone・ツールON/OFF・最後に選んだタブは端末ごとなので除外）
const SYNC_KEYS = [
  STORAGE_KEY_ALL, STORAGE_KEY_PRESETS, STORAGE_KEY_ICONS, STORAGE_KEY_GROUPS,
  STORAGE_KEY_CUSTOM, STORAGE_KEY_MASTER, STORAGE_KEY_ORDER
];
const GIST_FILENAME = 'ne_quick_access_data.json';
const BAR_SELECTOR = '#original_status_list';

let allItems = { orig: [], save: [], custom: [] };
let presets = [];
let activePresetId = null;
let iconMap = {};   // {'type:id': '絵文字'}
let editingPresetId = null;  // 設定モーダルで編集中のタブ
let commonGroups = [];  // 全タブ共通の行リスト [{id, name}]
let trackOn = false;    // クリック記録ON/OFF
let doneMap = {};       // 実施済み {'type:id': true}
let toolEnabled = true; // ツール自体のON/OFF（デフォルトON）
let masterAssign = {};  // 行割り当てマスター（新タブの初期値）
let orderMap = {};      // 並び順 {'type:id': 数値}
let observer = null;

// =====================================================
// メッセージ受信（ポップアップからの一覧取得依頼用に残す）
// =====================================================
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === 'fetchAll') {
    fetchAll().then(sendResponse);
    return true;
  }
  return false;
});

// =====================================================
// 初期化
// =====================================================
(async function init() {
  injectStyles();
  await loadData();
  applyBarOverride();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[STORAGE_KEY_ALL] || changes[STORAGE_KEY_PRESETS] || changes[STORAGE_KEY_ACTIVE] || changes[STORAGE_KEY_ICONS] || changes[STORAGE_KEY_GROUPS] || changes[STORAGE_KEY_TRACK] || changes[STORAGE_KEY_DONE] || changes[STORAGE_KEY_ENABLED] || changes[STORAGE_KEY_CUSTOM] || changes[STORAGE_KEY_MASTER] || changes[STORAGE_KEY_ORDER]) {
      loadData().then(() => {
        applyBarOverride();
        // 設定モーダルが開いていれば中身も更新
        if (document.getElementById('ne-quick-modal')) refreshModalBody();
      });
    }
  });

  setupBarObserver();
})();

async function loadData() {
  const data = await chrome.storage.local.get([STORAGE_KEY_ALL, STORAGE_KEY_PRESETS, STORAGE_KEY_ACTIVE, STORAGE_KEY_ICONS, STORAGE_KEY_GROUPS, STORAGE_KEY_TRACK, STORAGE_KEY_DONE, STORAGE_KEY_ENABLED, STORAGE_KEY_CUSTOM, STORAGE_KEY_MASTER, STORAGE_KEY_ORDER]);
  allItems = data[STORAGE_KEY_ALL] || { orig: [], save: [], custom: [] };
  allItems.custom = data[STORAGE_KEY_CUSTOM] || [];
  presets = data[STORAGE_KEY_PRESETS] || [];
  activePresetId = data[STORAGE_KEY_ACTIVE] || (presets[0]?.id ?? null);
  iconMap = data[STORAGE_KEY_ICONS] || {};
  commonGroups = data[STORAGE_KEY_GROUPS] || [];
  trackOn = data[STORAGE_KEY_TRACK] || false;
  doneMap = data[STORAGE_KEY_DONE] || {};
  toolEnabled = data[STORAGE_KEY_ENABLED] !== false;  // 未設定ならON
  masterAssign = data[STORAGE_KEY_MASTER] || {};
  orderMap = data[STORAGE_KEY_ORDER] || {};

  // 旧バージョンの preset.groups があれば共通グループへ統合（初回のみ）
  if (commonGroups.length === 0) {
    const seen = new Set();
    presets.forEach(p => {
      (p.groups || []).forEach(g => {
        if (!seen.has(g.name) && g.name) {
          commonGroups.push({ id: g.id, name: g.name });
          seen.add(g.name);
        }
      });
    });
    if (commonGroups.length > 0) {
      await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups });
    }
  }

  // プリセットが無ければ「全表示」を作る（全オリステ+全保存を自動投入）
  if (presets.length === 0) {
    const allOrig = (allItems.orig || []).map(it => String(it.id));
    const allSave = (allItems.save || []).map(it => String(it.id));
    presets = [{ id: genId(), name: '全表示', picks: { orig: allOrig, save: allSave }, isAll: true }];
    activePresetId = presets[0].id;
    await saveAll();
  }

  // 「全表示」タブが存在しなければ先頭に追加（既存ユーザー向けマイグレーション）
  if (!presets.some(p => p.isAll)) {
    const allOrig = (allItems.orig || []).map(it => String(it.id));
    const allSave = (allItems.save || []).map(it => String(it.id));
    presets.unshift({ id: genId(), name: '全表示', picks: { orig: allOrig, save: allSave }, isAll: true });
    await saveAll();
  }
  if (!presets.find(p => p.id === activePresetId)) {
    activePresetId = presets[0].id;
    await chrome.storage.local.set({ [STORAGE_KEY_ACTIVE]: activePresetId });
  }

  // 既存プリセットに assign が無ければ補完（groupsは共通管理に移行したので不要）
  let migrated = false;
  presets.forEach(p => {
    if (p.groups) { delete p.groups; migrated = true; }  // 旧フィールド除去
  });
  if (migrated) await saveAll();
}

async function saveAll() {
  await chrome.storage.local.set({
    [STORAGE_KEY_PRESETS]: presets,
    [STORAGE_KEY_ACTIVE]: activePresetId
  });
}

function getActivePreset() {
  return presets.find(p => p.id === activePresetId) || presets[0] || null;
}

// =====================================================
// バー差し替え（タブ + 設定ボタン + ボタン群）
// =====================================================
function applyBarOverride() {
  const bar = document.querySelector(BAR_SELECTOR);
  if (!bar) return;

  if (!bar.dataset.neQuickOriginal) {
    bar.dataset.neQuickOriginal = bar.innerHTML;
  }

  // ツールOFF：ネクストエンジン本来のバーに戻す
  if (!toolEnabled) {
    bar.classList.remove('ne-quick-bar');
    bar.dataset.neQuickApplied = 'off';
    bar.innerHTML = bar.dataset.neQuickOriginal;
    return;
  }

  bar.dataset.neQuickApplied = '1';
  bar.classList.add('ne-quick-bar');

  rebuildBar(bar);
}

// タブHTML（通常表示 + 各プリセット）を生成
function buildTabsHtml() {
  const presetTabs = presets.map(p => {
    const total = (p.picks.orig?.length || 0) + (p.picks.save?.length || 0);
    const active = p.id === activePresetId ? ' active' : '';
    return `<span class="neq-tab${active}" data-preset-id="${escapeAttr(p.id)}">${escapeHtml(p.name)}<span class="neq-tab-count">${total}</span></span>`;
  }).join('');
  return presetTabs;
}

// タブ切り替えハンドラ（共通）
function attachTabHandlers(bar) {
  bar.querySelectorAll('.neq-tab').forEach(tab => {
    tab.addEventListener('click', async () => {
      activePresetId = tab.dataset.presetId;
      await chrome.storage.local.set({ [STORAGE_KEY_ACTIVE]: activePresetId });
    });
  });
}

// 上段（タブ + 記録ボタン + 設定）を生成
function buildTopRow() {
  const tabsHtml = buildTabsHtml();
  const trackLabel = trackOn ? '記録 ON' : '記録 OFF';
  const trackCls = trackOn ? ' on' : '';
  return `
    <div class="neq-top-row">
      <div class="neq-tabs">${tabsHtml}</div>
      <div class="neq-top-actions">
        <button class="neq-track-btn${trackCls}" id="neq-track-toggle" title="クリックした項目を実施済みに記録">${trackLabel}</button>
        <button class="neq-clear-btn" id="neq-clear-done" title="実施済みの記録をすべて消す">クリア</button>
        <button class="neq-settings-btn" id="neq-open-settings">⚙ 設定</button>
      </div>
    </div>
  `;
}

// 記録ボタン・クリアボタンのハンドラ
function attachTopActionHandlers(bar) {
  const t = bar.querySelector('#neq-track-toggle');
  if (t) t.addEventListener('click', async () => {
    trackOn = !trackOn;
    await chrome.storage.local.set({ [STORAGE_KEY_TRACK]: trackOn });
  });
  const cl = bar.querySelector('#neq-clear-done');
  if (cl) cl.addEventListener('click', async () => {
    if (Object.keys(doneMap).length === 0) return;
    if (!confirm('実施済みの記録をすべてクリアしますか？')) return;
    doneMap = {};
    await chrome.storage.local.set({ [STORAGE_KEY_DONE]: doneMap });
  });
  const settingsBtn = bar.querySelector('#neq-open-settings');
  if (settingsBtn) settingsBtn.addEventListener('click', openSettingsModal);
}

function rebuildBar(bar) {
  const preset = getActivePreset();

  // 上段：タブ + 記録/クリア + 設定
  const topRow = buildTopRow();

  // 下段：グループ（行）ごとに描画
  const items = buildItemList(preset);
  let buttonsHtml;
  if (items.length === 0) {
    buttonsHtml = `<div class="neq-bar-empty">「${escapeHtml(preset ? preset.name : '')}」に表示する項目がありません。右上の「⚙ 設定」から選択してください。</div>`;
  } else {
    buttonsHtml = buildGroupedRows(preset, items);
  }

  bar.innerHTML = topRow + buttonsHtml;

  // タブ切り替え
  attachTabHandlers(bar);

  // 記録/クリア/設定ボタン
  attachTopActionHandlers(bar);

  // ボタン群
  attachButtonHandlers(bar);
}

function buildItemList(preset) {
  if (!preset) return [];
  const origMap = new Map((allItems.orig || []).map(it => [String(it.id), it]));
  const saveMap = new Map((allItems.save || []).map(it => [String(it.id), it]));
  const customMap = new Map((allItems.custom || []).map(it => [String(it.id), it]));
  const items = [];
  (preset.picks.orig || []).forEach(id => {
    const it = origMap.get(String(id));
    if (it) items.push({ ...it, type: 'orig' });
  });
  (preset.picks.save || []).forEach(id => {
    const it = saveMap.get(String(id));
    if (it) items.push({ ...it, type: 'save' });
  });
  (preset.picks.custom || []).forEach(id => {
    const it = customMap.get(String(id));
    if (it) items.push({ ...it, type: 'custom' });
  });
  return items;
}

// グループ（行）ごとにまとめてHTML生成
function buildGroupedRows(preset, items) {
  const groups = commonGroups || [];            // 全タブ共通の行リスト [{id, name}]
  const assign = masterAssign || {};            // 全タブ共通の行割り当て {'type:id': groupId}

  // 行内の並び順ソート：数字が小さい順、数字なしは後ろ（元の順を維持）
  const sortByOrder = (arr) => {
    return arr
      .map((it, idx) => ({ it, idx }))
      .sort((a, b) => {
        const oa = orderMap[a.it.type + ':' + a.it.id];
        const ob = orderMap[b.it.type + ':' + b.it.id];
        const hasA = oa !== undefined && oa !== '' && oa !== null;
        const hasB = ob !== undefined && ob !== '' && ob !== null;
        if (hasA && hasB) return Number(oa) - Number(ob) || a.idx - b.idx;
        if (hasA) return -1;   // 数字ありが前
        if (hasB) return 1;
        return a.idx - b.idx;  // どちらも数字なしは元の順
      })
      .map(x => x.it);
  };

  // 各グループに属する項目を集める
  const rows = [];
  groups.forEach(g => {
    const groupItems = sortByOrder(items.filter(it => assign[it.type + ':' + it.id] === g.id));
    rows.push({ group: g, items: groupItems });
  });

  // どのグループにも属さない項目は「未分類」行へ
  const assignedIds = new Set(items
    .filter(it => groups.some(g => assign[it.type + ':' + it.id] === g.id))
    .map(it => it.type + ':' + it.id));
  const unassigned = sortByOrder(items.filter(it => !assignedIds.has(it.type + ':' + it.id)));

  let html = '';
  rows.forEach(row => {
    if (row.items.length === 0) return; // 空の行は出さない
    const label = `<span class="neq-row-label">${escapeHtml(row.group.name || '')}</span>`;
    html += `<div class="neq-row" data-group-id="${escapeAttr(row.group.id)}">${label}<div class="neq-buttons">${row.items.map(buildButton).join('')}</div></div>`;
  });

  if (unassigned.length > 0) {
    // 他に行がある場合だけ「未分類」ラベルを出す。無ければ空ラベル枠（位置揃え用）
    const hasOtherRows = rows.some(r => r.items.length > 0);
    const label = hasOtherRows
      ? `<span class="neq-row-label neq-row-label-other">未分類</span>`
      : `<span class="neq-row-label"></span>`;
    html += `<div class="neq-row" data-group-id="">${label}<div class="neq-buttons">${unassigned.map(buildButton).join('')}</div></div>`;
  }

  return `<div class="neq-rows">${html}</div>`;
}

function buildButton(item) {
  let typeClass = 'neq-btn-orig';
  if (item.type === 'save') typeClass = 'neq-btn-save';
  else if (item.type === 'custom') typeClass = 'neq-btn-custom';
  const idAttr = item.type === 'orig' ? `id="original_status_${escapeAttr(item.id)}"` : '';
  const icon = getItemIcon(item.type, item.id, item.name);
  const iconSpan = icon ? `<span class="neq-btn-icon">${renderIconHTML(icon, 14)}</span>` : '';
  const doneClass = doneMap[item.type + ':' + item.id] ? ' neq-done' : '';
  return `<a ${idAttr} class="badge neq-btn ${typeClass}${doneClass}" data-ne-type="${item.type}" data-ne-id="${escapeAttr(item.id)}" href="javascript:void(0);" draggable="true" title="${escapeAttr(item.name)} (${escapeAttr(item.id)})">${iconSpan}${escapeHtml(item.name)}</a>`;
}

// =====================================================
// ボタン：クリック実行 + ドラッグ並び替え
// =====================================================
function attachButtonHandlers(bar) {
  const wraps = bar.querySelectorAll('.neq-buttons');
  if (!wraps.length) return;

  const allBtns = bar.querySelectorAll('.neq-btn');
  allBtns.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      if (btn.classList.contains('neq-dragging')) return;
      bar.querySelectorAll('.neq-btn').forEach(b => b.classList.remove('badge-info'));
      btn.classList.add('badge-info');
      executeFromPage(btn.dataset.neType, btn.dataset.neId);

      // クリック記録ONなら実施済みにマーク
      if (trackOn) {
        const key = btn.dataset.neType + ':' + btn.dataset.neId;
        doneMap[key] = true;
        btn.classList.add('neq-done');
        await chrome.storage.local.set({ [STORAGE_KEY_DONE]: doneMap });
      }
    });

    btn.addEventListener('dragstart', (e) => {
      btn.classList.add('neq-dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    btn.addEventListener('dragend', () => {
      btn.classList.remove('neq-dragging');
      bar.querySelectorAll('.neq-drag-over').forEach(b => b.classList.remove('neq-drag-over'));
    });
    btn.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
    btn.addEventListener('dragenter', (e) => {
      e.preventDefault();
      const d = bar.querySelector('.neq-dragging');
      if (d && btn !== d) btn.classList.add('neq-drag-over');
    });
    btn.addEventListener('dragleave', () => btn.classList.remove('neq-drag-over'));
    btn.addEventListener('drop', async (e) => {
      e.preventDefault(); e.stopPropagation();
      btn.classList.remove('neq-drag-over');
      const d = bar.querySelector('.neq-dragging');
      if (!d || d === btn) return;
      const rect = btn.getBoundingClientRect();
      if (e.clientX < rect.left + rect.width / 2) {
        btn.parentNode.insertBefore(d, btn);
      } else {
        btn.parentNode.insertBefore(d, btn.nextSibling);
      }
      await saveBarLayout(bar);
    });
  });

  // 空の行（.neq-buttonsだけど中身が無い）にもドロップできるように
  wraps.forEach(wrap => {
    wrap.addEventListener('dragover', (e) => { e.preventDefault(); });
    wrap.addEventListener('drop', async (e) => {
      const d = bar.querySelector('.neq-dragging');
      if (!d) return;
      // ボタン以外の余白にドロップされた場合は行末に追加
      if (e.target === wrap) {
        wrap.appendChild(d);
        await saveBarLayout(bar);
      }
    });
  });
}

// バー上のDOM順とグループ所属をプリセットに保存
async function saveBarLayout(bar) {
  const preset = getActivePreset();
  if (!preset) return;

  const newOrig = [], newSave = [], newCustom = [];

  bar.querySelectorAll('.neq-row').forEach(row => {
    row.querySelectorAll('.neq-btn').forEach(b => {
      if (b.dataset.neType === 'orig') newOrig.push(b.dataset.neId);
      else if (b.dataset.neType === 'save') newSave.push(b.dataset.neId);
      else if (b.dataset.neType === 'custom') newCustom.push(b.dataset.neId);
    });
  });

  preset.picks.orig = newOrig;
  preset.picks.save = newSave;
  preset.picks.custom = newCustom;

  // 行割り当ては全タブ共通（masterAssign）を更新
  bar.querySelectorAll('.neq-row').forEach(row => {
    const gid = row.dataset.groupId || '';
    row.querySelectorAll('.neq-btn').forEach(b => {
      const key = b.dataset.neType + ':' + b.dataset.neId;
      if (gid) masterAssign[key] = gid;
      else delete masterAssign[key];
    });
  });

  await chrome.storage.local.set({
    [STORAGE_KEY_PRESETS]: presets,
    [STORAGE_KEY_MASTER]: masterAssign
  });
}

// =====================================================
// 設定モーダル（大画面）
// =====================================================
function openSettingsModal() {
  if (document.getElementById('ne-quick-modal')) return; // 既に開いてる

  const overlay = document.createElement('div');
  overlay.id = 'ne-quick-modal';
  overlay.className = 'neq-modal-overlay';
  overlay.innerHTML = `
    <div class="neq-modal">
      <div class="neq-modal-header">
        <span class="neq-modal-title">NE Quick Access 設定</span>
        <button class="neq-modal-close" id="neq-modal-close">×</button>
      </div>
      <div class="neq-modal-toolbar">
        <button class="neq-tbtn neq-tbtn-fetch" id="neq-modal-fetch">↻ 一覧を再取得</button>
        <button class="neq-tbtn neq-tbtn-edit" id="neq-add-custom">＋項目を追加</button>
        <button class="neq-tbtn neq-tbtn-edit" id="neq-edit-rows">行の編集</button>
        <button class="neq-tbtn neq-tbtn-edit" id="neq-edit-tabs">タブの編集</button>
        <button class="neq-tbtn neq-tbtn-sync" id="neq-cloud-sync">☁ クラウド同期</button>
        <span class="neq-toolbar-hint">タブを選び、表示する項目にチェック→「表示する行」で何行目に置くか選べます</span>
      </div>
      <div class="neq-modal-body" id="neq-modal-body"></div>
      <div class="neq-modal-footer">
        <span class="neq-footer-hint">変更は自動保存されます</span>
        <button class="neq-done-btn" id="neq-modal-done">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('neq-modal-close').addEventListener('click', closeSettingsModal);
  document.getElementById('neq-modal-done').addEventListener('click', closeSettingsModal);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeSettingsModal(); });
  document.getElementById('neq-modal-fetch').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.textContent = '取得中...';
    btn.disabled = true;
    const r = await fetchAll();
    if (r.ok) {
      await loadData();
      refreshModalBody();
      btn.textContent = `↻ 再取得（オリステ${r.orig.length}/保存${r.save.length}）`;
    } else {
      btn.textContent = '取得失敗';
      alert('取得に失敗しました: ' + (r.error || ''));
    }
    setTimeout(() => { btn.textContent = '↻ 一覧を再取得'; btn.disabled = false; }, 2000);
  });

  // 自由項目を追加
  document.getElementById('neq-add-custom').addEventListener('click', async () => {
    const name = prompt('自由項目の名前を入力してください（例：RPA実施）');
    if (!name || !name.trim()) return;
    allItems.custom = allItems.custom || [];
    const newId = 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
    allItems.custom.push({ id: newId, name: name.trim() });
    // 「全表示」タブには自動で追加
    presets.forEach(p => {
      if (p.isAll) {
        p.picks.custom = p.picks.custom || [];
        if (!p.picks.custom.includes(newId)) p.picks.custom.push(newId);
      }
    });
    await chrome.storage.local.set({
      [STORAGE_KEY_CUSTOM]: allItems.custom,
      [STORAGE_KEY_PRESETS]: presets
    });
    refreshModalBody();
  });

  // 行の編集モーダルを開く
  document.getElementById('neq-edit-rows').addEventListener('click', openRowEditor);

  // タブの編集モーダルを開く
  document.getElementById('neq-edit-tabs').addEventListener('click', openTabEditor);

  // クラウド同期モーダルを開く
  document.getElementById('neq-cloud-sync').addEventListener('click', openSyncModal);

  refreshModalBody();
}

function closeSettingsModal() {
  const m = document.getElementById('ne-quick-modal');
  if (m) m.remove();
}

// =====================================================
// クラウド同期モーダル
// =====================================================
async function openSyncModal() {
  const existing = document.getElementById('neq-sync-modal');
  if (existing) existing.remove();

  const cfg = await getSyncConfig();

  const overlay = document.createElement('div');
  overlay.id = 'neq-sync-modal';
  overlay.className = 'neq-modal-overlay neq-row-overlay';
  overlay.innerHTML = `
    <div class="neq-row-modal" style="width:480px;">
      <div class="neq-modal-header">
        <span class="neq-modal-title">☁ クラウド同期（GitHub Gist）</span>
        <button class="neq-modal-close" id="neq-sync-close">×</button>
      </div>
      <div class="neq-row-body">
        <div class="neq-sync-field">
          <label>GitHub アクセストークン</label>
          <input type="password" id="neq-sync-token" value="${escapeAttr(cfg.token || '')}" placeholder="ghp_xxxxxxxx" autocomplete="off">
        </div>
        <div class="neq-sync-field">
          <label>Gist ID</label>
          <input type="text" id="neq-sync-gistid" value="${escapeAttr(cfg.gistId || '')}" placeholder="例: 1a2b3c4d5e6f...">
        </div>
        <button class="neq-sync-save" id="neq-sync-save">設定を保存</button>
        <div class="neq-sync-actions">
          <button class="neq-sync-btn neq-sync-push" id="neq-sync-push">⬆ 送信（このPCの設定をアップロード）</button>
          <button class="neq-sync-btn neq-sync-pull" id="neq-sync-pull">⬇ 受信（クラウドから取り込む）</button>
        </div>
        <div class="neq-sync-status" id="neq-sync-status"></div>
        <div class="neq-sync-help">
          <strong>送信</strong>＝今のPCの設定をクラウドに上書き保存。<br>
          <strong>受信</strong>＝クラウドの設定をこのPCに反映（今の設定は上書きされます）。<br>
          ※トークンとGist IDは各PCに一度入力すれば保存されます。
        </div>
      </div>
      <div class="neq-modal-footer">
        <span class="neq-footer-hint">トークン・Gist IDは自動保存されます</span>
        <button class="neq-done-btn" id="neq-sync-done">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  document.getElementById('neq-sync-close').addEventListener('click', close);
  document.getElementById('neq-sync-done').addEventListener('click', close);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

  const tokenInput = document.getElementById('neq-sync-token');
  const gistInput = document.getElementById('neq-sync-gistid');
  const status = document.getElementById('neq-sync-status');
  const setStatus = (msg, cls) => { status.textContent = msg; status.className = 'neq-sync-status ' + (cls || ''); };

  // 入力を自動保存
  const saveCfg = async () => {
    await saveSyncConfig({ token: tokenInput.value.trim(), gistId: gistInput.value.trim() });
  };
  tokenInput.addEventListener('change', saveCfg);
  gistInput.addEventListener('change', saveCfg);

  // 設定を保存ボタン
  document.getElementById('neq-sync-save').addEventListener('click', async () => {
    if (!tokenInput.value.trim() || !gistInput.value.trim()) {
      setStatus('✗ トークンとGist IDの両方を入力してください', 'err');
      return;
    }
    await saveCfg();
    setStatus('✓ トークンとGist IDを保存しました', 'ok');
  });

  // 送信
  document.getElementById('neq-sync-push').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    if (!tokenInput.value.trim() || !gistInput.value.trim()) {
      setStatus('✗ 先にトークンとGist IDを入力・保存してください', 'err');
      return;
    }
    await saveCfg();
    btn.disabled = true; setStatus('⬆ 送信中... しばらくお待ちください', 'loading');
    const r = await syncPush();
    btn.disabled = false;
    if (r.ok) setStatus('✓ 送信が完了しました！（' + new Date(r.updatedAt).toLocaleString() + '）\n他のPCで「受信」すると反映されます', 'ok');
    else setStatus('✗ 送信に失敗しました： ' + r.error, 'err');
  });

  // 受信
  document.getElementById('neq-sync-pull').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    if (!tokenInput.value.trim() || !gistInput.value.trim()) {
      setStatus('✗ 先にトークンとGist IDを入力・保存してください', 'err');
      return;
    }
    await saveCfg();
    if (!confirm('クラウドの設定をこのPCに反映します。\n現在の設定は上書きされますがよろしいですか？')) return;
    btn.disabled = true; setStatus('⬇ 受信中... しばらくお待ちください', 'loading');
    const r = await syncPull();
    btn.disabled = false;
    if (r.ok) {
      setStatus('✓ 受信が完了しました！設定をこのPCに反映しました' + (r.updatedAt ? '（クラウド更新日時: ' + new Date(r.updatedAt).toLocaleString() + '）' : ''), 'ok');
      refreshModalBody();
    } else {
      setStatus('✗ 受信に失敗しました： ' + r.error, 'err');
    }
  });
}

// =====================================================
// タブ編集モーダル
// =====================================================
function openTabEditor() {
  const existing = document.getElementById('neq-tab-editor');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'neq-tab-editor';
  overlay.className = 'neq-modal-overlay neq-row-overlay';
  overlay.innerHTML = `
    <div class="neq-row-modal">
      <div class="neq-modal-header">
        <span class="neq-modal-title">タブの編集</span>
        <button class="neq-modal-close" id="neq-tab-close">×</button>
      </div>
      <div class="neq-row-body" id="neq-tab-body"></div>
      <div class="neq-modal-footer">
        <span class="neq-footer-hint">ドラッグで並び替え・変更は自動保存</span>
        <button class="neq-done-btn" id="neq-tab-done">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('neq-tab-close').addEventListener('click', () => { overlay.remove(); refreshModalBody(); });
  document.getElementById('neq-tab-done').addEventListener('click', () => { overlay.remove(); refreshModalBody(); });
  overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); refreshModalBody(); } });

  refreshTabEditor();
}

function refreshTabEditor() {
  const body = document.getElementById('neq-tab-body');
  if (!body) return;

  const itemsHtml = presets.map((p, i) => {
    if (p.isAll) {
      return `<div class="neq-row-item" style="background:#f3f0e8;">
        <span class="neq-row-handle" style="visibility:hidden;">⋮⋮</span>
        <span class="neq-row-num">★</span>
        <input type="text" class="neq-row-name" value="${escapeAttr(p.name)}" disabled style="color:#6b5a3e;">
        <span style="font-size:11px;color:#999;flex-shrink:0;">固定🔒</span>
      </div>`;
    }
    return `<div class="neq-row-item" draggable="true" data-preset-id="${escapeAttr(p.id)}">
      <span class="neq-row-handle" title="ドラッグで並び替え">⋮⋮</span>
      <span class="neq-row-num">${i}</span>
      <input type="text" class="neq-tab-name" value="${escapeAttr(p.name)}" data-preset-id="${escapeAttr(p.id)}" placeholder="タブ名">
      <button class="neq-row-del" data-preset-id="${escapeAttr(p.id)}" title="このタブを削除">×</button>
    </div>`;
  }).join('');

  body.innerHTML = `
    <div class="neq-row-list" id="neq-tab-list">${itemsHtml}</div>
    <button class="neq-row-add-btn" id="neq-tab-add">＋ タブを追加</button>
  `;

  // 追加
  body.querySelector('#neq-tab-add').addEventListener('click', async () => {
    const name = prompt('新しいタブの名前を入力してください', `使用分${presets.length}`);
    if (!name || !name.trim()) return;
    const initPicks = { orig: [], save: [], custom: [] };
    Object.keys(masterAssign).forEach(key => {
      const gid = masterAssign[key];
      if (!gid) return;
      const [type, id] = key.split(':');
      if (initPicks[type]) initPicks[type].push(id);
    });
    presets.push({ id: genId(), name: name.trim(), picks: initPicks });
    await saveAll();
    refreshTabEditor();
  });

  // 名前変更
  body.querySelectorAll('.neq-tab-name').forEach(input => {
    input.addEventListener('change', async () => {
      const p = presets.find(x => x.id === input.dataset.presetId);
      if (p) { const v = input.value.trim(); if (v) { p.name = v; await saveAll(); } }
    });
  });

  // 削除
  body.querySelectorAll('.neq-row-del').forEach(btn => {
    btn.addEventListener('click', async () => {
      const pid = btn.dataset.presetId;
      const p = presets.find(x => x.id === pid);
      if (!p) return;
      const nonAll = presets.filter(x => !x.isAll);
      if (nonAll.length <= 1) { alert('全表示以外のタブが最低1つ必要です'); return; }
      if (!confirm(`タブ「${p.name}」を削除しますか？`)) return;
      presets = presets.filter(x => x.id !== pid);
      if (activePresetId === pid) activePresetId = presets[0].id;
      if (editingPresetId === pid) editingPresetId = presets[0].id;
      await saveAll();
      refreshTabEditor();
    });
  });

  // ドラッグ並び替え（全表示は固定）
  const list = body.querySelector('#neq-tab-list');
  if (list) {
    let dragged = null;
    list.querySelectorAll('.neq-row-item[draggable="true"]').forEach(item => {
      item.addEventListener('dragstart', () => { dragged = item; item.classList.add('neq-row-dragging'); });
      item.addEventListener('dragend', () => {
        item.classList.remove('neq-row-dragging');
        list.querySelectorAll('.neq-row-over').forEach(x => x.classList.remove('neq-row-over'));
      });
      item.addEventListener('dragover', (e) => { e.preventDefault(); });
      item.addEventListener('dragenter', (e) => { e.preventDefault(); if (dragged && item !== dragged) item.classList.add('neq-row-over'); });
      item.addEventListener('dragleave', () => item.classList.remove('neq-row-over'));
      item.addEventListener('drop', async (e) => {
        e.preventDefault();
        item.classList.remove('neq-row-over');
        if (!dragged || dragged === item) return;
        const rect = item.getBoundingClientRect();
        if (e.clientY < rect.top + rect.height / 2) item.parentNode.insertBefore(dragged, item);
        else item.parentNode.insertBefore(dragged, item.nextSibling);
        const newOrder = [...list.querySelectorAll('.neq-row-item[draggable="true"]')].map(x => x.dataset.presetId);
        presets.sort((a, b) => {
          if (a.isAll) return -1;
          if (b.isAll) return 1;
          return newOrder.indexOf(a.id) - newOrder.indexOf(b.id);
        });
        await saveAll();
        refreshTabEditor();
      });
    });
  }
}

// =====================================================
// 行（グループ）編集モーダル
// =====================================================
function openRowEditor() {
  const existing = document.getElementById('neq-row-editor');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'neq-row-editor';
  overlay.className = 'neq-modal-overlay neq-row-overlay';
  overlay.innerHTML = `
    <div class="neq-row-modal">
      <div class="neq-modal-header">
        <span class="neq-modal-title">行の編集</span>
        <button class="neq-modal-close" id="neq-row-close">×</button>
      </div>
      <div class="neq-row-body" id="neq-row-body"></div>
      <div class="neq-modal-footer">
        <span class="neq-footer-hint">ドラッグで並び替え・変更は自動保存</span>
        <button class="neq-done-btn" id="neq-row-done">閉じる</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('neq-row-close').addEventListener('click', () => overlay.remove());
  document.getElementById('neq-row-done').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

  refreshRowEditor();
}

function refreshRowEditor() {
  const body = document.getElementById('neq-row-body');
  if (!body) return;

  const rowsHtml = commonGroups.map((g, i) => `
    <div class="neq-row-item" draggable="true" data-group-id="${escapeAttr(g.id)}">
      <span class="neq-row-handle" title="ドラッグで並び替え">⋮⋮</span>
      <span class="neq-row-num">${i + 1}</span>
      <input type="text" class="neq-row-name" value="${escapeAttr(g.name)}" data-group-id="${escapeAttr(g.id)}" placeholder="行の名前（空欄でもOK）">
      <button class="neq-row-del" data-group-id="${escapeAttr(g.id)}" title="この行を削除">×</button>
    </div>
  `).join('');

  body.innerHTML = `
    <div class="neq-row-list" id="neq-row-list">${rowsHtml || '<div class="neq-row-empty">行がありません。下のボタンで追加してください。</div>'}</div>
    <button class="neq-row-add-btn" id="neq-row-add">＋ 行を追加</button>
  `;

  // 追加
  body.querySelector('#neq-row-add').addEventListener('click', async () => {
    commonGroups.push({ id: genId(), name: '' });
    await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups });
    refreshRowEditor();
  });

  // 名前変更
  body.querySelectorAll('.neq-row-name').forEach(input => {
    input.addEventListener('change', async () => {
      const g = commonGroups.find(x => x.id === input.dataset.groupId);
      if (g) { g.name = input.value.trim(); await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups }); }
    });
  });

  // 削除
  body.querySelectorAll('.neq-row-del').forEach(btn => {
    btn.addEventListener('click', async () => {
      const gid = btn.dataset.groupId;
      const g = commonGroups.find(x => x.id === gid);
      if (!confirm(`行「${g?.name || '(無名)'}」を削除しますか？`)) return;
      commonGroups = commonGroups.filter(x => x.id !== gid);
      Object.keys(masterAssign).forEach(k => { if (masterAssign[k] === gid) delete masterAssign[k]; });
      await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups, [STORAGE_KEY_MASTER]: masterAssign });
      refreshRowEditor();
    });
  });

  // ドラッグ並び替え
  const list = body.querySelector('#neq-row-list');
  if (list) {
    let dragged = null;
    list.querySelectorAll('.neq-row-item').forEach(item => {
      item.addEventListener('dragstart', () => { dragged = item; item.classList.add('neq-row-dragging'); });
      item.addEventListener('dragend', () => {
        item.classList.remove('neq-row-dragging');
        list.querySelectorAll('.neq-row-over').forEach(x => x.classList.remove('neq-row-over'));
      });
      item.addEventListener('dragover', (e) => { e.preventDefault(); });
      item.addEventListener('dragenter', (e) => { e.preventDefault(); if (dragged && item !== dragged) item.classList.add('neq-row-over'); });
      item.addEventListener('dragleave', () => item.classList.remove('neq-row-over'));
      item.addEventListener('drop', async (e) => {
        e.preventDefault();
        item.classList.remove('neq-row-over');
        if (!dragged || dragged === item) return;
        const rect = item.getBoundingClientRect();
        if (e.clientY < rect.top + rect.height / 2) item.parentNode.insertBefore(dragged, item);
        else item.parentNode.insertBefore(dragged, item.nextSibling);
        const newOrder = [...list.querySelectorAll('.neq-row-item')].map(x => x.dataset.groupId);
        commonGroups.sort((a, b) => newOrder.indexOf(a.id) - newOrder.indexOf(b.id));
        await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups });
        refreshRowEditor();
      });
    });
  }
}


function refreshModalBody() {
  const body = document.getElementById('neq-modal-body');
  if (!body) return;
  try {
    _refreshModalBodyInner(body);
  } catch (e) {
    console.error('[NE Quick Access] 設定画面エラー:', e);
    const detail = (e && e.stack) ? String(e.stack).split('\n').slice(0, 3).join('<br>') : String(e && e.message || e);
    body.innerHTML = `<div class="neq-modal-empty">表示中にエラーが発生しました。<br>「↻ 一覧を再取得」を試すか、ページを再読み込みしてください。<br><small style="color:#c0392b;display:block;margin-top:8px;text-align:left;">${escapeHtml(detail)}</small></div>`;
  }
}

function _refreshModalBodyInner(body) {
  const allCount = (allItems.orig?.length || 0) + (allItems.save?.length || 0) + (allItems.custom?.length || 0);
  if (allCount === 0) {
    body.innerHTML = `
      <div class="neq-modal-empty">
        まだオリステ・保存検索の一覧を取得していません。<br>
        上の「↻ 一覧を再取得」ボタンを押してください。
      </div>`;
    return;
  }

  // 編集対象タブを決定
  if (!editingPresetId || editingPresetId === 'NORMAL' || !presets.find(p => p.id === editingPresetId)) {
    const validActive = (activePresetId && activePresetId !== 'NORMAL' && presets.find(p => p.id === activePresetId)) ? activePresetId : null;
    editingPresetId = validActive || presets[0].id;
  }
  const editing = presets.find(p => p.id === editingPresetId) || presets[0];

  // ===== タブ選択行 =====
  const tabChips = presets.map(p => {
    const isEditing = p.id === editingPresetId;
    const active = isEditing ? ' editing' : '';
    const handle = p.isAll ? '' : '<span class="neq-mtab-handle" title="ドラッグで並び替え">⋮⋮</span>';
    const draggableAttr = p.isAll ? '' : 'draggable="true"';
    return `<span class="neq-mtab${active}" ${draggableAttr} data-preset-id="${escapeAttr(p.id)}">
      ${handle}
      <span class="neq-mtab-select" data-preset-id="${escapeAttr(p.id)}">${escapeHtml(p.name)}</span>
      ${p.isAll ? '<span class="neq-mtab-lock" title="全表示タブは固定です">🔒</span>' : ''}
    </span>`;
  }).join('');

  // 行（グループ）管理は別モーダルに分離したので、ここでは出さない
  const groups = commonGroups || [];
  const groupMgrHtml = '';

  // ===== 項目テーブル =====
  const allList = [
    ...(allItems.orig || []).map(it => ({ ...it, type: 'orig' })),
    ...(allItems.save || []).map(it => ({ ...it, type: 'save' })),
    ...(allItems.custom || []).map(it => ({ ...it, type: 'custom' }))
  ];

  const isAll = editing.isAll;
  if (!editing.picks) editing.picks = { orig: [], save: [], custom: [] };
  const picksOrig = new Set(editing.picks.orig || []);
  const picksSave = new Set(editing.picks.save || []);
  const picksCustom = new Set(editing.picks.custom || []);
  const assign = masterAssign || {};  // 行割り当ては全タブ共通

  let rows, theadCols;

  if (isAll) {
    // ===== 全表示モード：全タブを列に並べた俯瞰チェック表 =====
    // 各タブの picks を Set 化
    const tabPickSets = presets.map(p => {
      if (!p.picks) p.picks = { orig: [], save: [], custom: [] };
      return {
        preset: p,
        orig: new Set(p.picks.orig || []),
        save: new Set(p.picks.save || []),
        custom: new Set(p.picks.custom || [])
      };
    });

    rows = allList.map(item => {
      const badgeClass = item.type === 'orig' ? 'neq-bdg-orig' : (item.type === 'save' ? 'neq-bdg-save' : 'neq-bdg-custom');
      const badgeText = item.type === 'orig' ? 'オリステ' : (item.type === 'save' ? '保存' : 'メモ');
      const curIcon = getItemIcon(item.type, item.id, item.name);
      const iconBtnLabel = curIcon ? renderIconHTML(curIcon, 16) : '<span class="neq-icon-none">なし</span>';

      const tabCells = tabPickSets.map(t => {
        if (t.preset.isAll) {
          return `<td class="neq-col-tab"><input type="checkbox" checked disabled title="全表示は全項目が自動で入ります"></td>`;
        }
        const set = item.type === 'orig' ? t.orig : (item.type === 'save' ? t.save : t.custom);
        const checked = set.has(String(item.id)) ? 'checked' : '';
        return `<td class="neq-col-tab"><input type="checkbox" class="neq-tabassign" data-preset-id="${escapeAttr(t.preset.id)}" data-type="${item.type}" data-id="${escapeAttr(item.id)}" ${checked}></td>`;
      }).join('');

      // マスター行プルダウン
      const mkey = item.type + ':' + item.id;
      const mcur = masterAssign[mkey] || '';
      const mopts = `<option value="">未分類</option>` + groups.map(g =>
        `<option value="${escapeAttr(g.id)}" ${mcur === g.id ? 'selected' : ''}>${escapeHtml(g.name || '(無名の行)')}</option>`
      ).join('');
      const masterCell = `<td class="neq-col-grp"><select class="neq-master-select" data-type="${item.type}" data-id="${escapeAttr(item.id)}">${mopts}</select></td>`;

      const ordVal = orderMap[mkey] !== undefined ? orderMap[mkey] : '';
      const orderCell = `<td class="neq-col-ord"><input type="number" class="neq-ord-input" data-type="${item.type}" data-id="${escapeAttr(item.id)}" value="${escapeAttr(String(ordVal))}" min="1" placeholder="-"></td>`;

      return `
        <tr>
          <td class="neq-col-name">
            <button class="neq-icon-btn" data-type="${item.type}" data-id="${escapeAttr(item.id)}" data-name="${escapeAttr(item.name)}" title="アイコンを変更">${iconBtnLabel}</button>
            <span class="neq-bdg ${badgeClass}">${badgeText}</span>
            <span class="neq-item-name" title="${escapeAttr(item.name)}">${escapeHtml(item.name)}</span>${item.type === 'custom' ? `<button class="neq-custom-del" data-id="${escapeAttr(item.id)}" title="この自由項目を削除">×</button>` : ''}
          </td>
          ${masterCell}
          ${orderCell}
          ${tabCells}
          <td class="neq-col-spacer"></td>
        </tr>`;
    }).join('');

    const tabColHeaders = presets.map(p => {
      if (p.isAll) {
        return `<th class="neq-col-tab">${escapeHtml(p.name)} 🔒</th>`;
      }
      return `<th class="neq-col-tab">
        <div class="neq-col-tab-head">
          <span>${escapeHtml(p.name)}</span>
          <label class="neq-colcheck-wrap" title="この列を全選択／全解除">
            <input type="checkbox" class="neq-colcheck" data-preset-id="${escapeAttr(p.id)}">
            <span class="neq-colcheck-label">全選択</span>
          </label>
        </div>
      </th>`;
    }).join('');
    theadCols = `<th class="neq-col-name">項目（全${allCount}件）</th><th class="neq-col-grp">表示する行</th><th class="neq-col-ord">順番</th>${tabColHeaders}<th class="neq-col-spacer"></th>`;

  } else {
    // ===== 個別タブモード：チェック + 行プルダウン =====
    rows = allList.map(item => {
      const badgeClass = item.type === 'orig' ? 'neq-bdg-orig' : (item.type === 'save' ? 'neq-bdg-save' : 'neq-bdg-custom');
      const badgeText = item.type === 'orig' ? 'オリステ' : (item.type === 'save' ? '保存' : 'メモ');
      const curIcon = getItemIcon(item.type, item.id, item.name);
      const iconBtnLabel = curIcon ? renderIconHTML(curIcon, 16) : '<span class="neq-icon-none">なし</span>';
      const key = item.type + ':' + item.id;

      const pickSet = item.type === 'orig' ? picksOrig : (item.type === 'save' ? picksSave : picksCustom);
      const checked = pickSet.has(String(item.id)) ? 'checked' : '';
      const checkCell = `<td class="neq-col-chk"><input type="checkbox" class="neq-assign" data-type="${item.type}" data-id="${escapeAttr(item.id)}" ${checked}></td>`;

      const cur = assign[key] || '';
      const opts = `<option value="">未分類</option>` + groups.map(g =>
        `<option value="${escapeAttr(g.id)}" ${cur === g.id ? 'selected' : ''}>${escapeHtml(g.name || '(無名の行)')}</option>`
      ).join('');
      const groupCell = `<td class="neq-col-grp"><select class="neq-grp-select" data-type="${item.type}" data-id="${escapeAttr(item.id)}">${opts}</select></td>`;

      const ordVal = orderMap[key] !== undefined ? orderMap[key] : '';
      const orderCell = `<td class="neq-col-ord"><input type="number" class="neq-ord-input" data-type="${item.type}" data-id="${escapeAttr(item.id)}" value="${escapeAttr(String(ordVal))}" min="1" placeholder="-"></td>`;

      return `
        <tr>
          <td class="neq-col-name">
            <button class="neq-icon-btn" data-type="${item.type}" data-id="${escapeAttr(item.id)}" data-name="${escapeAttr(item.name)}" title="アイコンを変更">${iconBtnLabel}</button>
            <span class="neq-bdg ${badgeClass}">${badgeText}</span>
            <span class="neq-item-name" title="${escapeAttr(item.name)}">${escapeHtml(item.name)}</span>${item.type === 'custom' ? `<button class="neq-custom-del" data-id="${escapeAttr(item.id)}" title="この自由項目を削除">×</button>` : ''}
          </td>
          ${checkCell}
          ${groupCell}
          ${orderCell}
          <td class="neq-col-spacer"></td>
        </tr>`;
    }).join('');

    theadCols = `<th class="neq-col-name">項目（全${allCount}件）</th><th class="neq-col-chk">表示</th><th class="neq-col-grp">表示する行</th><th class="neq-col-ord">順番</th><th class="neq-col-spacer"></th>`;
  }

  body.innerHTML = `
    <div class="neq-sticky-head">
      <div class="neq-tabmgr">
        <span class="neq-tabmgr-label">タブを選択:</span>
        ${tabChips}
        <button class="neq-mtab-add" id="neq-add-tab">＋ タブ追加</button>
      </div>
      ${groupMgrHtml}
    </div>
    <div class="neq-table-wrap">
      <table class="neq-table">
        <thead>
          <tr>${theadCols}</tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;

  // タブ選択
  body.querySelectorAll('.neq-mtab-select').forEach(el => {
    el.addEventListener('click', () => {
      editingPresetId = el.dataset.presetId;
      refreshModalBody();
    });
  });

  // タブのドラッグ並び替え（全表示タブは固定で動かせない）
  const tabmgr = body.querySelector('.neq-tabmgr');
  if (tabmgr) {
    let draggedTab = null;
    tabmgr.querySelectorAll('.neq-mtab[draggable="true"]').forEach(chip => {
      chip.addEventListener('dragstart', (e) => {
        draggedTab = chip;
        chip.classList.add('neq-mtab-dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      chip.addEventListener('dragend', () => {
        chip.classList.remove('neq-mtab-dragging');
        tabmgr.querySelectorAll('.neq-mtab-over').forEach(c => c.classList.remove('neq-mtab-over'));
      });
      chip.addEventListener('dragover', (e) => { e.preventDefault(); });
      chip.addEventListener('dragenter', (e) => {
        e.preventDefault();
        if (draggedTab && chip !== draggedTab && chip.getAttribute('draggable') === 'true') {
          chip.classList.add('neq-mtab-over');
        }
      });
      chip.addEventListener('dragleave', () => chip.classList.remove('neq-mtab-over'));
      chip.addEventListener('drop', async (e) => {
        e.preventDefault();
        chip.classList.remove('neq-mtab-over');
        if (!draggedTab || draggedTab === chip) return;
        const rect = chip.getBoundingClientRect();
        if (e.clientX < rect.left + rect.width / 2) chip.parentNode.insertBefore(draggedTab, chip);
        else chip.parentNode.insertBefore(draggedTab, chip.nextSibling);
        // 新しい順序を presets に反映（全表示タブは先頭固定）
        const newOrder = [...tabmgr.querySelectorAll('.neq-mtab')].map(c => c.dataset.presetId);
        presets.sort((a, b) => {
          if (a.isAll) return -1;  // 全表示は常に先頭
          if (b.isAll) return 1;
          return newOrder.indexOf(a.id) - newOrder.indexOf(b.id);
        });
        await saveAll();
        refreshModalBody();
      });
    });
  }

  // タブ追加
  body.querySelector('#neq-add-tab').addEventListener('click', async () => {
    const name = prompt('新しいタブの名前を入力してください', `使用分${presets.length + 1}`);
    if (!name || !name.trim()) return;
    // 行割り当てが共通設定されている項目を初期値として投入
    const initPicks = { orig: [], save: [], custom: [] };
    Object.keys(masterAssign).forEach(key => {
      const gid = masterAssign[key];
      if (!gid) return;
      const [type, id] = key.split(':');
      if (initPicks[type]) initPicks[type].push(id);
    });
    const np = { id: genId(), name: name.trim(), picks: initPicks };
    presets.push(np);
    editingPresetId = np.id;
    await saveAll();
    await loadData();
    refreshModalBody();
  });

  // タブ削除
  body.querySelectorAll('.neq-mtab-del').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (presets.length <= 1) { alert('最後のタブは削除できません'); return; }
      const p = presets.find(x => x.id === btn.dataset.presetId);
      if (!p) return;
      if (!confirm(`タブ「${p.name}」を削除しますか？`)) return;
      presets = presets.filter(x => x.id !== btn.dataset.presetId);
      if (activePresetId === btn.dataset.presetId) activePresetId = presets[0].id;
      if (editingPresetId === btn.dataset.presetId) editingPresetId = presets[0].id;
      await saveAll();
      await loadData();
      refreshModalBody();
    });
  });

  // 行（グループ）追加
  const addGrpBtn = body.querySelector('#neq-add-group');
  if (addGrpBtn) {
    addGrpBtn.addEventListener('click', async () => {
      const name = prompt('行の名前を入力してください（空欄でもOK）', `行${(commonGroups.length) + 1}`);
      if (name === null) return;
      commonGroups.push({ id: genId(), name: name.trim() });
      await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups });
      refreshModalBody();
    });
  }

  // 行名変更
  body.querySelectorAll('.neq-grp-name').forEach(input => {
    input.addEventListener('change', async () => {
      const g = commonGroups.find(x => x.id === input.dataset.groupId);
      if (g) { g.name = input.value.trim(); await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups }); }
    });
  });

  // 行削除
  body.querySelectorAll('.neq-grp-del').forEach(btn => {
    btn.addEventListener('click', async () => {
      const gid = btn.dataset.groupId;
      if (!confirm('この行を削除しますか？（全タブ共通の行が消えます）')) return;
      commonGroups = commonGroups.filter(x => x.id !== gid);
      // 共通の行割り当てからこの行を除去
      Object.keys(masterAssign).forEach(k => { if (masterAssign[k] === gid) delete masterAssign[k]; });
      await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups, [STORAGE_KEY_MASTER]: masterAssign });
      refreshModalBody();
    });
  });

  // 行（グループ）チップのドラッグ並び替え
  const grpList = body.querySelector('#neq-grp-list');
  if (grpList) {
    let dragged = null;
    grpList.querySelectorAll('.neq-grp').forEach(chip => {
      chip.addEventListener('dragstart', (e) => {
        dragged = chip;
        chip.classList.add('neq-grp-dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      chip.addEventListener('dragend', () => {
        chip.classList.remove('neq-grp-dragging');
        grpList.querySelectorAll('.neq-grp-over').forEach(c => c.classList.remove('neq-grp-over'));
      });
      chip.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
      chip.addEventListener('dragenter', (e) => {
        e.preventDefault();
        if (dragged && chip !== dragged) chip.classList.add('neq-grp-over');
      });
      chip.addEventListener('dragleave', () => chip.classList.remove('neq-grp-over'));
      chip.addEventListener('drop', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        chip.classList.remove('neq-grp-over');
        if (!dragged || dragged === chip) return;
        const rect = chip.getBoundingClientRect();
        if (e.clientX < rect.left + rect.width / 2) {
          chip.parentNode.insertBefore(dragged, chip);
        } else {
          chip.parentNode.insertBefore(dragged, chip.nextSibling);
        }
        // 新しい順序を commonGroups に反映
        const newOrder = [...grpList.querySelectorAll('.neq-grp')].map(c => c.dataset.groupId);
        commonGroups.sort((a, b) => newOrder.indexOf(a.id) - newOrder.indexOf(b.id));
        await chrome.storage.local.set({ [STORAGE_KEY_GROUPS]: commonGroups });
        // バーの行順も変わるので onChanged で反映される
      });
    });
  }

  // チェック割り当て（個別タブモード）
  body.querySelectorAll('.neq-assign').forEach(chk => {
    chk.addEventListener('change', async () => {
      const type = chk.dataset.type;
      const id = String(chk.dataset.id);
      const arr = editing.picks[type] || (editing.picks[type] = []);
      if (chk.checked) {
        if (!arr.includes(id)) arr.push(id);
      } else {
        const i = arr.indexOf(id);
        if (i >= 0) arr.splice(i, 1);
      }
      await saveAll();
    });
  });

  // チェック割り当て（全表示モード：各タブ列）
  body.querySelectorAll('.neq-tabassign').forEach(chk => {
    chk.addEventListener('change', async () => {
      const p = presets.find(x => x.id === chk.dataset.presetId);
      if (!p) return;
      const type = chk.dataset.type;
      const id = String(chk.dataset.id);
      const arr = p.picks[type] || (p.picks[type] = []);
      if (chk.checked) {
        if (!arr.includes(id)) arr.push(id);
      } else {
        const i = arr.indexOf(id);
        if (i >= 0) arr.splice(i, 1);
      }
      await saveAll();
      updateColCheckState(p.id);
    });
  });

  // 列の全選択／全解除（ヘッダーのチェックボックス）
  body.querySelectorAll('.neq-colcheck').forEach(colChk => {
    colChk.addEventListener('change', async () => {
      const pid = colChk.dataset.presetId;
      const p = presets.find(x => x.id === pid);
      if (!p) return;
      const on = colChk.checked;
      // この列の全チェックボックスを切り替え
      body.querySelectorAll(`.neq-tabassign[data-preset-id="${CSS.escape(pid)}"]`).forEach(cb => {
        cb.checked = on;
      });
      // picks を再構築（全項目 or 空）
      p.picks.orig = [];
      p.picks.save = [];
      p.picks.custom = [];
      if (on) {
        (allItems.orig || []).forEach(it => p.picks.orig.push(String(it.id)));
        (allItems.save || []).forEach(it => p.picks.save.push(String(it.id)));
        (allItems.custom || []).forEach(it => p.picks.custom.push(String(it.id)));
      }
      await saveAll();
    });
  });

  // 各列の全選択チェックの初期状態を反映
  presets.forEach(p => { if (!p.isAll) updateColCheckState(p.id); });

  // 指定タブ列の「全選択」チェックの状態を、実際のチェック数に合わせて更新
  function updateColCheckState(pid) {
    const colChk = body.querySelector(`.neq-colcheck[data-preset-id="${CSS.escape(pid)}"]`);
    if (!colChk) return;
    const boxes = [...body.querySelectorAll(`.neq-tabassign[data-preset-id="${CSS.escape(pid)}"]`)];
    if (boxes.length === 0) return;
    const checkedCount = boxes.filter(b => b.checked).length;
    colChk.checked = checkedCount === boxes.length;
    colChk.indeterminate = checkedCount > 0 && checkedCount < boxes.length;
  }

  // マスター行プルダウン（全表示モード）
  body.querySelectorAll('.neq-master-select').forEach(sel => {
    sel.addEventListener('change', async () => {
      const key = sel.dataset.type + ':' + sel.dataset.id;
      if (sel.value) masterAssign[key] = sel.value;
      else delete masterAssign[key];
      await chrome.storage.local.set({ [STORAGE_KEY_MASTER]: masterAssign });
    });
  });

  // 行プルダウン
  body.querySelectorAll('.neq-grp-select').forEach(sel => {
    sel.addEventListener('change', async () => {
      const type = sel.dataset.type;
      const id = String(sel.dataset.id);
      const key = type + ':' + id;
      // 行割り当ては全タブ共通
      if (sel.value) {
        masterAssign[key] = sel.value;
        // 行を選んだら、編集中タブにチェックも入れる
        const arr = editing.picks[type] || (editing.picks[type] = []);
        if (!arr.includes(id)) arr.push(id);
      } else {
        delete masterAssign[key];
      }
      await saveAll();
      await chrome.storage.local.set({ [STORAGE_KEY_MASTER]: masterAssign });
      refreshModalBody();
    });
  });

  // 順番入力（全タブ共通）
  body.querySelectorAll('.neq-ord-input').forEach(inp => {
    inp.addEventListener('change', async () => {
      const key = inp.dataset.type + ':' + inp.dataset.id;
      const v = inp.value.trim();
      if (v === '' || isNaN(Number(v))) delete orderMap[key];
      else orderMap[key] = Number(v);
      await chrome.storage.local.set({ [STORAGE_KEY_ORDER]: orderMap });
    });
  });

  // アイコン変更ボタン
  body.querySelectorAll('.neq-icon-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      openIconPicker(btn);
    });
  });

  // 自由項目の削除
  body.querySelectorAll('.neq-custom-del').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const target = (allItems.custom || []).find(x => String(x.id) === String(id));
      if (!target) return;
      if (!confirm(`自由項目「${target.name}」を削除しますか？`)) return;
      allItems.custom = (allItems.custom || []).filter(x => String(x.id) !== String(id));
      // 全タブのpicksと共通の行割り当てからも除去
      presets.forEach(p => {
        if (p.picks.custom) p.picks.custom = p.picks.custom.filter(x => String(x) !== String(id));
      });
      delete masterAssign['custom:' + id];
      delete doneMap['custom:' + id];
      await chrome.storage.local.set({
        [STORAGE_KEY_CUSTOM]: allItems.custom,
        [STORAGE_KEY_PRESETS]: presets,
        [STORAGE_KEY_MASTER]: masterAssign,
        [STORAGE_KEY_DONE]: doneMap
      });
      refreshModalBody();
    });
  });

  // 表ヘッダーの sticky top を、固定ヘッダーブロックの高さに合わせる
  const stickyHead = body.querySelector('.neq-sticky-head');
  const ths = body.querySelectorAll('.neq-table thead th');
  if (stickyHead && ths.length) {
    const h = stickyHead.offsetHeight;
    ths.forEach(th => { th.style.top = h + 'px'; });
  }
}

// アイコン選択ポップアップ
function openIconPicker(anchorBtn) {
  // 既存のピッカーを閉じる
  const existing = document.getElementById('neq-icon-picker');
  if (existing) existing.remove();

  const type = anchorBtn.dataset.type;
  const id = anchorBtn.dataset.id;
  const name = anchorBtn.dataset.name;

  const picker = document.createElement('div');
  picker.id = 'neq-icon-picker';
  picker.className = 'neq-icon-picker';
  picker.innerHTML = `
    <div class="neq-icon-picker-grid">
      <button class="neq-icon-choice neq-icon-choice-none" data-icon="" title="アイコンなし">なし</button>
      ${NEQ_ICON_CHOICES.map(ic => `<button class="neq-icon-choice" data-icon="${escapeAttr(ic)}">${renderIconHTML(ic, 18)}</button>`).join('')}
    </div>
    <div class="neq-icon-picker-foot">
      <button class="neq-icon-reset">自動に戻す</button>
    </div>
  `;
  document.body.appendChild(picker);

  // 位置調整（ボタンの下）
  const rect = anchorBtn.getBoundingClientRect();
  picker.style.top = (rect.bottom + window.scrollY + 4) + 'px';
  picker.style.left = (rect.left + window.scrollX) + 'px';

  // 画面外にはみ出さないように
  const pr = picker.getBoundingClientRect();
  if (pr.right > window.innerWidth) {
    picker.style.left = (window.innerWidth - pr.width - 10) + 'px';
  }

  picker.querySelectorAll('.neq-icon-choice').forEach(c => {
    c.addEventListener('click', async () => {
      const chosen = c.dataset.icon; // '' = なし
      iconMap[type + ':' + id] = chosen;
      await chrome.storage.local.set({ [STORAGE_KEY_ICONS]: iconMap });
      anchorBtn.innerHTML = chosen ? renderIconHTML(chosen, 16) : '<span class="neq-icon-none">なし</span>';
      picker.remove();
    });
  });
  picker.querySelector('.neq-icon-reset').addEventListener('click', async () => {
    delete iconMap[type + ':' + id];
    await chrome.storage.local.set({ [STORAGE_KEY_ICONS]: iconMap });
    const a = autoIcon(name);
    anchorBtn.innerHTML = a ? renderIconHTML(a, 16) : '<span class="neq-icon-none">なし</span>';
    picker.remove();
  });

  // 外側クリックで閉じる
  setTimeout(() => {
    const closeHandler = (ev) => {
      if (!picker.contains(ev.target) && ev.target !== anchorBtn) {
        picker.remove();
        document.removeEventListener('click', closeHandler);
      }
    };
    document.addEventListener('click', closeHandler);
  }, 50);
}

// =====================================================
// 実行
// =====================================================
async function executeFromPage(type, id) {
  try {
    if (type === 'custom') return; // 自由項目はネクストエンジンの動作なし（記録だけ）
    const fnPath = type === 'orig' ? 'originalStatus.search' : 'searchBookmark.search';
    const safeId = String(id).replace(/[^0-9a-zA-Z_-]/g, '');
    if (!safeId) return;
    await chrome.runtime.sendMessage({ action: 'executeInMainWorld', fnPath, id: safeId });
  } catch (e) {
    console.error('[NE Quick Access]', e);
  }
}

// =====================================================
// クラウド同期（GitHub Gist）
// =====================================================
async function getSyncConfig() {
  const d = await chrome.storage.local.get([STORAGE_KEY_SYNC]);
  return d[STORAGE_KEY_SYNC] || { token: '', gistId: '' };
}

async function saveSyncConfig(cfg) {
  await chrome.storage.local.set({ [STORAGE_KEY_SYNC]: cfg });
}

// 送信：このPCの設定をGistに書き込む
async function syncPush() {
  const cfg = await getSyncConfig();
  if (!cfg.token || !cfg.gistId) {
    return { ok: false, error: 'トークンとGist IDを入力してください' };
  }
  // 共有対象データを集める
  const data = await chrome.storage.local.get(SYNC_KEYS);
  const payload = {};
  SYNC_KEYS.forEach(k => { payload[k] = data[k] ?? null; });
  payload._updatedAt = new Date().toISOString();

  try {
    const r = await chrome.runtime.sendMessage({
      action: 'gistPush',
      token: cfg.token,
      gistId: cfg.gistId,
      filename: GIST_FILENAME,
      content: JSON.stringify(payload, null, 2)
    });
    if (r && r.ok) return { ok: true, updatedAt: payload._updatedAt };
    return { ok: false, error: (r && r.error) || '送信に失敗しました' };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || e) };
  }
}

// 受信：Gistから設定を取得してこのPCに反映
async function syncPull() {
  const cfg = await getSyncConfig();
  if (!cfg.token || !cfg.gistId) {
    return { ok: false, error: 'トークンとGist IDを入力してください' };
  }
  try {
    const r = await chrome.runtime.sendMessage({
      action: 'gistPull',
      token: cfg.token,
      gistId: cfg.gistId,
      filename: GIST_FILENAME
    });
    if (!r || !r.ok) return { ok: false, error: (r && r.error) || '受信に失敗しました' };
    const payload = JSON.parse(r.content);
    const toSet = {};
    SYNC_KEYS.forEach(k => {
      if (payload[k] !== undefined && payload[k] !== null) toSet[k] = payload[k];
    });
    await chrome.storage.local.set(toSet);
    await loadData();
    applyBarOverride();
    return { ok: true, updatedAt: payload._updatedAt };
  } catch (e) {
    return { ok: false, error: '通信エラー: ' + (e.message || e) };
  }
}

// =====================================================
// 一覧取得
// =====================================================
async function fetchAll() {
  try {
    const origItems = await ensureAndFetch('#tab_original_status', '#original_status_table_tbody');
    const saveItems = await ensureAndFetch('#tab_search_bookmark', '#search_bookmark_table tbody');
    allItems = { orig: origItems, save: saveItems };
    await chrome.storage.local.set({ [STORAGE_KEY_ALL]: allItems });

    // 「全表示」プリセット（isAll）があれば中身を全件に同期
    let changed = false;
    presets.forEach(p => {
      if (p.isAll) {
        p.picks.orig = origItems.map(it => String(it.id));
        p.picks.save = saveItems.map(it => String(it.id));
        changed = true;
      }
    });
    if (changed) await saveAll();

    return { ok: true, orig: origItems, save: saveItems };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  }
}

async function ensureAndFetch(tabSelector, tbodySelector) {
  const tab = document.querySelector(tabSelector);
  if (!tab) throw new Error(`タブが見つかりません (${tabSelector})`);
  tab.click();
  const tbody = await waitFor(() => {
    const el = document.querySelector(tbodySelector);
    if (el && el.querySelectorAll('tr').length > 0) return el;
    return null;
  }, 3000);
  if (!tbody) {
    if (document.querySelector(tbodySelector)) return [];
    throw new Error(`一覧が読み込めませんでした (${tbodySelector})`);
  }
  const rows = tbody.querySelectorAll('tr');
  const items = [];
  rows.forEach(tr => {
    const id = tr.dataset.bookmarkId;
    if (!id) return;
    let name = tr.querySelector('td:nth-child(2) a')?.textContent.trim();
    if (!name) name = tr.querySelector('td:nth-child(2)')?.textContent.trim();
    items.push({ id: String(id), name: name || `(無名:${id})` });
  });
  // 取得後は元のタブに戻す（伝票操作タブ）
  const denpyoTab = document.querySelector('#tab_denpyo');
  if (denpyoTab) denpyoTab.click();
  return items;
}

function waitFor(checkFn, timeout = 3000, interval = 100) {
  return new Promise(resolve => {
    const start = Date.now();
    const timer = setInterval(() => {
      const r = checkFn();
      if (r) { clearInterval(timer); resolve(r); }
      else if (Date.now() - start > timeout) { clearInterval(timer); resolve(null); }
    }, interval);
  });
}

// =====================================================
// Observer
// =====================================================
function setupBarObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => {
    const bar = document.querySelector(BAR_SELECTOR);
    // 適用済みマーカー（'1' または 'normal'）が無い＝ネクストエンジンが再生成した時だけ再適用
    if (bar && bar.dataset.neQuickApplied !== '1' && bar.dataset.neQuickApplied !== 'off') {
      applyBarOverride();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// =====================================================
// CSS
// =====================================================
function injectStyles() {
  if (document.getElementById('ne-quick-access-styles')) return;
  const style = document.createElement('style');
  style.id = 'ne-quick-access-styles';
  style.textContent = `
    #original_status_list.ne-quick-bar { padding: 0 !important; background: transparent; }

    .neq-top-row {
      display: flex; align-items: flex-end; justify-content: space-between;
      border-bottom: 2px solid #2b7cd3; margin-bottom: 8px; gap: 8px;
    }
    .neq-tabs { display: flex; flex-wrap: wrap; gap: 2px; }
    .neq-tab {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 7px 16px; font-size: 13px; font-weight: 500; color: #555;
      background: #eef0f2; border: 1px solid #d5d5d5; border-bottom: none;
      border-radius: 5px 5px 0 0; cursor: pointer; margin-bottom: -1px; transition: all 0.1s;
    }
    .neq-tab:hover { background: #e0e6ec; }
    .neq-tab.active { background: #2b7cd3; color: #fff; border-color: #2b7cd3; font-weight: 700; }
    .neq-tab-count { font-size: 10px; background: rgba(0,0,0,0.12); padding: 1px 6px; border-radius: 8px; }
    .neq-tab.active .neq-tab-count { background: rgba(255,255,255,0.25); }

    .neq-settings-btn {
      flex-shrink: 0; padding: 6px 14px; font-size: 12px; font-weight: 500;
      background: #fff; color: #2b7cd3; border: 1px solid #2b7cd3;
      border-radius: 4px; cursor: pointer; margin-bottom: 4px; font-family: inherit;
    }
    .neq-settings-btn:hover { background: #2b7cd3; color: #fff; }

    /* 上段のアクションボタン群 */
    .neq-top-actions { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
    .neq-track-btn {
      padding: 6px 12px; font-size: 12px; font-weight: 500; font-family: inherit;
      background: #fff; color: #888; border: 1px solid #ccc; border-radius: 4px;
      cursor: pointer; margin-bottom: 4px;
    }
    .neq-track-btn:hover { border-color: #999; }
    .neq-track-btn.on {
      background: #2c9c52; color: #fff; border-color: #2c9c52;
    }
    .neq-track-btn.on:hover { background: #25813f; }
    .neq-clear-btn {
      padding: 6px 12px; font-size: 12px; font-family: inherit;
      background: #fff; color: #888; border: 1px solid #ccc; border-radius: 4px;
      cursor: pointer; margin-bottom: 4px;
    }
    .neq-clear-btn:hover { background: #f5f5f5; border-color: #999; }

    /* 実施済みの薄い塗りつぶし */
    .neq-btn.neq-done {
      background: #dcefe0 !important;
      opacity: 0.62;
    }
    .neq-btn.neq-done::after {
      content: " ✓"; color: #2c9c52; font-weight: 700;
    }


    .neq-buttons { display: flex; flex-wrap: wrap; gap: 6px; padding: 6px 4px 10px; }
    .neq-btn {
      display: inline-block; padding: 5px 11px !important; font-size: 12px !important;
      font-weight: 500 !important; text-decoration: none !important; border-radius: 3px !important;
      border: 1px solid #c5c5c5 !important; cursor: pointer; user-select: none;
      transition: all 0.1s ease; margin: 0 !important; line-height: 1.5 !important;
    }
    .neq-btn-orig { background: #fff !important; border-color: #d0a065 !important; color: #6b4a1e !important; }
    .neq-btn-orig:hover { background: #d0a065 !important; color: #fff !important; box-shadow: 0 2px 5px rgba(208,160,101,0.4); }
    .neq-btn-save { background: #fff !important; border-color: #2b7cd3 !important; color: #1d4f87 !important; }
    .neq-btn-save:hover { background: #2b7cd3 !important; color: #fff !important; box-shadow: 0 2px 5px rgba(43,124,211,0.4); }
    /* 自由項目（メモ）：紫系 */
    .neq-btn-custom { background: #fff !important; border-color: #8e44ad !important; color: #6a3080 !important; }
    .neq-btn-custom:hover { background: #8e44ad !important; color: #fff !important; box-shadow: 0 2px 5px rgba(142,68,173,0.4); }
    .neq-btn.badge-info { box-shadow: inset 0 0 0 2px #2b7cd3, 0 1px 3px rgba(0,0,0,0.15); font-weight: 700 !important; }
    .neq-btn.neq-dragging { opacity: 0.4; cursor: grabbing !important; }
    .neq-btn.neq-drag-over { border-style: dashed !important; border-width: 2px !important; transform: scale(1.05); }

    .neq-bar-empty {
      padding: 10px 14px; color: #888; font-size: 12px; background: #fffbe6;
      border: 1px dashed #e0c060; border-radius: 3px; margin: 4px;
    }

    /* ===== 設定モーダル ===== */
    .neq-modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 99999;
      display: flex; align-items: center; justify-content: center;
    }
    .neq-modal {
      background: #fff; width: 96vw; max-width: 1600px; height: 92vh;
      border-radius: 8px; display: flex; flex-direction: column;
      box-shadow: 0 12px 48px rgba(0,0,0,0.3); overflow: hidden;
      font-family: -apple-system, "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif;
    }
    .neq-modal-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 14px 20px; border-bottom: 1px solid #e0e0e0; background: #f8f9fa;
    }
    .neq-modal-title { font-size: 16px; font-weight: 700; color: #333; }
    .neq-modal-close {
      width: 32px; height: 32px; border: none; background: none; font-size: 24px;
      color: #888; cursor: pointer; border-radius: 4px; line-height: 1;
    }
    .neq-modal-close:hover { background: #e0e0e0; color: #333; }

    .neq-modal-toolbar {
      display: flex; align-items: center; gap: 12px; padding: 10px 20px;
      border-bottom: 1px solid #eee; background: #fafafa;
    }
    .neq-fetch-btn {
      padding: 7px 14px; font-size: 12px; background: #fff; color: #2b7cd3;
      border: 1px solid #2b7cd3; border-radius: 4px; cursor: pointer; font-family: inherit;
    }
    .neq-fetch-btn:hover:not(:disabled) { background: #2b7cd3; color: #fff; }
    .neq-fetch-btn:disabled { opacity: 0.6; cursor: default; }

    /* ツールバーボタン（色分け） */
    .neq-tbtn {
      padding: 7px 14px; font-size: 12px; border-radius: 4px; cursor: pointer;
      font-family: inherit; font-weight: 500; background: #fff; border: 1px solid;
    }
    .neq-tbtn:disabled { opacity: 0.6; cursor: default; }
    /* 一覧を再取得：緑 */
    .neq-tbtn-fetch { color: #2c9c52; border-color: #2c9c52; }
    .neq-tbtn-fetch:hover:not(:disabled) { background: #2c9c52; color: #fff; }
    /* 項目追加・行編集・タブ編集：青 */
    .neq-tbtn-edit { color: #2b7cd3; border-color: #2b7cd3; }
    .neq-tbtn-edit:hover:not(:disabled) { background: #2b7cd3; color: #fff; }
    /* クラウド同期：紫 */
    .neq-tbtn-sync { color: #8e44ad; border-color: #8e44ad; }
    .neq-tbtn-sync:hover:not(:disabled) { background: #8e44ad; color: #fff; }
    .neq-toolbar-hint { font-size: 12px; color: #888; }

    .neq-modal-body { flex: 1; overflow: auto; padding: 0; }
    .neq-modal-empty { padding: 60px 20px; text-align: center; color: #888; font-size: 14px; line-height: 1.8; }

    .neq-sticky-head {
      position: sticky; top: 0; z-index: 5; background: #fff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.04);
    }
    .neq-tabmgr {
      display: flex; align-items: flex-start; flex-wrap: wrap; gap: 8px;
      padding: 12px 20px; border-bottom: 1px solid #eee; background: #fff;
      max-height: 140px; overflow-y: auto;
    }
    .neq-tabmgr-label { font-size: 12px; font-weight: 600; color: #666; flex-shrink: 0; padding-top: 6px; }
    .neq-mtab-handle {
      cursor: grab; color: #aac; font-size: 11px; letter-spacing: -2px;
      padding: 0 1px; user-select: none;
    }
    .neq-mtab-handle:active { cursor: grabbing; }
    .neq-mtab.neq-mtab-dragging { opacity: 0.4; }
    .neq-mtab.neq-mtab-over { border-color: #2b7cd3; border-style: dashed; }
    .neq-mtab {
      display: inline-flex; align-items: center; gap: 2px; background: #eef4fb;
      border: 1px solid #cfe0f3; border-radius: 4px; padding: 2px 2px 2px 6px;
    }
    .neq-mtab-name {
      border: none; background: transparent; font-size: 13px; font-weight: 600;
      color: #1d4f87; width: 100px; padding: 4px 2px; font-family: inherit;
    }
    .neq-mtab-name:focus { outline: none; background: #fff; border-radius: 3px; }
    .neq-mtab-del {
      width: 20px; height: 20px; border: none; background: none; color: #999;
      font-size: 16px; cursor: pointer; border-radius: 3px; line-height: 1;
    }
    .neq-mtab-del:hover { background: #f5c6c6; color: #c0392b; }
    .neq-mtab-lock { padding: 0 6px; font-size: 12px; }
    .neq-mtab-add {
      padding: 6px 12px; font-size: 12px; border: 1px dashed #999; background: none;
      color: #666; border-radius: 4px; cursor: pointer; font-family: inherit;
    }
    .neq-mtab-add:hover { border-color: #2b7cd3; color: #2b7cd3; }

    .neq-table-wrap { padding: 0 20px 20px; }
    .neq-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: fixed; }
    .neq-table thead th {
      position: sticky; top: 0; background: #eaf0f6 !important; padding: 10px 8px;
      border-bottom: 2px solid #d5d5d5; text-align: center; font-size: 12px;
      font-weight: 700; color: #444; z-index: 3;
    }
    .neq-table th.neq-col-name { text-align: left; padding-left: 14px; }
    .neq-col-tab { width: 90px; text-align: center; }
    .neq-col-tab-head { display: flex; flex-direction: column; align-items: center; gap: 4px; }
    .neq-colcheck-wrap {
      display: inline-flex; align-items: center; gap: 3px; cursor: pointer;
      font-size: 10px; color: #2b7cd3; font-weight: 500; white-space: nowrap;
    }
    .neq-colcheck { width: 14px; height: 14px; cursor: pointer; margin: 0; }
    .neq-colcheck-label { user-select: none; }
    .neq-table tbody tr { border-bottom: 1px solid #eee; }
    .neq-table tbody tr:hover { background: #f7fafd; }
    /* 名前セルは td のときだけ flex（th には適用しない） */
    .neq-table td.neq-col-name {
      display: flex; align-items: center; gap: 8px; padding: 8px 12px;
    }
    .neq-table td { padding: 8px; vertical-align: middle; }
    .neq-bdg { font-size: 9px; padding: 1px 5px; border-radius: 2px; font-weight: 700; flex-shrink: 0; }
    .neq-bdg-orig { background: #fff1e6; color: #d35400; }
    .neq-bdg-save { background: #e8f1fb; color: #2b7cd3; }
    .neq-bdg-custom { background: #f3e8fb; color: #8e44ad; }
    .neq-custom-del {
      margin-left: 6px; width: 18px; height: 18px; border: none; background: none;
      color: #c08; font-size: 14px; cursor: pointer; border-radius: 3px; line-height: 1;
      flex-shrink: 0;
    }
    .neq-custom-del:hover { background: #f5c6e0; color: #a0186a; }
    .neq-item-name {
      flex: 1; overflow: hidden; text-overflow: ellipsis;
      white-space: nowrap; vertical-align: middle;
    }
    .neq-assign { width: 17px; height: 17px; cursor: pointer; }

    .neq-modal-footer {
      display: flex; align-items: center; justify-content: space-between;
      padding: 12px 20px; border-top: 1px solid #e0e0e0; background: #f8f9fa;
    }
    .neq-footer-hint { font-size: 12px; color: #999; }
    .neq-done-btn {
      padding: 8px 24px; font-size: 13px; background: #2b7cd3; color: #fff;
      border: none; border-radius: 4px; cursor: pointer; font-weight: 600; font-family: inherit;
    }
    .neq-done-btn:hover { background: #1f5fa3; }

    /* 行編集モーダル */
    .neq-row-overlay { z-index: 100001; }
    .neq-row-modal {
      background: #fff; width: 440px; max-width: 90vw; max-height: 80vh;
      border-radius: 8px; display: flex; flex-direction: column;
      box-shadow: 0 12px 48px rgba(0,0,0,0.3); overflow: hidden;
      font-family: -apple-system, "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif;
    }
    .neq-row-body { flex: 1; overflow-y: auto; padding: 16px 20px; }
    .neq-row-list { display: flex; flex-direction: column; gap: 6px; margin-bottom: 12px; }
    .neq-row-item {
      display: flex; align-items: center; gap: 8px; padding: 8px 10px;
      border: 1px solid #e0e0e0; border-radius: 5px; background: #fafafa;
    }
    .neq-row-item.neq-row-dragging { opacity: 0.4; }
    .neq-row-item.neq-row-over { border-color: #2b7cd3; border-style: dashed; background: #eef4fb; }
    .neq-row-handle { cursor: grab; color: #aac; font-size: 13px; letter-spacing: -2px; }
    .neq-row-num {
      flex-shrink: 0; width: 22px; height: 22px; border-radius: 50%;
      background: #2b7cd3; color: #fff; font-size: 11px; font-weight: 700;
      display: flex; align-items: center; justify-content: center;
    }
    .neq-row-name {
      flex: 1; border: 1px solid #ddd; border-radius: 4px; padding: 6px 8px;
      font-size: 13px; font-family: inherit;
    }
    .neq-row-name:focus { outline: none; border-color: #2b7cd3; }
    .neq-row-del {
      width: 24px; height: 24px; border: none; background: none; color: #c0392b;
      font-size: 16px; cursor: pointer; border-radius: 4px; flex-shrink: 0;
    }
    .neq-row-del:hover { background: #f5c6c6; }
    .neq-row-add-btn {
      width: 100%; padding: 10px; border: 1px dashed #2b7cd3; background: #fff;
      color: #2b7cd3; border-radius: 5px; cursor: pointer; font-size: 13px;
      font-family: inherit; font-weight: 500;
    }
    .neq-row-add-btn:hover { background: #e8f1fb; }
    .neq-row-empty { color: #999; font-size: 13px; text-align: center; padding: 20px; }

    /* クラウド同期モーダル */
    .neq-sync-field { margin-bottom: 14px; }
    .neq-sync-field label { display: block; font-size: 12px; font-weight: 600; color: #555; margin-bottom: 4px; }
    .neq-sync-field input {
      width: 100%; padding: 8px 10px; border: 1px solid #ddd; border-radius: 5px;
      font-size: 13px; font-family: inherit; box-sizing: border-box;
    }
    .neq-sync-field input:focus { outline: none; border-color: #2b7cd3; }
    .neq-sync-save {
      width: 100%; padding: 9px; border-radius: 5px; cursor: pointer; font-size: 13px;
      font-family: inherit; font-weight: 600; border: 1px solid #888;
      background: #f5f5f5; color: #444; margin-bottom: 4px;
    }
    .neq-sync-save:hover { background: #e8e8e8; }
    .neq-sync-actions { display: flex; flex-direction: column; gap: 8px; margin: 16px 0; }
    .neq-sync-btn {
      padding: 11px; border-radius: 5px; cursor: pointer; font-size: 13px;
      font-family: inherit; font-weight: 600; border: 1px solid;
    }
    .neq-sync-push { background: #2b7cd3; color: #fff; border-color: #2b7cd3; }
    .neq-sync-push:hover { background: #1f5fa3; }
    .neq-sync-pull { background: #fff; color: #2c9c52; border-color: #2c9c52; }
    .neq-sync-pull:hover { background: #2c9c52; color: #fff; }
    .neq-sync-btn:disabled { opacity: 0.5; cursor: default; }
    .neq-sync-status {
      font-size: 12px; padding: 8px 10px; border-radius: 5px; margin-bottom: 12px;
      min-height: 18px; white-space: pre-line; line-height: 1.6;
    }
    .neq-sync-status.ok { background: #f0faf3; color: #2c8c4a; }
    .neq-sync-status.err { background: #fdf2f2; color: #c0392b; }
    .neq-sync-status.loading { background: #f0f4f8; color: #555; }
    .neq-sync-help {
      font-size: 11px; color: #888; line-height: 1.7; background: #fafafa;
      padding: 10px 12px; border-radius: 5px;
    }

    /* 編集中タブの強調 */
    .neq-mtab.editing { background: #2b7cd3; border-color: #2b7cd3; }
    .neq-mtab.editing .neq-mtab-select { color: #fff; font-weight: 700; }
    .neq-mtab-select { cursor: pointer; padding: 4px 6px; font-size: 13px; font-weight: 600; color: #1d4f87; }
    .neq-mtab-select:hover { text-decoration: underline; }
    .neq-mtab-rename {
      border: 1px solid #fff; background: rgba(255,255,255,0.95); border-radius: 3px;
      font-size: 13px; font-weight: 700; color: #1d4f87; padding: 3px 6px;
      width: 110px; font-family: inherit;
    }
    .neq-mtab-rename:focus { outline: 2px solid #fff; }

    /* 行（グループ）管理バー */
    .neq-groupmgr {
      display: flex; align-items: center; flex-wrap: wrap; gap: 8px;
      padding: 10px 20px; border-bottom: 1px solid #eee; background: #f4f8fc;
    }
    .neq-groupmgr-label { font-size: 12px; font-weight: 600; color: #2b7cd3; }
    .neq-grp {
      display: inline-flex; align-items: center; gap: 2px; background: #fff;
      border: 1px solid #cfe0f3; border-radius: 4px; padding: 2px 2px 2px 4px;
    }
    .neq-grp-list { display: inline-flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .neq-grp-handle {
      cursor: grab; color: #aac; font-size: 12px; letter-spacing: -2px;
      padding: 0 2px; user-select: none;
    }
    .neq-grp-handle:active { cursor: grabbing; }
    .neq-grp.neq-grp-dragging { opacity: 0.4; }
    .neq-grp.neq-grp-over { border-color: #2b7cd3; border-style: dashed; background: #eef4fb; }
    .neq-grp-name {
      border: none; background: transparent; font-size: 12px; color: #333;
      width: 90px; padding: 3px; font-family: inherit;
    }
    .neq-grp-name:focus { outline: none; background: #f0f6fc; border-radius: 3px; }
    .neq-grp-del {
      width: 18px; height: 18px; border: none; background: none; color: #aaa;
      font-size: 14px; cursor: pointer; border-radius: 3px; line-height: 1;
    }
    .neq-grp-del:hover { background: #f5c6c6; color: #c0392b; }
    .neq-grp-add {
      padding: 5px 10px; font-size: 12px; border: 1px dashed #2b7cd3; background: none;
      color: #2b7cd3; border-radius: 4px; cursor: pointer; font-family: inherit;
    }
    .neq-grp-add:hover { background: #e8f1fb; }

    /* テーブルの列 */
    .neq-col-chk { width: 70px; text-align: center; }
    .neq-col-grp { width: 150px; text-align: center; }
    .neq-col-ord { width: 64px; text-align: center; }
    .neq-ord-input {
      width: 48px; padding: 4px 4px; border: 1px solid #ddd; border-radius: 4px;
      font-size: 12px; text-align: center; font-family: inherit;
    }
    .neq-ord-input:focus { outline: none; border-color: #2b7cd3; }
    .neq-col-name { width: 480px; }
    .neq-col-spacer { width: auto; }
    .neq-grp-select {
      width: 130px; padding: 4px 6px; font-size: 12px; border: 1px solid #ccc;
      border-radius: 4px; font-family: inherit; background: #fff;
    }
    .neq-grp-select:focus { outline: none; border-color: #2b7cd3; }

    /* バーの行表示 */
    .neq-rows { display: flex; flex-direction: column; gap: 6px; padding: 4px; }
    .neq-row { display: flex; align-items: flex-start; gap: 0; }
    .neq-row-label {
      flex-shrink: 0;
      width: 120px;            /* 全行で固定幅 → ボタン開始位置が揃う */
      box-sizing: border-box;
      font-size: 11px; font-weight: 700; color: #555;
      padding: 5px 10px 5px 4px;
      margin-right: 10px;
      text-align: left;
      border-right: 2px solid #2b7cd3;   /* ラベルとボタンの境界線 */
      align-self: stretch;
      display: flex; align-items: center;
    }
    .neq-row-label-other { color: #999; font-weight: 500; }
    .neq-row .neq-buttons { padding: 0; flex: 1; }


    /* ボタンのアイコン */
    .neq-btn-icon { margin-right: 4px; font-size: 13px; }

    /* 設定モーダルのアイコンボタン */
    .neq-icon-btn {
      width: 30px; height: 28px; border: 1px solid #ddd; background: #fff;
      border-radius: 4px; cursor: pointer; font-size: 16px; line-height: 1;
      flex-shrink: 0; padding: 0; transition: all 0.1s;
    }
    .neq-icon-btn:hover { border-color: #2b7cd3; background: #eef4fb; }

    /* アイコンピッカー */
    .neq-icon-picker {
      position: absolute; z-index: 100000; background: #fff;
      border: 1px solid #ccc; border-radius: 8px; box-shadow: 0 6px 24px rgba(0,0,0,0.2);
      padding: 8px; width: 230px;
    }
    .neq-icon-picker-grid {
      display: grid; grid-template-columns: repeat(5, 1fr); gap: 4px;
    }
    .neq-icon-choice {
      width: 100%; aspect-ratio: 1; border: 1px solid transparent; background: none; cursor: pointer;
      font-size: 18px; border-radius: 4px; line-height: 1; padding: 0;
      display: flex; align-items: center; justify-content: center;
    }
    .neq-icon-choice:hover { background: #eef4fb; border-color: #cfe0f3; }
    .neq-icon-choice-none {
      font-size: 10px !important; color: #888; border: 1px dashed #ccc !important;
      grid-column: span 1; font-weight: 600;
    }
    .neq-icon-choice-none:hover { background: #f0f0f0; border-color: #999 !important; }
    .neq-icon-none { font-size: 10px; color: #aaa; }
    .neq-icon-picker-foot {
      margin-top: 6px; padding-top: 6px; border-top: 1px solid #eee; text-align: center;
    }
    .neq-icon-reset {
      padding: 4px 12px; font-size: 11px; border: 1px solid #ddd; background: #fff;
      border-radius: 4px; cursor: pointer; color: #666; font-family: inherit;
    }
    .neq-icon-reset:hover { background: #f0f0f0; }
  `;
  document.head.appendChild(style);
}


// =====================================================
// アイコン自動割り当て
// =====================================================
const NEQ_ICON_RULES = [
  { kw: ['出荷確定', '追跡番号'], icon: '✅' },
  { kw: ['印刷'], icon: '🖨️' },
  { kw: ['更新'], icon: 'refresh:blue' },
  { kw: ['確認', 'CHECK', 'チェック'], icon: '✔️' },
];

function autoIcon(name) {
  if (!name) return '';
  for (const rule of NEQ_ICON_RULES) {
    for (const kw of rule.kw) {
      if (name.includes(kw)) return rule.icon;
    }
  }
  return ''; // 該当しなければアイコンなし
}

// 回転矢印の色（6色）
const NEQ_REFRESH_COLORS = {
  red: '#d9342b', blue: '#2b7cd3', green: '#2c9c52',
  orange: '#e08a1e', purple: '#8e44ad', gray: '#888888'
};
// チェックも同じ色パレットを使う
const NEQ_CHECK_COLORS = NEQ_REFRESH_COLORS;

// 選択可能なアイコン候補（絵文字 + チェック6色 + 回転矢印6色）
const NEQ_ICON_CHOICES = [
  '✔️', '🖨️', '✅', '☑️', '⚠️', '🤖', '💳', '💰',
  'check:red', 'check:blue', 'check:green',
  'check:orange', 'check:purple', 'check:gray',
  '🔄',
  'refresh:red', 'refresh:blue', 'refresh:green',
  'refresh:orange', 'refresh:purple', 'refresh:gray'
];

// アイコン値を表示用HTMLに変換（絵文字はそのまま、refresh:色 / check:色 はSVG）
function renderIconHTML(value, size) {
  if (!value) return '';
  if (typeof value === 'string' && value.startsWith('refresh:')) {
    const color = NEQ_REFRESH_COLORS[value.split(':')[1]] || '#888';
    const s = size || 14;
    const sw = s >= 16 ? 2.4 : 2;
    const r = s >= 16 ? 8 : 7;
    return `<svg width="${s}" height="${s}" viewBox="-12 -12 24 24" style="vertical-align:middle;">
      <path d="M ${-r} -1 A ${r} ${r} 0 1 1 ${-(r-2)} ${r-1}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round"/>
      <path d="M ${-r} ${-r} L ${-r} -0.5 L -0.5 -0.5 Z" fill="${color}"/>
    </svg>`;
  }
  if (typeof value === 'string' && value.startsWith('check:')) {
    const color = NEQ_CHECK_COLORS[value.split(':')[1]] || '#888';
    const s = size || 14;
    const sw = s >= 16 ? 2.8 : 2.4;
    return `<svg width="${s}" height="${s}" viewBox="-12 -12 24 24" style="vertical-align:middle;">
      <path d="M -7 0 L -2 6 L 8 -6" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
  }
  return escapeHtml(value); // 絵文字
}

// 項目のアイコンを取得（保存済み > 自動）
// 保存値が '' (空文字) の場合は「アイコンなし」として空を返す
function getItemIcon(type, id, name) {
  const key = type + ':' + id;
  if (Object.prototype.hasOwnProperty.call(iconMap, key)) {
    return iconMap[key]; // '' を含めてユーザー指定値を尊重
  }
  return autoIcon(name);
}

// =====================================================
// utility
// =====================================================
function genId() { return 'p_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function escapeHtml(str) {
  return String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function escapeAttr(str) { return escapeHtml(str); }

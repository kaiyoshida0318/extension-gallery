// ========== 共通ユーティリティ ==========
const $ = id => document.getElementById(id);

// ========== ログ記録システム ==========
// chrome.storage.local に蓄積、コピー時に整形して出力
const LOG_KEY = 'rms_dl_logs';
const LOG_MAX = 2000;  // 最大件数

async function appendLog(category, text, extra = null) {
  try {
    const stored = await chrome.storage.local.get([LOG_KEY]);
    const logs = stored[LOG_KEY] || [];
    logs.push({
      t: new Date().toISOString(),
      cat: category,
      msg: String(text),
      extra: extra
    });
    // 上限超えたら古いものを削る
    if (logs.length > LOG_MAX) logs.splice(0, logs.length - LOG_MAX);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
    updateLogCount(logs.length);
  } catch (_) { /* logging失敗は致命にしない */ }
}

async function getLogCount() {
  const s = await chrome.storage.local.get([LOG_KEY]);
  return (s[LOG_KEY] || []).length;
}

function updateLogCount(n) {
  const el = document.getElementById('log-count');
  if (el) el.textContent = `ログ ${n}件`;
}

async function clearLogs() {
  await chrome.storage.local.remove([LOG_KEY]);
  updateLogCount(0);
}

// ページコンテキストから飛んでくるログメッセージを受信して保存
// (popup側でリスナー登録。ただしpopupが閉じてるとリスナーが居なくなるので、
//  page context内のlog()関数はchrome.storage.localへ直接書く方式も併用する)
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type === 'rms-log') {
    appendLog(msg.panel || 'page', msg.text, { progress: msg.progress, tabId: sender?.tab?.id });
  } else if (msg?.type === 'rms-log-detail') {
    // API呼び出しなど詳細ログ用
    appendLog(msg.cat || 'detail', msg.text, msg.extra);
  }
});

// 拡張内部のconsole.error/warnも記録(popup側で発生したもの)
const _origConsoleError = console.error;
console.error = function (...args) {
  try { appendLog('error', args.map(a => {
    if (a instanceof Error) return `${a.name}: ${a.message}\n${a.stack || ''}`;
    if (typeof a === 'object') return JSON.stringify(a);
    return String(a);
  }).join(' ')); } catch (_) {}
  _origConsoleError.apply(console, args);
};
const _origConsoleWarn = console.warn;
console.warn = function (...args) {
  try { appendLog('warn', args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')); } catch (_) {}
  _origConsoleWarn.apply(console, args);
};

// 起動時に件数表示を更新
(async () => { updateLogCount(await getLogCount()); })();

function setStatus(panelPrefix, msg, append = true) {
  const el = $(`${panelPrefix}-status`);
  if (append) el.textContent += '\n' + msg;
  else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(panelPrefix, pct) {
  $(`${panelPrefix}-progress`).style.width = pct + '%';
}

// ========== ログをコピー / クリア ==========
async function buildLogReport() {
  const stored = await chrome.storage.local.get([LOG_KEY]);
  const logs = stored[LOG_KEY] || [];
  const manifest = chrome.runtime.getManifest();

  // タブ情報も収集
  let tabsInfo = 'タブ取得失敗';
  try {
    const tabs = await chrome.tabs.query({});
    const relevant = tabs.filter(t => t.url && (t.url.includes('rakuten.co.jp')));
    tabsInfo = relevant.map(t => `  [${t.id}] ${t.active ? '*' : ' '} ${t.url?.slice(0, 100)}`).join('\n') || '  (該当タブなし)';
  } catch (_) {}

  // 現在の入力状況
  const inputs = {
    'bulk-start': $('bulk-start')?.value,
    'bulk-end': $('bulk-end')?.value,
    'is-period': $('is-period')?.value,
    'is-device': $('is-device')?.value,
    'is-tax': $('is-tax')?.value,
    'is-interval': $('is-interval')?.value,
    'rppAll-interval': $('rppAll-interval')?.value,
    'rppItem-timeout': $('rppItem-timeout')?.value,
    'rppKw-timeout': $('rppKw-timeout')?.value
  };

  const header = `=== RMS一括ダウンローダー ログレポート ===
出力日時: ${new Date().toISOString()}
拡張: ${manifest.name} v${manifest.version}
UA: ${navigator.userAgent}

[Rakuten関連タブ]
${tabsInfo}

[現在のUI設定]
${Object.entries(inputs).map(([k, v]) => `  ${k}: ${v ?? '(空)'}`).join('\n')}

[ログ: ${logs.length}件]
`;
  const body = logs.map(l => {
    const time = l.t.replace('T', ' ').replace(/\.\d{3}Z$/, '');
    let line = `[${time}] (${l.cat}) ${l.msg}`;
    if (l.extra && Object.keys(l.extra).length) {
      line += ` | ${JSON.stringify(l.extra)}`;
    }
    return line;
  }).join('\n');

  return header + body + '\n=== ログレポート終わり ===';
}

$('bulk-copylog')?.addEventListener('click', async () => {
  const btn = $('bulk-copylog');
  try {
    const report = await buildLogReport();
    await navigator.clipboard.writeText(report);
    btn.textContent = '✅ コピーしました';
    btn.classList.add('copied');
    setTimeout(() => {
      btn.textContent = '📋 ログをコピー';
      btn.classList.remove('copied');
    }, 2000);
  } catch (e) {
    // fallback: textareaに入れて手動コピー
    try {
      const report = await buildLogReport();
      const ta = document.createElement('textarea');
      ta.value = report;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      btn.textContent = '✅ コピー(fallback)';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = '📋 ログをコピー';
        btn.classList.remove('copied');
      }, 2000);
    } catch (e2) {
      btn.textContent = '❌ コピー失敗';
      _origConsoleError('log copy failed', e2);
    }
  }
});

$('bulk-clearlog')?.addEventListener('click', async () => {
  if (!confirm('すべてのログを消去します。よろしいですか?')) return;
  await clearLogs();
  const btn = $('bulk-clearlog');
  btn.textContent = '✅ クリア完了';
  setTimeout(() => { btn.textContent = '🗑️ ログをクリア'; }, 1500);
});

// タブ切替
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $(`panel-${tab.dataset.panel}`).classList.add('active');
  });
});

// 初期日付: 保存された日付があれば復元、無ければ開始日=空欄/終了日=昨日
const DATE_LOCK_KEY = 'rms_dl_date_lock';
const fmtDate = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

async function loadSavedDates() {
  try {
    const s = await chrome.storage.local.get([DATE_LOCK_KEY]);
    return s[DATE_LOCK_KEY] || null; // {startDate, endDate} or null
  } catch (_) { return null; }
}

async function applyInitialDates() {
  const t = new Date();
  const y = new Date(t); y.setDate(y.getDate() - 1);
  const yesterday = fmtDate(y);

  const saved = await loadSavedDates();
  const initStart = saved?.startDate || '';
  const initEnd   = saved?.endDate   || yesterday;

  ['bulk-end', 'rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end'].forEach(id => {
    const el = $(id); if (el) el.value = initEnd;
  });
  ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'].forEach(id => {
    const el = $(id); if (el) el.value = initStart;
  });

  // ロック表示更新
  updateDateLockUI(!!saved);
  refreshEmptyHighlight();
}

function updateDateLockUI(locked) {
  const badge = $('date-lock-badge');
  if (badge) badge.style.display = locked ? 'inline-block' : 'none';
  ['bulk-start', 'bulk-end'].forEach(id => {
    const el = $(id);
    if (!el) return;
    if (locked) el.classList.add('date-locked');
    else el.classList.remove('date-locked');
  });
  const saveBtn = $('bulk-savedate');
  if (saveBtn) {
    if (locked) {
      saveBtn.textContent = '✅ 保存中(再保存で更新)';
      saveBtn.classList.add('locked');
    } else {
      saveBtn.textContent = '💾 日付を保存(固定)';
      saveBtn.classList.remove('locked');
    }
  }
}

// 起動時に実行(awaitできないので即時呼び出し)
applyInitialDates();

// 開始日が空かどうかで背景色を切り替える
const START_DATE_IDS = ['bulk-start', 'rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'];
function refreshEmptyHighlight() {
  START_DATE_IDS.forEach(id => {
    const el = $(id);
    if (!el) return;
    if (el.value) el.classList.remove('empty-required');
    else el.classList.add('empty-required');
  });
}
// 初期表示で適用
refreshEmptyHighlight();
// 各開始日inputが変更されたら再判定
START_DATE_IDS.forEach(id => {
  const el = $(id);
  if (el) {
    el.addEventListener('input', refreshEmptyHighlight);
    el.addEventListener('change', refreshEmptyHighlight);
  }
});

// 上部の一括期間を変更したら、下の各タブの日付も同期(空欄の時は同期しない)
function syncBulkDatesToTabs() {
  const s = $('bulk-start').value;
  const e = $('bulk-end').value;
  if (s) ['rppAll-start', 'is-start', 'rppItem-start', 'rppKw-start'].forEach(id => { $(id).value = s; });
  if (e) ['rppAll-end', 'is-end', 'rppItem-end', 'rppKw-end'].forEach(id => { $(id).value = e; });
  refreshEmptyHighlight();
}
$('bulk-start').addEventListener('change', syncBulkDatesToTabs);
$('bulk-end').addEventListener('change', syncBulkDatesToTabs);

// ========== 日付保存(固定) / 解除 ==========
$('bulk-savedate')?.addEventListener('click', async () => {
  const startDate = $('bulk-start').value;
  const endDate = $('bulk-end').value;
  if (!startDate && !endDate) {
    setBulkHint('❌ 保存する日付を入力してください', true);
    return;
  }
  try {
    await chrome.storage.local.set({
      [DATE_LOCK_KEY]: { startDate, endDate }
    });
    updateDateLockUI(true);
    setBulkHint(`✅ 保存しました (${startDate || '(空)'} 〜 ${endDate || '(空)'})`);
    appendLog('lock', `日付保存: ${startDate} 〜 ${endDate}`);
  } catch (e) {
    setBulkHint(`❌ 保存失敗: ${e.message}`, true);
  }
});

$('bulk-cleardate')?.addEventListener('click', async () => {
  try {
    await chrome.storage.local.remove([DATE_LOCK_KEY]);
    updateDateLockUI(false);
    setBulkHint('🔓 日付の固定を解除しました');
    appendLog('lock', `日付固定を解除`);
  } catch (e) {
    setBulkHint(`❌ 解除失敗: ${e.message}`, true);
  }
});

// 一括ヒント表示
function setBulkHint(msg, isError = false) {
  const el = $('bulk-hint');
  el.textContent = msg;
  el.style.color = isError ? '#a01010' : '#806000';
}

// ========== 一括: 必要なページを開く ==========
const REQUIRED_URLS = [
  { url: 'https://datatool.rms.rakuten.co.jp/realtime/item', match: 'datatool.rms.rakuten.co.jp/realtime/item' },
  { url: 'https://ad.rms.rakuten.co.jp/rpp/reports', match: 'ad.rms.rakuten.co.jp/rpp/reports' }
];

$('bulk-open').addEventListener('click', async () => {
  $('bulk-open').disabled = true;
  setBulkHint('🔍 既存タブを確認中…');
  try {
    const tabs = await chrome.tabs.query({});
    let opened = 0, existing = 0;
    for (const u of REQUIRED_URLS) {
      const found = tabs.find(t => t.url && t.url.includes(u.match));
      if (found) {
        existing++;
      } else {
        await chrome.tabs.create({ url: u.url, active: false });
        opened++;
      }
    }
    setBulkHint(`✅ 既存 ${existing}件、新規オープン ${opened}件`);
  } catch (e) {
    setBulkHint(`❌ エラー: ${e.message}`, true);
  } finally {
    $('bulk-open').disabled = false;
  }
});

// ========== 一括: 4種類まとめてダウンロード ==========
// ========== 日付バリデーション共通ヘルパー ==========
function validateBulkDates() {
  const startDate = $('bulk-start').value;
  const endDate = $('bulk-end').value;
  if (!startDate) { setBulkHint('❌ 開始日を入力してください', true); return null; }
  if (!endDate) { setBulkHint('❌ 終了日を入力してください', true); return null; }
  if (startDate > endDate) { setBulkHint('❌ 開始日が終了日より後になっています', true); return null; }
  syncBulkDatesToTabs();
  return { startDate, endDate };
}

// ========== 該当URLのタブを探す(無ければ新規) ==========
async function getOrCreateJobTab(job) {
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(t => t.url && t.url.includes(job.urlMatch));
  if (tab) return tab;
  appendLog('bulk', `  ⚠ ${job.name}用のタブが見つかりません。新規オープンします: ${job.ensureUrl}`);
  tab = await chrome.tabs.create({ url: job.ensureUrl, active: false });
  const start = Date.now();
  while ((Date.now() - start) < 15000) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete') return t2;
    } catch (_) {
      const refreshed = (await chrome.tabs.query({})).find(t => t.url && t.url.includes(job.urlMatch));
      if (refreshed) return refreshed;
    }
  }
  return tab;
}

// ========== ジョブ実行共通ヘルパー ==========
// jobs配列を順次実行する。タブをアクティブにしない(ポップアップが閉じるのを防ぐ)
async function runJobsSequentially(jobs, label) {
  let okCount = 0, ngCount = 0;
  appendLog('bulk', `${label} 開始 (${jobs.length}種類)`);

  for (let i = 0; i < jobs.length; i++) {
    const job = jobs[i];
    setBulkHint(`▶ [${i + 1}/${jobs.length}] ${job.name} を実行中…`);
    appendLog('bulk', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      const targetTab = await getOrCreateJobTab(job);
      if (!targetTab || targetTab.id == null) {
        throw new Error(`タブを取得できませんでした (urlMatch=${job.urlMatch})`);
      }
      const tabId = targetTab.id;
      appendLog('bulk', `  タブID=${tabId} url=${targetTab.url?.slice(0, 80)}`);

      await chrome.scripting.executeScript({
        target: { tabId },
        func: installProgressOverlay,
        args: [job.overlayTitle]
      });
      const r = (await chrome.scripting.executeScript({
        target: { tabId },
        func: job.fn,
        args: job.args
      }))[0].result;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        okCount++;
        appendLog('bulk', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ngCount++;
        appendLog('bulk', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
        console.warn(`[${job.name}]`, r?.error);
      }
    } catch (e) {
      ngCount++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      appendLog('bulk', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}\n${e.stack || ''}`);
      console.error(`[${job.name}]`, e);
    }
    // ★ジョブ間のsleepを削除。
    // sleep中のsetTimeoutコールバックはpopupのmicrotask queueに依存するため、
    // popupが閉じた瞬間にawaitが消えて後続ジョブが実行されない可能性がある。
    // 連続実行で隙を作らない方が安定する。
  }
  appendLog('bulk', `${label} 完了: 成功 ${okCount} / 失敗 ${ngCount}`);
  setBulkHint(`🎉 ${label}完了: 成功 ${okCount} / 失敗 ${ngCount}`);
  return { okCount, ngCount };
}

// ========== ① 商品別売上ボタン ==========
$('bulk-dl-is').addEventListener('click', async () => {
  appendLog('bulk', `🔘 ①商品別売上 ボタン押下`);
  const dates = validateBulkDates();
  if (!dates) return;
  const { startDate, endDate } = dates;

  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-open').disabled = true;
  setBulkHint('🚀 商品別売上をbackgroundで実行中…');

  const payload = {
    startDate, endDate,
    period: $('is-period').value || 'daily',
    device: $('is-device').value || 'all',
    tax: $('is-tax').value || 'incl',
    filter: ($('is-filter').value || '').trim(),
    filterBy: $('is-filterBy').value || 'all',
    interval: parseFloat($('is-interval').value) || 3
  };

  // backgroundに依頼。fire-and-forget(popup閉じても継続)
  chrome.runtime.sendMessage({ type: 'run-itemsales', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `① 完了レスポンス: ${JSON.stringify(response)}`);
      setBulkHint(`✅ 商品別売上 完了`);
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-open').disabled = false;
  });

  appendLog('bulk', `→ backgroundへ依頼送信完了 (popup閉じても継続します)`);
  setBulkHint(`✅ background処理開始。popup閉じてもOKです`);
});

// ========== ② RPP 3種 連続ボタン ==========
$('bulk-dl-rpp').addEventListener('click', async () => {
  appendLog('bulk', `🔘 ②RPP3種 ボタン押下`);
  const dates = validateBulkDates();
  if (!dates) return;
  const { startDate, endDate } = dates;

  $('bulk-dl-is').disabled = true;
  $('bulk-dl-rpp').disabled = true;
  $('bulk-open').disabled = true;

  const payload = {
    rppAll: {
      startDate, endDate,
      interval: parseFloat($('rppAll-interval').value) || 3,
      options: collectRppOptions('rppAll')
    },
    rppItem: {
      startDate, endDate,
      timeout: parseInt($('rppItem-timeout').value, 10) || 10,
      options: collectRppOptions('rppItem'),
      selectionType: 3, reportType: 4,
      panelPrefix: 'rppItem', reportName: '全商品レポート'
    },
    rppKw: {
      startDate, endDate,
      timeout: parseInt($('rppKw-timeout').value, 10) || 10,
      options: collectRppOptions('rppKw'),
      selectionType: 4, reportType: 3,
      panelPrefix: 'rppKw', reportName: '全キーワードレポート'
    }
  };

  // backgroundに依頼。popup閉じても継続するのでfire-and-forgetで返答待たなくてもOK
  chrome.runtime.sendMessage({ type: 'run-bulk-rpp3', payload }, (response) => {
    if (chrome.runtime.lastError) {
      appendLog('bulk', `⚠ background応答エラー(処理は継続している可能性あり): ${chrome.runtime.lastError.message}`);
    } else {
      appendLog('bulk', `② 完了レスポンス: ${JSON.stringify(response)}`);
      setBulkHint(`✅ RPP3種 完了`);
    }
    $('bulk-dl-is').disabled = false;
    $('bulk-dl-rpp').disabled = false;
    $('bulk-open').disabled = false;
  });

  appendLog('bulk', `→ backgroundへ依頼送信完了 (popup閉じても継続します)`);
  setBulkHint(`✅ background処理開始。popup閉じてもOKです`);
});

// リアルタイムログ受信(どのパネルから来たかをmsg.panelで判定)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'rms-log') {
    setStatus(msg.panel, msg.text);
    if (typeof msg.progress === 'number') setProgress(msg.panel, msg.progress);
  }
});

// ========== 全ての広告(RPP) ==========

// フォーム値を集める(prefixで使い回す: rppAll / rppItem / rppKw)
function collectRppOptions(prefix) {
  const getRadio = name => document.querySelector(`input[name="${name}"]:checked`)?.value;
  const getCb = id => $(id)?.checked;
  return {
    periodType: parseInt(getRadio(`${prefix}-periodType`) || '0', 10),
    campaignType: getRadio(`${prefix}-campaignType`) || '1',
    reportFilter: parseInt(getRadio(`${prefix}-reportFilter`) || '1', 10),
    rankType: 1,
    allUsers: getCb(`${prefix}-allUsers`),
    newUsers: getCb(`${prefix}-newUsers`),
    existingUsers: getCb(`${prefix}-existingUsers`),
    noOfClicks: getCb(`${prefix}-noOfClicks`),
    adsalesBefore: getCb(`${prefix}-adsalesBefore`),
    cpc: getCb(`${prefix}-cpc`),
    h12: getCb(`${prefix}-h12`),
    h720: getCb(`${prefix}-h720`),
    gms: getCb(`${prefix}-gms`),
    roas: getCb(`${prefix}-roas`),
    cv: getCb(`${prefix}-cv`),
    cvr: getCb(`${prefix}-cvr`),
    cpa: getCb(`${prefix}-cpa`)
  };
}

// 既定値に戻す処理(prefixで使い回す)
// allCheckedAll: 「全ての広告」は新規・既存OFFが初期値。商品別/キーワード別は全てONが画像の状態
function resetRppForm(prefix, opts = { userAllOn: false, h12On: false }) {
  const setRadio = (name, value) => {
    const el = document.querySelector(`input[name="${name}"][value="${value}"]`);
    if (el) el.checked = true;
  };
  setRadio(`${prefix}-periodType`, '0');
  setRadio(`${prefix}-campaignType`, '1');
  setRadio(`${prefix}-reportFilter`, '1');
  const cbMap = {
    [`${prefix}-allUsers`]: true,
    [`${prefix}-newUsers`]: opts.userAllOn,
    [`${prefix}-existingUsers`]: opts.userAllOn,
    [`${prefix}-noOfClicks`]: true,
    [`${prefix}-adsalesBefore`]: true,
    [`${prefix}-cpc`]: true,
    [`${prefix}-h12`]: opts.h12On,
    [`${prefix}-h720`]: true,
    [`${prefix}-gms`]: true,
    [`${prefix}-roas`]: true,
    [`${prefix}-cv`]: true,
    [`${prefix}-cvr`]: true,
    [`${prefix}-cpa`]: true
  };
  for (const [id, val] of Object.entries(cbMap)) {
    const el = $(id);
    if (el) el.checked = val;
  }
}

// 既定値に戻すボタン(全ての広告)
$('rppAll-reset').addEventListener('click', () => {
  resetRppForm('rppAll', { userAllOn: false, h12On: false });
});

// 既定値に戻すボタン(商品別 / キーワード別)
$('rppItem-reset').addEventListener('click', () => {
  resetRppForm('rppItem', { userAllOn: true, h12On: true });
});
$('rppKw-reset').addEventListener('click', () => {
  resetRppForm('rppKw', { userAllOn: true, h12On: true });
});

// 全ての広告 ボタン
$('rppAll-run').addEventListener('click', async () => {
  const startDate = $('rppAll-start').value;
  const endDate = $('rppAll-end').value;
  const interval = parseFloat($('rppAll-interval').value) || 1;

  if (!startDate) { setStatus('rppAll', '❌ 開始日を入力してください', false); return; }
  if (!endDate) { setStatus('rppAll', '❌ 終了日を入力してください', false); return; }
  if (startDate > endDate) { setStatus('rppAll', '❌ 開始日が終了日より後になっています', false); return; }

  // RPPタブを「URL一致」で探す(アクティブでなくてもOK)
  const allTabs = await chrome.tabs.query({});
  const tab = allTabs.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
  if (!tab) {
    setStatus('rppAll', '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
  }

  const options = collectRppOptions('rppAll');

  $('rppAll-run').disabled = true;
  setStatus('rppAll', '🚀 開始…', false);
  setProgress('rppAll', 0);

  try {
    // ページにオーバーレイ進捗ウィンドウを設置
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 全ての広告 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: rppAllDownloader,
      args: [{ startDate, endDate, interval, options }]
    }))[0].result;
    if (r?.ok) setStatus('rppAll', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('rppAll', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('rppAll', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('rppAll-run').disabled = false;
  }
});

// ========== 商品別売上 ボタン ==========
$('is-run').addEventListener('click', async () => {
  const params = {
    startDate: $('is-start').value,
    endDate: $('is-end').value,
    period: $('is-period').value,
    device: $('is-device').value,
    tax: $('is-tax').value,
    filter: $('is-filter').value.trim(),
    filterBy: $('is-filterBy').value,
    interval: parseFloat($('is-interval').value) || 2
  };

  if (!params.startDate) { setStatus('is', '❌ 開始日を入力してください', false); return; }
  if (!params.endDate) { setStatus('is', '❌ 終了日を入力してください', false); return; }
  if (params.startDate > params.endDate) { setStatus('is', '❌ 開始日が終了日より後になっています', false); return; }

  // 商品別売上タブをURL一致で探す
  const allTabsIs = await chrome.tabs.query({});
  const tab = allTabsIs.find(t => t.url && t.url.includes('datatool.rms.rakuten.co.jp/realtime/item'));
  if (!tab) {
    setStatus('is', '❌ 商品別売上ページ(datatool.rms.rakuten.co.jp/realtime/item)を開いてください', false); return;
  }

  $('is-run').disabled = true;
  setStatus('is', '🚀 開始…', false);
  setProgress('is', 0);

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installProgressOverlay,
      args: ['🛒 商品別売上 ダウンロード中']
    });

    const r = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: itemSalesDownloader,
      args: [params]
    }))[0].result;
    if (r?.ok) setStatus('is', `\n✅ 完了: 成功 ${r.success} / 失敗 ${r.fail}`);
    else setStatus('is', `\n❌ ${r?.error || '不明なエラー'}`);
  } catch (e) {
    setStatus('is', `\n❌ 実行エラー: ${e.message}`);
  } finally {
    $('is-run').disabled = false;
  }
});

// ========== 商品別 / キーワード別(RPP 非同期レポート) 共通ハンドラ ==========
// reportType: 4 = 全商品レポート, 3 = 全キーワードレポート
// selectionType: 3 = 商品別, 4 = キーワード別
function registerRppAsyncHandler(prefix, selectionType, reportType, reportName, buttonLabelWhenDone) {
  $(`${prefix}-run`).addEventListener('click', async () => {
    const startDate = $(`${prefix}-start`).value;
    const endDate = $(`${prefix}-end`).value;
    const timeout = parseInt($(`${prefix}-timeout`).value, 10) || 120;

    if (!startDate) { setStatus(prefix, '❌ 開始日を入力してください', false); return; }
    if (!endDate) { setStatus(prefix, '❌ 終了日を入力してください', false); return; }
    if (startDate > endDate) { setStatus(prefix, '❌ 開始日が終了日より後になっています', false); return; }

    // RPPタブをURL一致で探す
    const allTabsRpp = await chrome.tabs.query({});
    const tab = allTabsRpp.find(t => t.url && t.url.includes('ad.rms.rakuten.co.jp/rpp'));
    if (!tab) {
      setStatus(prefix, '❌ RPPページ(ad.rms.rakuten.co.jp/rpp)を開いてください', false); return;
    }

    const options = collectRppOptions(prefix);

    $(`${prefix}-run`).disabled = true;
    setStatus(prefix, `🚀 ${reportName} 開始…`, false);
    setProgress(prefix, 0);

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: installProgressOverlay,
        args: [`🛒 ${reportName} ダウンロード中`]
      });

      const r = (await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: rppAsyncDownloader,
        args: [{ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix: prefix, reportName }]
      }))[0].result;
      if (r?.ok) setStatus(prefix, `\n✅ ${r.filename || '完了'}`);
      else setStatus(prefix, `\n❌ ${r?.error || '不明なエラー'}`);
    } catch (e) {
      setStatus(prefix, `\n❌ 実行エラー: ${e.message}`);
    } finally {
      $(`${prefix}-run`).disabled = false;
    }
  });
}

registerRppAsyncHandler('rppItem', 3, 4, '全商品レポート');
registerRppAsyncHandler('rppKw', 4, 3, '全キーワードレポート');


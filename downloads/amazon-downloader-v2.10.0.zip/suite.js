// 最上部：共通の開始日/終了日 と「必要ページを開く」
const $ = (id) => document.getElementById(id);
function jstToday(off = 0) {
  return new Date(Date.now() + 9 * 3600 * 1000 + off * 86400000).toISOString().slice(0, 10);
}
const DATE_LOCK_KEY = 'amazon_dl_date_lock';

async function initTop() {
  const store = await chrome.storage.local.get([DATE_LOCK_KEY, 'sharedDates']);
  const lock = store[DATE_LOCK_KEY];
  const sd = store.sharedDates;
  let s, e;
  if (lock) {                       // 固定されていれば固定値を優先
    s = lock.startDate || jstToday(-1);
    e = lock.endDate || jstToday(-1);
  } else {                          // それ以外は前回値、なければ昨日
    s = sd && sd.start ? sd.start : jstToday(-1);
    e = sd && sd.end ? sd.end : jstToday(-1);
  }
  $('top-start').value = s;
  $('top-end').value = e;
  await chrome.storage.local.set({ sharedDates: { start: s, end: e } });
  updateDateLockUI(!!lock);
}

function setDateHint(msg, isError) {
  const el = $('date-hint'); if (!el) return;
  el.textContent = msg || '';
  el.style.color = isError ? '#a01010' : '#806000';
}

function updateDateLockUI(locked) {
  const badge = $('date-lock-badge'); if (badge) badge.style.display = locked ? 'inline-block' : 'none';
  ['top-start', 'top-end'].forEach((id) => {
    const el = $(id); if (!el) return;
    el.classList.toggle('date-locked', locked);
  });
  const sb = $('date-save');
  if (sb) { sb.textContent = locked ? '✅ 保存中(再保存で更新)' : '💾 日付を保存(固定)'; sb.classList.toggle('locked', locked); }
}

$('date-save').addEventListener('click', async () => {
  const startDate = $('top-start').value, endDate = $('top-end').value;
  if (!startDate && !endDate) { setDateHint('❌ 保存する日付を入力してください', true); return; }
  await chrome.storage.local.set({ [DATE_LOCK_KEY]: { startDate, endDate } });
  updateDateLockUI(true);
  setDateHint(`✅ 保存しました (${startDate || '(空)'} 〜 ${endDate || '(空)'})`);
});

$('date-clear').addEventListener('click', async () => {
  await chrome.storage.local.remove([DATE_LOCK_KEY]);
  updateDateLockUI(false);
  setDateHint('🔓 日付の固定を解除しました');
});
async function save() {
  const now = Date.now();
  const startDate = $('top-start').value, endDate = $('top-end').value;
  const patch = {
    sharedDates: { start: startDate, end: endDate },
    // 日付(月)を変えたら「取得済み」表示をリセット
    ads_status: { state: 'idle', ts: now },
    ship_status: { state: 'idle', ts: now },
    kw_status: { state: 'idle', ts: now }
  };
  // 固定中に日付を変えたら、固定値も追従して更新
  const store = await chrome.storage.local.get([DATE_LOCK_KEY]);
  if (store[DATE_LOCK_KEY]) patch[DATE_LOCK_KEY] = { startDate, endDate };
  chrome.storage.local.set(patch);
}
$('top-start').addEventListener('change', save);
$('top-end').addEventListener('change', save);

$('top-open').addEventListener('click', async () => {
  const urls = [
    'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
    'https://sellercentral-japan.amazon.com/orders-v3?page=1'
  ];
  for (const u of urls) { try { await chrome.tabs.create({ url: u, active: false }); } catch (_) {} }
  const b = $('top-open'); b.textContent = '✅ 開きました（各タブを一度表示してください）';
  setTimeout(() => (b.textContent = '🗂️ 必要ページを開く'), 2500);
});

initTop();

// ===== 保存先(File System Access API)の状態表示 =====
async function renderFs() {
  const st = await AMZ_FS.status();
  const nameEl = $('fs-name'), setBtn = $('fs-set');
  if (st.state === 'granted') {
    nameEl.textContent = st.name; nameEl.style.color = '#1a7f37';
    setBtn.textContent = '変更'; setBtn.style.background = '#888';
  } else if (st.state === 'none') {
    nameEl.textContent = '未設定（要設定）'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '設定'; setBtn.style.background = '#c25a00';
  } else {
    nameEl.textContent = (st.name || '') + '：要許可'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '許可'; setBtn.style.background = '#c25a00';
  }
}
$('fs-set').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
});
chrome.storage.onChanged.addListener((ch) => { if (ch.amz_fs_state) renderFs(); });
renderFs();

// ===== 各セクション(iframe)の高さを中身に自動で合わせる =====
// iframe 内に個別の縦スクロールバーが出ないようにする。
// ログ欄をドラッグで広げた時や表示内容が増えた時も ResizeObserver で追従する。
(function autoFitFrames() {
  const fit = (f) => {
    try {
      const b = f.contentDocument && f.contentDocument.body;
      if (!b) return;
      const h = Math.ceil(b.getBoundingClientRect().height);
      if (h > 0 && f.style.height !== h + 'px') f.style.height = h + 'px';
    } catch (_) {}
  };
  const hook = (f) => {
    fit(f);
    try {
      if (f.__amzRO) f.__amzRO.disconnect();
      const RO = (f.contentWindow && f.contentWindow.ResizeObserver) || ResizeObserver;
      f.__amzRO = new RO(() => fit(f));
      f.__amzRO.observe(f.contentDocument.body);
    } catch (_) {}
  };
  document.querySelectorAll('iframe.frame').forEach((f) => {
    f.addEventListener('load', () => hook(f));
    try { if (f.contentDocument && f.contentDocument.readyState === 'complete' && f.contentDocument.body) hook(f); } catch (_) {}
  });
})();

// ===== 3種まとめてDL =====
// 各セクション(iframe)の「実行」ボタンをそのまま押して完了を待つ。
//  ・広告 → KW は同じAmazon広告タブを使う(KWはタブを遷移させる)ので順番に実行
//  ・出荷数はバックグラウンド(セラーセントラル)で動くので並行して実行
// 完了判定: ボタンが disabled(実行中) → 再び有効 になったら終了。
//           成功は各 *_status が 'done' かつ開始後に更新されていること。
(function bulkDownload() {
  const btn = $('all-run'); if (!btn) return;
  const msg = $('all-msg');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const STEPS = {
    ads:  { frame: 'f-ads',  statusKey: 'ads_status',  chip: 'st-ads',  label: '📊 広告' },
    ship: { frame: 'f-ship', statusKey: 'ship_status', chip: 'st-ship', label: '📦 出荷数' },
    kw:   { frame: 'f-kw',   statusKey: 'kw_status',   chip: 'st-kw',   label: '🔑 KW' }
  };
  let running = false, stopReq = false;

  const setChip = (k, cls, suffix) => {
    const el = $(STEPS[k].chip); if (!el) return;
    el.className = 'step ' + cls;
    el.textContent = STEPS[k].label + (suffix ? ' ' + suffix : '');
  };
  const setMsg = (html) => { if (msg) msg.innerHTML = html; };
  const frameDoc = (k) => { try { return document.getElementById(STEPS[k].frame).contentDocument; } catch (_) { return null; } };
  const lastLine = (doc) => {
    try {
      const el = doc.getElementById('status');
      const t = (el && (el.value || el.textContent) || '').trim().split('\n').filter(Boolean);
      return t.length ? t[t.length - 1].trim().slice(0, 80) : '';
    } catch (_) { return ''; }
  };

  // 1セクションを実行して終わるまで待つ
  async function runStep(k) {
    if (stopReq) { setChip(k, 'skip', '中止'); return { ok: false, skipped: true }; }
    const doc = frameDoc(k);
    const b = doc && doc.getElementById('run');
    if (!b) { setChip(k, 'ng', '✕'); return { ok: false, error: '画面が読み込まれていません' }; }
    if (b.disabled) { setChip(k, 'ng', '✕'); return { ok: false, error: 'すでに実行中です' }; }
    const t0 = Date.now();
    setChip(k, 'run', '⏳');
    b.click();
    // 開始待ち(ボタンが disabled になる)。ならなければ開始前エラー
    let started = false;
    for (let i = 0; i < 40; i++) { await sleep(200); if (b.disabled) { started = true; break; } }
    if (!started) {
      setChip(k, 'ng', '✕');
      return { ok: false, error: lastLine(doc) || '開始できませんでした' };
    }
    // 終了待ち
    while (b.disabled) await sleep(1000);
    await sleep(300);
    const st = (await chrome.storage.local.get([STEPS[k].statusKey]))[STEPS[k].statusKey] || {};
    const ok = st.state === 'done' && (st.ts || 0) >= t0;
    if (ok) setChip(k, 'ok', '✓');
    else if (stopReq) setChip(k, 'skip', '停止');
    else setChip(k, 'ng', '✕');
    return { ok, error: ok ? '' : (lastLine(doc) || '失敗') };
  }

  function requestStopAll() {
    stopReq = true;
    for (const k of Object.keys(STEPS)) {
      try { const s = frameDoc(k).getElementById('stop'); if (s) s.click(); } catch (_) {}
    }
    btn.disabled = true; btn.textContent = '停止処理中…';
    setMsg('■ 停止を要求しました（現在の日の処理が終わり次第止まります）');
  }

  btn.addEventListener('click', async () => {
    if (running) { requestStopAll(); return; }

    const startDate = $('top-start').value, endDate = $('top-end').value;
    if (!startDate || !endDate) { setMsg('❌ 上で開始日・終了日を入力してください'); return; }
    if (startDate > endDate) { setMsg('❌ 開始日が終了日より後になっています'); return; }
    try {
      const fs = await AMZ_FS.status();
      if (fs.state !== 'granted') {
        setMsg('❌ 保存先フォルダが未設定／要許可です。「保存先」から設定してください');
        chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
        return;
      }
    } catch (_) {}

    running = true; stopReq = false;
    btn.classList.add('running'); btn.textContent = '■ まとめて停止';
    for (const k of Object.keys(STEPS)) setChip(k, 'wait', '待機');
    setMsg(`▶ ${startDate} 〜 ${endDate} を取得中…<br><b>実行中はこのポップアップを閉じないでください。</b>`);

    const results = {};
    try {
      // 出荷数は並行、広告 → KW は順番
      const shipP = runStep('ship').then((r) => (results.ship = r));
      results.ads = await runStep('ads');
      results.kw = await runStep('kw');
      await shipP;
    } catch (e) {
      setMsg('❌ ' + (e && e.message || e));
    }

    const okN = Object.values(results).filter((r) => r && r.ok).length;
    const name = { ads: '広告', ship: '出荷数', kw: 'KW' };
    const ngs = Object.entries(results).filter(([, r]) => r && !r.ok && !r.skipped)
      .map(([k, r]) => `${name[k]}：${r.error}`);
    if (stopReq) setMsg(`■ 停止しました（完了 ${okN}/3）`);
    else if (okN === 3) setMsg(`🎉 3種すべて完了しました（${startDate} 〜 ${endDate}）`);
    else setMsg(`⚠ 完了 ${okN}/3<br>` + ngs.map((t) => '・' + t.replace(/</g, '&lt;')).join('<br>'));
    try {
      chrome.notifications.create('all-' + Date.now(), {
        type: 'basic', iconUrl: 'icons/icon128.png',
        title: '3種まとめてDL：' + (okN === 3 ? '完了' : `完了 ${okN}/3`),
        message: `${startDate} 〜 ${endDate}`, priority: 2
      }, (id) => setTimeout(() => chrome.notifications.clear(id), 8000));
    } catch (_) {}

    running = false;
    btn.disabled = false; btn.classList.remove('running'); btn.textContent = '⏬ 3種まとめてDL';
  });
})();

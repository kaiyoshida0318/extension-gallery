// ============================================================
// bridge.js  (world: ISOLATED = 既定, run_at: document_start)
// hook.js(MAIN世界)からの postMessage を受け取り、
// chrome.storage.local に最新の retrieveReport を保存する。
//
// エンドポイントごとに別キーで保存する:
//   ・campaign-manager/retrieveReport → amzn_captured      (広告データ用トークン)
//   ・cm/dds/retrieveReport           → amzn_cap_dds        (KWデータ用トークン)
// dds と campaign-manager ではトークンの通用先が異なるため、
// 上書きで混ざらないように分離している。
// ============================================================
(function () {
  const CAP_KEY = 'amzn_captured';   // campaign-manager 系(広告データ)
  const DDS_KEY = 'amzn_cap_dds';    // cm/dds 系(KWデータ)

  const safeParse = (s) => { try { return JSON.parse(s); } catch (_) { return null; } };

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__amznHook !== true) return;
    const url = d.url || '';
    const rec = {
      url,
      headers: d.headers || {},
      body: safeParse(d.body),
      bodyRaw: d.body || null,
      ts: d.ts || Date.now()
    };
    try {
      if (/\/dds\/retrieveReport/.test(url)) {
        chrome.storage.local.set({ [DDS_KEY]: rec });
      } else {
        chrome.storage.local.set({ [CAP_KEY]: rec });
      }
    } catch (_) {}
  });
})();

// ===== セラーセントラル 出荷数データ ダウンローダー (background) =====
importScripts('fsstore.js');
const SC_ORIGIN = 'https://sellercentral-japan.amazon.com';
const ORDERS_PAGE = SC_ORIGIN + '/orders-v3?page=1';
const API_PATH = '/orders-api/search';
const PAGE_SIZE = 100;            // 1回のAPI取得件数（画面の100件表示と同じ）
const MAX_LOG = 500;
const JST_OFFSET_MS = 9 * 3600 * 1000;
const NOTIFY_CLOSE_SEC = 8;       // 完了通知を自動で消すまでの秒数
const AGG_KEY = 'asin';          // 集計キー：ASIN固定
const FULFILLMENT_LABEL = { fba: 'Amazon出荷(FBA)', mfn: '出品者出荷', all: 'すべて' };

let stopRequested = false;
let running = false;

// ---------- ログ / 状態 ----------
async function log(msg, level = 'info') {
  const t = new Date(Date.now() + JST_OFFSET_MS).toISOString().slice(11, 19);
  const line = `[${t}] ${level === 'error' ? '❌ ' : level === 'warn' ? '⚠️ ' : ''}${msg}`;
  const { logs = [] } = await chrome.storage.local.get('logs');
  logs.push(line);
  while (logs.length > MAX_LOG) logs.shift();
  await chrome.storage.local.set({ logs });
}
async function setState(patch) {
  const { state = {} } = await chrome.storage.local.get('state');
  await chrome.storage.local.set({ state: { ...state, ...patch } });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- 日付（JST） ----------
function parseYmd(s) { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; }
function dayList(start, end) {
  const out = [];
  let t = Date.UTC(...Object.values(parseYmd(start)).map((v, i) => (i === 1 ? v - 1 : v)));
  const te = Date.UTC(...Object.values(parseYmd(end)).map((v, i) => (i === 1 ? v - 1 : v)));
  while (t <= te) { out.push(new Date(t).toISOString().slice(0, 10)); t += 86400000; }
  return out;
}
// JSTのその日 00:00:00 〜 23:59:59（セラーセントラル画面で「同日〜同日」を選んだ時と同じ形式）
function jstRange(ymd) {
  const { y, m, d } = parseYmd(ymd);
  const start = Date.UTC(y, m - 1, d) - JST_OFFSET_MS;
  return { start, end: start + 86400000 - 1000 };
}
function fileName(ymd) {               // 2026-09-16 → 出荷数データ-2026-0916.csv
  const [y, m, d] = ymd.split('-');
  return `出荷数データ-${y}-${m}${d}.csv`;
}

// ---------- セラーセントラルのタブ ----------
async function getScTab() {
  const tabs = await chrome.tabs.query({ url: SC_ORIGIN + '/*' });
  const ready = tabs.find((t) => t.status === 'complete') || tabs[0];
  if (ready) return ready;
  await log('セラーセントラルのタブが無いため開きます…');
  const tab = await chrome.tabs.create({ url: ORDERS_PAGE, active: false });
  for (let i = 0; i < 60; i++) {
    await sleep(1000);
    const t = await chrome.tabs.get(tab.id);
    if (t.status === 'complete') { await sleep(1500); return t; }
  }
  return tab;
}

// ページ内で実行される関数（ログイン済みCookieでAPIを叩く）
async function pageFetch(url) {
  try {
    const r = await fetch(url, { credentials: 'include', headers: { accept: 'application/json' } });
    const text = await r.text();
    let j = null;
    try { j = JSON.parse(text); } catch (e) { /* HTML(ログイン画面等) */ }
    if (!j) return { status: r.status, error: 'JSONではない応答（ログイン切れの可能性）' };
    if (!Array.isArray(j.orders)) return { status: r.status, error: '想定外の応答形式（ordersが無い）' };
    return {
      status: r.status,
      total: typeof j.total === 'number' ? j.total : null,
      orders: j.orders.map((o) => ({
        id: o.amazonOrderId,
        st: o.orderFulfillmentStatus,
        items: (o.orderItems || []).map((i) => ({
          itemId: i.orderItemId,
          asin: i.asin || '',
          sku: i.sellerSku || '',
          name: String((typeof i.extendedTitle === 'string' && i.extendedTitle) || i.productName || '').replace(/\uFFFD/g, '').trim(),
          qo: Number(i.quantityOrdered) || 0,
          qc: Number(i.quantityCanceled) || 0,
        })),
      })),
    };
  } catch (e) {
    return { status: 0, error: String(e && e.message || e) };
  }
}

async function fetchPage(tabId, url) {
  for (let attempt = 1; attempt <= 4; attempt++) {
    let res;
    try {
      const [inj] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageFetch, args: [url] });
      res = inj.result;
    } catch (e) {
      res = { status: 0, error: 'タブで実行できません: ' + e.message };
    }
    if (res && !res.error && res.status === 200) return res;
    const st = res ? res.status : 0;
    if (st === 401 || st === 403) throw new Error(`認証エラー(${st})。セラーセントラルに再ログインしてください`);
    if (st === 400 || st === 422) throw new Error(`入力エラー(${st})：${res.error || ''}`);
    if (attempt === 4) throw new Error(`取得失敗(${st}) ${res && res.error || ''}`);
    const wait = (st === 429 ? 5000 : 2000) * attempt;
    await log(`取得失敗(${st}) ${res && res.error || ''} → ${wait / 1000}秒後に再試行(${attempt}/3)`, 'warn');
    await sleep(wait);
  }
}

// ---------- 1日分 ----------
async function fetchDay(tabId, ymd, opt) {
  const { start, end } = jstRange(ymd);
  const orders = new Map();
  let offset = 0, total = null, page = 0;
  while (true) {
    if (stopRequested) throw new Error('停止しました');
    page++;
    const q = new URLSearchParams({
      limit: String(PAGE_SIZE),
      offset: String(offset),
      sort: 'order_date_asc',
      'date-range': `${start}-${end}`,
      fulfillmentType: opt.fulfillment,
      orderStatus: 'all',
      forceOrdersTableRefreshTrigger: 'false',
    });
    const res = await fetchPage(tabId, `${API_PATH}?${q}`);
    if (total === null) total = res.total;
    res.orders.forEach((o) => orders.set(o.id, o));
    const pages = total ? Math.ceil(total / PAGE_SIZE) : 1;
    await log(`${ymd} ページ${page}/${pages}：${res.orders.length}件（累計${orders.size}/${total ?? '?'}件）`);
    offset += PAGE_SIZE;
    if (!res.orders.length || res.orders.length < PAGE_SIZE || (total !== null && offset >= total)) break;
    await sleep(800);
  }
  if (total !== null && orders.size !== total) {
    await log(`${ymd} 件数不一致：取得${orders.size}件 / 画面上の総数${total}件（取得中に注文が増減した可能性）`, 'warn');
  }
  return { orders: [...orders.values()], total };
}

// ---------- 集計 / CSV ----------
function aggregate(ymd, orders, key) {
  const map = new Map();
  let canceledOrders = 0;
  for (const o of orders) {
    if (/cancel/i.test(o.st || '')) { canceledOrders++; continue; }   // キャンセル注文は除外
    for (const it of o.items) {
      const qty = it.qo - it.qc;                                        // 一部キャンセル分も差し引く
      if (qty <= 0) continue;
      const k = key === 'sku' ? it.sku : it.asin;
      let row = map.get(k);
      if (!row) { row = { asin: new Set(), sku: new Set(), name: it.name, qty: 0, orders: new Set() }; map.set(k, row); }
      row.asin.add(it.asin); row.sku.add(it.sku);
      row.qty += qty; row.orders.add(o.id);
    }
  }
  const rows = [...map.values()].sort((a, b) => b.qty - a.qty);
  return { rows, canceledOrders };
}

function csvCell(v) {
  const s = String(v ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function buildCsv(ymd, rows, key) {
  const head = key === 'sku'
    ? ['日付', 'SKU', 'ASIN', '商品名', '注文数量', '注文件数']
    : ['日付', 'ASIN', 'SKU', '商品名', '注文数量', '注文件数'];
  const lines = [head.map(csvCell).join(',')];
  for (const r of rows) {
    const asin = [...r.asin].join(' / '), sku = [...r.sku].join(' / ');
    const cols = key === 'sku' ? [ymd, sku, asin, r.name, r.qty, r.orders.size] : [ymd, asin, sku, r.name, r.qty, r.orders.size];
    lines.push(cols.map(csvCell).join(','));
  }
  return '\uFEFF' + lines.join('\r\n') + '\r\n';
}
function toDataUrl(text) {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return 'data:text/csv;charset=utf-8;base64,' + btoa(bin);
}

// ---------- 保存（File System Access API：選んだフォルダへ直接書き込み） ----------
// 保存先フォルダ直下にCSVを直接保存
async function saveCsv(ymd, name, csv) {
  const bytes = new TextEncoder().encode(csv);
  return AMZ_FS.writeFile('', name, bytes);   // 保存先直下に直接保存
}

// ---------- 完了通知 ----------
function notify(ok, ng, total) {
  const stopped = stopRequested;
  const title = stopped ? '出荷数データ：停止しました' : ng ? '出荷数データ：完了（一部失敗）' : '出荷数データ：ダウンロード完了';
  const message = `成功 ${ok}日 / 失敗 ${ng}日（全${total}日）` + (ng ? '\n詳細は拡張のログを確認してください' : '');
  const id = 'shipcount-' + Date.now();
  chrome.notifications.create(id, {
    type: 'basic', iconUrl: 'icons/icon128.png', title, message, priority: 2, requireInteraction: false,
  });
  setTimeout(() => chrome.notifications.clear(id), NOTIFY_CLOSE_SEC * 1000);   // 一定時間で自動で消す
  chrome.action.setBadgeBackgroundColor({ color: ng || stopped ? '#d13212' : '#067d62' });
  chrome.action.setBadgeText({ text: ng || stopped ? '!' : '✓' });
}
chrome.notifications.onClicked.addListener((id) => chrome.notifications.clear(id));

// ---------- メイン ----------
async function run(opt) {
  const fs = await AMZ_FS.status();
  if (fs.state !== 'granted') {
    await log('保存先フォルダが未設定、または許可が必要です。ポップアップの「保存先」から設定してください', 'error');
    try { chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') }); } catch (_) {}
    return;
  }
  running = true; stopRequested = false;
  await chrome.storage.local.set({ ship_status: { state: 'running', ts: Date.now() } });
  chrome.action.setBadgeText({ text: '…' });
  chrome.action.setBadgeBackgroundColor({ color: '#232f3e' });
  if (!FULFILLMENT_LABEL[opt.fulfillment]) opt.fulfillment = 'fba';   // 未指定時はFBA
  const days = dayList(opt.start, opt.end);
  await setState({ running: true, done: 0, total: days.length, current: '' });
  await log(`開始：${opt.start} 〜 ${opt.end}（${days.length}日）ASIN別 / ${FULFILLMENT_LABEL[opt.fulfillment]}`);
  let ok = 0, ng = 0;
  try {
    const tab = await getScTab();
    for (let i = 0; i < days.length; i++) {
      if (stopRequested) { await log('停止しました', 'warn'); break; }
      const ymd = days[i];
      await setState({ current: ymd, done: i });
      try {
        const { orders } = await fetchDay(tab.id, ymd, opt);
        const { rows, canceledOrders } = aggregate(ymd, orders, AGG_KEY);
        const csv = buildCsv(ymd, rows, AGG_KEY);
        const savedPath = await saveCsv(ymd, fileName(ymd), csv);
        const sumQty = rows.reduce((s, r) => s + r.qty, 0);
        await log(`💾 保存: ${savedPath}（${rows.length}商品 / 合計${sumQty}個、注文${orders.length}件、キャンセル除外${canceledOrders}件）`);
        ok++;
      } catch (e) {
        ng++;
        await log(`${ymd} 失敗：${e.message}`, 'error');
        if (/認証エラー|停止/.test(e.message)) break;
      }
      await setState({ done: i + 1 });
      if (i < days.length - 1) await sleep(Math.max(0, Number(opt.interval) || 0) * 1000);
    }
  } catch (e) {
    await log(`中断：${e.message}`, 'error');
  } finally {
    await log(`終了：成功${ok}日 / 失敗${ng}日`);
    notify(ok, ng, days.length);
    running = false;
    await setState({ running: false, current: '' });
    await chrome.storage.local.set({ ship_status: { state: stopRequested ? 'idle' : 'done', ts: Date.now() } });
  }
}

function dataUrlToBytes(dataUrl) {
  const bin = atob(dataUrl.slice(dataUrl.indexOf(',') + 1));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  if (msg.type === 'start') {
    if (running) { send({ ok: false, error: '実行中です' }); return; }
    run(msg.options);
    send({ ok: true });
  } else if (msg.type === 'stop') {
    stopRequested = true; send({ ok: true });
  } else if (msg.type === 'amz_ads_done') {
    chrome.storage.local.set({ ads_status: { state: 'done', ts: Date.now() } });
    // 広告ダウンロード完了(注入スクリプトから)。ポップアップを閉じていても通知を出す。
    const ok = msg.success || 0, ng = msg.fail || 0;
    const id = 'ads-' + Date.now();
    chrome.notifications.create(id, {
      type: 'basic', iconUrl: 'icons/icon128.png',
      title: ng ? '広告データ：完了（一部失敗）' : '広告データ：ダウンロード完了',
      message: `成功 ${ok}日 / 失敗 ${ng}日` + (ng ? '\n詳細は拡張のログを確認してください' : ''),
      priority: 2, requireInteraction: false,
    });
    setTimeout(() => chrome.notifications.clear(id), 8000);
    chrome.action.setBadgeBackgroundColor({ color: ng ? '#d13212' : '#067d62' });
    chrome.action.setBadgeText({ text: ng ? '!' : '✓' });
    send({ ok: true });
  } else if (msg.type === 'amz_save_data') {
    // 広告側(注入スクリプト)から届くCSVデータをフォルダへ書き込む
    (async () => {
      try {
        const path = await AMZ_FS.writeFile(msg.subdir, msg.filename, dataUrlToBytes(msg.dataUrl));
        send({ ok: true, path });
      } catch (e) {
        send({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true;   // 非同期レスポンス
  }
});

// SWが再起動したら実行中フラグをリセット
chrome.runtime.onStartup.addListener(() => setState({ running: false, current: '' }));
chrome.runtime.onInstalled.addListener(() => setState({ running: false, current: '' }));

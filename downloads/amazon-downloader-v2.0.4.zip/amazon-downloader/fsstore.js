// 保存先フォルダ(File System Access API)の管理。
// popup / 設定ページ(folder) / Service Worker(background) の全部から使う。
self.AMZ_FS = (() => {
  const DB = 'amz_suite_fs';
  const STORE = 'handles';
  const KEY = 'root';

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function getRoot() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).get(KEY);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
  }
  async function setRoot(handle) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(handle, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  // { state: 'none' | 'granted' | 'prompt' | 'denied', name }
  async function status() {
    const h = await getRoot();
    if (!h) return { state: 'none' };
    let state = 'prompt';
    try { state = await h.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    return { state, name: h.name };
  }
  // ユーザー操作の中から呼ぶ(ページ側専用。Service Worker では使えない)
  async function requestPermission() {
    const h = await getRoot();
    if (!h) return 'none';
    return h.requestPermission({ mode: 'readwrite' });
  }
  // root/サブフォルダ(多階層可)/ファイル名 に書き込む(同名は上書き)
  async function writeFile(subdir, filename, data) {
    const root = await getRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');
    let perm = 'prompt';
    try { perm = await root.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    if (perm !== 'granted') throw new Error('保存先フォルダへの書き込み許可が切れています（保存先を選び直してください）');

    const parts = (subdir || '').split('/').map((s) => s.trim()).filter(Boolean);
    let dir = root, made = [];
    try {
      for (const p of parts) { dir = await dir.getDirectoryHandle(p, { create: true }); made.push(p); }
    } catch (e) {
      // サブフォルダ作成に失敗したら保存先直下に保存(データを失わない)
      dir = root; made = [];
    }
    let fh;
    try {
      fh = await dir.getFileHandle(filename, { create: true });
    } catch (e) {
      throw new Error(`ファイル作成に失敗(${e.name}: ${e.message})。保存先フォルダが移動/削除された可能性があります。保存先を選び直してください`);
    }
    const w = await fh.createWritable();
    try { await w.write(data); await w.close(); }
    catch (e) { try { await w.abort(); } catch (_) {} throw new Error(`書き込みに失敗(${e.name}: ${e.message})`); }
    return `${root.name}/${made.length ? made.join('/') + '/' : ''}${filename}`;
  }
  return { getRoot, setRoot, status, requestPermission, writeFile };
})();

// ============================================================
// bridge.js  (world: ISOLATED = 既定, run_at: document_start)
// hook.js(MAIN世界)からの postMessage を受け取り、
// chrome.storage.local に最新の retrieveReport を保存する。
// ============================================================
(function () {
  const CAP_KEY = 'amzn_captured';

  const safeParse = (s) => { try { return JSON.parse(s); } catch (_) { return null; } };

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || d.__amznHook !== true) return;
    try {
      chrome.storage.local.set({
        [CAP_KEY]: {
          url: d.url || '',
          headers: d.headers || {},
          body: safeParse(d.body),   // {reportConfig:...} か null
          bodyRaw: d.body || null,
          ts: d.ts || Date.now()
        }
      });
    } catch (_) {}
  });
})();

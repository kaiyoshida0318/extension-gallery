// 最上部：共通の開始日/終了日 と「必要ページを開く」
const $ = (id) => document.getElementById(id);
function jstToday(off = 0) {
  return new Date(Date.now() + 9 * 3600 * 1000 + off * 86400000).toISOString().slice(0, 10);
}
async function initTop() {
  const { sharedDates } = await chrome.storage.local.get('sharedDates');
  const s = sharedDates && sharedDates.start ? sharedDates.start : jstToday(-1);
  const e = sharedDates && sharedDates.end ? sharedDates.end : jstToday(-1);
  $('top-start').value = s;
  $('top-end').value = e;
  await chrome.storage.local.set({ sharedDates: { start: s, end: e } });
}
function save() {
  chrome.storage.local.set({ sharedDates: { start: $('top-start').value, end: $('top-end').value } });
}
$('top-start').addEventListener('change', save);
$('top-end').addEventListener('change', save);

$('top-open').addEventListener('click', async () => {
  const urls = [
    'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
    'https://sellercentral-japan.amazon.com/orders-v3?page=1'
  ];
  for (const u of urls) { try { await chrome.tabs.create({ url: u, active: false }); } catch (_) {} }
  const b = $('top-open'); b.textContent = '✅ 開きました（各タブを一度表示してください）';
  setTimeout(() => (b.textContent = '🗂️ 必要ページを開く'), 2500);
});

initTop();

// ===== 保存先(File System Access API)の状態表示 =====
async function renderFs() {
  const st = await AMZ_FS.status();
  const nameEl = $('fs-name'), setBtn = $('fs-set');
  if (st.state === 'granted') {
    nameEl.textContent = st.name; nameEl.style.color = '#1a7f37';
    setBtn.textContent = '変更'; setBtn.style.background = '#888';
  } else if (st.state === 'none') {
    nameEl.textContent = '未設定（要設定）'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '設定'; setBtn.style.background = '#c25a00';
  } else {
    nameEl.textContent = (st.name || '') + '：要許可'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '許可'; setBtn.style.background = '#c25a00';
  }
}
$('fs-set').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
});
chrome.storage.onChanged.addListener((ch) => { if (ch.amz_fs_state) renderFs(); });
renderFs();

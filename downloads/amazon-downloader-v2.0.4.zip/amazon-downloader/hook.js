// ============================================================
// hook.js  (world: MAIN, run_at: document_start)
// Amazon広告ページが自分で送る retrieveReport を傍受し、
// 新鮮なトークン(ヘッダ)とボディを postMessage で bridge.js に渡す。
// ※ chrome.* は使えない世界なので postMessage 経由で受け渡す。
// ============================================================
(function () {
  if (window.__amznHookInstalled) return;
  window.__amznHookInstalled = true;

  const TARGET = 'retrieveReport';  // 新旧どちらのエンドポイントも捕捉

  const headersToObj = (h) => {
    const out = {};
    try {
      if (!h) return out;
      if (h instanceof Headers) h.forEach((v, k) => { out[k] = v; });
      else if (Array.isArray(h)) h.forEach(([k, v]) => { out[k] = v; });
      else if (typeof h === 'object') Object.assign(out, h);
    } catch (_) {}
    return out;
  };

  const report = (url, headers, body) => {
    try {
      window.postMessage({
        __amznHook: true,
        url,
        headers,
        body: (typeof body === 'string' ? body : null),
        ts: Date.now()
      }, '*');
    } catch (_) {}
  };

  // ---- fetch フック ----
  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      try {
        const url = (typeof input === 'string') ? input : (input && input.url) || '';
        if (url.indexOf(TARGET) !== -1) {
          let headers = headersToObj(init && init.headers);
          // Request オブジェクト側のヘッダも拾う
          if (input && input.headers instanceof Headers) {
            input.headers.forEach((v, k) => { if (!(k in headers)) headers[k] = v; });
          }
          const body = (init && init.body) || null;
          report(url, headers, body);
        }
      } catch (_) {}
      return origFetch.apply(this, arguments);
    };
  }

  // ---- XHR フック(念のため) ----
  const X = window.XMLHttpRequest;
  if (X && X.prototype) {
    const open = X.prototype.open;
    const setH = X.prototype.setRequestHeader;
    const send = X.prototype.send;
    X.prototype.open = function (method, url) {
      this.__amznUrl = url;
      this.__amznHeaders = {};
      return open.apply(this, arguments);
    };
    X.prototype.setRequestHeader = function (k, v) {
      try { if (this.__amznHeaders) this.__amznHeaders[k] = v; } catch (_) {}
      return setH.apply(this, arguments);
    };
    X.prototype.send = function (body) {
      try {
        if (this.__amznUrl && String(this.__amznUrl).indexOf(TARGET) !== -1) {
          report(this.__amznUrl, this.__amznHeaders || {}, body);
        }
      } catch (_) {}
      return send.apply(this, arguments);
    };
  }
})();

# RMS一括ダウンローダー v4.0

楽天RMSの各種レポートを日付範囲で一括ダウンロードするChrome拡張。
4タブ構成で、すべて実装済み。

## タブ構成

| タブ | 仕組み | 対応URL | 出力 |
|------|--------|---------|------|
| **商品別売上** (青) | 検索API → DL APIをページネーション | datatool.rms.rakuten.co.jp/realtime/item | 日次/月次/範囲 単位のCSV(楽天オリジナル形式) |
| **全ての広告** | downloadPerfFile を日ごとにループ | ad.rms.rakuten.co.jp/rpp/reports | 日ごとに1CSV(楽天オリジナル) |
| **商品別** | downloadAsync → list ポーリング → ZIP取得 | ad.rms.rakuten.co.jp/rpp/reports | 期間まるごと1ZIP(中にCSV) |
| **キーワード別** | downloadAsync → list ポーリング → ZIP取得 | ad.rms.rakuten.co.jp/rpp/reports | 期間まるごと1ZIP(中にCSV) |

## インストール

1. zipを解凍 → `rms-downloader/` フォルダ
2. Chromeで `chrome://extensions` を開く
3. 「デベロッパーモード」ON
4. 「パッケージ化されていない拡張機能を読み込む」 → `rms-downloader` フォルダを選択

## 使い方

各タブで「対応URL」に書かれたページを開いた状態で、日付範囲を選び、ダウンロード開始ボタンを押すだけ。

### 詳細オプション(全RPPタブ共通)
普段は閉じています。クリックで展開すると、以下が編集可能:
- 集計期間(全期間/月ごと/日ごと)
- 絞り込み: キャンペーン(ID/名前)
- 絞り込み: 商品・キーワード(ランキング/指定商品/指定キーワード)
- 顧客種類(合計/新規顧客/既存顧客)
- 実績項目(クリック数/実績額/CPC)
- コンバージョン種類(12時間/720時間)
- 効果項目(売上金額/ROAS/売上件数/CVR/注文獲得単価)

「既定値に戻す」で初期状態に。

### 「商品別」「キーワード別」タブの動作
1. `POST /reports/downloadAsync` でジョブ投入
2. `GET /download/list` を3秒間隔でポーリング
3. status=2(完了) を検知したらZIPを取得
4. ZIPを `rpp_item_reports_{店舗}_{時刻}.zip` の名前で保存

サーバーがZIP生成にかかる時間は通常10〜60秒程度。
タイムアウトは「完了待ち最大時間(秒)」で調整可能(初期値120秒)。

## API仕様メモ

### 商品別売上 (datatool)
- `GET /realtime/get-shop-item-list?...` で検索
- `GET /realtime/get-shop-item-dl?...&size=1000&cycleNumber=N` で全件取得
- レスポンスはJSON、クライアント側でCSV組み立て(楽天オリジナルと同形式)

### 全ての広告 (RPP downloadPerfFile)
- `POST /rpp/api/reports/downloadPerfFile`
- レスポンスは Shift_JIS CSV を直接返す
- 日付ごとに1ファイルなので、1日ずつループ実行

### 商品別 / キーワード別 (RPP downloadAsync)
- `POST /rpp/api/reports/downloadAsync` でジョブ投入(`{"status":"SUCCESS"}` 201返却)
- `GET /rpp/api/download/list` でジョブ一覧 (`data.userHistoryList[]`)
  - 各ジョブ: `id`, `status` (0=待機/1=処理中/2=完了/3=失敗/4=空完了), `reportType`, `requestDate`
- `GET /rpp/api/download/report?downloadId={id}&reportType={3or4}&storageType=STAAS` でZIP取得

## トラブル

- **401/403**: セッション切れ → 対応ページをリロードして再実行
- **タイムアウト**: 「完了待ち最大時間」を長く(180秒など)
- **同時に複数ジョブ投げると識別ミス**: 1つの拡張から複数ジョブを並行実行しないでください

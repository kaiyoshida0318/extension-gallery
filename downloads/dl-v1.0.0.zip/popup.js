// popup.js
const btn = document.getElementById('dlBtn');
const pickBtn = document.getElementById('pickBtn');
const statusEl = document.getElementById('status');
const logEl = document.getElementById('log');

function log(msg) {
  console.log('[RakutenDL]', msg);
  const time = new Date().toLocaleTimeString();
  logEl.textContent += `[${time}] ${msg}\n`;
  logEl.scrollTop = logEl.scrollHeight;
}
function setStatus(msg) { statusEl.textContent = msg; log(msg); }

window.addEventListener('error', (e) => log('💥 ' + e.message));
window.addEventListener('unhandledrejection', (e) => log('💥 ' + (e.reason?.message || e.reason)));

btn.addEventListener('click', async () => {
  log('▶ 商品画像取得');
  btn.disabled = true; pickBtn.disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('item.rakuten.co.jp')) {
      setStatus('⚠️ 楽天の商品ページで実行してください'); return;
    }
    setStatus('width=100% の商品画像を収集中…');

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: collectProductImages
    });
    log('検出: ' + JSON.stringify({ count: result?.urls?.length, debug: result?.debug }));

    if (!result?.urls?.length) {
      setStatus(`画像が見つかりませんでした\n${result?.debug || ''}`);
      return;
    }

    const preview = result.urls.slice(0, 20).map((u, i) => `${i+1}. ${u}`).join('\n');
    const more = result.urls.length > 20 ? `\n... 他${result.urls.length - 20}件` : '';
    setStatus(`✅ ${result.urls.length}件 検出\n${result.debug}\n\n${preview}${more}\n\nダウンロード開始…`);

    const response = await chrome.runtime.sendMessage({
      type: 'DOWNLOAD_ALL', urls: result.urls, folder: result.folder
    });

    if (response?.ok) {
      setStatus(`✅ ${response.success}/${result.urls.length}件 DL開始\nフォルダ: ${result.folder}\n\n${preview}${more}`);
    } else {
      setStatus('⚠️ エラー: ' + response?.error);
    }
  } catch (e) {
    setStatus('⚠️ ' + e.message);
    log('💥 ' + (e.stack || e));
  } finally {
    btn.disabled = false; pickBtn.disabled = false;
  }
});

pickBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('item.rakuten.co.jp')) {
      setStatus('⚠️ 楽天の商品ページで実行してください'); return;
    }
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: startPicker });
    window.close();
  } catch (e) {
    setStatus('⚠️ ' + e.message);
  }
});

// ===== ページ内で実行 =====
function collectProductImages() {
  try {
    const shopId = (location.pathname.match(/^\/([^\/]+)\//) || [])[1] || '';
    const allImgs = document.querySelectorAll('img');

    // width="100%" の img だけを抽出
    // HTML属性の width="100%" もしくは style の width:100% を判定
    const productImgs = [];
    let totalImgs = 0;
    let widthMatched = 0;

    allImgs.forEach(img => {
      totalImgs++;
      const widthAttr = img.getAttribute('width');
      const styleWidth = img.style.width;

      // width属性が "100%" もしくは style.width が "100%"
      const isFullWidth =
        (widthAttr && widthAttr.trim() === '100%') ||
        (styleWidth && styleWidth.replace(/\s/g, '') === '100%');

      if (!isFullWidth) return;
      widthMatched++;

      const src = img.currentSrc || img.src || img.getAttribute('src');
      if (!src) return;
      if (src.startsWith('data:') || src.startsWith('blob:')) return;

      productImgs.push(src);
    });

    // 絶対URL化
    let arr = productImgs.map(u => {
      try { return new URL(u, location.href).toString(); } catch { return null; }
    }).filter(Boolean);

    // 楽天画像CDNのみ（image.rakuten.co.jp / *.r10s.jp）
    arr = arr.filter(u => {
      try {
        const url = new URL(u);
        return url.hostname === 'image.rakuten.co.jp' || url.hostname.endsWith('.r10s.jp');
      } catch { return false; }
    });

    // ホスト統一: image.rakuten.co.jp を優先（shop.r10s.jp と同じ画像を指すため）
    arr = arr.map(u => {
      try {
        const url = new URL(u);
        if (url.hostname === 'shop.r10s.jp') {
          url.hostname = 'image.rakuten.co.jp';
        }
        return url.toString();
      } catch { return u; }
    });

    // 重複除去（出現順を保持）
    const seen = new Set();
    const ordered = [];
    for (const u of arr) {
      if (!seen.has(u)) {
        seen.add(u);
        ordered.push(u);
      }
    }
    arr = ordered;

    const debug = `全img${totalImgs}件 → width=100%が${widthMatched}件 → 楽天画像URL${arr.length}件`;

    const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+)/);
    const folder = 'rakuten-images/' + (m ? `${m[1]}_${m[2]}` : 'item_' + Date.now());
    return { urls: arr, folder, debug };
  } catch (e) {
    return { urls: [], folder: '', debug: 'エラー: ' + e.message };
  }
}

function startPicker() {
  if (window.__rakutenPickerActive) return;
  window.__rakutenPickerActive = true;
  const overlay = document.createElement('div');
  overlay.style.cssText = `position:fixed;pointer-events:none;border:3px solid #bf0000;background:rgba(191,0,0,0.08);z-index:2147483646;transition:all 0.05s;box-sizing:border-box;`;
  document.body.appendChild(overlay);
  const hint = document.createElement('div');
  hint.textContent = '画像エリアにカーソル合わせてクリック / Esc:キャンセル';
  hint.style.cssText = `position:fixed;top:10px;left:50%;transform:translateX(-50%);background:#bf0000;color:white;padding:8px 16px;border-radius:4px;font:bold 13px sans-serif;z-index:2147483647;pointer-events:none;box-shadow:0 2px 8px rgba(0,0,0,0.3);`;
  document.body.appendChild(hint);
  let cur = null;
  const onOver = (e) => {
    const el = e.target;
    if (!el || el === overlay || el === hint) return;
    cur = el;
    const r = el.getBoundingClientRect();
    overlay.style.left = r.left + 'px'; overlay.style.top = r.top + 'px';
    overlay.style.width = r.width + 'px'; overlay.style.height = r.height + 'px';
  };
  const onClick = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (!cur) return;
    cleanup();
    const urls = new Set();
    if (cur.tagName === 'IMG') { const s = cur.currentSrc || cur.src; if (s && !s.startsWith('data:')) urls.add(s); }
    cur.querySelectorAll('img').forEach(img => {
      [img.currentSrc, img.src].forEach(s => { if (s && !s.startsWith('data:') && !s.startsWith('blob:')) urls.add(s); });
    });
    let arr = Array.from(urls).map(u => { try { return new URL(u, location.href).toString(); } catch { return null; } }).filter(Boolean);
    arr = arr.filter(u => { try { const url = new URL(u); return url.hostname === 'image.rakuten.co.jp' || url.hostname.endsWith('.r10s.jp'); } catch { return false; } });
    arr = Array.from(new Set(arr)).sort();
    if (arr.length === 0) { toast('画像が見つかりません', true); return; }
    const m = location.pathname.match(/^\/([^\/]+)\/([^\/]+)/);
    const folder = 'rakuten-images/' + (m ? `${m[1]}_${m[2]}` : 'item_' + Date.now());
    toast(`${arr.length}件 DL中…`);
    chrome.runtime.sendMessage({ type: 'DOWNLOAD_ALL', urls: arr, folder }, (res) => {
      if (res?.ok) toast(`✅ ${res.success}/${arr.length}件 DL開始`); else toast('⚠️ ' + (res?.error || '不明'), true);
    });
  };
  const onKey = (e) => { if (e.key === 'Escape') { cleanup(); toast('キャンセル'); } };
  function cleanup() {
    document.removeEventListener('mouseover', onOver, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    overlay.remove(); hint.remove();
    window.__rakutenPickerActive = false;
  }
  function toast(t, err) {
    const d = document.createElement('div');
    d.textContent = t;
    d.style.cssText = `position:fixed;top:10px;left:50%;transform:translateX(-50%);background:${err?'#bf0000':'#222'};color:white;padding:10px 18px;border-radius:4px;font:13px sans-serif;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.3);`;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 3500);
  }
  document.addEventListener('mouseover', onOver, true);
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKey, true);
}

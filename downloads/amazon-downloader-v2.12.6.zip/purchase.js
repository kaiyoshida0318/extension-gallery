// ============================================================
// purchase.js  ④購入商品データ（v2.12.0〜, 仕様書「購入商品データ_取得仕様書.md」第2版 2026-10-26）
//   広告経由で「実際に買われた商品（ASIN）」ごとの広告売上を、1日1ファイルで取る（速報）。SP・SB 両方。宣伝商品/Halo を区別。
//   月別（確定値）は別ツール「Amazon月別-一括ダウンローダー」が担当（このツールでは取らない）。
//   取り元: 統合レポート（adsApi/v1）。① の65列版では取れない。
//   background（purchasejob.js）と拡張ページの両方から読み込む。
//
// 実機確認（2026-10-26）:
//  ・「日付(date.value)」＋「変換された商品ID(convertedProduct.id)」は組み合わせ可。ただし画面が自動で足す
//    マーケットプレイス2列と予算の通貨も入れないと INVALID_METRIC_COMBINATION（400）になる。
//  ・期間プリセット「過去30日間」は 日付 ありでも使える: period = {reportConfigurationPresetPeriod:{preset:'LAST_30_DAYS'}}
//  ・毎日の予約: scheduleType 'RECURRING_DAILY', schedule {recurringDailySchedule:{timeZone, hourOfDay, expirationDate}}
//    （hourOfDay と expirationDate は必須。作成直後は実行されず、翌日の指定時刻から）
//  ・日付の保持期間は24か月（reportingFields の dataRetentionPeriod: MONTHS_24）。実測では開始日 2024-10-12 まで作成可
//  ・実物の列: 日付(2026/10/25),変換された商品ID,…,キャンペーンID(="…"),予算の通貨,商品購入数,売上,注文された商品点数 ／ 1日ごとの行
// ============================================================
self.PURCHASE = (() => {
  const ACCOUNT = 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m';
  const SCHEDULE_NAME = 'Amacheck_購入商品データ_毎日';
  const FIELDS = ['date.value', 'convertedProduct.id', 'convertedProductMarketplace.value', 'productRelevance.value',
    'advertisedProduct.id', 'advertisedProductMarketplace.value', 'adProduct.value', 'campaign.name', 'campaign.id',
    'budgetCurrency.value', 'metric.purchases', 'metric.sales', 'metric.unitsSold'];
  // Amazon の列名（ja-JP）。英語表示になった場合の名前と、列の並び（FIELDS順）での位置も持っておく
  const COLS = {
    date:      { ja: ['日付'], en: ['Date'], pos: 0 },
    converted: { ja: ['変換された商品ID'], en: ['Converted product ID', 'Purchased product ID'], pos: 1 },
    relevance: { ja: ['商品の関連性'], en: ['Product relevance'], pos: 3 },
    advertised:{ ja: ['広告対象商品ID'], en: ['Advertised product ID'], pos: 4 },
    product:   { ja: ['広告プロダクト'], en: ['Ad product'], pos: 6 },
    campName:  { ja: ['キャンペーン名'], en: ['Campaign name'], pos: 7 },
    campId:    { ja: ['キャンペーンID'], en: ['Campaign ID'], pos: 8 },
    purchases: { ja: ['商品購入数'], en: ['Purchases'], pos: 10 },
    sales:     { ja: ['売上'], en: ['Sales'], pos: 11 },
    units:     { ja: ['注文された商品点数'], en: ['Units sold'], pos: 12 }
  };

  // ---- 統合レポートの設定（period / schedule を差し替えて使う） ----
  function config({ name, period, scheduleType, schedule }) {
    return {
      name, format: 'CSV', locale: 'ja-JP', status: 'ACTIVE', emailDeliveryMarketplace: 'JP',
      linkedAccounts: [{ advertiserAccountId: ACCOUNT }],
      linkedQuery: { reportingQuery: { fields: FIELDS, filter: null } },   // filter 無し＝全広告プロダクト・状態で絞らない
      period, scheduleType, schedule, timeZoneMode: 'CAMPAIGN_TIMEZONE'
    };
  }

  // ---- ページ(advertising-japan)で動く関数（executeScript で注入するので自己完結） ----
  async function pageCreateCfg({ headers, account, cfg }) {
    try {
      const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/create/reportConfigurations',
        { method: 'POST', credentials: 'include', headers, body: JSON.stringify({ accessRequestedAccounts: [{ advertiserAccountId: account }], reportConfigurations: [cfg] }) });
      const t = await r.text();
      let rc = null; try { const j = JSON.parse(t); rc = j.success && j.success[0] && j.success[0].reportConfiguration; } catch (_) {}
      if (!rc) return { ok: false, error: `HTTP ${r.status} ${t.slice(0, 200)}` };
      return { ok: true, cfgId: rc.reportConfigurationId, schedId: rc.latestScheduledReportId, next: rc.nextScheduledReportDateTime };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }
  // 名前で予約レポートを探す（最大5ページ）。ACTIVE のものだけ
  async function pageFindCfg({ headers, name }) {
    try {
      let token = null, found = null;
      for (let p = 0; p < 5 && !found; p++) {
        const body = { maxResults: 100 }; if (token) body.nextToken = token;
        const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/query/reportConfigurations',
          { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) });
        if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
        const j = await r.json();
        found = (j.reportConfigurations || []).find((c) => c.name === name && c.status === 'ACTIVE' && /RECURRING/.test(c.scheduleType || '')) || null;
        token = j.nextToken; if (!token) break;
      }
      return { ok: true, cfg: found ? { cfgId: found.reportConfigurationId, schedule: found.schedule, next: found.nextScheduledReportDateTime } : null };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }
  // そのレポートの実行履歴から、一番新しい「完了」の回と、処理中の回があるかを返す
  async function pageRuns({ headers, cfgId }) {
    try {
      const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/query/scheduledReports',
        { method: 'POST', credentials: 'include', headers, body: JSON.stringify({ reportConfigurationIdFilter: { include: [cfgId] }, maxResults: 50 }) });
      if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
      const list = ((await r.json()).scheduledReports || []);
      const done = list.filter((x) => x.status === 'COMPLETED').sort((a, b) => String(b.scheduledDateTime || b.creationDateTime).localeCompare(String(a.scheduledDateTime || a.creationDateTime)));
      const latest = list.slice().sort((a, b) => String(b.scheduledDateTime || b.creationDateTime).localeCompare(String(a.scheduledDateTime || a.creationDateTime)))[0] || null;
      return { ok: true, completed: done[0] ? { schedId: done[0].scheduledReportId, at: done[0].scheduledDateTime || done[0].creationDateTime } : null,
        latest: latest ? { status: latest.status, schedId: latest.scheduledReportId, failure: latest.failureCode } : null };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }

  // ---- 変換（Amazon CSV → Amacheck 用の④・日別） ----
  // 仕様書 第2版：1ファイル＝1日。CSVに日付列は入れない（日付はファイル名）。
  // 取り元は「日付」入りのレポート（予約の過去30日分 or その場で作る期間指定）で、ここで日ごとに分ける。
  const AD_TYPE = { 'Sponsored Products': 'SP', 'Sponsored Brands': 'SB', 'Sponsored Display': 'SD',
    'スポンサープロダクト広告': 'SP', 'スポンサーブランド広告': 'SB', 'スポンサーディスプレイ広告': 'SD' };
  const REL = { 'Promoted': '宣伝商品', 'Brand halo': 'Halo', 'プロモーション': '宣伝商品', 'ブランドハロー': 'Halo' };
  const OUT_HEADER = ['広告タイプ', 'キャンペーン名', 'キャンペーンID', '広告対象ASIN', '購入ASIN', '関連性', '商品購入数', '注文点数', '売上'];

  // text: Amazon の CSV 文字列 → { ok, byDay: { 'YYYY-MM-DD': [[...OUT_HEADER順]] }, header(元), minDate, maxDate }
  function transform(text) {
    const table = OFFICIAL.parseCsv(text);
    if (!table.length) return { ok: false, error: 'CSVが空でした' };
    const header = table[0].map((h) => String(h).replace(/^\uFEFF/, '').trim());
    const idx = {}, missing = [];
    for (const [k, c] of Object.entries(COLS)) {
      let i = header.findIndex((h) => c.ja.includes(h) || c.en.map((x) => x.toLowerCase()).includes(h.toLowerCase()));
      // 列名が想定外でも並びが同じなら位置で（日付は除く：日付なしの「期間」まとめ版を日別と取り違えないため）
      if (i < 0 && k !== 'date' && header.length === FIELDS.length) i = c.pos;
      if (i < 0) missing.push(c.ja[0]);
      idx[k] = i;
    }
    if (idx.date < 0 && header.some((h) => h === '期間' || /^(date range|period)$/i.test(h)))
      return { ok: false, error: '「日付」列がありません（期間まとめの版です）。日別にするにはレポートのディメンションに「日付」を入れてください' };
    if (missing.length) return { ok: false, error: '必要な列が見つかりません: ' + missing.join('、') + '（列: ' + header.join(',').slice(0, 200) + '）' };
    const num = OFFICIAL.num;
    const byDay = {};
    let minDate = '', maxDate = '';
    for (const r of table.slice(1)) {
      const day = OFFICIAL.normDate(r[idx.date]);
      if (!day) continue;
      if (!minDate || day < minDate) minDate = day;
      if (!maxDate || day > maxDate) maxDate = day;
      const purchases = num(r[idx.purchases]), units = num(r[idx.units]), sales = num(r[idx.sales]);
      if (purchases === 0 && units === 0 && sales === 0) continue;     // 全部0の行は出さない
      const prod = String(r[idx.product] || '').trim();
      const rel = String(r[idx.relevance] || '').trim();
      (byDay[day] = byDay[day] || []).push([AD_TYPE[prod] || prod, r[idx.campName] || '', OFFICIAL.normId(r[idx.campId]).replace(/[^\dA-Za-z]/g, ''),
        String(r[idx.advertised] || '').trim(), String(r[idx.converted] || '').trim(), REL[rel] || rel,
        String(r[idx.purchases] ?? '').trim(), String(r[idx.units] ?? '').trim(), String(r[idx.sales] ?? '').trim()]);
    }
    // 並び: 広告タイプ → キャンペーン名 → 購入ASIN
    for (const rows of Object.values(byDay))
      rows.sort((a, b) => a[0].localeCompare(b[0]) || String(a[1]).localeCompare(String(b[1]), 'ja') || a[4].localeCompare(b[4]));
    return { ok: true, byDay, header, minDate, maxDate };
  }
  // 行が0件の日も列名だけのファイルを出す（「取ったが0件」と「取り忘れ」を区別するため）
  function toCsv(rows) {
    const lines = [OUT_HEADER.map(OFFICIAL.csvCell).join(',')];
    for (const r of rows || []) lines.push(r.map(OFFICIAL.csvCell).join(','));
    return '\uFEFF' + lines.join('\r\n') + '\r\n';
  }
  const compact = (d) => { const [y, m, dd] = d.split('-'); return `${y}-${m}${dd}`; };
  // 購入商品データ-YYYY-MMDD.csv（YYYY-MMDD はデータの日付）
  const fileName = (day) => `購入商品データ-${compact(day)}.csv`;

  return { ACCOUNT, SCHEDULE_NAME, FIELDS, OUT_HEADER, config, pageCreateCfg, pageFindCfg, pageRuns, transform, toCsv, fileName };
})();

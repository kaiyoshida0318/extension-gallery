// 対象サイトのページに注入される downloader 群(ISOLATED world)
// 結果は { status: 'ok' | 'noData' | 'notReady' | 'error' | 'cancelled', message } で返す。
(() => {
  if (window.__AMZDL) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const progress = (kind, msg) => {
    try { chrome.runtime.sendMessage({ type: 'amz_progress', kind, msg }); } catch (e) { /* noop */ }
  };

  const isCancelled = async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'amz_is_cancelled' });
      return !!(r && r.cancelled);
    } catch (e) { return false; }
  };

  function monthRange(month) {
    const [y, m] = month.split('-').map(Number);
    const mm = String(m).padStart(2, '0');
    const startMs = Date.UTC(y, m - 1, 1) - 9 * 3600e3; // JST 00:00
    const nextMs = Date.UTC(y, m, 1) - 9 * 3600e3;
    const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const dd = String(last).padStart(2, '0');
    return {
      y, m, mm, last, dd,
      startMs, endMs: nextMs - 1,
      startIso: `${y}-${mm}-01`,
      endIso: `${y}-${mm}-${dd}`,
    };
  }

  function bufToBase64(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    return btoa(s);
  }

  async function saveBuffer(buf, filename, month) {
    const dataUrl = `data:text/csv;base64,${bufToBase64(buf)}`;
    const res = await chrome.runtime.sendMessage({ type: 'amz_save_data', dataUrl, filename, month });
    if (!res || !res.ok) throw new Error('保存に失敗: ' + ((res && res.error) || '不明'));
  }

  async function saveUrl(url, filename, month) {
    const res = await chrome.runtime.sendMessage({ type: 'amz_save_url', url, filename, month });
    if (!res || !res.ok) throw new Error('保存に失敗: ' + ((res && res.error) || '不明'));
  }

  function httpFail(label, status, text) {
    const t = String(text || '').slice(0, 200);
    if (status === 401 || status === 403 || /signin|ログイン/.test(t)) {
      return { status: 'error', message: `${label}: 認証エラー(${status})。ログイン状態を確認してください` };
    }
    return { status: 'error', message: `${label}: HTTP ${status} ${t}` };
  }

  const waitFor = async (fn, timeoutMs, interval = 300) => {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      try { const v = fn(); if (v) return v; } catch (e) { /* noop */ }
      await sleep(interval);
    }
    return null;
  };

  // ───────────────────────── ① トランザクション(FBA手数料・販売手数料・出荷数)
  async function transaction(month) {
    const K = 'tx';
    const r = monthRange(month);
    const body = {
      accountType: 'PAYABLE',
      reportType: 'SELLER_TRANSACTION_DATE_RANGE',
      startDate: r.startMs,
      startDateISO: `${r.startIso}T00:00:00+09:00`,
      endDate: r.endMs,
      endDateISO: `${r.endIso}T23:59:59+09:00`,
      timeRangeType: 'MONTHLY',
    };
    progress(K, 'レポートをリクエスト中');
    const res = await fetch('/payments/reports/api/request-report', {
      method: 'POST',
      credentials: 'include',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (!res.ok) return httpFail('リクエスト', res.status, text);

    let j;
    try { j = JSON.parse(text); } catch (e) { return { status: 'error', message: '応答がJSONではありません(未ログインの可能性)' }; }
    const id = j.reportId || (j.generatedReport && j.generatedReport.reportId);
    if (!id) return { status: 'error', message: 'reportId が取得できませんでした' };

    let st = j.generatedReport && j.generatedReport.status;
    const t0 = Date.now();
    while (st !== 'DOWNLOADABLE') {
      if (await isCancelled()) return { status: 'cancelled' };
      if (Date.now() - t0 > 10 * 60e3) return { status: 'notReady', message: '10分待っても生成が完了しませんでした。時間をおいて再取得してください' };
      await sleep(5000);
      const lr = await fetch('/payments/reports/api/reports?sortOrderByRequestDate=DESC&resultsPerPage=50&pageNum=1', { credentials: 'include' });
      if (!lr.ok) continue;
      const lj = await lr.json().catch(() => ({}));
      const rep = (lj.reportResponse || []).find((x) => x.reportId === id);
      st = rep && rep.status;
      progress(K, `生成待ち(${st || '確認中'})${Math.round((Date.now() - t0) / 1000)}秒`);
      if (st && /NO_DATA|EMPTY/i.test(st)) return { status: 'noData', message: 'この月のトランザクションはありません' };
      if (st && /CANCEL|FAIL|FATAL|ERROR|EXPIRED/i.test(st)) return { status: 'error', message: `生成失敗(${st})` };
    }

    progress(K, 'ダウンロード中');
    const d = await fetch('/payments/reports/api/download-report?reportId=' + encodeURIComponent(id), { credentials: 'include' });
    if (!d.ok) return httpFail('ダウンロード', d.status, await d.text());
    const buf = await d.arrayBuffer();
    await saveBuffer(buf, `A-手数料・出荷数-${month}.csv`, month);
    return { status: 'ok', message: `${Math.max(1, Math.round(buf.byteLength / 1024))}KB` };
  }

  // ───────────────────────── ③ 保管費(在庫保管手数料レポート 月次)
  async function storageFee(month) {
    const K = 'storage';
    const r = monthRange(month);
    const meta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
    const tok = meta && meta.content;
    if (!tok) return { status: 'error', message: 'CSRFトークンが見つかりません(未ログイン or ページ未読込)' };
    const H = { 'anti-csrftoken-a2z': tok };

    const q = new URLSearchParams({
      reportFileFormat: 'CSV',
      reportStartDate: `${r.y}/${r.mm}/01`,
      reportEndDate: `${r.y}/${r.mm}/${r.dd}`,
      xdaysBeforeUntilToday: '-1',
      startDateTimeOffset: '0',
      endDateTimeOffset: '0',
      specialDateOptions: '',
      reportFRPId: '2673',
      language: 'ja_JP',
      disableTimezone: 'false',
    });
    progress(K, 'レポートをリクエスト中');
    const s = await fetch('/reportcentral/api/v1/submitDownloadReport?' + q.toString(), {
      method: 'POST', credentials: 'include', headers: H,
    });
    const stext = await s.text();
    if (!s.ok) return httpFail('リクエスト', s.status, stext);
    let sj;
    try { sj = JSON.parse(stext); } catch (e) { return { status: 'error', message: '応答がJSONではありません' }; }
    const ref = sj.reportReferenceId;
    if (!ref) return { status: 'error', message: 'referenceId が取得できませんでした' };

    let st = sj.reportStatus;
    const t0 = Date.now();
    while (st !== 'Done') {
      if (await isCancelled()) return { status: 'cancelled' };
      if (st === 'Cancelled') {
        // 保管手数料は翌月中旬ごろに確定する。確定前は「データはありません」になる
        const now = new Date();
        const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const prevKey = `${prev.getFullYear()}-${String(prev.getMonth() + 1).padStart(2, '0')}`;
        const curKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        if (month === curKey || (month === prevKey && now.getDate() < 25)) {
          return { status: 'notReady', message: '保管手数料は翌月中旬ごろ確定します' };
        }
        return { status: 'noData', message: 'データはありません' };
      }
      if (st && /Fatal|Fail|Error/i.test(st)) return { status: 'error', message: `生成失敗(${st})` };
      if (Date.now() - t0 > 10 * 60e3) return { status: 'notReady', message: '10分待っても生成が完了しませんでした' };
      await sleep(4000);
      const pr = await fetch('/reportcentral/api/v1/getDownloadReportStatus?referenceIds=' + encodeURIComponent(ref), { credentials: 'include', headers: H });
      if (!pr.ok) continue;
      const pj = await pr.json().catch(() => null);
      st = Array.isArray(pj) ? pj[0] : st;
      progress(K, `生成待ち(${st || '確認中'})${Math.round((Date.now() - t0) / 1000)}秒`);
    }

    progress(K, 'ダウンロード中');
    const d = await fetch(`/reportcentral/api/v1/downloadFile?referenceId=${encodeURIComponent(ref)}&fileFormat=CSV`, { credentials: 'include', headers: H });
    if (!d.ok) return httpFail('ダウンロード', d.status, await d.text());
    const buf = await d.arrayBuffer();
    await saveBuffer(buf, `C-保管費-${month}.csv`, month);
    return { status: 'ok', message: `${Math.max(1, Math.round(buf.byteLength / 1024))}KB` };
  }

  // ───────────────────────── ④ 総売上(ビジネスレポート 売上ダッシュボード)
  async function sales(month) {
    const K = 'sales';
    const r = monthRange(month);
    const body = {
      operationName: 'salesDashboardDownloadQuery',
      variables: {
        input: {
          dashboardMode: 'CUSTOM',
          breakdownType: 'MARKETPLACE_TOTAL',
          fulfillment: 'BOTH',
          fromDate: r.startIso,
          endDate: r.endIso,
          isSundayStart: false,
        },
      },
      query: 'query salesDashboardDownloadQuery($input: GetSalesDashboardDataInput) {\n  getSalesDashboardDownload(input: $input) {\n    url\n    __typename\n  }\n}\n',
    };
    progress(K, 'ダウンロードURLを取得中');
    const res = await fetch('/business-reports/api', {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': 'application/json', accept: '*/*' },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (!res.ok) return httpFail('取得', res.status, text);
    let j;
    try { j = JSON.parse(text); } catch (e) { return { status: 'error', message: '応答がJSONではありません(未ログインの可能性)' }; }
    if (j.errors && j.errors.length) return { status: 'error', message: 'APIエラー: ' + String(j.errors[0].message || '').slice(0, 150) };
    const url = j.data && j.data.getSalesDashboardDownload && j.data.getSalesDashboardDownload.url;
    if (!url) return { status: 'error', message: 'ダウンロードURLが返りませんでした' };
    progress(K, 'ダウンロード中');
    await saveUrl(url, `D-総売上-${month}.csv`, month);
    return { status: 'ok' };
  }

  // ───────────────────────── ② 広告費・広告売上(キャンペーンマネージャーの画面操作)
  async function ads(month) {
    const K = 'ads';
    const r = monthRange(month);
    const P = 'campaignOverviewAllCampaigns';

    // エクスポートボタンは ID → data-e2e-id → 表示テキストの順で探す
    const findExport = () =>
      document.getElementById(`${P}:udm-export-dropdown`) ||
      document.querySelector('button[data-e2e-id$="udm-export-dropdown"]') ||
      [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'エクスポート' && b.getAttribute('aria-haspopup'));
    const findDateOpener = () =>
      document.getElementById(`${P}:dateRangeFilter:openContainer`) ||
      document.querySelector('button[data-e2e-id$="dateRangeFilter:openContainer"]');

    progress(K, '広告画面の読み込み待ち(最大5分)');
    const t0 = Date.now();
    const exportBtn = await waitFor(() => {
      const b = findExport();
      if (!b) {
        progress(K, `広告画面の読み込み待ち ${Math.round((Date.now() - t0) / 1000)}秒`);
        // 表の部分は画面に入らないと描画されないことがあるため下へスクロール
        window.scrollTo(0, document.body.scrollHeight);
      }
      return b;
    }, 300000, 2000);
    if (!exportBtn) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: 'キャンペーン画面のエクスポートボタンが見つかりません' };
    }

    exportBtn.scrollIntoView({ block: 'center' });
    await sleep(500);
    const opener = await waitFor(findDateOpener, 30000);
    if (!opener) return { status: 'error', message: '日付選択ボタンが見つかりません' };

    const wantLabel = `${r.mm}/01 - ${r.y}/${r.mm}/${r.dd}`;
    const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

    if (norm(opener.textContent) !== wantLabel) {
      progress(K, `期間を ${r.startIso}〜${r.endIso} に設定中`);
      opener.click();
      const opened = await waitFor(() => document.querySelector('button[aria-label="前月に移動"]'), 30000);
      if (!opened) return { status: 'error', message: '日付ピッカーが開きませんでした' };

      const qs = (iso) => document.querySelector(`button[data-iso-date="${iso}"]`);
      for (let i = 0; i < 60 && !qs(r.startIso); i++) {
        const cur = document.querySelector('button[data-iso-date]');
        const curIso = cur && cur.getAttribute('data-iso-date');
        const nav = curIso && curIso > r.startIso ? '前月に移動' : '翌月に移動';
        const b = document.querySelector(`button[aria-label="${nav}"]`);
        if (!b) break;
        b.click();
        await sleep(200);
      }
      const sb = await waitFor(() => qs(r.startIso), 10000);
      if (!sb) return { status: 'error', message: `カレンダーで ${r.startIso} が見つかりません` };
      sb.click();
      await sleep(300);
      for (let i = 0; i < 3 && !qs(r.endIso); i++) {
        const b = document.querySelector('button[aria-label="翌月に移動"]');
        if (!b) break;
        b.click();
        await sleep(250);
      }
      const eb = await waitFor(() => qs(r.endIso), 10000);
      if (!eb) return { status: 'error', message: `カレンダーで ${r.endIso} が見つかりません` };
      eb.click();
      await sleep(300);
      const apply = await waitFor(() => [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '適用'), 10000);
      if (!apply) return { status: 'error', message: '「適用」ボタンが見つかりません' };
      apply.click();

      const ok = await waitFor(() => {
        const o = findDateOpener();
        return o && norm(o.textContent) === wantLabel;
      }, 90000, 1000);
      if (!ok) return { status: 'error', message: '期間の反映を確認できませんでした' };
    }

    // テーブルの再読込を待つ
    progress(K, 'テーブルの更新待ち');
    await sleep(5000);
    await waitFor(() => !document.querySelector('[aria-busy="true"], [data-testid*="skeleton"], [class*="Skeleton"]'), 60000, 1000);
    await sleep(3000);
    if (await isCancelled()) return { status: 'cancelled' };

    // 画面が作る CSV(Blob)をページ側のフックで横取りし、拡張から名前を付けて保存する
    const captured = new Promise((resolve) => {
      const onMsg = (e) => {
        if (e.source !== window || !e.data || (e.data.__amz !== 'adsBlob' && e.data.__amz !== 'adsBlobError')) return;
        window.removeEventListener('message', onMsg);
        resolve(e.data);
      };
      window.addEventListener('message', onMsg);
      setTimeout(() => { window.removeEventListener('message', onMsg); resolve(null); }, 60000);
    });
    window.postMessage({ __amz: 'adsArm' }, '*');

    progress(K, 'エクスポート中');
    const exp2 = findExport();
    if (!exp2) return { status: 'error', message: 'エクスポートボタンが見つかりません(期間変更後)' };
    exp2.scrollIntoView({ block: 'center' });
    await sleep(300);
    exp2.click();
    const dl = await waitFor(() =>
      document.getElementById(`${P}:export`) ||
      document.querySelector('button[data-e2e-id$=":export"]') ||
      [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'ダウンロード'), 30000);
    if (!dl) return { status: 'error', message: 'エクスポートメニューの「ダウンロード」が見つかりません' };
    dl.click();

    progress(K, 'CSVの生成待ち');
    const got = await captured;
    window.postMessage({ __amz: 'adsDisarm' }, '*');
    if (!got) return { status: 'error', message: 'CSVが生成されませんでした(60秒)' };
    if (got.__amz === 'adsBlobError') return { status: 'error', message: 'CSVの読み取りに失敗: ' + got.message };
    const buf = got.buf;
    if (!buf || !buf.byteLength) return { status: 'error', message: 'CSVが空でした' };
    progress(K, '保存中');
    await saveBuffer(buf, `B-広告費・広告売上-${month}.csv`, month);
    return { status: 'ok', message: `期間 ${wantLabel}(画面のフィルター条件のまま出力)` };
  }


  // ───────────────────────── ②' 広告(レポート作成方式:古い月用)
  // 「効果測定とレポート」で Campaign テンプレートのレポートを作り、完了後にCSVを取得する。
  const ADS_REPORT_PREFIX = (month) => `B-広告費・広告売上-${month}`;

  function setInputValue(input, value) {
    const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // レポートを作成して送信するところまで
  async function adsReportCreate(month, reportName) {
    const K = 'adsReport';
    const r = monthRange(month);
    progress(K, 'レポート作成画面の読み込み待ち(最大5分)');
    const t0 = Date.now();
    const nameInput = await waitFor(() => {
      const i = [...document.querySelectorAll('input')].find((x) => /^Campaign\s*-/.test(x.value || ''));
      if (!i) progress(K, `レポート作成画面の読み込み待ち ${Math.round((Date.now() - t0) / 1000)}秒`);
      return i;
    }, 300000, 2000);
    if (!nameInput) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: 'レポート作成画面が開きませんでした' };
    }

    const name = reportName || `${ADS_REPORT_PREFIX(month)}-${Date.now()}`;
    setInputValue(nameInput, name);

    progress(K, `期間を ${r.startIso}〜${r.endIso} に設定中`);
    const periodBtn = await waitFor(() => [...document.querySelectorAll('button')].find((b) => /過去7日間|過去30日間|\d+年\d+月\d+日/.test(b.textContent) && b.textContent.length < 60), 30000);
    if (!periodBtn) return { status: 'error', message: '「レポート期間」のボタンが見つかりません' };
    periodBtn.scrollIntoView({ block: 'center' });
    await sleep(300);
    periodBtn.click();

    const opened = await waitFor(() => document.querySelector('button[aria-label="前月に移動"]'), 30000);
    if (!opened) return { status: 'error', message: '日付ピッカーが開きませんでした' };

    const qs = (iso) => document.querySelector(`button[data-iso-date="${iso}"]`);
    for (let i = 0; i < 80 && !qs(r.startIso); i++) {
      const cur = document.querySelector('button[data-iso-date]');
      const curIso = cur && cur.getAttribute('data-iso-date');
      const nav = curIso && curIso > r.startIso ? '前月に移動' : '翌月に移動';
      const b = document.querySelector(`button[aria-label="${nav}"]`);
      if (!b) break;
      b.click();
      await sleep(180);
    }
    const sb = await waitFor(() => qs(r.startIso), 10000);
    if (!sb) return { status: 'error', message: `カレンダーで ${r.startIso} が見つかりません` };
    sb.click();
    await sleep(300);
    for (let i = 0; i < 3 && !qs(r.endIso); i++) {
      const b = document.querySelector('button[aria-label="翌月に移動"]');
      if (!b) break;
      b.click();
      await sleep(250);
    }
    const eb = await waitFor(() => qs(r.endIso), 10000);
    if (!eb) return { status: 'error', message: `カレンダーで ${r.endIso} が見つかりません` };
    eb.click();
    await sleep(300);
    const save = await waitFor(() => [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '保存'), 10000);
    if (!save) return { status: 'error', message: '日付ピッカーの「保存」が見つかりません' };
    save.click();
    await sleep(1500);

    progress(K, 'レポートを送信中');
    const send = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '送信');
    if (!send) return { status: 'error', message: '「送信」ボタンが見つかりません' };
    send.click();

    // 「レポート名はすでに存在します」等のエラーを拾う
    await sleep(2500);
    const err = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /すでに存在します|already exists/.test(e.textContent || ''));
    if (err) return { status: 'error', message: `レポート名が重複しました(${name})` };

    const listed = await waitFor(() => [...document.querySelectorAll('[role=row]')].some((x) => x.textContent.includes(name)), 120000, 2000);
    if (!listed) {
      const msg = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /Fix the following issues|入力してください|エラー/.test(e.textContent || ''));
      return { status: 'error', message: msg ? `送信できませんでした: ${msg.textContent.trim().slice(0, 80)}` : 'レポートが一覧に現れませんでした' };
    }
    return { status: 'created', message: 'レポートを作成しました', name };
  }

  // 一覧から対象レポートの状態を見て、完了していればダウンロードURLを返す
  async function adsReportPick(month, reportName) {
    const K = 'adsReport';
    const name = reportName || ADS_REPORT_PREFIX(month);
    progress(K, 'レポートの状態を確認中');
    const row = await waitFor(() => [...document.querySelectorAll('[role=row]')].find((x) => x.textContent.includes(name)), 180000, 2000);
    if (!row) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: `レポート「${name}」が一覧に見つかりません` };
    }
    const text = row.textContent;
    if (/エラー|失敗|キャンセル/.test(text)) return { status: 'error', message: 'レポートの作成に失敗しました' };
    if (!/完了/.test(text)) return { status: 'pending', message: '生成中' };

    const act = [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'アクション');
    if (!act) return { status: 'error', message: '行のアクションボタンが見つかりません' };
    act.click();
    const link = await waitFor(() => [...document.querySelectorAll('a')].find((a) => a.textContent.trim() === '最新版をダウンロードする' && a.getAttribute('href')), 10000);
    if (!link) return { status: 'error', message: 'ダウンロードのリンクが見つかりません' };
    const url = new URL(link.getAttribute('href'), location.origin).href;
    document.body.click();
    return { status: 'ok', url };
  }

  // 拡張から取得できなかったときの保険:画面のリンクをそのままクリックする
  // (Chrome の通常のダウンロードになり、ファイル名は Amazon が付けた名前のまま)
  async function adsReportClick(month, reportName) {
    const K = 'adsReport';
    const name = reportName || ADS_REPORT_PREFIX(month);
    const row = await waitFor(() => [...document.querySelectorAll('[role=row]')].find((x) => x.textContent.includes(name)), 60000, 2000);
    if (!row) return { status: 'error', message: `レポート「${name}」が一覧に見つかりません` };
    const act = [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'アクション');
    if (!act) return { status: 'error', message: '行のアクションボタンが見つかりません' };
    act.click();
    const link = await waitFor(() => [...document.querySelectorAll('a')].find((a) => a.textContent.trim() === '最新版をダウンロードする' && a.getAttribute('href')), 10000);
    if (!link) return { status: 'error', message: 'ダウンロードのリンクが見つかりません' };
    progress(K, 'ブラウザのダウンロードで取得中');
    link.click();
    await sleep(3000);
    return { status: 'ok' };
  }

  const RUNNERS = { tx: transaction, storage: storageFee, sales, ads, adsReportCreate, adsReportPick, adsReportClick };

  window.__AMZDL = {
    async run(kind, month, extra) {
      const fn = RUNNERS[kind];
      if (!fn) return { status: 'error', message: '未知の種類: ' + kind };
      try {
        return await fn(month, extra);
      } catch (e) {
        return { status: 'error', message: String((e && e.message) || e).slice(0, 300) };
      }
    },
  };
})();

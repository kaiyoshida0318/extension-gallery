// Service Worker: ジョブ実行・タブ管理・保存・状態管理
importScripts('fsstore.js');

const KINDS = {
  tx:      { label: 'FBA手数料・販売手数料・出荷数', url: 'https://sellercentral.amazon.co.jp/payments/reports-repository', match: 'https://sellercentral.amazon.co.jp/payments/reports-repository*' },
  ads:     { label: '広告費・広告売上',             url: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns', match: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns*' },
  storage: { label: '保管費',                       url: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1', match: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1*' },
  adsReport: {
    label: '広告(レポート作成)',
    url: 'https://advertising.amazon.co.jp/reporting/new?templateId=campaign',
    match: 'https://advertising.amazon.co.jp/reporting*',
    listUrl: 'https://advertising.amazon.co.jp/reporting',
  },
  sales:   { label: '総売上',                       url: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html#/dashboard', match: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html*' },
};
const ORDER = ['tx', 'ads', 'storage', 'sales'];
const MAX_ATTEMPTS = 2;

// ───────── 状態の書き込みは直列化(レース回避)
let chain = Promise.resolve();
function withState(fn) {
  chain = chain.then(fn).catch((e) => console.error(e));
  return chain;
}

function log(text, level = 'info') {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_logs']);
    const logs = s.amz_logs || [];
    logs.unshift({ at: Date.now(), level, text });
    await chrome.storage.local.set({ amz_logs: logs.slice(0, 300) });
  });
}

function patchJob(patch) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_job']);
    await chrome.storage.local.set({ amz_job: { ...(s.amz_job || {}), ...patch } });
  });
}

function setResult(month, kind, result) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_results']);
    const all = s.amz_results || {};
    all[month] = all[month] || {};
    all[month][kind] = { ...result, at: Date.now() };
    // 古い月は24件まで保持
    const keys = Object.keys(all).sort().reverse();
    for (const k of keys.slice(24)) delete all[k];
    await chrome.storage.local.set({ amz_results: all });
  });
}

async function getJob() {
  await chain;
  const s = await chrome.storage.local.get(['amz_job']);
  return s.amz_job || null;
}

// ───────── タブ管理(タブIDは保持せず、毎回URLで探す)
function waitTabComplete(tabId, timeoutMs = 90000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (fn, v) => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(timer); fn(v); };
    const onUpd = (id, info, tab) => { if (id === tabId && info.status === 'complete') finish(resolve, tab); };
    const timer = setTimeout(() => finish(reject, new Error('ページの読み込みがタイムアウトしました')), timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') finish(resolve, t); }).catch((e) => finish(reject, e));
  });
}

async function getOrCreateTab(kind) {
  const def = KINDS[kind];
  const found = await chrome.tabs.query({ url: def.match });
  let tab;
  if (found.length) {
    tab = found[0];
    // SPA の状態を初期化するため再読み込み
    await chrome.tabs.update(tab.id, { url: def.url });
  } else {
    tab = await chrome.tabs.create({ url: def.url, active: false });
  }
  await sleep(500);
  tab = await waitTabComplete(tab.id);
  const t = await chrome.tabs.get(tab.id);
  if (/\/ap\/signin|\/ap\/mfa|signin/i.test(t.url || '')) {
    throw new Error('ログインが必要です。開いたタブでログインしてから再実行してください');
  }
  return t;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 広告画面(ページ側 = MAIN world)に仕込むフック。
// 画面が CSV を <a download> で保存する瞬間に Blob を横取りし、拡張側へ渡す(実際のダウンロードは止める)
function installAdsBlobHook() {
  if (window.__amzAdsHook) return;
  window.__amzAdsHook = true;
  let armed = false;
  const blobs = new Map();
  const origCreate = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const url = origCreate.apply(this, arguments);
    try { if (obj instanceof Blob) { blobs.set(url, obj); if (blobs.size > 20) blobs.delete(blobs.keys().next().value); } } catch (e) {}
    return url;
  };
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__amz === 'adsArm') armed = true;
    if (e.data.__amz === 'adsDisarm') armed = false;
  });
  const grab = (a) => {
    const href = String(a.href || '');
    if (!armed || !(href.startsWith('blob:') || href.startsWith('data:'))) return false;
    armed = false;
    const blob = blobs.get(href);
    const p = blob ? blob.arrayBuffer() : fetch(href).then((r) => r.arrayBuffer());
    p.then((buf) => window.postMessage({ __amz: 'adsBlob', name: a.download || '', buf }, '*'))
      .catch((err) => window.postMessage({ __amz: 'adsBlobError', message: String(err) }, '*'));
    return true;
  };
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (grab(this)) return;
    return origClick.apply(this, arguments);
  };
  const origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (this instanceof HTMLAnchorElement && ev && ev.type === 'click' && grab(this)) return true;
    return origDispatch.apply(this, arguments);
  };
}

async function runOnTab(tabId, kind, month, extra) {
  if (kind === 'ads') {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: installAdsBlobHook });
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ['injected.js'] });
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (k, m, x) => window.__AMZDL.run(k, m, x),
    args: [kind, month, extra ?? null],
  });
  return res && res.result ? res.result : { status: 'error', message: '注入スクリプトから結果が返りませんでした' };
}

// ───────── ジョブ実行
// 広告(レポート作成方式):作成 → 完了までページを再読み込みしながら待つ → CSVを保存
async function runAdsReport(month) {
  const K = 'adsReport';
  const def = KINDS[K];
  const front = async (tab) => {
    const [prev] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
    await chrome.tabs.update(tab.id, { active: true });
    return prev;
  };

  let tab = await getOrCreateTab(K);
  const prev = await front(tab);
  try {
    // レポート名は毎回ユニークにする(Amazon 側で同名のレポートは作れないため)
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const stamp = `${String(d.getFullYear()).slice(2)}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}`;
    const reportName = `B-広告費・広告売上-${month}-${stamp}`;

    const created = await runOnTab(tab.id, 'adsReportCreate', month, reportName);
    if (created.status !== 'created') return created;
    await log(`広告レポートを作成: ${reportName}`);
    await patchJob({ progress: 'レポートの生成待ち' });

    const t0 = Date.now();
    while (Date.now() - t0 < 20 * 60e3) {
      const j = await getJob();
      if (j && j.cancel) return { status: 'cancelled', message: '中止しました' };
      await sleep(20000);
      await chrome.tabs.update(tab.id, { url: def.listUrl });
      await sleep(1000);
      await waitTabComplete(tab.id);
      const picked = await runOnTab(tab.id, 'adsReportPick', month, reportName);
      if (picked.status === 'ok') {
        await patchJob({ progress: 'CSVを保存中' });
        await log(`広告レポート完了。CSVを取得します`);
        let lastErr = '';
        for (const mode of ['include', 'omit']) {
          try {
            const r = await fetch(picked.url, { credentials: mode });
            if (!r.ok) { lastErr = `HTTP ${r.status}`; continue; }
            const bytes = new Uint8Array(await r.arrayBuffer());
            if (!bytes.length) { lastErr = '空のファイル'; continue; }
            await saveToFolder(month, `B-広告費・広告売上-${month}.csv`, bytes);
            return { status: 'ok', message: `${Math.max(1, Math.round(bytes.length / 1024))}KB(レポート作成方式)` };
          } catch (e) {
            lastErr = String((e && e.message) || e);
          }
        }
        // 保存先フォルダに直接書けなかった場合は、画面のリンクをクリックして
        // 通常のダウンロード(ダウンロードフォルダ・Amazonが付けた名前)にする
        await log(`フォルダへの直接保存に失敗(${lastErr})。画面のダウンロードに切り替えます`, 'warn');
        const clicked = await runOnTab(tab.id, 'adsReportClick', month, reportName);
        if (clicked.status !== 'ok') return { status: 'error', message: `CSVの取得に失敗: ${lastErr}` };
        return { status: 'ok', message: 'ダウンロードフォルダに保存(Amazonのファイル名のまま)' };
      }
      if (picked.status === 'error') return picked;
      await patchJob({ progress: `レポートの生成待ち ${Math.round((Date.now() - t0) / 1000)}秒` });
    }
    return { status: 'notReady', message: '20分待っても完了しませんでした。時間をおいて再実行してください' };
  } finally {
    if (prev && prev.id !== tab.id) chrome.tabs.update(prev.id, { active: true }).catch(() => {});
  }
}

async function runJob(month, kinds) {
  const current = await getJob();
  if (current && current.running) {
    await log('すでに実行中のため、新しい依頼は無視しました', 'warn');
    return;
  }
  const fs = await AMZ_FS.status();
  if (fs.state !== 'granted') {
    const why = fs.state === 'none' ? '保存先フォルダが未設定です' : '保存先フォルダへの書き込み許可が必要です';
    await log(`${why}。ポップアップから設定してください`, 'error');
    await notify(`⚠ 開始できませんでした`, `${why}。ポップアップの「保存先」から設定してください`);
    return;
  }
  await patchJob({ running: true, month, kinds, current: null, cancel: false, startedAt: Date.now(), progress: '' });
  // 長時間の待機中に Service Worker が停止しないようにする
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  try {
    await runJobInner(month, kinds);
  } catch (e) {
    await log('予期しないエラー: ' + String((e && e.message) || e), 'error');
    await patchJob({ running: false, current: null, progress: '' });
    await notify(`❌ ${month.replace('-', '年')}月 エラーで停止しました`, String((e && e.message) || e).slice(0, 200));
  } finally {
    clearInterval(keepAlive);
  }
}

async function runJobInner(month, kinds) {
  const summary = [];
  savedFolder = '';
  await log(`▶ ${month} 開始: ${kinds.map((k) => KINDS[k].label).join(' / ')}`);

  for (const kind of kinds) {
    const j = await getJob();
    if (j && j.cancel) {
      await setResult(month, kind, { status: 'cancelled', message: '中止しました' });
      summary.push({ kind, status: 'cancelled' });
      continue;
    }
    await patchJob({ current: kind, progress: '開始' });
    await setResult(month, kind, { status: 'running', message: '実行中' });

    let result = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      if (attempt > 1) {
        await log(`${KINDS[kind].label}: リトライ ${attempt}/${MAX_ATTEMPTS}`, 'warn');
        await sleep(8000);
      }
      try {
        if (kind === 'adsReport') {
          result = await runAdsReport(month);
          if (result.status !== 'error') break;
          if ((await getJob())?.cancel) break;
          continue;
        }
        const tab = await getOrCreateTab(kind);
        if (kind === 'ads') {
          // 広告画面は裏タブだと描画が極端に遅くなるため、実行中だけ前面に出す
          const [prev] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
          await chrome.tabs.update(tab.id, { active: true });
          try {
            result = await runOnTab(tab.id, kind, month);
          } finally {
            if (prev && prev.id !== tab.id) chrome.tabs.update(prev.id, { active: true }).catch(() => {});
          }
        } else {
          result = await runOnTab(tab.id, kind, month);
        }
      } catch (e) {
        result = { status: 'error', message: String((e && e.message) || e) };
      }
      if (result.status !== 'error') break;
      if (/ログイン/.test(result.message || '')) break;
      if ((await getJob())?.cancel) break;
    }

    await setResult(month, kind, result);
    summary.push({ kind, status: result.status, message: result.message });
    const mark = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' }[result.status] || '❔';
    await log(`${mark} ${KINDS[kind].label}: ${result.message || result.status}`, result.status === 'error' ? 'error' : 'info');
  }

  const j = await getJob();
  await patchJob({ running: false, current: null, progress: '', finishedAt: Date.now() });
  await log(j && j.cancel ? `⏹ ${month} 中止しました` : `■ ${month} 完了`);
  await notifyJobDone(month, summary, !!(j && j.cancel));
}

// ───────── 完了通知
const MARK = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' };
const HEAD = { ok: '取得済み', noData: 'データなし', notReady: '未確定', error: '失敗', cancelled: '中止' };
const SHORT = { tx: 'FBA手数料・販売手数料', ads: '広告費・広告売上', adsReport: '広告(レポート作成)', storage: '保管費', sales: '総売上' };
let savedFolder = ''; // 直近の保存先(通知表示用)

async function notifyJobDone(month, summary, cancelled) {
  const [yy, mo] = month.split('-');
  const label = `${yy}年${Number(mo)}月`;
  const pending = summary.some((r) => r.status === 'notReady');
  const okCount = summary.filter((r) => r.status === 'ok').length;
  const bad = summary.some((r) => r.status === 'error');
  const title = cancelled
    ? `⏹ ${label} 中止しました(${okCount}/${summary.length}件 取得)`
    : bad
      ? `⚠ ${label} 一部失敗しました(${okCount}/${summary.length}件 取得)`
      : pending
        ? `⏰ ${label} 完了(未確定あり ${okCount}/${summary.length}件 取得)`
        : `✅ ${label} 保存完了(${okCount}/${summary.length}件)`;
  const body = summary
    .map((r) => `${MARK[r.status] || '❔'} ${SHORT[r.kind]}:${HEAD[r.status] || r.status}`)
    .join('\n');
  const tail = okCount > 0 && savedFolder ? `\n保存先: ${savedFolder}` : '';
  await notify(title, body + tail);
}

async function notify(title, message) {
  try {
    await chrome.notifications.create('amz_' + Date.now(), {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message: message || ' ',
      priority: 2,
    });
  } catch (e) {
    console.error('notification failed', e);
  }
}

// ───────── 保存(指定フォルダへ直接書き込み)
function dataUrlToBytes(dataUrl) {
  const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

async function saveToFolder(month, filename, bytes) {
  const path = await AMZ_FS.writeFile(month, filename, bytes);
  savedFolder = path.slice(0, path.lastIndexOf('/'));
  await log(`💾 保存: ${path}`);
  return path;
}

// ───────── メッセージ
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case 'amz_start': {
        const kinds = (msg.kinds && msg.kinds.length ? msg.kinds : ORDER).filter((k) => KINDS[k]);
        runJob(msg.month, kinds); // fire-and-forget
        sendResponse({ ok: true });
        break;
      }
      case 'amz_cancel':
        await patchJob({ cancel: true });
        await log('中止を受け付けました(処理中の1件が終わり次第止まります)', 'warn');
        sendResponse({ ok: true });
        break;
      case 'amz_is_cancelled': {
        const j = await getJob();
        sendResponse({ cancelled: !!(j && j.cancel) });
        break;
      }
      case 'amz_progress':
        await patchJob({ progress: msg.msg });
        sendResponse({ ok: true });
        break;
      case 'amz_save_data':
        try {
          const path = await saveToFolder(msg.month, msg.filename, dataUrlToBytes(msg.dataUrl));
          sendResponse({ ok: true, path });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      case 'amz_save_url':
        try {
          const r = await fetch(msg.url);
          if (!r.ok) throw new Error(`ファイル取得に失敗(HTTP ${r.status})`);
          const bytes = new Uint8Array(await r.arrayBuffer());
          const path = await saveToFolder(msg.month, msg.filename, bytes);
          sendResponse({ ok: true, path });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      default:
        sendResponse({ ok: false });
    }
  })();
  return true;
});

// 拡張の再起動で「実行中」のまま固まるのを防ぐ
chrome.runtime.onStartup.addListener(() => patchJob({ running: false, current: null, progress: '' }));
chrome.runtime.onInstalled.addListener(() => patchJob({ running: false, current: null, progress: '' }));

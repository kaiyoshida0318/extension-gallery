// Service Worker: ジョブ実行・タブ管理・保存・状態管理
const ROOT_DIR = 'Amazon月次レポート';

const KINDS = {
  tx:      { label: 'FBA手数料・販売手数料・出荷数', url: 'https://sellercentral.amazon.co.jp/payments/reports-repository', match: 'https://sellercentral.amazon.co.jp/payments/reports-repository*' },
  ads:     { label: '広告費・広告売上',             url: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns', match: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns*' },
  storage: { label: '保管費',                       url: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1', match: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1*' },
  sales:   { label: '総売上',                       url: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html#/dashboard', match: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html*' },
};
const ORDER = ['tx', 'ads', 'storage', 'sales'];
const MAX_ATTEMPTS = 2;

// ───────── 状態の書き込みは直列化(レース回避)
let chain = Promise.resolve();
function withState(fn) {
  chain = chain.then(fn).catch((e) => console.error(e));
  return chain;
}

function log(text, level = 'info') {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_logs']);
    const logs = s.amz_logs || [];
    logs.unshift({ at: Date.now(), level, text });
    await chrome.storage.local.set({ amz_logs: logs.slice(0, 300) });
  });
}

function patchJob(patch) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_job']);
    await chrome.storage.local.set({ amz_job: { ...(s.amz_job || {}), ...patch } });
  });
}

function setResult(month, kind, result) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_results']);
    const all = s.amz_results || {};
    all[month] = all[month] || {};
    all[month][kind] = { ...result, at: Date.now() };
    // 古い月は24件まで保持
    const keys = Object.keys(all).sort().reverse();
    for (const k of keys.slice(24)) delete all[k];
    await chrome.storage.local.set({ amz_results: all });
  });
}

async function getJob() {
  await chain;
  const s = await chrome.storage.local.get(['amz_job']);
  return s.amz_job || null;
}

// ───────── タブ管理(タブIDは保持せず、毎回URLで探す)
function waitTabComplete(tabId, timeoutMs = 90000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (fn, v) => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(timer); fn(v); };
    const onUpd = (id, info, tab) => { if (id === tabId && info.status === 'complete') finish(resolve, tab); };
    const timer = setTimeout(() => finish(reject, new Error('ページの読み込みがタイムアウトしました')), timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') finish(resolve, t); }).catch((e) => finish(reject, e));
  });
}

async function getOrCreateTab(kind) {
  const def = KINDS[kind];
  const found = await chrome.tabs.query({ url: def.match });
  let tab;
  if (found.length) {
    tab = found[0];
    // SPA の状態を初期化するため再読み込み
    await chrome.tabs.update(tab.id, { url: def.url });
  } else {
    tab = await chrome.tabs.create({ url: def.url, active: false });
  }
  await sleep(500);
  tab = await waitTabComplete(tab.id);
  const t = await chrome.tabs.get(tab.id);
  if (/\/ap\/signin|\/ap\/mfa|signin/i.test(t.url || '')) {
    throw new Error('ログインが必要です。開いたタブでログインしてから再実行してください');
  }
  return t;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 広告画面(ページ側 = MAIN world)に仕込むフック。
// 画面が CSV を <a download> で保存する瞬間に Blob を横取りし、拡張側へ渡す(実際のダウンロードは止める)
function installAdsBlobHook() {
  if (window.__amzAdsHook) return;
  window.__amzAdsHook = true;
  let armed = false;
  const blobs = new Map();
  const origCreate = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const url = origCreate.apply(this, arguments);
    try { if (obj instanceof Blob) { blobs.set(url, obj); if (blobs.size > 20) blobs.delete(blobs.keys().next().value); } } catch (e) {}
    return url;
  };
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__amz === 'adsArm') armed = true;
    if (e.data.__amz === 'adsDisarm') armed = false;
  });
  const grab = (a) => {
    const href = String(a.href || '');
    if (!armed || !(href.startsWith('blob:') || href.startsWith('data:'))) return false;
    armed = false;
    const blob = blobs.get(href);
    const p = blob ? blob.arrayBuffer() : fetch(href).then((r) => r.arrayBuffer());
    p.then((buf) => window.postMessage({ __amz: 'adsBlob', name: a.download || '', buf }, '*'))
      .catch((err) => window.postMessage({ __amz: 'adsBlobError', message: String(err) }, '*'));
    return true;
  };
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (grab(this)) return;
    return origClick.apply(this, arguments);
  };
  const origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (this instanceof HTMLAnchorElement && ev && ev.type === 'click' && grab(this)) return true;
    return origDispatch.apply(this, arguments);
  };
}

async function runOnTab(tabId, kind, month) {
  if (kind === 'ads') {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: installAdsBlobHook });
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ['injected.js'] });
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (k, m) => window.__AMZDL.run(k, m),
    args: [kind, month],
  });
  return res && res.result ? res.result : { status: 'error', message: '注入スクリプトから結果が返りませんでした' };
}

// ───────── ジョブ実行
async function runJob(month, kinds) {
  const current = await getJob();
  if (current && current.running) {
    await log('すでに実行中のため、新しい依頼は無視しました', 'warn');
    return;
  }
  await patchJob({ running: true, month, kinds, current: null, cancel: false, startedAt: Date.now(), progress: '' });
  // 長時間の待機中に Service Worker が停止しないようにする
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  try {
    await runJobInner(month, kinds);
  } catch (e) {
    await log('予期しないエラー: ' + String((e && e.message) || e), 'error');
    await patchJob({ running: false, current: null, progress: '' });
    await notify(`❌ ${month.replace('-', '年')}月 エラーで停止しました`, String((e && e.message) || e).slice(0, 200), null);
  } finally {
    clearInterval(keepAlive);
  }
}

async function runJobInner(month, kinds) {
  lastDownloadId = null;
  jobDownloadIds = [];
  const summary = [];
  await log(`▶ ${month} 開始: ${kinds.map((k) => KINDS[k].label).join(' / ')}`);

  for (const kind of kinds) {
    const j = await getJob();
    if (j && j.cancel) {
      await setResult(month, kind, { status: 'cancelled', message: '中止しました' });
      summary.push({ kind, status: 'cancelled' });
      continue;
    }
    await patchJob({ current: kind, progress: '開始' });
    await setResult(month, kind, { status: 'running', message: '実行中' });

    let result = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      if (attempt > 1) {
        await log(`${KINDS[kind].label}: リトライ ${attempt}/${MAX_ATTEMPTS}`, 'warn');
        await sleep(8000);
      }
      try {
        const tab = await getOrCreateTab(kind);
        if (kind === 'ads') {
          // 広告画面は裏タブだと描画が極端に遅くなるため、実行中だけ前面に出す
          const [prev] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
          await chrome.tabs.update(tab.id, { active: true });
          try {
            result = await runOnTab(tab.id, kind, month);
          } finally {
            if (prev && prev.id !== tab.id) chrome.tabs.update(prev.id, { active: true }).catch(() => {});
          }
        } else {
          result = await runOnTab(tab.id, kind, month);
        }
      } catch (e) {
        result = { status: 'error', message: String((e && e.message) || e) };
      }
      if (result.status !== 'error') break;
      if (/ログイン/.test(result.message || '')) break;
      if ((await getJob())?.cancel) break;
    }

    await setResult(month, kind, result);
    summary.push({ kind, status: result.status, message: result.message });
    const mark = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' }[result.status] || '❔';
    await log(`${mark} ${KINDS[kind].label}: ${result.message || result.status}`, result.status === 'error' ? 'error' : 'info');
  }

  const j = await getJob();
  await patchJob({ running: false, current: null, progress: '', finishedAt: Date.now() });
  await log(j && j.cancel ? `⏹ ${month} 中止しました` : `■ ${month} 完了`);
  await notifyJobDone(month, summary, !!(j && j.cancel));
}

// ───────── 完了通知
const MARK = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' };
const HEAD = { ok: '取得済み', noData: 'データなし', notReady: '未確定', error: '失敗', cancelled: '中止' };
const SHORT = { tx: 'FBA手数料・販売手数料', ads: '広告費・広告売上', storage: '保管費', sales: '総売上' };
let lastDownloadId = null;
let jobDownloadIds = [];

async function trackDownload(opts) {
  const id = await download(opts);
  jobDownloadIds.push(id);
  return id;
}

// ダウンロードが最後まで書き込まれるのを待つ
function waitDownloadDone(id, timeoutMs = 180000) {
  return new Promise((resolve) => {
    let finished = false;
    const done = (state) => { if (finished) return; finished = true; chrome.downloads.onChanged.removeListener(onChg); clearTimeout(t); resolve(state); };
    const onChg = (d) => { if (d.id === id && d.state && d.state.current !== 'in_progress') done(d.state.current); };
    const t = setTimeout(() => done('timeout'), timeoutMs);
    chrome.downloads.onChanged.addListener(onChg);
    chrome.downloads.search({ id }).then(([d]) => { if (!d) done('missing'); else if (d.state !== 'in_progress') done(d.state); });
  });
}

async function notifyJobDone(month, summary, cancelled) {
  const [yy, mo] = month.split('-');
  const label = `${yy}年${Number(mo)}月`;
  const pending = summary.some((r) => r.status === 'notReady');
  const okCount = summary.filter((r) => r.status === 'ok').length;
  const bad = summary.some((r) => r.status === 'error');
  const title = cancelled
    ? `⏹ ${label} 中止しました(${okCount}/${summary.length}件 取得)`
    : bad
      ? `⚠ ${label} 一部失敗しました(${okCount}/${summary.length}件 取得)`
      : pending
        ? `⏰ ${label} 完了(未確定あり ${okCount}/${summary.length}件 取得)`
        : `✅ ${label} ダウンロード完了(${okCount}/${summary.length}件)`;
  const body = summary
    .map((r) => `${MARK[r.status] || '❔'} ${SHORT[r.kind]}:${HEAD[r.status] || r.status}`)
    .join('\n');
  const states = await Promise.all(jobDownloadIds.map((id) => waitDownloadDone(id)));
  const broken = states.filter((st) => st !== 'complete').length;
  const tail = broken ? `\n⚠ 保存が完了しなかったファイルが${broken}件あります` : '';
  await notify(title, body + tail, okCount > 0 ? lastDownloadId : null);
}

async function notify(title, message, downloadId) {
  const id = 'amz_' + Date.now();
  const opts = {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message: message || ' ',
    priority: 2,
  };
  if (downloadId != null) opts.buttons = [{ title: '保存フォルダを開く' }];
  try {
    await chrome.notifications.create(id, opts);
    await chrome.storage.local.set({ amz_notif: { id, downloadId } });
  } catch (e) {
    console.error('notification failed', e);
  }
}

async function openSavedFolder(notificationId) {
  const s = await chrome.storage.local.get(['amz_notif']);
  const n = s.amz_notif;
  if (n && n.id === notificationId && n.downloadId != null) {
    try { chrome.downloads.show(n.downloadId); } catch (e) { chrome.downloads.showDefaultFolder(); }
  } else {
    chrome.downloads.showDefaultFolder();
  }
  chrome.notifications.clear(notificationId);
}
chrome.notifications.onButtonClicked.addListener((nid) => { if (nid.startsWith('amz_')) openSavedFolder(nid); });
chrome.notifications.onClicked.addListener((nid) => { if (nid.startsWith('amz_')) openSavedFolder(nid); });

// ───────── ダウンロード
// onDeterminingFilename を登録していると download() の filename 指定が無視されるため、
// 付けたい名前を控えておき、リスナー側で改めて指定する
const namedDownloads = new Map(); // downloadId -> filename
const pendingNames = [];          // id 確定前に発火した場合の予備(FIFO)
const namedDone = new Set();      // リスナーで名前を付け終えた downloadId

function download(opts) {
  return new Promise((resolve, reject) => {
    if (opts.filename) pendingNames.push(opts.filename);
    chrome.downloads.download(opts, (id) => {
      if (opts.filename && id !== undefined) {
        if (namedDone.has(id)) namedDone.delete(id);
        else namedDownloads.set(id, opts.filename);
      }
      if ((chrome.runtime.lastError || id === undefined) && opts.filename) {
        const i = pendingNames.indexOf(opts.filename);
        if (i >= 0) pendingNames.splice(i, 1);
      }
      if (chrome.runtime.lastError || id === undefined) reject(new Error(chrome.runtime.lastError?.message || 'download failed'));
      else resolve(id);
    });
  });
}
const pathFor = (month, filename) => `${ROOT_DIR}/${month}/${filename}`;

// 広告は画面側で Blob を生成して保存されるため、ファイル名をここで差し替える
let adsExpect = null; // { month, until, resolve }
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (item.byExtensionId === chrome.runtime.id) {
    let name = namedDownloads.get(item.id);
    if (name) {
      namedDownloads.delete(item.id);
      const i = pendingNames.indexOf(name);
      if (i >= 0) pendingNames.splice(i, 1);
    } else {
      name = pendingNames.shift();
      namedDone.add(item.id);
    }
    if (name) suggest({ filename: name, conflictAction: 'uniquify' });
    else suggest();
    return;
  }
  const fromAds = /^blob:https:\/\/advertising\.amazon\.co\.jp/.test(item.url || '') || /^https:\/\/advertising\.amazon\.co\.jp/.test(item.referrer || '');
  if (fromAds && adsExpect && Date.now() < adsExpect.until) {
    const ext = ((item.filename || '').match(/\.[A-Za-z0-9]+$/) || ['.csv'])[0];
    const { month, resolve } = adsExpect;
    adsExpect = null;
    lastDownloadId = item.id;
    jobDownloadIds.push(item.id);
    suggest({ filename: pathFor(month, `B-広告費・広告売上-${month}${ext}`), conflictAction: 'uniquify' });
    resolve && resolve(true);
    return;
  }
  suggest();
});

// ───────── メッセージ
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case 'amz_start': {
        const kinds = (msg.kinds && msg.kinds.length ? msg.kinds : ORDER).filter((k) => KINDS[k]);
        runJob(msg.month, kinds); // fire-and-forget
        sendResponse({ ok: true });
        break;
      }
      case 'amz_cancel':
        await patchJob({ cancel: true });
        await log('中止を受け付けました(処理中の1件が終わり次第止まります)', 'warn');
        sendResponse({ ok: true });
        break;
      case 'amz_is_cancelled': {
        const j = await getJob();
        sendResponse({ cancelled: !!(j && j.cancel) });
        break;
      }
      case 'amz_progress':
        await patchJob({ progress: msg.msg });
        sendResponse({ ok: true });
        break;
      case 'amz_save_data':
        try {
          lastDownloadId = await trackDownload({ url: msg.dataUrl, filename: pathFor(msg.month, msg.filename), conflictAction: 'uniquify', saveAs: false });
          sendResponse({ ok: true });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      case 'amz_save_url':
        try {
          lastDownloadId = await trackDownload({ url: msg.url, filename: pathFor(msg.month, msg.filename), conflictAction: 'uniquify', saveAs: false });
          sendResponse({ ok: true });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      case 'amz_expect_ads_download':
        adsExpect = { month: msg.month, until: Date.now() + 60000, resolve: null, promise: null };
        adsExpect.promise = new Promise((r) => { adsExpect.resolve = r; });
        sendResponse({ ok: true });
        break;
      case 'amz_wait_ads_download': {
        const exp = adsExpect;
        if (!exp) { sendResponse({ ok: true }); break; } // すでに捕捉済み
        const ok = await Promise.race([exp.promise, sleep(msg.timeoutMs || 45000).then(() => false)]);
        if (!ok && adsExpect === exp) adsExpect = null;
        sendResponse({ ok: !!ok });
        break;
      }
      default:
        sendResponse({ ok: false });
    }
  })();
  return true;
});

// 拡張の再起動で「実行中」のまま固まるのを防ぐ
chrome.runtime.onStartup.addListener(() => patchJob({ running: false, current: null, progress: '' }));
chrome.runtime.onInstalled.addListener(() => patchJob({ running: false, current: null, progress: '' }));

// =====================================================
// NE Quick Access - 在庫チェック機能（トップ画面）
// 楽天商品検索APIで在庫切れを検出し、ヘッダー右上に表示
// 仕様書 spec_stock_check.md に基づく実装（最小構成・区分なし＋無視リスト版）
// =====================================================

// ★重要：エンドポイントバージョン（§2-1）
const RAKUTEN_ENDPOINT = 'https://openapi.rakuten.co.jp/ichibams/api/IchibaItem/Search/20260701';
const SAFE_INTERVAL = 1200;  // レート制限対策（§4-3）
const HITS_PER_PAGE = 30;
const MAX_PAGES = 100;

// ストレージキー
const KEY_STOCK_SOLDOUT   = 'ne_stock_soldOut';     // ["10001259", ...]
const KEY_STOCK_CHECKEDAT = 'ne_stock_checkedAt';   // ISO datetime
const KEY_STOCK_INFO      = 'ne_stock_info';        // {code: {n, i, u}}
const KEY_STOCK_UNCHECKED = 'ne_stock_unchecked';   // []
const KEY_STOCK_IGNORED   = 'ne_stock_ignored';     // {code: true}
const KEY_STOCK_LASTERROR = 'ne_stock_lasterror';   // string
const KEY_RAKUTEN_CONFIG  = 'ne_rakuten_config';    // {shopCode, wsAppId, wsAccessKey}

// グローバル状態
let stockSoldOut = [];
let stockCheckedAt = '';
let stockInfo = {};
let stockUnchecked = [];
let stockIgnored = {};
let stockLastError = '';
let rakutenConfig = { shopCode: '', wsAppId: '', wsAccessKey: '' };
let scanRunning = false;
let scanProgress = '';

// =====================================================
// 初期化
// =====================================================
(async function init() {
  injectStyles();
  await loadStockData();
  renderStockButton();

  // 起動時：今日まだチェックしていなければ自動チェック
  setTimeout(() => {
    if (!isCheckedToday() && rakutenConfig.shopCode && rakutenConfig.wsAppId && rakutenConfig.wsAccessKey) {
      runStockScan(false, true);
    }
  }, 1500);

  // ストレージ変更を監視（クラウド同期の受信で更新されたときも反映）
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[KEY_STOCK_SOLDOUT] || changes[KEY_STOCK_CHECKEDAT] ||
        changes[KEY_STOCK_INFO] || changes[KEY_STOCK_UNCHECKED] ||
        changes[KEY_STOCK_IGNORED] || changes[KEY_RAKUTEN_CONFIG] ||
        changes[KEY_STOCK_LASTERROR]) {
      loadStockData().then(renderStockButton);
    }
  });
})();

async function loadStockData() {
  const d = await chrome.storage.local.get([
    KEY_STOCK_SOLDOUT, KEY_STOCK_CHECKEDAT, KEY_STOCK_INFO,
    KEY_STOCK_UNCHECKED, KEY_STOCK_IGNORED, KEY_STOCK_LASTERROR, KEY_RAKUTEN_CONFIG
  ]);
  stockSoldOut = d[KEY_STOCK_SOLDOUT] || [];
  stockCheckedAt = d[KEY_STOCK_CHECKEDAT] || '';
  stockInfo = d[KEY_STOCK_INFO] || {};
  stockUnchecked = d[KEY_STOCK_UNCHECKED] || [];
  stockIgnored = d[KEY_STOCK_IGNORED] || {};
  stockLastError = d[KEY_STOCK_LASTERROR] || '';
  rakutenConfig = d[KEY_RAKUTEN_CONFIG] || { shopCode: '', wsAppId: '', wsAccessKey: '' };
}

function isCheckedToday() {
  if (!stockCheckedAt) return false;
  const d = new Date(stockCheckedAt);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() &&
         d.getMonth() === now.getMonth() &&
         d.getDate() === now.getDate();
}

function todayLabel(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = n => String(n).padStart(2, '0');
  return pad(d.getMonth() + 1) + pad(d.getDate());
}

// =====================================================
// ボタン描画
// =====================================================
function renderStockButton() {
  let btn = document.getElementById('neq-stock-btn');
  if (!btn) {
    btn = document.createElement('button');
    btn.id = 'neq-stock-btn';
    btn.type = 'button';
    btn.addEventListener('click', openStockModal);
    // 挿入先：ヘッダー内、なければbody直下でfixed表示
    const container = document.querySelector('#header .container-fluid') ||
                      document.querySelector('#header') ||
                      document.querySelector('.navbar-inner') ||
                      document.body;
    if (container === document.body) {
      btn.classList.add('neq-stock-btn-floating');
    }
    container.appendChild(btn);
  }

  // 有効な在庫切れ（無視されていない、かつ 情報がある＝存在する商品）
  const active = stockSoldOut.filter(c => !stockIgnored[c]);
  const activeCount = active.length;

  btn.className = 'neq-stock-btn' + (btn.classList.contains('neq-stock-btn-floating') ? ' neq-stock-btn-floating' : '');

  if (scanRunning) {
    btn.classList.add('neq-stock-scanning');
    btn.innerHTML = `⏳ 在庫チェック中...${scanProgress ? ' ' + scanProgress : ''}`;
    return;
  }

  if (!rakutenConfig.shopCode || !rakutenConfig.wsAppId || !rakutenConfig.wsAccessKey) {
    // 未設定
    btn.classList.add('neq-stock-unset');
    btn.innerHTML = `⚙ 在庫チェック（要設定）`;
    return;
  }

  if (activeCount > 0) {
    // 要対応：赤ベタ＋点滅
    btn.classList.add('neq-stock-alarm');
    btn.innerHTML = `🚨 在庫切れ ${activeCount}`;
    return;
  }

  if (stockLastError && !stockCheckedAt) {
    // エラー
    btn.classList.add('neq-stock-error');
    btn.innerHTML = `⚠ 在庫チェック`;
    return;
  }

  if (stockCheckedAt) {
    // チェック済み・問題なし
    btn.classList.add('neq-stock-ok');
    btn.innerHTML = `✅ 在庫チェック ${todayLabel(stockCheckedAt)}`;
    return;
  }

  // 未チェック
  btn.classList.add('neq-stock-todo');
  btn.innerHTML = `🚨 在庫チェック`;
}

// =====================================================
// スキャン本体（§4-1 方式A：店舗一括）
// =====================================================
async function runStockScan(userTriggered, isAuto) {
  // ガード（§8）：手動でも自動でもないなら何もしない
  if (!userTriggered && !isAuto) return;
  if (scanRunning) return;
  if (!rakutenConfig.shopCode || !rakutenConfig.wsAppId || !rakutenConfig.wsAccessKey) {
    if (userTriggered) alert('先に楽天API設定を入力してください（店舗コード・アプリID・アクセスキー）');
    return;
  }

  scanRunning = true;
  scanProgress = '';
  renderStockButton();
  // モーダルが開いていれば中も更新
  if (document.getElementById('neq-stock-modal')) refreshModalBody();

  const shop = rakutenConfig.shopCode;
  const availMap = {};   // {code: 0 or 1}
  const infoMap = {};    // {code: {n, i, u}}
  let epErr = '';
  let totalHits = 0;

  try {
    let page = 1;
    let hasMore = true;
    let pageCount = 0;
    while (hasMore && page <= MAX_PAGES) {
      // ★§2-3 sort=+updateTimestamp / §2-4 availability=0 / §2-2 elements に itemUrl
      const qs =
        `applicationId=${encodeURIComponent(rakutenConfig.wsAppId)}` +
        `&shopCode=${encodeURIComponent(shop)}` +
        `&availability=0` +
        `&hits=${HITS_PER_PAGE}` +
        `&page=${page}` +
        `&sort=${encodeURIComponent('+updateTimestamp')}` +
        `&elements=${encodeURIComponent('itemCode,itemUrl,itemName,mediumImageUrls,availability')}` +
        `&format=json`;
      const url = `${RAKUTEN_ENDPOINT}?${qs}`;

      const r = await chrome.runtime.sendMessage({
        action: 'rakutenGet',
        url,
        accessKey: rakutenConfig.wsAccessKey
      });

      if (!r || !r.ok) {
        epErr = (r && r.error) || '通信エラー';
        // §2-1 バージョン切れの目印
        if (epErr.includes('API Configuration not found')) {
          epErr = '楽天APIのエンドポイントが古い可能性があります。仕様書§2-1参照。' + epErr;
        }
        break;
      }
      const data = r.data;
      const items = data.Items || [];
      if (page === 1) {
        pageCount = data.pageCount || 0;
        totalHits = data.count || data.hits || items.length;
      }

      items.forEach(entry => {
        const item = entry.Item || entry;
        const code = codeOf(item);   // ★§2-2 itemUrl から管理番号
        if (!code) return;
        availMap[code] = readAvail(item);
        infoMap[code] = infoOf(item);
      });

      // 進捗表示
      scanProgress = `${page}/${pageCount || '?'}`;
      renderStockButton();

      hasMore = items.length === HITS_PER_PAGE && !(pageCount && page >= pageCount);
      page++;
      if (hasMore) await sleep(SAFE_INTERVAL);
    }
  } catch (e) {
    epErr = 'エラー: ' + (e.message || String(e));
  }

  scanRunning = false;

  if (epErr && Object.keys(availMap).length === 0) {
    // 全滅：エラーとして保存
    stockLastError = epErr;
    await chrome.storage.local.set({ [KEY_STOCK_LASTERROR]: epErr });
    renderStockButton();
    if (userTriggered) alert('在庫チェック失敗：\n' + epErr);
    if (document.getElementById('neq-stock-modal')) refreshModalBody();
    return;
  }

  // 在庫切れ抽出（availability === 0）
  const soldOut = Object.keys(availMap).filter(c => availMap[c] === 0);
  // 在庫切れ分だけ info を残す（§5-2）
  const info = {};
  soldOut.forEach(c => { if (infoMap[c]) info[c] = infoMap[c]; });

  stockSoldOut = soldOut;
  stockInfo = info;
  stockCheckedAt = new Date().toISOString();
  stockUnchecked = []; // マスタ持たないので判定不能リストは無し
  stockLastError = '';

  await chrome.storage.local.set({
    [KEY_STOCK_SOLDOUT]: stockSoldOut,
    [KEY_STOCK_INFO]: stockInfo,
    [KEY_STOCK_CHECKEDAT]: stockCheckedAt,
    [KEY_STOCK_UNCHECKED]: stockUnchecked,
    [KEY_STOCK_LASTERROR]: ''
  });

  renderStockButton();
  if (document.getElementById('neq-stock-modal')) refreshModalBody();
}

// ★§2-2 itemUrl から商品管理番号を取り出す（fallback: itemCode の後半）
function codeOf(item) {
  const url = String((item && item.itemUrl) || '');
  const m = url.match(/item\.rakuten\.co\.jp\/[^/]+\/([^/?#]+)/);
  if (m && m[1]) return m[1];
  const ic = String((item && item.itemCode) || '');
  return ic.includes(':') ? ic.split(':')[1] : '';
}

function readAvail(item) {
  const a = item.availability;
  return (a === 0 || a === '0') ? 0 : 1;
}

function infoOf(item) {
  const imgs = item.mediumImageUrls || [];
  let img = '';
  if (imgs.length > 0) {
    const first = imgs[0];
    img = typeof first === 'string' ? first : (first.imageUrl || '');
  }
  return {
    n: item.itemName || '',
    i: img,
    u: item.itemUrl || ''
  };
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// =====================================================
// モーダル
// =====================================================
function openStockModal() {
  const existing = document.getElementById('neq-stock-modal');
  if (existing) { existing.remove(); return; }

  const overlay = document.createElement('div');
  overlay.id = 'neq-stock-modal';
  overlay.className = 'neq-stock-modal-overlay';
  overlay.innerHTML = `
    <div class="neq-stock-modal-box">
      <div class="neq-stock-modal-head">
        <span class="neq-stock-modal-title">🚨 在庫切れチェック</span>
        <div class="neq-stock-modal-head-btns">
          <button class="neq-stock-rescan-btn" id="neq-stock-rescan">🔄 再チェック</button>
          <button class="neq-stock-close-btn" id="neq-stock-close">×</button>
        </div>
      </div>
      <div class="neq-stock-modal-body" id="neq-stock-modal-body"></div>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('neq-stock-close').addEventListener('click', closeStockModal);
  overlay.addEventListener('click', e => { if (e.target === overlay) closeStockModal(); });
  document.getElementById('neq-stock-rescan').addEventListener('click', () => runStockScan(true, false));

  refreshModalBody();
}

function closeStockModal() {
  const m = document.getElementById('neq-stock-modal');
  if (m) m.remove();
}

function refreshModalBody() {
  const body = document.getElementById('neq-stock-modal-body');
  if (!body) return;

  const cfgSet = rakutenConfig.shopCode && rakutenConfig.wsAppId && rakutenConfig.wsAccessKey;
  const active = stockSoldOut.filter(c => !stockIgnored[c]);
  const ignored = stockSoldOut.filter(c => stockIgnored[c]);

  const configHtml = `
    <details class="neq-stock-config" ${cfgSet ? '' : 'open'}>
      <summary>⚙ 楽天API設定</summary>
      <div class="neq-stock-config-body">
        <div class="neq-stock-field">
          <label>店舗コード（例：yukaiya）</label>
          <input type="text" id="neq-stock-shopcode" value="${escapeAttr(rakutenConfig.shopCode)}">
        </div>
        <div class="neq-stock-field">
          <label>楽天WS アプリID</label>
          <input type="text" id="neq-stock-appid" value="${escapeAttr(rakutenConfig.wsAppId)}">
        </div>
        <div class="neq-stock-field">
          <label>楽天WS アクセスキー</label>
          <input type="password" id="neq-stock-accesskey" value="${escapeAttr(rakutenConfig.wsAccessKey)}" autocomplete="off">
        </div>
        <button class="neq-stock-config-save" id="neq-stock-config-save">設定を保存</button>
        <div class="neq-stock-config-hint">
          ※クラウド同期の対象になるため、送信すれば他PCにも自動反映されます
        </div>
      </div>
    </details>
  `;

  let statusHtml = '';
  if (scanRunning) {
    statusHtml = `<div class="neq-stock-status neq-stock-status-loading">⏳ チェック中... ${scanProgress}</div>`;
  } else if (stockLastError && !stockCheckedAt) {
    statusHtml = `<div class="neq-stock-status neq-stock-status-err">⚠ 前回失敗：${escapeHtml(stockLastError)}</div>`;
  } else if (stockCheckedAt) {
    statusHtml = `<div class="neq-stock-status neq-stock-status-ok">最終チェック：${escapeHtml(new Date(stockCheckedAt).toLocaleString())}</div>`;
  } else {
    statusHtml = `<div class="neq-stock-status">まだチェックされていません</div>`;
  }

  const activeHtml = renderItemsList(active, false);
  const ignoredHtml = ignored.length > 0
    ? `<details class="neq-stock-ignored-wrap"><summary>🙈 無視中の在庫切れ商品 ${ignored.length}件</summary>${renderItemsList(ignored, true)}</details>`
    : '';

  body.innerHTML = `
    ${configHtml}
    ${statusHtml}
    <div class="neq-stock-section">
      <div class="neq-stock-section-head">
        ${active.length > 0
          ? `<span class="neq-stock-section-title neq-stock-section-title-alarm">🚨 要対応の在庫切れ ${active.length}件</span>`
          : `<span class="neq-stock-section-title neq-stock-section-title-ok">✅ 要対応の在庫切れはありません</span>`}
      </div>
      ${activeHtml}
    </div>
    ${ignoredHtml}
  `;

  // 設定保存
  const saveBtn = document.getElementById('neq-stock-config-save');
  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      rakutenConfig = {
        shopCode: document.getElementById('neq-stock-shopcode').value.trim(),
        wsAppId: document.getElementById('neq-stock-appid').value.trim(),
        wsAccessKey: document.getElementById('neq-stock-accesskey').value.trim()
      };
      await chrome.storage.local.set({ [KEY_RAKUTEN_CONFIG]: rakutenConfig });
      saveBtn.textContent = '✓ 保存しました';
      setTimeout(() => { saveBtn.textContent = '設定を保存'; }, 2000);
      renderStockButton();
    });
  }

  // 各商品の無視／解除・楽天リンク
  body.querySelectorAll('.neq-stock-ignore-btn').forEach(b => {
    b.addEventListener('click', async () => {
      const c = b.dataset.code;
      stockIgnored[c] = true;
      await chrome.storage.local.set({ [KEY_STOCK_IGNORED]: stockIgnored });
      refreshModalBody();
      renderStockButton();
    });
  });
  body.querySelectorAll('.neq-stock-unignore-btn').forEach(b => {
    b.addEventListener('click', async () => {
      const c = b.dataset.code;
      delete stockIgnored[c];
      await chrome.storage.local.set({ [KEY_STOCK_IGNORED]: stockIgnored });
      refreshModalBody();
      renderStockButton();
    });
  });
}

function renderItemsList(codes, isIgnoredList) {
  if (codes.length === 0) {
    return `<div class="neq-stock-empty">${isIgnoredList ? '（なし）' : '在庫切れ商品はありません'}</div>`;
  }
  const rows = codes.map(code => {
    const info = stockInfo[code] || {};
    const name = info.n || `(商品名不明: ${code})`;
    const img = info.i || '';
    const url = info.u || '';
    const btnHtml = isIgnoredList
      ? `<button class="neq-stock-unignore-btn" data-code="${escapeAttr(code)}" title="無視を解除">↩ 解除</button>`
      : `<button class="neq-stock-ignore-btn" data-code="${escapeAttr(code)}" title="この商品を無視リストに追加">🙈 無視</button>`;
    const imgHtml = img
      ? `<img class="neq-stock-item-img" src="${escapeAttr(img)}" alt="" loading="lazy">`
      : `<div class="neq-stock-item-img neq-stock-item-noimg">画像なし</div>`;
    const linkHtml = url
      ? `<a class="neq-stock-item-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer" title="楽天商品ページ">↗</a>`
      : '';
    return `
      <div class="neq-stock-item">
        ${imgHtml}
        <div class="neq-stock-item-body">
          <div class="neq-stock-item-name">${escapeHtml(name)}</div>
          <div class="neq-stock-item-code">${escapeHtml(code)}</div>
        </div>
        <div class="neq-stock-item-actions">
          ${linkHtml}
          ${btnHtml}
        </div>
      </div>
    `;
  }).join('');
  return `<div class="neq-stock-items">${rows}</div>`;
}

// =====================================================
// ユーティリティ
// =====================================================
function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function escapeAttr(s) { return escapeHtml(s); }

// =====================================================
// CSS
// =====================================================
function injectStyles() {
  if (document.getElementById('neq-stock-styles')) return;
  const style = document.createElement('style');
  style.id = 'neq-stock-styles';
  style.textContent = `
    /* ---- ヘッダーボタン ---- */
    .neq-stock-btn {
      display: inline-flex; align-items: center; justify-content: center;
      padding: 6px 14px; margin: 4px 8px;
      font-family: -apple-system, "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif;
      font-size: 13px; font-weight: 700;
      border: 1.5px solid #b71c1c; background: #fff; color: #b71c1c;
      border-radius: 5px; cursor: pointer;
      transition: all .15s ease;
      white-space: nowrap;
    }
    .neq-stock-btn:hover { transform: translateY(-1px); box-shadow: 0 2px 6px rgba(0,0,0,.15); }
    .neq-stock-btn-floating {
      position: fixed; top: 10px; right: 12px; z-index: 99998;
      box-shadow: 0 2px 8px rgba(0,0,0,.15);
    }

    .neq-stock-btn.neq-stock-alarm {
      background: #b71c1c !important; color: #fff !important; border-color: #b71c1c !important;
      animation: neq-stock-btn-alarm 1.3s ease-in-out infinite;
    }
    @keyframes neq-stock-btn-alarm {
      0%,100% { box-shadow: 0 0 0 0 rgba(183,28,28,.55); }
      50%     { box-shadow: 0 0 0 6px rgba(183,28,28,0); }
    }
    @media (prefers-reduced-motion: reduce) {
      .neq-stock-btn.neq-stock-alarm { animation: none; }
    }
    .neq-stock-btn.neq-stock-ok {
      background: #fff !important; color: #1b7a3e !important; border-color: #1b7a3e !important;
    }
    .neq-stock-btn.neq-stock-error {
      background: #fff !important; color: #8a6100 !important; border-color: #e0a800 !important;
    }
    .neq-stock-btn.neq-stock-todo {
      background: #fff !important; color: #b71c1c !important; border-color: #b71c1c !important;
    }
    .neq-stock-btn.neq-stock-scanning {
      background: #fff !important; color: #666 !important; border-color: #bbb !important;
    }
    .neq-stock-btn.neq-stock-unset {
      background: #fff !important; color: #888 !important; border-color: #ccc !important;
    }

    /* ---- モーダル ---- */
    .neq-stock-modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 99999;
      display: flex; align-items: center; justify-content: center;
      font-family: -apple-system, "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif;
    }
    .neq-stock-modal-box {
      background: #fff; width: 720px; max-width: 92vw; max-height: 88vh;
      border-radius: 8px; display: flex; flex-direction: column;
      box-shadow: 0 12px 48px rgba(0,0,0,.3); overflow: hidden;
    }
    .neq-stock-modal-head {
      display: flex; align-items: center; justify-content: space-between;
      padding: 12px 18px; border-bottom: 1px solid #e0e0e0; background: #f8f9fa;
    }
    .neq-stock-modal-title { font-size: 15px; font-weight: 700; color: #333; }
    .neq-stock-modal-head-btns { display: flex; gap: 6px; }
    .neq-stock-rescan-btn {
      padding: 6px 12px; font-size: 12px; font-weight: 600;
      background: #fff; color: #2b7cd3; border: 1px solid #2b7cd3; border-radius: 4px;
      cursor: pointer; font-family: inherit;
    }
    .neq-stock-rescan-btn:hover { background: #2b7cd3; color: #fff; }
    .neq-stock-close-btn {
      width: 30px; height: 30px; border: none; background: none;
      font-size: 22px; color: #888; cursor: pointer; border-radius: 4px; line-height: 1;
    }
    .neq-stock-close-btn:hover { background: #f0f0f0; }

    .neq-stock-modal-body { flex: 1; overflow-y: auto; padding: 16px 20px; }

    /* ---- 設定 ---- */
    .neq-stock-config {
      background: #fafafa; border: 1px solid #e0e0e0; border-radius: 6px;
      padding: 8px 12px; margin-bottom: 14px;
    }
    .neq-stock-config summary { cursor: pointer; font-weight: 600; font-size: 13px; color: #555; }
    .neq-stock-config-body { padding-top: 12px; }
    .neq-stock-field { margin-bottom: 10px; }
    .neq-stock-field label { display: block; font-size: 11px; font-weight: 600; color: #666; margin-bottom: 3px; }
    .neq-stock-field input {
      width: 100%; padding: 7px 10px; border: 1px solid #ccc; border-radius: 4px;
      font-size: 13px; font-family: inherit; box-sizing: border-box;
    }
    .neq-stock-field input:focus { outline: none; border-color: #2b7cd3; }
    .neq-stock-config-save {
      padding: 7px 14px; font-size: 12px; font-weight: 600;
      background: #2b7cd3; color: #fff; border: none; border-radius: 4px;
      cursor: pointer; font-family: inherit;
    }
    .neq-stock-config-save:hover { background: #1f5fa3; }
    .neq-stock-config-hint { font-size: 11px; color: #888; margin-top: 8px; }

    /* ---- ステータス ---- */
    .neq-stock-status {
      font-size: 12px; padding: 8px 12px; border-radius: 5px;
      background: #f0f4f8; color: #555; margin-bottom: 14px;
    }
    .neq-stock-status-loading { background: #f5f5f5; color: #555; }
    .neq-stock-status-err { background: #fdf2f2; color: #c0392b; }
    .neq-stock-status-ok { background: #f0faf3; color: #2c8c4a; }

    /* ---- セクション ---- */
    .neq-stock-section { margin-bottom: 18px; }
    .neq-stock-section-head { margin-bottom: 8px; }
    .neq-stock-section-title {
      display: inline-block; padding: 5px 12px; border-radius: 4px;
      font-size: 13px; font-weight: 700;
    }
    .neq-stock-section-title-alarm { background: #fdecea; color: #b71c1c; }
    .neq-stock-section-title-ok { background: #eaf7ee; color: #1b7a3e; }

    /* ---- 商品リスト ---- */
    .neq-stock-items { display: flex; flex-direction: column; gap: 8px; }
    .neq-stock-empty { color: #999; font-size: 13px; padding: 16px; text-align: center; }
    .neq-stock-item {
      display: flex; align-items: center; gap: 12px;
      padding: 8px 10px; border: 1px solid #eee; border-radius: 5px; background: #fff;
    }
    .neq-stock-item-img {
      width: 48px; height: 48px; object-fit: cover; border-radius: 4px;
      background: #f5f5f5; flex-shrink: 0;
    }
    .neq-stock-item-noimg {
      display: flex; align-items: center; justify-content: center;
      font-size: 9px; color: #aaa;
    }
    .neq-stock-item-body { flex: 1; min-width: 0; }
    .neq-stock-item-name {
      font-size: 13px; font-weight: 500; color: #333;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .neq-stock-item-code { font-size: 11px; color: #888; margin-top: 2px; }
    .neq-stock-item-actions { display: flex; gap: 4px; flex-shrink: 0; align-items: center; }
    .neq-stock-item-link {
      text-decoration: none; padding: 4px 8px; font-size: 12px;
      color: #2b7cd3; border: 1px solid #2b7cd3; border-radius: 3px;
    }
    .neq-stock-item-link:hover { background: #2b7cd3; color: #fff; }
    .neq-stock-ignore-btn, .neq-stock-unignore-btn {
      padding: 4px 10px; font-size: 12px; font-family: inherit;
      background: #fff; color: #888; border: 1px solid #ccc; border-radius: 3px;
      cursor: pointer; white-space: nowrap;
    }
    .neq-stock-ignore-btn:hover { background: #f5f5f5; color: #555; border-color: #999; }
    .neq-stock-unignore-btn { color: #2c9c52; border-color: #2c9c52; }
    .neq-stock-unignore-btn:hover { background: #2c9c52; color: #fff; }

    .neq-stock-ignored-wrap {
      background: #fafafa; border: 1px solid #e5e5e5; border-radius: 5px;
      padding: 8px 12px;
    }
    .neq-stock-ignored-wrap summary {
      cursor: pointer; font-weight: 600; font-size: 12px; color: #888;
    }
    .neq-stock-ignored-wrap > .neq-stock-items { margin-top: 10px; }
  `;
  document.head.appendChild(style);
}

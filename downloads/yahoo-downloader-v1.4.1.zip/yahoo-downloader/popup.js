// ====== popup.js ======
// 実処理は background(Service Worker)。popupは「依頼」と「表示」だけ。

var LOG_KEY = 'yh_dl_logs';
var HISTORY_KEY = 'yh_dl_history';
var JOB_KEY = 'yh_active_job';
var CANCEL_KEY = 'yh_cancel_flag';
var DONE_KEY = 'yh_done_flags';
var DONE_SNAP_KEY = 'yh_done_flags_snap';
var DATES_KEY = 'yh_dates_saved';
var SETTINGS_KEY = 'yh_settings';

var KIND_LABEL = {
  ad: '① 広告詳細', item: '② 商品分析', overall: '③ 全体分析',
  itemmgr: '④ 商品データ', bidcsv: '⑤ 入札商品データ'
};
var MARK = { pending: '⬜', processing: '⏳', ok: '✅', ng: '❌', nodata: '⚪', notready: '⏰' };
var SNAP_KINDS = ['itemmgr', 'bidcsv'];

var $ = function (id) { return document.getElementById(id); };

function iso(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function yesterday() {
  var d = new Date(); d.setDate(d.getDate() - 1); return iso(d);
}

// 固定設定(UIからは触らない)
var SELLER = 'yukaiya';
var AD_REPORT_TYPE = 'product';   // ① 広告詳細レポート = 商品別

function settings() {
  return { seller: SELLER, reportType: AD_REPORT_TYPE };
}

function saveSettings() {
  chrome.storage.local.set({ [SETTINGS_KEY]: settings() });
}

// ---------- 起動時 ----------
(async function init() {
  var s = await chrome.storage.local.get([DATES_KEY]);
  var y = yesterday();
  var saved = s[DATES_KEY];
  if (saved && saved.locked) {
    $('startDate').value = saved.startDate || y;
    $('endDate').value = saved.endDate || y;
    setLocked(true);
  } else {
    $('startDate').value = y;
    $('endDate').value = y;
  }

  // 開いたらアイコンのバッジは消す(見たので用済み)
  try { chrome.action.setBadgeText({ text: '' }); } catch (e) {}

  render();
})();

function setLocked(locked) {
  $('saveDates').classList.toggle('locked', locked);
  $('saveDates').textContent = locked ? '💾 保存中(固定)' : '💾 日付を保存(固定)';
  $('startDate').classList.toggle('date-locked', locked);
  $('endDate').classList.toggle('date-locked', locked);
}

// ---------- 描画 ----------
function renderLastResult(r) {
  var el = $('lastResult');
  if (!r) { el.hidden = true; return; }
  var t = new Date(r.t);
  var hh = String(t.getMonth() + 1) + '/' + String(t.getDate()) + ' ' +
    String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
  el.classList.toggle('fail', !!r.fail);
  el.innerHTML = '<b>' + r.head + '</b><span class="when">' + hh + '</span><br>' +
    r.title + '<br>' + r.detail;
  el.hidden = false;
}

async function render() {
  var s = await chrome.storage.local.get([LOG_KEY, HISTORY_KEY, JOB_KEY, DONE_KEY, DONE_SNAP_KEY, 'yh_last_result']);
  renderLastResult(s.yh_last_result);
  renderJob(s[JOB_KEY]);
  renderHistory(s[HISTORY_KEY] || []);
  renderDone(s[DONE_KEY] || {}, s[DONE_SNAP_KEY] || {});
  var logs = s[LOG_KEY] || [];
  $('logCount').textContent = 'ログ ' + logs.length + ' 件';
}

function renderDone(flags, snapFlags) {
  [['ad', 'runAd'], ['item', 'runItem'], ['overall', 'runOverall']].forEach(function (p) {
    $(p[1]).classList.toggle('done', !!flags[p[0]]);
  });
  // 区分Bは「今日取ったか」で判定する(値は実行日。日付が変われば自動で外れる)
  var today = iso(new Date());
  [['itemmgr', 'runItemMgr'], ['bidcsv', 'runBidCsv']].forEach(function (p) {
    $(p[1]).classList.toggle('done', snapFlags[p[0]] === today);
  });
}

function renderJob(job) {
  var area = $('jobArea');
  if (!job) {
    area.innerHTML = '';
    setRunning(false);
    return;
  }
  setRunning(true);
  var byKind = {};
  job.tasks.forEach(function (t) { (byKind[t.kind] = byKind[t.kind] || []).push(t); });
  var lines = Object.keys(byKind).map(function (k) {
    return '<div class="job-line"><span class="lbl">' + (KIND_LABEL[k] || k) + '</span>' +
      byKind[k].map(function (t) { return MARK[t.state] || '⬜'; }).join('') + '</div>';
  }).join('');
  var done = job.tasks.filter(function (t) { return t.state !== 'pending' && t.state !== 'processing'; }).length;
  area.innerHTML =
    '<div class="active-job-box">' +
      '<div class="active-job-head"><span>⏳ ' + job.title + '</span>' +
      '<button class="cancel-btn" id="cancelBtn">⏹ 中止</button></div>' +
      '<div class="active-job-cells">' + lines + '</div>' +
      '<div class="active-job-stats">' + done + ' / ' + job.tasks.length + ' 完了 ' +
      '&nbsp;⚠ DL中はポップアップを閉じても継続します</div>' +
    '</div>';
  $('cancelBtn').addEventListener('click', function () {
    chrome.storage.local.set({ [CANCEL_KEY]: true });
    $('cancelBtn').disabled = true;
    $('cancelBtn').textContent = '中止中…';
  });
}

function setRunning(running) {
  ['runAll', 'runAd', 'runItem', 'runOverall', 'runSnapAll', 'runItemMgr', 'runBidCsv', 'retryFailed'].forEach(function (id) {
    $(id).disabled = running;
  });
}

function renderHistory(list) {
  var el = $('histList');
  if (!list.length) { el.innerHTML = '<div class="empty">履歴はまだありません</div>'; return; }
  el.innerHTML = list.slice(0, 40).map(function (h) {
    var t = new Date(h.t);
    var hh = String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
    var res = h.result === 'ok' ? '✅'
      : h.result === 'nodata' ? '⚪ データなし'
      : h.result === 'notready' ? '⏰ ' + (h.msg || '準備中')
      : '❌ ' + (h.msg || '失敗');
    var day = h.day === 'snapshot' ? 'スナップショット' : h.day;
    return '<div class="hist-item ' + h.result + '"><span class="time">[' + hh + ']</span>' +
      (h.type || h.kind) + ' ' + day + ' → <span class="res">' + res + '</span></div>';
  }).join('');
}

// ---------- 実行 ----------
function daysBetween(a, b) {
  var out = [], d = new Date(a + 'T00:00:00'), end = new Date(b + 'T00:00:00');
  while (d <= end) { out.push(iso(d)); d.setDate(d.getDate() + 1); }
  return out;
}

function validRange() {
  var a = $('startDate').value, b = $('endDate').value;
  $('startDate').classList.toggle('empty-required', !a);
  $('endDate').classList.toggle('empty-required', !b);
  if (!a || !b) { alert('開始日と終了日を入力してください'); return null; }
  if (a > b) { alert('開始日が終了日より後になっています'); return null; }
  return [a, b];
}

async function guardRunning() {
  var s = await chrome.storage.local.get([JOB_KEY]);
  if (s[JOB_KEY]) {
    alert('進行中のジョブがあります。先に ⏹ 中止 を押してください。');
    return false;
  }
  return true;
}

function start(title, kinds, days) {
  saveSettings();
  chrome.runtime.sendMessage(
    { type: 'run', title: title, kinds: kinds, days: days, settings: settings() },
    function () { void chrome.runtime.lastError; }
  );
  setRunning(true);
}

$('runAll').addEventListener('click', async function () {
  var r = validRange(); if (!r) return;
  if (!(await guardRunning())) return;
  start('期間指定 3種DL (' + r[0] + '〜' + r[1] + ')', ['ad', 'item', 'overall'], daysBetween(r[0], r[1]));
});

[['runAd', 'ad'], ['runItem', 'item'], ['runOverall', 'overall']].forEach(function (p) {
  $(p[0]).addEventListener('click', async function () {
    var r = validRange(); if (!r) return;
    if (!(await guardRunning())) return;
    start(KIND_LABEL[p[1]] + ' DL (' + r[0] + '〜' + r[1] + ')', [p[1]], daysBetween(r[0], r[1]));
  });
});

// ---------- 区分B: 最新状態スナップショット ----------
function startTasks(title, tasks) {
  saveSettings();
  chrome.runtime.sendMessage(
    { type: 'run-tasks', title: title, tasks: tasks, settings: settings() },
    function () { void chrome.runtime.lastError; }
  );
  setRunning(true);
}

$('runSnapAll').addEventListener('click', async function () {
  if (!(await guardRunning())) return;
  startTasks('④⑤ 最新状態 2種DL', SNAP_KINDS.map(function (k) { return { kind: k, day: 'snapshot' }; }));
});

[['runItemMgr', 'itemmgr'], ['runBidCsv', 'bidcsv']].forEach(function (p) {
  $(p[0]).addEventListener('click', async function () {
    if (!(await guardRunning())) return;
    startTasks(KIND_LABEL[p[1]] + ' 最新状態DL', [{ kind: p[1], day: 'snapshot' }]);
  });
});

// ---------- 失敗分の再取得 ----------
$('retryFailed').addEventListener('click', async function () {
  var s = await chrome.storage.local.get([HISTORY_KEY]);
  var list = s[HISTORY_KEY] || [];
  var latest = {};
  // 履歴は新しい順。(kind, day) ごとに最新のものだけ見る
  list.forEach(function (h) {
    var key = h.kind + '|' + h.day;
    if (!(key in latest)) latest[key] = h;
  });
  // ❌失敗 と ⏰準備中 が対象(⚪データなしは、そもそも存在しないので対象外)
  var tasks = Object.keys(latest)
    .filter(function (k) { return latest[k].result === 'ng' || latest[k].result === 'notready'; })
    .map(function (k) { return { kind: latest[k].kind, day: latest[k].day }; })
    .sort(function (a, b) { return (a.kind + a.day).localeCompare(b.kind + b.day); });

  if (!tasks.length) { alert('再取得が必要な失敗はありません'); return; }
  if (!confirm(tasks.length + ' 件を再取得します。よろしいですか?')) return;
  startTasks('♻ 失敗分の再取得', tasks);
});

// ---------- その他 ----------
$('openTabs').addEventListener('click', function () {
  saveSettings();
  chrome.runtime.sendMessage({ type: 'open-tabs', settings: settings() }, function () { void chrome.runtime.lastError; });
});

$('saveDates').addEventListener('click', function () {
  var r = validRange(); if (!r) return;
  chrome.storage.local.set({ [DATES_KEY]: { startDate: r[0], endDate: r[1], locked: true } });
  setLocked(true);
});

$('clearDates').addEventListener('click', function () {
  chrome.storage.local.remove([DATES_KEY]);
  setLocked(false);
});

$('clearHist').addEventListener('click', function () {
  if (!confirm('DL履歴をクリアしますか?')) return;
  chrome.storage.local.set({ [HISTORY_KEY]: [] });
});

$('copyLog').addEventListener('click', async function () {
  var s = await chrome.storage.local.get([LOG_KEY]);
  var text = (s[LOG_KEY] || []).map(function (l) {
    return '[' + l.t + '] (' + l.cat + ') ' + l.msg;
  }).join('\n');
  await navigator.clipboard.writeText(text || '(ログなし)');
  $('copyLog').classList.add('copied');
  $('copyLog').textContent = '✅ コピーしました';
  setTimeout(function () {
    $('copyLog').classList.remove('copied');
    $('copyLog').textContent = '📋 ログをコピー';
  }, 1500);
});

$('clearLog').addEventListener('click', function () {
  chrome.storage.local.set({ [LOG_KEY]: [] });
});

// 日付を変えたら完了マーカーをリセット
['startDate', 'endDate'].forEach(function (id) {
  $(id).addEventListener('change', function () { chrome.storage.local.remove([DONE_KEY]); });
});
// storage の変化を購読(popupを閉じても background が書くので、開き直せば反映される)
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== 'local') return;
  render();
});

// ====== injected.js (MAIN world) ======
// ページのコンテキストで実行される。
// 方針: 「サイト自身のCSV生成処理」をそのまま使い、
//       生成された Blob を横取りして、こちらで決めたファイル名で保存する。
//       → CSVの中身はサイトが出すものと完全に同一(文字コード・列・書式すべて)。
//
// 注意: 再注入されても壊れないよう、トップレベルは function 宣言と var のみ。

var YH_VER = '1.4.1';

function yhSleep(ms) {
  return new Promise(function (r) { setTimeout(r, ms); });
}

// ---- Blob 横取りフックの導入(1回だけ) ----
function yhInstallHooks() {
  if (window.__yhHooked) return;
  window.__yhHooked = true;
  window.__yhCap = { blob: null, name: null };

  var origCreate = URL.createObjectURL;
  window.__yhOrigCreateObjectURL = origCreate;
  URL.createObjectURL = function (obj) {
    try {
      if (window.__yhArmed && obj && typeof obj.size === 'number' && typeof obj.type === 'string') {
        window.__yhCap.blob = obj;
      }
    } catch (e) {}
    return origCreate.call(URL, obj);
  };

  var origClick = HTMLAnchorElement.prototype.click;
  window.__yhOrigAnchorClick = origClick;
  HTMLAnchorElement.prototype.click = function () {
    // 武装中は、サイトが出そうとした <a download> のクリックを握りつぶす
    // (ファイル名を差し替えて後でこちらから保存する)
    if (window.__yhArmed && this.hasAttribute('download')) {
      window.__yhCap.name = this.getAttribute('download');
      return;
    }
    return origClick.call(this);
  };
}

function yhArm() {
  yhInstallHooks();
  window.__yhCap = { blob: null, name: null };
  window.__yhArmed = true;
}

function yhDisarm() {
  window.__yhArmed = false;
}

// 横取りしたBlobを、こちらのファイル名で保存
function yhSaveBlob(blob, filename) {
  // ④のように yhArm() を通らない経路でも動くよう、必ずフックを用意しておく
  yhInstallHooks();
  var createUrl = window.__yhOrigCreateObjectURL || URL.createObjectURL;
  var clickEl = window.__yhOrigAnchorClick || HTMLAnchorElement.prototype.click;
  var url = createUrl.call(URL, blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  clickEl.call(a);
  setTimeout(function () {
    try { URL.revokeObjectURL(url); } catch (e) {}
    try { a.remove(); } catch (e) {}
  }, 20000);
}

// Blob を data URL 化して background に渡す。
// 保存は chrome.downloads で行う(ページ内の <a download> は Chrome の
// 「複数ファイルの自動ダウンロード」ブロックで2件目以降が無音で捨てられるため)。
function yhToDataUrl(blob) {
  return new Promise(function (resolve, reject) {
    var fr = new FileReader();
    fr.onload = function () { resolve(String(fr.result)); };
    fr.onerror = function () { reject(new Error('ファイルの読み取りに失敗しました')); };
    fr.readAsDataURL(blob);
  });
}

// Blob が来るまで待つ
function yhWaitBlob(timeoutMs) {
  var start = Date.now();
  return (function loop() {
    if (window.__yhCap && window.__yhCap.blob) return Promise.resolve(window.__yhCap.blob);
    if (Date.now() - start > timeoutMs) return Promise.resolve(null);
    return yhSleep(300).then(loop);
  })();
}

// CSVの中身を軽く検査する(データ有無 / 対象日が入っているか)
function yhInspectCsv(blob, dayIso) {
  return blob.arrayBuffer().then(function (buf) {
    var bytes = new Uint8Array(buf);
    var text;
    try { text = new TextDecoder('shift_jis').decode(bytes); }
    catch (e) { text = new TextDecoder('utf-8').decode(bytes); }
    var lines = text.split(/\r?\n/).filter(function (s) { return s.trim().length > 0; });
    var slash = dayIso.replace(/-/g, '/');
    return {
      bytes: blob.size,
      lines: lines.length,
      hasDaySlash: text.indexOf(slash) >= 0,   // 2026/09/08
      hasDayIso: text.indexOf(dayIso) >= 0,    // 2026-09-08
      header: lines[0] ? lines[0].slice(0, 200) : ''
    };
  });
}

function yhFmt(dayIso) { return dayIso.replace(/-/g, ''); }

// サイトが付けた元のファイル名の末尾に対象日を足す
//   広告詳細レポート_..._日別.csv → 広告詳細レポート_..._日別-20260901.csv
function yhBuildName(origName, fallbackBase, dayIso) {
  var name = (origName && String(origName).trim()) || (fallbackBase + '.csv');
  var i = name.lastIndexOf('.');
  var base = i > 0 ? name.slice(0, i) : name;
  var ext = i > 0 ? name.slice(i) : '.csv';
  return base + '-' + yhFmt(dayIso) + ext;
}

// =====================================================================
// ① 広告詳細レポート (cam.yahoo.co.jp/{seller}/report/adDetail)
//    reportType: 'product' | 'searchKeywordProduct' | 'deliveryCategory'
// =====================================================================
function yahooAdDetailDownloader(p) {
  var dayIso = p.day;
  var reportType = p.reportType || 'product';
  var seller = p.seller || 'yukaiya';
  var timeout = (p.timeout || 60) * 1000;

  // --- fetch を差し替えて、集計期間(since/until)を対象日に強制する ---
  if (!window.__yhFetchPatched) {
    window.__yhFetchPatched = true;
    var origFetch = window.fetch;
    window.fetch = function (input, init) {
      try {
        var url = (typeof input === 'string') ? input : (input && input.url) || '';
        if (window.__yhTargetDay &&
            /\/api\/report\/[a-zA-Z-]*download/.test(url) &&
            init && typeof init.body === 'string') {
          var b = JSON.parse(init.body);
          b.since = window.__yhTargetDay;
          b.until = window.__yhTargetDay;
          init = Object.assign({}, init, { body: JSON.stringify(b) });
          window.__yhRewroteAt = Date.now();
        }
      } catch (e) { /* 失敗しても素通しする(後段の日付検証で弾く) */ }
      return origFetch.call(this, input, init);
    };
  }
  window.__yhTargetDay = dayIso.replace(/-/g, '/');
  window.__yhRewroteAt = 0;

  return (async function () {
    // レポート種別ラジオ
    var radios = Array.prototype.slice.call(document.querySelectorAll('input[name="reportType"]'));
    if (!radios.length) {
      return { ok: false, status: 'error', error: '広告詳細レポートのページが読み込まれていません' };
    }
    var radio = radios.filter(function (r) { return r.value === reportType; })[0];
    if (!radio) {
      return { ok: false, status: 'error', error: 'レポート種別が見つかりません: ' + reportType };
    }
    if (!radio.checked) { radio.click(); await yhSleep(700); }

    // 集計単位「日別」
    var spanRadio = Array.prototype.slice.call(document.querySelectorAll('input[name="aggregationPeriodType"]'))
      .filter(function (r) { return r.value === '1'; })[0];
    if (spanRadio && !spanRadio.checked) { spanRadio.click(); await yhSleep(400); }

    // DLボタンが押せるようになるまで待つ
    var btn = null;
    var t0 = Date.now();
    while (Date.now() - t0 < 15000) {
      btn = Array.prototype.slice.call(document.querySelectorAll('button'))
        .filter(function (b) { return /CSV.*ダウンロード/.test(b.textContent || ''); })[0];
      if (btn && !btn.disabled) break;
      await yhSleep(400);
    }
    if (!btn) return { ok: false, status: 'error', error: 'CSVダウンロードボタンが見つかりません' };
    if (btn.disabled) return { ok: false, status: 'error', error: 'CSVダウンロードボタンが有効になりません' };

    yhArm();
    btn.click();
    var blob = await yhWaitBlob(timeout);
    yhDisarm();

    if (!blob) {
      return { ok: false, status: 'error', error: 'CSVが生成されませんでした(タイムアウト/セッション切れの可能性)' };
    }
    if (!window.__yhRewroteAt) {
      return { ok: false, status: 'error', error: '集計期間の差し替えに失敗しました(サイト仕様変更の可能性)' };
    }

    var info = await yhInspectCsv(blob, dayIso);
    if (info.lines <= 1) {
      return { ok: true, status: 'nodata', bytes: info.bytes, lines: info.lines };
    }
    if (!info.hasDaySlash) {
      return { ok: false, status: 'error', error: '取得CSVに対象日(' + dayIso + ')が入っていません' };
    }

    var fn = yhBuildName(window.__yhCap.name, '広告詳細レポート_' + reportType, dayIso);
    return { ok: true, status: 'ok', file: fn, bytes: info.bytes, lines: info.lines,
             dataUrl: await yhToDataUrl(blob) };
  })();
}

// =====================================================================
// ②③ ストアクリエイターPro (pro.store.yahoo.co.jp)
//     Phase A: 日付をセットしてフォーム送信(=ページ遷移)
//     Phase B: 遷移後にサイトのCSVボタンを押してBlobを横取り
// =====================================================================

// kind: 'overall' | 'item'
function yhProConf(kind, seller) {
  seller = seller || 'yukaiya';
  if (kind === 'overall') {
    // 「全体分析図から選択した指標の推移」側のCSV(= yukaiya-store_overall_kpi.csv)
    return { formName: 'changeForm', btnId: 'graphCsvDownload', fallbackBase: seller + '-store_overall_kpi' };
  }
  return { formName: 'itemListForm', btnId: 'itemReportCsvDownload', fallbackBase: seller + '-item_report' };
}

// --- Phase A ---
function yahooProSetDate(p) {
  var conf = yhProConf(p.kind);
  var slash = p.day.replace(/-/g, '/');
  var f = document.forms[conf.formName];
  if (!f) return { ok: false, error: 'フォームが見つかりません: ' + conf.formName + '(ページ未ロード/ログイン切れ?)' };

  function set(name, val) { if (f.elements[name]) f.elements[name].value = val; }
  set('span', 'daily');
  set('dateFrom', slash);
  set('dateTo', slash);
  if (f.elements['mall']) set('mall', 'shp');
  if (f.elements['device']) set('device', 'all');
  if (f.elements['since']) set('since', '');
  if (f.elements['until']) set('until', '');

  window.__yhNavMark = true;   // 遷移したかどうかの目印(遷移すると消える)
  try { f.submit(); } catch (e) { return { ok: false, error: 'フォーム送信に失敗: ' + e.message }; }
  return { ok: true };
}

// --- 遷移完了チェック ---
function yahooProCheckReady(p) {
  var slash = p.day.replace(/-/g, '/');
  var from = document.getElementById('dailyInputDatepickerFrom');
  var to = document.getElementById('dailyInputDatepickerTo');
  var conf = yhProConf(p.kind);
  return {
    navigated: !window.__yhNavMark,
    ready: document.readyState,
    from: from ? from.value : null,
    to: to ? to.value : null,
    btn: !!document.getElementById(conf.btnId),
    match: !!(from && to && from.value === slash && to.value === slash)
  };
}

// --- Phase B ---
function yahooProGrabCsv(p) {
  var conf = yhProConf(p.kind, p.seller);
  var seller = p.seller || 'yukaiya';
  var dayIso = p.day;
  var slash = dayIso.replace(/-/g, '/');
  var timeout = (p.timeout || 60) * 1000;

  return (async function () {
    // 日付が反映されているか最終確認
    var from = document.getElementById('dailyInputDatepickerFrom');
    var to = document.getElementById('dailyInputDatepickerTo');
    if (!from || !to) return { ok: false, status: 'error', error: '日付欄が見つかりません' };
    if (from.value !== slash || to.value !== slash) {
      return { ok: false, status: 'error', error: '日付が反映されていません(' + from.value + '〜' + to.value + ')' };
    }

    var btn = null;
    var t0 = Date.now();
    while (Date.now() - t0 < 20000) {
      btn = document.getElementById(conf.btnId);
      if (btn) break;
      await yhSleep(400);
    }
    if (!btn) return { ok: false, status: 'error', error: 'CSVダウンロードボタンが見つかりません' };

    yhArm();
    btn.click();
    var blob = await yhWaitBlob(timeout);
    yhDisarm();

    if (!blob) return { ok: false, status: 'error', error: 'CSVが生成されませんでした(タイムアウト)' };

    var info = await yhInspectCsv(blob, dayIso);
    if (info.lines <= 1) {
      return { ok: true, status: 'nodata', bytes: info.bytes, lines: info.lines };
    }
    // overall は CSV内に日付列(YYYY-MM-DD)があるので照合できる
    if (p.kind === 'overall' && !info.hasDayIso && !info.hasDaySlash) {
      return { ok: false, status: 'error', error: '取得CSVに対象日(' + dayIso + ')が入っていません' };
    }

    var fn = yhBuildName(window.__yhCap.name, conf.fallbackBase, dayIso);
    return { ok: true, status: 'ok', file: fn, bytes: info.bytes, lines: info.lines,
             dataUrl: await yhToDataUrl(blob) };
  })();
}

// ---- 進捗オーバーレイ(ページ上に表示) ----
function yhInstallOverlay(title) {
  var id = '__yh_overlay__';
  var el = document.getElementById(id);
  if (!el) {
    el = document.createElement('div');
    el.id = id;
    el.style.cssText = [
      'position:fixed', 'right:16px', 'bottom:16px', 'z-index:2147483647',
      'background:rgba(20,20,20,.92)', 'color:#fff', 'padding:10px 14px',
      'border-radius:8px', 'font:12px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
      'box-shadow:0 4px 16px rgba(0,0,0,.35)', 'max-width:320px', 'pointer-events:none'
    ].join(';');
    document.body.appendChild(el);
  }
  el.textContent = title;
  el.style.display = 'block';
  return true;
}

function yhUpdateOverlay(text) {
  var el = document.getElementById('__yh_overlay__');
  if (el) el.textContent = text;
  return true;
}

function yhRemoveOverlay() {
  var el = document.getElementById('__yh_overlay__');
  if (el) el.style.display = 'none';
  return true;
}

// =====================================================================
// 【区分B】最新状態スナップショット(日付の概念なし・1回押すだけ)
// =====================================================================

// cam.yahoo のページから campaignId / adGroupId を読む
function yhReadCamIds() {
  try {
    var el = document.getElementById('__NEXT_DATA__');
    if (!el) return { ok: false, error: '__NEXT_DATA__ が見つかりません' };
    var j = JSON.parse(el.textContent);
    var st = (j.props && j.props.pageProps && j.props.pageProps.initializeStore) || {};
    var campaignId = st.csvBidCampaignId ||
      (st.campaigns && st.campaigns[0] && st.campaigns[0].campaignId);
    var adGroupId = st.csvBidAdGroupId ||
      (st.adGroups && st.adGroups[0] && st.adGroups[0].adGroupId);
    if (!campaignId || !adGroupId) return { ok: false, error: 'campaignId/adGroupId が取得できません' };
    return { ok: true, campaignId: String(campaignId), adGroupId: String(adGroupId) };
  } catch (e) {
    return { ok: false, error: e && e.message ? e.message : String(e) };
  }
}

// 添付ファイルなら Blob、そうでなければ EUC-JP のHTMLテキストを返す
function yhFetchFile(url) {
  return fetch(url, { credentials: 'include' }).then(function (r) {
    var cd = String(r.headers.get('content-disposition') || '');
    var ct = String(r.headers.get('content-type') || '');
    var m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
    if (/attachment/i.test(cd) || /octet-stream|text\/csv/i.test(ct)) {
      return r.blob().then(function (b) {
        var name = 'itemdata.csv';
        if (m) { try { name = decodeURIComponent(m[1]); } catch (e) { name = m[1]; } }
        return { file: true, blob: b, name: name };
      });
    }
    return r.arrayBuffer().then(function (buf) {
      var bytes = new Uint8Array(buf);
      var text;
      try { text = new TextDecoder('euc-jp').decode(bytes); }
      catch (e) { text = new TextDecoder('utf-8').decode(bytes); }
      return { file: false, text: text, status: r.status };
    });
  });
}

// ストアエディタが返す「メッセージ画面」を読む
function yhParseEditorPage(html) {
  var d = new DOMParser().parseFromString(html, 'text/html');
  var g = function (n) {
    var el = d.querySelector('input[name="' + n + '"]');
    return el ? (el.value || '') : '';
  };
  return {
    msg: g('msg'),
    confirmMsg: g('confirm_msg'),
    redirectUrl: g('redirect_url'),
    loadModule: g('load_module')
  };
}

// ④ 商品データ(ストアエディタ 商品管理 → 商品データ → ダウンロード)
//    ページの downloadItemData() をそのまま呼び、window.open のURLを横取りする。
//    「準備完了の確認画面」が返ったら redirect_url を取りに行く。
function yahooItemMgrSnapshot(p) {
  return (async function () {
    if (typeof window.downloadItemData !== 'function') {
      return { ok: false, status: 'error', error: '商品管理ページが読み込まれていません(ログイン切れの可能性)' };
    }
    var captured = null;
    var origOpen = window.open;
    window.open = function (u) { captured = String(u); return null; };
    try { window.downloadItemData(); }
    catch (e) { window.open = origOpen; return { ok: false, status: 'error', error: 'downloadItemData 実行失敗: ' + e.message }; }
    window.open = origOpen;
    if (!captured) return { ok: false, status: 'error', error: 'ダウンロードURLが取得できませんでした' };

    var res = await yhFetchFile(new URL(captured, location.href).href);
    if (res.file) {
      return { ok: true, status: 'ok', file: res.name, bytes: res.blob.size,
               dataUrl: await yhToDataUrl(res.blob) };
    }

    var page = yhParseEditorPage(res.text);
    if (page.loadModule === 'confirmDelayed' && page.redirectUrl) {
      var res2 = await yhFetchFile(new URL(page.redirectUrl, location.href).href);
      if (res2.file) {
        return { ok: true, status: 'ok', file: res2.name, bytes: res2.blob.size,
                 dataUrl: await yhToDataUrl(res2.blob) };
      }
      return { ok: false, status: 'error', error: '確認後もファイルが返ってきませんでした' };
    }
    var msg = String(page.msg || page.confirmMsg || '').replace(/\\n|\n/g, ' ').trim();
    return {
      ok: true, status: 'notready',
      error: msg || 'ダウンロード準備中です。数分おいてもう一度実行してください'
    };
  })();
}

// ⑤ 広告の入札商品データ(コマースアドマネージャー アイテムリーチ → CSV入札・削除)
//    ファイル名はサイトのまま(BID_ITEM.csv)
function yahooBidCsvSnapshot(p) {
  var timeout = (p && p.timeout ? p.timeout : 60) * 1000;
  return (async function () {
    var btn = null;
    var t0 = Date.now();
    while (Date.now() - t0 < 15000) {
      btn = Array.prototype.slice.call(document.querySelectorAll('button'))
        .filter(function (b) { return (b.textContent || '').trim() === 'ダウンロード'; })[0];
      if (btn && !btn.disabled) break;
      await yhSleep(400);
    }
    if (!btn) return { ok: false, status: 'error', error: 'ダウンロードボタンが見つかりません(ページ未ロード/ログイン切れ?)' };
    if (btn.disabled) return { ok: false, status: 'error', error: 'ダウンロードボタンが有効になりません' };

    yhArm();
    btn.click();
    var blob = await yhWaitBlob(timeout);
    yhDisarm();
    if (!blob) return { ok: false, status: 'error', error: 'CSVが生成されませんでした(タイムアウト)' };

    var info = await yhInspectCsv(blob, '1970-01-01');
    if (info.lines <= 1) return { ok: true, status: 'nodata', bytes: info.bytes, lines: info.lines };

    var fn = window.__yhCap.name || 'BID_ITEM.csv';   // ファイル名はサイトのまま
    return { ok: true, status: 'ok', file: fn, bytes: info.bytes, lines: info.lines,
             dataUrl: await yhToDataUrl(blob) };
  })();
}

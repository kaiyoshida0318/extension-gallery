// ====== Service Worker (background) ======
// popupが閉じても動き続けて、ジョブを順次実行する

const LOG_KEY = 'rms_dl_logs';
const HISTORY_KEY = 'rms_dl_history';

// 簡易DL履歴を chrome.storage.local に保存
async function recordHistory(entry) {
  try {
    const s = await chrome.storage.local.get([HISTORY_KEY]);
    const list = s[HISTORY_KEY] || [];
    list.unshift({ t: new Date().toISOString(), ...entry });
    if (list.length > 50) list.length = 50;
    await chrome.storage.local.set({ [HISTORY_KEY]: list });
  } catch (_) {}
}

async function appendBgLog(category, text, extra = null) {
  // 直列化(レース防止)
  appendBgLog._chain = (appendBgLog._chain || Promise.resolve()).then(async () => {
    try {
      const stored = await chrome.storage.local.get([LOG_KEY]);
      const logs = stored[LOG_KEY] || [];
      logs.push({
        t: new Date().toISOString(),
        cat: category,
        msg: String(text),
        extra: extra
      });
      if (logs.length > 2000) logs.splice(0, logs.length - 2000);
      await chrome.storage.local.set({ [LOG_KEY]: logs });
    } catch (_) {}
  });
  return appendBgLog._chain;
}

// 該当URLのタブを探す。無ければensureUrlで新規作成
async function getOrCreateTab(urlMatch, ensureUrl) {
  const tabs = await chrome.tabs.query({});
  let tab = tabs.find(t => t.url && t.url.includes(urlMatch));
  if (tab) return tab;
  await appendBgLog('bg', `タブが見つからないので新規オープン: ${ensureUrl}`);
  tab = await chrome.tabs.create({ url: ensureUrl, active: false });
  const start = Date.now();
  while ((Date.now() - start) < 15000) {
    await new Promise(r => setTimeout(r, 500));
    try {
      const t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete') return t2;
    } catch (_) {
      const refreshed = (await chrome.tabs.query({})).find(t => t.url && t.url.includes(urlMatch));
      if (refreshed) return refreshed;
    }
  }
  return tab;
}

// タブに injected.js を読み込み、指定の関数を呼び出す
async function runOnTab(tabId, funcName, params) {
  // ① injected.js を注入(関数定義がpage contextに入る)
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['injected.js']
  });
  // ② 注入された関数を名前で呼び出す
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (funcName, params) => {
      const fn = (typeof globalThis[funcName] === 'function')
        ? globalThis[funcName]
        : (typeof self[funcName] === 'function' ? self[funcName] : null);
      if (!fn) return { ok: false, error: `関数が未注入: ${funcName}` };
      try {
        return await fn(params);
      } catch (e) {
        return { ok: false, error: e.message, stack: e.stack };
      }
    },
    args: [funcName, params]
  });
  return results?.[0]?.result;
}

// オーバーレイ準備
async function installOverlayOnTab(tabId, title) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['injected.js']
  });
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (title) => {
      if (typeof installProgressOverlay === 'function') installProgressOverlay(title);
    },
    args: [title]
  });
}

// ====== メッセージリスナー ======
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'run-bulk-rpp3') {
    // 即座にtrueを返してSWを生かしておく
    handleBulkRpp3(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;  // 非同期レスポンス
  }
  if (msg?.type === 'run-itemsales') {
    handleItemSales(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-cpn') {
    handleCpn(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-bulk-cpn2') {
    handleBulkCpn2(msg.payload).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  if (msg?.type === 'run-retry-failed') {
    handleRetryFailed(msg.tasks || []).then(result => {
      try { sendResponse(result); } catch (_) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (_) {}
    });
    return true;
  }
  return false;
});

// ====== ハンドラ: 商品別売上 ======
async function handleItemSales(payload) {
  await appendBgLog('bg', `▶ 商品別売上 開始`);
  const tab = await getOrCreateTab('datatool.rms.rakuten.co.jp/realtime/item', 'https://datatool.rms.rakuten.co.jp/realtime/item');
  if (!tab) {
    await appendBgLog('bg', `❌ 商品別売上タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  タブID=${tab.id}`);
  await installOverlayOnTab(tab.id, '🛒 商品別売上 ダウンロード中');
  const r = await runOnTab(tab.id, 'itemSalesDownloader', payload);
  await appendBgLog('bg', `✅ 商品別売上 完了: ${JSON.stringify(r)}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return r;
}

// ====== ハンドラ: RPP 3種連続 ======
async function handleBulkRpp3(payload) {
  await appendBgLog('bg', `▶ RPP3種 開始`);
  const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
  if (!tab) {
    await appendBgLog('bg', `❌ RPPタブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  RPPタブID=${tab.id}`);

  // 3ジョブの仕様
  const jobs = [
    { name: '全ての広告', funcName: 'rppAllDownloader', params: payload.rppAll, overlayTitle: '🛒 全ての広告 ダウンロード中' },
    { name: '全商品レポート', funcName: 'rppAsyncDownloader', params: payload.rppItem, overlayTitle: '🛒 全商品レポート ダウンロード中' },
    { name: '全キーワードレポート', funcName: 'rppAsyncDownloader', params: payload.rppKw, overlayTitle: '🛒 全キーワードレポート ダウンロード中' }
  ];

  let ok = 0, ng = 0;
  for (let i = 0; i < jobs.length; i++) {
    // 中止フラグチェック(連続ジョブの途中で止められるよう)
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りのRPP3種ジョブをスキップ`);
      ng += (jobs.length - i);
      break;
    }
    const job = jobs[i];
    await appendBgLog('bg', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      // タブが消滅していたら再取得
      let curTab;
      try { curTab = await chrome.tabs.get(tab.id); } catch (_) { curTab = null; }
      if (!curTab) {
        await appendBgLog('bg', `  タブ消滅 → 再取得`);
        const re = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
        if (!re) throw new Error('タブ再取得失敗');
        tab.id = re.id;
      }
      await installOverlayOnTab(tab.id, job.overlayTitle);
      const r = await runOnTab(tab.id, job.funcName, job.params);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        ok++;
        await appendBgLog('bg', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ng++;
        await appendBgLog('bg', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
      }
    } catch (e) {
      ng++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 RPP3種 完了: 成功 ${ok} / 失敗 ${ng}`);
  // 中止フラグはここでクリア(次のジョブに引き継がない)
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return { ok: true, success: ok, fail: ng };
}

// ====== ハンドラ: クーポン広告(cpnadv) ======
async function handleCpn(payload) {
  await appendBgLog('bg', `▶ クーポン広告 開始 (mode=${payload?.mode})`);
  const tab = await getOrCreateTab(
    'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
    'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
  );
  if (!tab) {
    await appendBgLog('bg', `❌ クーポン広告タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  タブID=${tab.id}`);
  const overlayTitle = payload?.mode === 'keyword'
    ? '🛒 クーポン広告 全KWレポート ダウンロード中'
    : '🛒 クーポン広告 商品別レポート ダウンロード中';
  await installOverlayOnTab(tab.id, overlayTitle);
  const r = await runOnTab(tab.id, 'cpnadvAsyncDownloader', payload);
  await appendBgLog('bg', `✅ クーポン広告 完了: ${JSON.stringify(r)}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return r;
}

// ====== ハンドラ: クーポン広告 2種連続 (商品別 → KW別) ======
async function handleBulkCpn2(payload) {
  await appendBgLog('bg', `▶ クーポン2種 開始`);
  const tab = await getOrCreateTab(
    'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
    'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
  );
  if (!tab) {
    await appendBgLog('bg', `❌ クーポン広告タブ取得失敗`);
    return { ok: false, error: 'タブ取得失敗' };
  }
  await appendBgLog('bg', `  クーポンタブID=${tab.id}`);

  const jobs = [
    {
      name: 'クーポン広告 商品別',
      params: { ...payload, mode: 'item' },
      overlayTitle: '🛒 クーポン広告 商品別レポート ダウンロード中'
    },
    {
      name: 'クーポン広告 KW別(全件)',
      params: { ...payload, mode: 'keyword' },
      overlayTitle: '🛒 クーポン広告 全KWレポート ダウンロード中'
    }
  ];

  let ok = 0, ng = 0;
  for (let i = 0; i < jobs.length; i++) {
    // 中止フラグチェック
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りのクーポン広告ジョブをスキップ`);
      ng += (jobs.length - i);
      break;
    }
    const job = jobs[i];
    await appendBgLog('bg', `[${i + 1}/${jobs.length}] ${job.name} 実行開始`);
    const t0 = Date.now();
    try {
      let curTab;
      try { curTab = await chrome.tabs.get(tab.id); } catch (_) { curTab = null; }
      if (!curTab) {
        await appendBgLog('bg', `  タブ消滅 → 再取得`);
        const re = await getOrCreateTab(
          'ad.rms.rakuten.co.jp/cpnadv/performance_reports',
          'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports'
        );
        if (!re) throw new Error('タブ再取得失敗');
        tab.id = re.id;
      }
      await installOverlayOnTab(tab.id, job.overlayTitle);
      const r = await runOnTab(tab.id, 'cpnadvAsyncDownloader', job.params);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (r?.ok) {
        ok++;
        await appendBgLog('bg', `  ✅ ${job.name} 成功 (${dt}秒, 成功=${r.success ?? '-'} 失敗=${r.fail ?? '-'})`);
      } else {
        ng++;
        await appendBgLog('bg', `  ❌ ${job.name} 失敗 (${dt}秒): ${r?.error || '不明'}`);
      }
    } catch (e) {
      ng++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${job.name} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 クーポン2種 完了: 成功 ${ok} / 失敗 ${ng}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return { ok: true, success: ok, fail: ng };
}

// ====== ハンドラ: 失敗分の再取得 ======
// tasks: [{ kind: 'rppAll', type: '② 全ての広告', days: ['2026-06-15', ...] }, ...]
async function handleRetryFailed(tasks) {
  await appendBgLog('bg', `▶ ♻ 失敗分の再取得 開始 (${tasks.length}タスク)`);
  let okTasks = 0, ngTasks = 0;

  for (let i = 0; i < tasks.length; i++) {
    // 中止フラグチェック
    const flagState = await chrome.storage.local.get(['rms_cancel_flag']);
    if (flagState.rms_cancel_flag) {
      await appendBgLog('bg', `⏹ 中止フラグ検出 → 残りの再取得タスクをスキップ`);
      ngTasks += (tasks.length - i);
      break;
    }
    const task = tasks[i];
    await appendBgLog('bg', `[${i + 1}/${tasks.length}] ${task.type} 失敗分再取得 (${task.days.length}日)`);
    const t0 = Date.now();
    try {
      const result = await runRetryTask(task);
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      if (result?.ok || result?.success > 0) {
        okTasks++;
        await appendBgLog('bg', `  ✅ ${task.type} 完了 (${dt}秒, 成功=${result.success ?? '-'} 失敗=${result.fail ?? '-'})`);
      } else {
        ngTasks++;
        await appendBgLog('bg', `  ❌ ${task.type} 失敗 (${dt}秒): ${result?.error || '不明'}`);
      }
    } catch (e) {
      ngTasks++;
      const dt = ((Date.now() - t0) / 1000).toFixed(1);
      await appendBgLog('bg', `  💥 ${task.type} 例外 (${dt}秒): ${e.message}`);
    }
  }
  await appendBgLog('bg', `🎉 失敗分再取得 完了: 成功タスク ${okTasks} / 失敗タスク ${ngTasks}`);
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return { ok: true, okTasks, ngTasks };
}

// 1つの再取得タスクを kind に応じた downloader で実行
async function runRetryTask(task) {
  const days = task.days;
  if (!Array.isArray(days) || days.length === 0) return { ok: false, error: '日付リストが空' };
  const startDate = days[0];
  const endDate = days[days.length - 1];

  if (task.kind === 'itemSales') {
    const tab = await getOrCreateTab('datatool.rms.rakuten.co.jp/realtime/item', 'https://datatool.rms.rakuten.co.jp/realtime/item');
    if (!tab) throw new Error('datatoolタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ① 商品別売上 失敗分再取得');
    return await runOnTab(tab.id, 'itemSalesDownloader', {
      startDate, endDate, period: 'daily', device: 'all', tax: 'incl', interval: 3, daysOverride: days
    });
  }
  if (task.kind === 'rppAll') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全ての広告 失敗分再取得');
    return await runOnTab(tab.id, 'rppAllDownloader', {
      startDate, endDate, interval: 3, daysOverride: days
    });
  }
  if (task.kind === 'rppItem') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全商品レポート 失敗分再取得');
    return await runOnTab(tab.id, 'rppAsyncDownloader', {
      startDate, endDate, timeout: 30, selectionType: 3, reportType: 4,
      panelPrefix: 'rppItem', reportName: '全商品レポート', daysOverride: days
    });
  }
  if (task.kind === 'rppKw') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/rpp', 'https://ad.rms.rakuten.co.jp/rpp/reports');
    if (!tab) throw new Error('rppタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ② 全KWレポート 失敗分再取得');
    return await runOnTab(tab.id, 'rppAsyncDownloader', {
      startDate, endDate, timeout: 30, selectionType: 4, reportType: 3,
      panelPrefix: 'rppKw', reportName: '全キーワードレポート', daysOverride: days
    });
  }
  if (task.kind === 'cpnItem') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/cpnadv/performance_reports', 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports');
    if (!tab) throw new Error('cpnadvタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ③ クーポン商品別 失敗分再取得');
    return await runOnTab(tab.id, 'cpnadvAsyncDownloader', {
      startDate, endDate, mode: 'item', interval: 3, timeout: 30, daysOverride: days
    });
  }
  if (task.kind === 'cpnKw') {
    const tab = await getOrCreateTab('ad.rms.rakuten.co.jp/cpnadv/performance_reports', 'https://ad.rms.rakuten.co.jp/cpnadv/performance_reports');
    if (!tab) throw new Error('cpnadvタブ取得失敗');
    await installOverlayOnTab(tab.id, '🛒 ③ クーポンKW別 失敗分再取得');
    return await runOnTab(tab.id, 'cpnadvAsyncDownloader', {
      startDate, endDate, mode: 'keyword', interval: 3, timeout: 30, daysOverride: days
    });
  }
  return { ok: false, error: `未知のkind: ${task.kind}` };
}

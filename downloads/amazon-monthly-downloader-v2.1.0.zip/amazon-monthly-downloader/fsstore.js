// 保存先フォルダ(File System Access API)の管理。
// popup / folder ページ / Service Worker の全部から使う。
// フォルダのハンドルは拡張の IndexedDB に保存する。
self.AMZ_FS = (() => {
  const DB = 'amz_fs';
  const STORE = 'handles';
  const KEY = 'root';

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function getRoot() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).get(KEY);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
  }

  async function setRoot(handle) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(handle, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // { state: 'none' | 'granted' | 'prompt' | 'denied', name }
  async function status() {
    const h = await getRoot();
    if (!h) return { state: 'none' };
    let state = 'prompt';
    try { state = await h.queryPermission({ mode: 'readwrite' }); } catch (e) { /* noop */ }
    return { state, name: h.name };
  }

  // ユーザー操作の中から呼ぶ(ページ側専用)
  async function requestPermission() {
    const h = await getRoot();
    if (!h) return 'none';
    return h.requestPermission({ mode: 'readwrite' });
  }

  // root/サブフォルダ/ファイル名 に書き込む(同名は上書き)
  async function writeFile(subdir, filename, data) {
    const root = await getRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');
    const perm = await root.queryPermission({ mode: 'readwrite' });
    if (perm !== 'granted') throw new Error('保存先フォルダへの書き込み許可が切れています(ポップアップの「保存先を許可」を押してください)');
    const dir = subdir ? await root.getDirectoryHandle(subdir, { create: true }) : root;
    const fh = await dir.getFileHandle(filename, { create: true });
    const w = await fh.createWritable();
    try {
      await w.write(data);
      await w.close();
    } catch (e) {
      try { await w.abort(); } catch (_) { /* noop */ }
      throw e;
    }
    return `${root.name}/${subdir ? subdir + '/' : ''}${filename}`;
  }

  return { getRoot, setRoot, status, requestPermission, writeFile };
})();

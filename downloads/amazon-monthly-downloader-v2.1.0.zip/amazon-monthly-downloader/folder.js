const $ = (id) => document.getElementById(id);
const STATE_LABEL = { none: '未設定', granted: '保存できます', prompt: '許可が必要です', denied: '許可されていません' };

function say(text, cls) {
  $('msg').textContent = text;
  $('msg').className = cls || '';
}

async function render() {
  const st = await AMZ_FS.status();
  $('name').textContent = st.name || '未設定';
  $('state').textContent = STATE_LABEL[st.state] || st.state;
  $('state').className = 'state ' + st.state;
  $('permit').style.display = st.state === 'prompt' || st.state === 'denied' ? '' : 'none';
  chrome.storage.local.set({ amz_fs_state: { state: st.state, name: st.name || '', at: Date.now() } });
}

$('pick').addEventListener('click', async () => {
  try {
    const h = await window.showDirectoryPicker({ id: 'amz-monthly-reports', mode: 'readwrite' });
    await AMZ_FS.setRoot(h);
    let p = await h.queryPermission({ mode: 'readwrite' });
    if (p !== 'granted') p = await h.requestPermission({ mode: 'readwrite' });
    say(p === 'granted' ? `「${h.name}」に保存するよう設定しました` : '書き込みが許可されませんでした', p === 'granted' ? 'ok' : 'err');
  } catch (e) {
    if (e && e.name === 'AbortError') say('');
    else say('設定できませんでした: ' + (e && e.message), 'err');
  }
  render();
});

$('permit').addEventListener('click', async () => {
  try {
    const p = await AMZ_FS.requestPermission();
    say(p === 'granted' ? '保存を許可しました' : '許可されませんでした', p === 'granted' ? 'ok' : 'err');
  } catch (e) {
    say('許可できませんでした: ' + (e && e.message), 'err');
  }
  render();
});

render();

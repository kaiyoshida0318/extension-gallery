// =========================================================
// ChatGPTのページ上で動く本体スクリプト
// =========================================================

let running = false;       // 稼働中フラグ
let current = 0;           // 現在の回数
let total = 0;             // 目標回数

// ---- 設定（ChatGPTのUIが変わったらここを直す） ----
const SELECTORS = {
  // 入力欄（ProseMirrorのcontenteditable、無ければtextarea）
  editor: ['#prompt-textarea', 'div[contenteditable="true"]', 'textarea'],
  // 送信ボタン
  send: ['button[data-testid="send-button"]', '#composer-submit-button', 'button[aria-label*="送信"]', 'button[aria-label*="Send"]'],
  // 停止ボタン（出ている＝生成中の合図）
  stop: ['button[data-testid="stop-button"]', 'button[aria-label*="停止"]', 'button[aria-label*="Stop"]']
};

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function pick(list) {
  for (const sel of list) {
    const el = document.querySelector(sel);
    if (el) return el;
  }
  return null;
}

function isGenerating() {
  return !!pick(SELECTORS.stop);
}

// 入力欄に文章をセット
function setPromptText(text) {
  const el = pick(SELECTORS.editor);
  if (!el) return false;
  el.focus();

  if (el.tagName === 'TEXTAREA') {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  } else {
    // contenteditable（ProseMirror）の場合
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    document.execCommand('insertText', false, text);
  }
  return true;
}

// 送信
function clickSend() {
  const btn = pick(SELECTORS.send);
  if (btn && !btn.disabled) {
    btn.click();
    return true;
  }
  // ボタンが見つからなければEnterで送信を試みる
  const el = pick(SELECTORS.editor);
  if (el) {
    el.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
    }));
    return true;
  }
  return false;
}

// 生成が「始まる」のを待つ（最大15秒）
async function waitUntilGenerating(timeout = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (!running) return;
    if (isGenerating()) return;
    await sleep(300);
  }
}

// 生成が「終わる」のを待つ（最大5分）
async function waitUntilIdle(timeout = 300000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    if (!running) return;
    if (!isGenerating()) {
      // 一瞬止まって見えることがあるので、少し待って再確認
      await sleep(1000);
      if (!isGenerating()) return;
    }
    await sleep(500);
  }
}

function report() {
  chrome.runtime.sendMessage({
    type: 'status',
    running,
    current,
    total
  }).catch(() => {});
}

async function runLoop(text, repeat, settleMs) {
  running = true;
  total = repeat;
  current = 0;
  report();

  // 開始時点でまだ生成中なら、それが終わるのを待つ
  await waitUntilIdle();

  for (let i = 0; i < repeat; i++) {
    if (!running) break;

    setPromptText(text);
    await sleep(400);          // 入力反映待ち
    if (!running) break;

    clickSend();
    current = i + 1;
    report();

    await waitUntilGenerating(); // 生成が始まるのを待つ
    await waitUntilIdle();       // 生成が終わるのを待つ
    await sleep(settleMs);       // 画像描画などの余裕（追加待機）
  }

  running = false;
  report();
}

// ポップアップからの指示を受け取る
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'start') {
    if (!running) {
      runLoop(msg.text, msg.repeat, msg.settleMs);
    }
    sendResponse({ ok: true });
  } else if (msg.type === 'stop') {
    running = false;
    report();
    sendResponse({ ok: true });
  } else if (msg.type === 'getStatus') {
    sendResponse({ running, current, total });
  }
  return true;
});

const textEl = document.getElementById('text');
const repeatEl = document.getElementById('repeat');
const settleEl = document.getElementById('settle');
const onoff = document.getElementById('onoff');
const statusEl = document.getElementById('status');

// 設定の復元
chrome.storage.local.get(['text', 'repeat', 'settle'], (d) => {
  if (d.text != null) textEl.value = d.text;
  if (d.repeat != null) repeatEl.value = d.repeat;
  if (d.settle != null) settleEl.value = d.settle;
});

function saveSettings() {
  chrome.storage.local.set({
    text: textEl.value,
    repeat: repeatEl.value,
    settle: settleEl.value
  });
}
[textEl, repeatEl, settleEl].forEach(el => el.addEventListener('input', saveSettings));

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setStatus(s) { statusEl.textContent = s; }

// 現在の稼働状態を取得して表示を合わせる
async function refresh() {
  const tab = await getActiveTab();
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'getStatus' });
    if (res && res.running) {
      onoff.checked = true;
      setStatus(`稼働中… ${res.current} / ${res.total} 回`);
    } else {
      onoff.checked = false;
      setStatus('停止中');
    }
  } catch {
    setStatus('このタブはChatGPTではありません');
  }
}
refresh();

onoff.addEventListener('change', async () => {
  const tab = await getActiveTab();
  if (onoff.checked) {
    const repeat = Math.max(1, parseInt(repeatEl.value, 10) || 1);
    const settleMs = (parseFloat(settleEl.value) || 0) * 1000;
    const text = textEl.value;
    if (!text.trim()) {
      setStatus('文章を入力してください');
      onoff.checked = false;
      return;
    }
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'start', text, repeat, settleMs });
      setStatus('開始しました');
    } catch {
      setStatus('ChatGPTのタブを開いてから実行してください');
      onoff.checked = false;
    }
  } else {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'stop' });
      setStatus('停止しました');
    } catch {}
  }
});

// content側からの状況更新を受信
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'status') {
    onoff.checked = msg.running;
    if (msg.running) {
      setStatus(`稼働中… ${msg.current} / ${msg.total} 回`);
    } else {
      setStatus(msg.current >= msg.total && msg.total > 0 ? '完了しました' : '停止中');
    }
  }
});

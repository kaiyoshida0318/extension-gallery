// ================================================================
// 保存先フォルダ (File System Access API) の管理。
// 画面 (popup / folder.html) / Service Worker (background) の
// どちらからでも使えるように self.AMZ_FS に露出する。
//
// このツール (rpp-downloader / 楽天RMS一括DL) 固有の変更:
//   - DB名: 'rakuten_fetch_fs'  (amazon-downloader の 'amz_suite_fs' とは別物)
//
// 設計は amazon-downloader v2.12.15 の fsstore.js と同じ。
// folder.html / folder.js とセットで動く。
// ================================================================
self.AMZ_FS = (() => {
  const DB = 'rakuten_fetch_fs';   // ★このツール用のDB名(amazon-downloaderとは別物)
  const STORE = 'handles';
  const KEY = 'root';

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function getRoot() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).get(KEY);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
  }
  async function setRoot(handle) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(handle, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  // { state: 'none' | 'granted' | 'prompt' | 'denied', name? }
  async function status() {
    const h = await getRoot();
    if (!h) return { state: 'none' };
    let state = 'prompt';
    try { state = await h.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    return { state, name: h.name };
  }
  // ユーザー操作の中から呼ぶ (画面側専用。Service Worker では使えない)
  async function requestPermission() {
    const h = await getRoot();
    if (!h) return 'none';
    return h.requestPermission({ mode: 'readwrite' });
  }
  // root/サブフォルダ(多階層可)/ファイル名 に書き込む (同名は上書き)
  async function writeFile(subdir, filename, data) {
    const root = await getRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');
    let perm = 'prompt';
    try { perm = await root.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    if (perm !== 'granted') throw new Error('保存先フォルダへの書き込み許可が切れています(保存先を選び直してください)');

    const parts = (subdir || '').split('/').map((s) => s.trim()).filter(Boolean);
    let dir = root, made = [];
    try {
      for (const p of parts) { dir = await dir.getDirectoryHandle(p, { create: true }); made.push(p); }
    } catch (e) {
      dir = root; made = [];   // サブフォルダ作成に失敗したら保存先直下に保存
    }
    // v6.0.2: 書き込み失敗で 0バイトのファイルが残る問題の対策
    //  - 失敗したら最大3回までやり直す(Dropbox 等の同期ソフトが一瞬ファイルを掴むことがある)
    //  - 書き終わったらサイズを確認し、期待値と違えばやり直す
    //  - 最後まで失敗したら、今回新しく作ったファイルは消す(空ファイルを残さない)
    const expected = byteLength(data);
    let existed = false;
    try { await dir.getFileHandle(filename, { create: false }); existed = true; } catch (_) {}
    let fh;
    try {
      fh = await dir.getFileHandle(filename, { create: true });
    } catch (e) {
      throw new Error(`ファイル作成に失敗(${e.name}: ${e.message})。保存先フォルダが移動/削除された可能性があります。保存先を選び直してください`);
    }
    let lastErr = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      let w = null;
      try {
        w = await fh.createWritable();
        await w.write(data);
        await w.close();
        w = null;
        const size = (await fh.getFile()).size;
        if (expected != null && size !== expected) {
          throw new Error(`サイズ不一致(書いた=${size} / 期待=${expected})`);
        }
        return `${root.name}/${made.length ? made.join('/') + '/' : ''}${filename}`;
      } catch (e) {
        if (w) { try { await w.abort(); } catch (_) {} }
        lastErr = e;
        if (attempt < 3) await new Promise((r) => setTimeout(r, 500 * attempt));
      }
    }
    if (!existed) { try { await dir.removeEntry(filename); } catch (_) {} }
    throw new Error(`書き込みに失敗(3回試行: ${lastErr?.name || ''} ${lastErr?.message || ''})`);
  }
  function byteLength(data) {
    if (data == null) return null;
    if (typeof data === 'string') return new TextEncoder().encode(data).length;
    if (data instanceof Blob) return data.size;
    if (data.byteLength != null) return data.byteLength;
    return null;
  }
  // ファイルがもし存在していたら上書きしない(uniquify 版)
  // ADcheck取り込み用フォルダで同名ファイル検出時に _(2) を付けるのに使う想定だが、
  // 現状の仕様では取得日時サフィックスで事実上一意なので使わない。
  async function fileExists(subdir, filename) {
    const root = await getRoot();
    if (!root) return false;
    const parts = (subdir || '').split('/').map((s) => s.trim()).filter(Boolean);
    let dir = root;
    try {
      for (const p of parts) { dir = await dir.getDirectoryHandle(p, { create: false }); }
    } catch (_) { return false; }
    try {
      await dir.getFileHandle(filename, { create: false });
      return true;
    } catch (_) { return false; }
  }
  return { getRoot, setRoot, status, requestPermission, writeFile, fileExists };
})();

# RMS一括ダウンローダー 引き継ぎドキュメント

**最終更新**: 2026-11-11
**現バージョン**: v6.0.7
**プロジェクト名**: rpp-downloader (ディレクトリ名もこれ)
**フォルダ名・zip名のルール**: zipの中身(拡張が入るフォルダ)は必ず `rpp-downloader/` で統一し、バージョン番号やサフィックスを付けない。配布zipの名前はバージョン付きでよい (例: `rpp-downloader-v6.0.2.zip`)。バージョンは manifest.json で管理する
**拡張の表示名**: RMS一括ダウンローダー

---

## 1. プロジェクト概要

### これは何か
Chrome拡張 (Manifest V3)。**楽天RMS** の各種レポートを「指定した期間について1日=1ファイル」でまとめてダウンロードする。
取得したファイルは **File System Access API** でユーザーが選んだフォルダに直接書き込む (v6.0.0〜)。

### 誰が使っているか
- **ゆかい屋** (shopName=`yukaiya`) と **KAIRY** (shopName=`kai-ry`) という2つの楽天ショップで利用中
- ただし **ショップごとに別の Chrome プロファイル** を立てて分離運用しているので、拡張そのものはショップ切替機能を持っていない
- (過去にショップ切替ドロップダウンを提案したが、ユーザーが分離運用で十分と判断した経緯あり)

### 取得したファイルの行き先
`ADcheck` という外部ツール(楽天・Yahoo広告の分析ツール)に取り込む。
ADcheck は **Shift_JIS CSV** をそのまま読むので、BOM追加・文字コード変換・zip展開は一切してはいけない。

---

## 2. 取得対象のレポート (7種類)

| ① 期間指定DL | 画面 | ファイル名 (v6.0.0時点) |
|---|---|---|
| 商品別売上 | datatool.rms.rakuten.co.jp/realtime/item | `YYYYMMDD_Item_SalesList.csv` (UTF-8 BOM) |
| 全ての広告 (RPP) | ad.rms.rakuten.co.jp/rpp/reports | `rpp_reports_yukaiya_YYYYMMDD.csv` (Shift_JIS) |
| 全商品レポート (RPP) | 同上 | `rpp_item_reports_yukaiya_YYYYMMDD.zip` (中にCSV) |
| 全キーワードレポート (RPP) | 同上 | `rpp_keyword_reports_yukaiya_YYYYMMDD.zip` |
| クーポン広告 商品別 (CPA) | ad.rms.rakuten.co.jp/cpnadv/performance_reports | `CouponAdvance_yukaiya_item_YYYYMMDD.zip` |
| クーポン広告 KW別 (CPA) | 同上 | `CouponAdvance_yukaiya_kw_YYYYMMDD.zip` |

| ④ スナップショット (1回/実行) | | |
|---|---|---|
| 登録済みKW全件 | ad.rms.rakuten.co.jp/rpp/items | `rpp_item_keyword_yukaiya_YYYYMMDD.csv` |

- ①〜③ は「実行日の **前日〜31日前** の31日分」を自動で取得する (v6.0.7〜。以前は30日前まで)。
- 31日前までにしている理由: RPPの720時間の売上はクリック日に計上され、D日の数字が出そろうのは D+31日以降。毎日31日前まで取り直すと、一番古い日が「出そろった数字」で月別フォルダに上書きされる。
- ④ は「実行日=当日時点」のスナップショットなので、1実行で1ファイル。
- `YYYYMMDD` は **データの日付** (集計対象日) であって取得日ではない。
- ADcheck取り込み用フォルダには、これに加えて `_getYYYYMMDD-HHMM` の取得日時サフィックスが入る。

---

## 3. 現在の保存先アーキテクチャ (v6.0.0)

### 流れ
```
injected.js (page context の downloader)
  ↓ blob 完成
  saveViaBackground(blob, {filename, day, kind, isSnapshot})
  ↓ Uint8Array → Array.from → chrome.runtime.sendMessage
  ↓ type:'save-file', payload:{filename, day, kind, isSnapshot, dataArr, mimeType}
  ↓
background.js handleSaveFile
  ↓ AMZ_FS.status() 確認 → granted
  ↓ new Uint8Array(dataArr) でバイト列復元
  ├→ AMZ_FS.writeFile('YYYY-MM-RPP', stripGetSuffix(filename), bytes)   # 月別、上書き
  └→ AMZ_FS.writeFile('ADcheck取り込み用', insertGetSuffix(filename, ts), bytes)
```

### 保存先フォルダの構造
```
{ユーザーが選んだフォルダ}/
  2026-10-CPA/             # CouponAdvance (item + kw)
    CouponAdvance_yukaiya_item_20261001.zip
    CouponAdvance_yukaiya_item_20261002.zip
    ...
    CouponAdvance_yukaiya_kw_20261001.zip
    ...
  2026-10-RPP/             # rpp_reports / rpp_item / rpp_keyword / Item_SalesList
    rpp_reports_yukaiya_20261001.csv
    rpp_item_reports_yukaiya_20261001.zip
    rpp_keyword_reports_yukaiya_20261001.zip
    20261001_Item_SalesList.csv
    ...
  2026-11-CPA/             # 月をまたぐ分は自動で別フォルダへ
  2026-11-RPP/
  ADcheck取り込み用/        # 全ファイルを取得日時サフィックス付きで保存
    rpp_reports_yukaiya_20261001_get20261111-1340.csv
    ...
    rpp_item_keyword_yukaiya_20261111_get20261111-1345.csv   # ④のスナップショットもここだけ
```

### 月別フォルダの振り分けロジック
`handleSaveFile` が呼ばれるときの引数 `day` と `kind` で決まる:
- `day`: `'2026-10-15'` → slice(0,7) で `'2026-10'`
- `kind`: `'CPA'` (CouponAdvance) or `'RPP'` (それ以外) or snapshot
- snapshot は `isSnapshot:true` + `day:null` + `kind:null` で来るので、月別には書かない

kind の決定は各 downloader 側で既にハードコードされている:
- `CouponAdvance_*` → `kind:'CPA'`
- それ以外 → `kind:'RPP'`

### 日時サフィックス処理
```js
// _getYYYYMMDD-HHMM を除去
function stripGetSuffix(filename) {
  return filename.replace(/_get\d{8}-\d{4}/, '');
}
// 拡張子前に _get を挿入
function insertGetSuffix(filename, ts) {
  const dotIdx = filename.lastIndexOf('.');
  if (dotIdx < 0) return `${filename}_get${ts}`;
  return `${filename.slice(0, dotIdx)}_get${ts}${filename.slice(dotIdx)}`;
}
```

---

## 4. バージョン履歴 (直近の大きな変更)

### v6.0.7 (2026-11-11) — 【直近】
- 自動セットを「前日〜31日前」に変更 (RPP 720時間の数字が出そろった日まで取るため)

### v6.0.6 (2026-11-11)
- 取得中にタブ(ウィンドウ)が閉じられたら、②③の残りの手順も止める (以前は新しいタブで続行 → やり直すと2本同時に動き、取り込み用に重複)
- 同じ取得の二重起動を防止 (2本目は ⛔ で断る)

### v6.0.5 (2026-11-11)
- 止まったジョブが popup に「実行中/中止中」のまま残る問題の修正 (中止後90秒進捗なしで片付け、拡張の更新時にも片付け)

### v6.0.4 (2026-11-11)
- 取得中の楽天のタブが閉じられたら検知して中断・通知 (以前は popup が「実行中」のまま止まって見えた)
- 楽天のタブの進捗表示に「このタブは閉じないでください」

### v6.0.3 (2026-11-11)
- HTTPエラー時に楽天の応答本文をログに残す (`httpError`)。全KWの 10/16・10/17 だけ downloadAsync が HTTP 400 になる件の調査用 (原因は未確定)

### v6.0.2 (2026-11-11)
**取り込み用に 0バイトのファイルが残る問題の修正** (詳細は CHANGES_v6.md 先頭)
- `writeFile` を3回までやり直し、サイズを確認し、失敗したら空ファイルを消す
- 月別・取り込み用のどちらか一方でも失敗したら、その日を失敗扱いにする (以前は片方成功で ✅ になっていた)

### v6.0.1 (2026-11-11)
**取得途中で「要許可」になって保存スキップされる問題の修正** (詳細は CHANGES_v6.md 先頭)
- 原因: Chrome は拡張のページが全部閉じて約5秒後に書き込み許可を取り消す。v6.0.0 は folder.html に「閉じてOK」と出していた
- 取得開始時に folder.html をピン留めで確保 (`ensureFolderTab`)
- 途中で許可が切れたら一時停止 → 通知 → 「🔑 許可」で続きから再開 (`waitForGrant`, 最大4分)

### v6.0.0 (2026-11-11)
**File System Access API に切り替え**
- 旧: `chrome.downloads.download` + Offscreen で blob URL生成 + `onDeterminingFilename` でファイル名強制
- 新: `fsstore.js` (AMZ_FS) でユーザー選択フォルダに直接書き込み
- offscreen.html / offscreen.js を削除
- manifest から `downloads` / `offscreen` パーミッションを削除
- popup上部にフォルダ状態行を追加 (未設定/要許可/granted)
- ①〜④ボタン押下時に `ensureFsGranted()` で事前チェック

### v5.14.3 (2026-11-11) — 1つ前
- `onDeterminingFilename` イベントでファイル名を強制上書きする方式 (日本語パス対応)
- 保存先: `Downloads/楽天RMS/{YYYY-MM-CPA|RPP}/` と `Downloads/楽天RMS/ADcheck取り込み用/`

### v5.14.2
- Offscreen Document を使って Service Worker から blob URL を作る (SW で `URL.createObjectURL` が使えない問題対応)

### v5.14.1
- data URL 方式 (Chrome がファイル名を無視する問題で頓挫)

### v5.13.0
- `URL.createObjectURL is not a function` エラーでDL失敗 → Offscreen方式へ

### v5.12.x
- 30日ローリングウィンドウ化 (前日〜30日前を自動セット)
- 完了時 `chrome.notifications` デスクトップ通知
- popup上部に「Chromeの『ダウンロード前に保存場所を確認』をOFFにする」ヒント

### v5.12.7
- **cpnadv API 403** エラー対応: X-XSRF-TOKEN ヘッダを cookie から抽出して付与

### v5.12.0 頃
- **cpnadv API migration**: 2026年10月に楽天がクーポン広告ページを AngularJS → React SPA に移行
  - 旧エンドポイント `/cpnadv/performance_reports/download` (form-urlencoded) → HTTP 405
  - 新エンドポイント `/cpnadv/api/downloads` (JSON + XSRF-TOKEN)
  - payload構造の変更:
    - `selectionType: 3/4` (数値) → `"ITEMS"/"KEYWORDS"` (文字列)
    - `periodType: 3` (数値) → `"SELECTED"` (文字列)
    - 構造: `{feature: '...', reportPayload: {...}}`
  - 非同期ジョブ方式: POST → jobId取得 → polling → GET `/cpnadv/api/downloads/report?jobId=XXX`

### v5.11.x
- ④ 登録済みKW全件DL (スナップショット) ボタン追加
- セクション分割: 上部「期間指定DL」/ 下部「④」で色分け (黄色)
- ①②③④ 完了マーカー (丸にチェック、日付変更でリセット)

### v5.10.x
- 「対象データなし」判定: 3回リトライで全部status=500ならnoDataとして ⚪ グレーマーク

### v5.9.x
- 「♻ 失敗分を再取得」ボタン追加
- 日付保存/固定ロック機能

### v5.8 以前
- RPP 3種連続DL
- クーポン広告 2種連続DL
- 進捗表示オーバーレイ + ⏹中止ボタン
- DL履歴 (chrome.storage.local に50件)

---

## 5. ファイル構成 (現在)

```
rpp-downloader/
  manifest.json           # v6.0.0, permissions: activeTab/scripting/tabs/storage/notifications
  background.js           # Service Worker。importScripts('fsstore.js') で AMZ_FS 使用
  injected.js             # page context に注入する downloader 群
  popup.html              # UI
  popup.js                # popup のロジック
  fsstore.js              # self.AMZ_FS。File System Access API のラッパ (DB名: rakuten_fetch_fs)
  folder.html             # 保存先フォルダ設定ページ (タブで開く)
  folder.js               # 設定ページのロジック (ピッカーID: rakuten-fetch-data)
  icons/
    icon16.png, icon48.png, icon128.png
  README.md
  CHANGES_v6.md           # v6.0.0 の変更詳細
  HANDOFF.md              # このファイル
```

### 削除したファイル (履歴として)
- `offscreen.html`, `offscreen.js` — v5.14.2〜v5.14.3 で使用。v6.0.0 で不要になった

---

## 6. 重要なコード箇所

### background.js の主要関数
- `handleSaveFile(payload)`: ファイル保存の心臓部。v6.0.0 で `AMZ_FS.writeFile` を2回呼ぶ形に書き換え済み
- `handleItemSales(payload)`: ①
- `handleBulkRpp3(payload)`: ②
- `handleCpn(payload)`: ③の単発
- `handleBulkCpn2(payload)`: ③の連続
- `handleRetryFailed(tasks)`: ♻失敗分再取得
- `handleRppKwSnapshot(payload)`: ④
- `notify(title, message, kind)`: `chrome.notifications` で完了通知
- `getOrCreateTab(urlMatch, ensureUrl)`: 該当URLのタブを探す or 新規作成
- `runOnTab(tabId, funcName, params)`: injected.js を注入して関数を呼ぶ
- メッセージハンドラ: `fs-status` / `run-bulk-rpp3` / `run-itemsales` / `run-cpn` / `run-bulk-cpn2` / `run-retry-failed` / `run-rpp-kw-snapshot` / `save-file`

### injected.js の主要関数 (page context)
- `saveViaBackground(blob, opts)`: blob → ArrayBuffer → Array化 → sendMessage
- `rppAllDownloader(params)`: ②全ての広告 (sync、/rpp/performance_reports のCSV直接DL)
- `rppAsyncDownloader(params)`: ②全商品/全KW (async job、POST→poll→GET)
- `itemSalesDownloader(params)`: ①商品別売上 (datatool のCSV直接DL)
- `cpnadvAsyncDownloader(params)`: ③クーポン広告 (v5.12 以降の新API対応)
- `rppKeywordSnapshotDownloader(params)`: ④登録済みKW全件 (ZIPダウンロード)
- `installProgressOverlay(title)`: 進捗オーバーレイ
- `markDay(jobId, day, status)`: マス目表示更新
- `recordDailyHistory(entry)`: DL履歴に1件追加

### popup.js の構成
- 完了マーカー (DONE_KEY = 'rms_done_flags')
- ログシステム (LOG_KEY = 'rms_dl_logs', 最大2000件)
- 失敗エントリ集計 (`aggregateFailures`) + `♻失敗分を再取得` ボタン
- 進行中ジョブ表示 (`renderActiveJob`) + `⏹ 中止` ボタン
- 日付保存/固定 (`bulk-savedate`, `bulk-cleardate`)
- 保存先フォルダ ステータス行 + `ensureFsGranted()` 事前チェック
- 必要なページを一括オープン (`bulk-open`)
- ①②③④ ボタンハンドラ
- 通知ON/OFF トグル
- DL履歴表示

### fsstore.js の API
```js
self.AMZ_FS = {
  getRoot(): Promise<FileSystemDirectoryHandle | null>
  setRoot(handle): Promise<void>
  status(): Promise<{state: 'none'|'granted'|'prompt'|'denied', name?: string}>
  requestPermission(): Promise<'granted'|'prompt'|'denied'|'none'>   // 画面側専用
  writeFile(subdir, filename, data): Promise<string>                  // path文字列を返す
  fileExists(subdir, filename): Promise<boolean>
}
```
- DB名: `rakuten_fetch_fs` (amazon-downloader の `amz_suite_fs` とは別)
- データはUint8Array / Blob / 文字列を受け付ける
- SWから `requestPermission` は呼べない (ユーザー操作内でしか呼べない制約)

---

## 7. storage のキー一覧 (chrome.storage.local)

| キー | 内容 |
|---|---|
| `rms_dl_logs` | ログ (最大2000件) |
| `rms_dl_history` | DL履歴 (最大50件) |
| `rms_done_flags` | 完了マーカー `{is, rpp, cpn, snap}` |
| `rms_cancel_flag` | ⏹中止フラグ |
| `rms_cancel_at` | 中止ボタンを押した時刻 (v6.0.5〜、止まったジョブの判定用) |
| `rms_active_job` | 進行中ジョブ情報 |
| `rms_notify_enabled` | 通知ON/OFF (true/false) |
| `rms_fs_state` | 保存先の状態 ('granted'/'prompt'/'denied'/'none') — folder.js が書く |
| `rms_fs_name` | 保存先フォルダ名 — folder.js が書く |
| `rms_date_locked` | 日付固定の有効/無効 |
| `rms_saved_start_date`, `rms_saved_end_date` | 保存された日付 |

---

## 8. 既知の挙動・制限

### 正常動作だが見落としやすい
- **クーポン広告 (CPA) の CSV は UTF-8 (BOM付き)**: zip の中の CSV は楽天から届いた時点で UTF-8 BOM。RPP 系は Shift_JIS。拡張は変換しないので、どちらも楽天の元のまま
- **「対象データなし」**: その日に該当広告のクリックが0件だと楽天APIがstatus=500を返す。3回リトライで全部500ならnoDataとして ⚪ 扱いにしてファイルを生成しない
  - 直近の例: 11/11の取得で `CouponAdvance_kw` の 10/14, 10/20, 10/24, 10/25 の4日分がnoData
  - 履歴では ⚪ グレーマーク、エラーではない
- **休日のスナップショット**: 自動取得ツール(別運用)が休日明けに1日分だけ取ることがある。それは楽天API側の仕様で、この拡張の制御範囲外

### Chrome関連の制約
- **書き込み許可は「拡張のページ(タブ)が1つでも開いている間」だけ有効**。全部閉じると約5秒後に `prompt` に戻る。Service Worker は数に入らない → folder.html をピン留めで開いておく (v6.0.1 で自動化)
- Service Worker から `requestPermission()` は呼べない → 必ず popup か folder.html 経由
- Chrome再起動後は permission が 'prompt' に戻ることがある → ユーザーが folder.html で「許可」を1回押す
- 「ダウンロード」フォルダ直下やデスクトップは Chrome が選ばせないことがある
- 拡張を削除して入れ直すと IndexedDB が消えて保存先未設定に戻る

### まだ入っていない機能
- 各 downloader の戻り値に `noData` カウントが入っていない (履歴にはあるが通知サマリに出ない)
- 保存成功/失敗の月別・取り込み用の件数を通知に詳細表示する機能
- ADcheck取り込み用フォルダの自動掃除 (手で空にする運用)
- ショップ切替ドロップダウン (ユーザーが別Chromeプロファイルでの分離運用を選択)

---

## 9. ユーザーとの運用取り決め

### 毎日の運用フロー (ユーザー側)
1. 午前中に拡張アイコンをクリック
2. 「📅 前日〜31日前を自動セット」ボタン
3. 「🔗 必要なページを一括オープン」ボタン
4. 楽天RMSに未ログインなら各ページでログイン
5. 「① 商品別売上 DL開始」 → 完了通知を待つ
6. 「② RPP 3種 連続DL」 → 完了通知を待つ
7. 「③ クーポン広告 2種 連続DL」 → 完了通知を待つ
8. 「④ 登録済みKW 全件DL」 → 完了通知を待つ
9. ADcheck取り込み用フォルダの中身をADcheckに取り込む → フォルダを空にする
10. (月別フォルダは保管用なのでそのまま放置)

### 初回セットアップ
1. zipを `chrome://extensions/` で読み込み (デベロッパーモードON)
2. 拡張アイコン → popup 上部「保存先: 未設定」の「設定」ボタン
3. folder.html でフォルダを選ぶ (例: `ダウンロード/楽天データ保管`)
4. Chrome の許可ダイアログで「許可」
5. popup に戻ると緑で表示される

### Chrome再起動後
- popup を開くと「保存先: 要許可」の黄色警告が出る
- 「許可」ボタンを押すと folder.html が開く → 「🔑 このフォルダへの保存を許可」をクリック

---

## 10. 新チャットで最初に確認しておくこと

1. **現バージョン**: zipの `manifest.json` を見て `v6.0.0` (以降) か確認
2. **保存方式**: File System Access API (fsstore.js) か、chrome.downloads か
3. **Rakuten API の変化**: cpnadv API がまた変わってないか (過去にReactに移行済み)
4. **ユーザーの最新の要望**: 直近は「保存先フォルダに直接書き込み」で完了済み

### 類似の兄弟プロジェクト
- **amazon-downloader** (v2.12.15): fsstore.js の元ネタ。Amazon出品者レポート用。同じユーザー所有だが別のChrome拡張
- **yahoo-downloader**: Yahoo!ショッピング版の似たツール (過去に仕様書HANDOFF-yahoo.mdを作成した)

---

## 11. プロジェクト固有の文脈

### ユーザーの呼称・好み
- ユーザー: `kaiyoshida0318@gmail.com` (@KAI と署名している)
- 口調: カジュアルな日本語、技術的詳細はストレートに言う
- フォーマット: 絵文字OK、コードブロックOK
- ショップ名: `yukaiya` (ゆかい屋) と `kai-ry` (KAIRY) の2ショップ運用

### 過去の意思決定
- **A. 拡張の名前は "RMS一括ダウンローダー"** (yahoo-downloader-ゆかい屋 等は却下)
- **①の filename `20260101_Item_SalesList.csv` にショップ名プレフィックスを付けない** (他の付けると後方互換性崩れる懸念で却下)
- **ショップ切替ドロップダウンは入れない** (分離運用で十分と判断)
- **保存はダウンロードフォルダではなくユーザー指定フォルダ** (v6.0.0 で実現)

---

## 12. 新チャットへの引き継ぎ要旨 (1段落版)

> これは楽天RMS (ad.rms.rakuten.co.jp, datatool.rms.rakuten.co.jp) の各種レポートを1日1ファイル・前日〜31日前の31日分で一括取得するChrome拡張 (Manifest V3)。ユーザーは `yukaiya` と `kai-ry` の2つの楽天ショップで別Chromeプロファイルで分離運用している。v6.0.0 で保存方式を `chrome.downloads` から File System Access API (`fsstore.js` の `AMZ_FS`) に切り替え済み。保存先は (1) `{選んだフォルダ}/YYYY-MM-{CPA|RPP}/` に `_get` なしで上書き保管、(2) `{選んだフォルダ}/ADcheck取り込み用/` に `_getYYYYMMDD-HHMM` 付きで全保存 (ADcheck外部ツールに取り込む用、ユーザーが取り込み後に手動で空にする運用)。CSV は Shift_JIS (ADcheckが読む形) のまま触らない。クーポン広告 (cpnadv) は2026年10月に楽天がReactに移行済みで新API `/cpnadv/api/downloads` + X-XSRF-TOKEN を使う。完了時は `chrome.notifications` でデスクトップ通知。

// ================================================================
// 保存先フォルダ設定ページ用スクリプト。
// - folder.html の #name / #state / #pick / #permit / #msg を操作。
// - 選択した FileSystemDirectoryHandle を AMZ_FS.setRoot() で保存。
// - 他の画面(popup)に状態変化を知らせるため chrome.storage.local に
//   amz_fs_state (このツール固有キー: rms_fs_state) も書き込む。
// ================================================================
const $ = (id) => document.getElementById(id);
const FS_STATE_KEY = 'rms_fs_state';   // popup が購読するキー

function say(t) { $('msg').textContent = t || ''; }

async function render() {
  const st = await AMZ_FS.status();
  const nameEl = $('name'), stEl = $('state'), permit = $('permit');
  nameEl.textContent = st.name || '未設定';
  nameEl.className = 'state ' + (st.state === 'granted' ? 'ok' : st.state === 'none' ? 'none' : 'warn');
  stEl.textContent = st.state === 'granted' ? '保存できます ✅'
                   : st.state === 'none'    ? '(未設定)'
                   : '許可が必要です ⚠';
  stEl.className = 'state ' + (st.state === 'granted' ? 'ok' : st.state === 'none' ? 'none' : 'warn');
  permit.style.display = (st.state === 'prompt' || st.state === 'denied') ? 'inline-block' : 'none';

  // 他の画面(popup)に知らせる
  try { chrome.storage.local.set({ [FS_STATE_KEY]: st.state, 'rms_fs_name': st.name || '' }); } catch (_) {}
}

$('pick').addEventListener('click', async () => {
  try {
    const h = await window.showDirectoryPicker({ id: 'rakuten-fetch-data', mode: 'readwrite' });
    await AMZ_FS.setRoot(h);
    let p = await h.queryPermission({ mode: 'readwrite' });
    if (p !== 'granted') p = await h.requestPermission({ mode: 'readwrite' });
    say(p === 'granted'
      ? `「${h.name}」に保存するよう設定しました。取得が終わるまで、このタブは開いたままにしてください。`
      : '書き込みが許可されませんでした');
  } catch (e) {
    if (e.name !== 'AbortError') say('設定できませんでした: ' + e.message);
  }
  render();
});

$('permit').addEventListener('click', async () => {
  const p = await AMZ_FS.requestPermission();
  say(p === 'granted' ? '保存を許可しました。取得中なら続きから再開します。このタブは開いたままにしてください。' : '許可されませんでした');
  render();
});

render();

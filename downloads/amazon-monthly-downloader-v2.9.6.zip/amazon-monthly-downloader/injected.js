// 対象サイトのページに注入される downloader 群(ISOLATED world)
// 結果は { status: 'ok' | 'noData' | 'notReady' | 'error' | 'cancelled', message } で返す。
(() => {
  if (window.__AMZDL) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const progress = (kind, msg) => {
    try { chrome.runtime.sendMessage({ type: 'amz_progress', kind, msg }); } catch (e) { /* noop */ }
  };

  const isCancelled = async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'amz_is_cancelled' });
      return !!(r && r.cancelled);
    } catch (e) { return false; }
  };

  function monthRange(month) {
    const [y, m] = month.split('-').map(Number);
    const mm = String(m).padStart(2, '0');
    const startMs = Date.UTC(y, m - 1, 1) - 9 * 3600e3; // JST 00:00
    const nextMs = Date.UTC(y, m, 1) - 9 * 3600e3;
    const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const dd = String(last).padStart(2, '0');
    return {
      y, m, mm, last, dd,
      startMs, endMs: nextMs - 1,
      startIso: `${y}-${mm}-01`,
      endIso: `${y}-${mm}-${dd}`,
    };
  }

  function bufToBase64(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    return btoa(s);
  }

  async function saveBuffer(buf, filename, month) {
    const dataUrl = `data:text/csv;base64,${bufToBase64(buf)}`;
    const res = await chrome.runtime.sendMessage({ type: 'amz_save_data', dataUrl, filename, month });
    if (!res || !res.ok) throw new Error('保存に失敗: ' + ((res && res.error) || '不明'));
  }

  async function saveUrl(url, filename, month) {
    const res = await chrome.runtime.sendMessage({ type: 'amz_save_url', url, filename, month });
    if (!res || !res.ok) throw new Error('保存に失敗: ' + ((res && res.error) || '不明'));
  }

  function httpFail(label, status, text) {
    const t = String(text || '').slice(0, 200);
    if (status === 401 || status === 403 || /signin|ログイン/.test(t)) {
      return { status: 'error', message: `${label}: 認証エラー(${status})。ログイン状態を確認してください` };
    }
    return { status: 'error', message: `${label}: HTTP ${status} ${t}` };
  }

  // 待機中も2秒おきに中止を確認する(中止されたら CancelledError を投げる)
  class CancelledError extends Error {}
  const waitFor = async (fn, timeoutMs, interval = 300) => {
    const t0 = Date.now();
    let lastCheck = 0;
    while (Date.now() - t0 < timeoutMs) {
      if (Date.now() - lastCheck > 2000) {
        lastCheck = Date.now();
        if (await isCancelled()) throw new CancelledError('cancelled');
      }
      try { const v = fn(); if (v) return v; } catch (e) { /* noop */ }
      await sleep(interval);
    }
    return null;
  };

  // ───────────────────────── ① トランザクション(FBA手数料・販売手数料・出荷数)
  async function transaction(month) {
    const K = 'tx';
    const r = monthRange(month);
    const body = {
      accountType: 'PAYABLE',
      reportType: 'SELLER_TRANSACTION_DATE_RANGE',
      startDate: r.startMs,
      startDateISO: `${r.startIso}T00:00:00+09:00`,
      endDate: r.endMs,
      endDateISO: `${r.endIso}T23:59:59+09:00`,
      timeRangeType: 'MONTHLY',
    };
    progress(K, 'レポートをリクエスト中');
    const res = await fetch('/payments/reports/api/request-report', {
      method: 'POST',
      credentials: 'include',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (!res.ok) return httpFail('リクエスト', res.status, text);

    let j;
    try { j = JSON.parse(text); } catch (e) { return { status: 'error', message: '応答がJSONではありません(未ログインの可能性)' }; }
    const id = j.reportId || (j.generatedReport && j.generatedReport.reportId);
    if (!id) return { status: 'error', message: 'reportId が取得できませんでした' };

    let st = j.generatedReport && j.generatedReport.status;
    const t0 = Date.now();
    while (st !== 'DOWNLOADABLE') {
      if (await isCancelled()) return { status: 'cancelled' };
      if (Date.now() - t0 > 10 * 60e3) return { status: 'notReady', message: '10分待っても生成が完了しませんでした。時間をおいて再取得してください' };
      await sleep(5000);
      const lr = await fetch('/payments/reports/api/reports?sortOrderByRequestDate=DESC&resultsPerPage=50&pageNum=1', { credentials: 'include' });
      if (!lr.ok) continue;
      const lj = await lr.json().catch(() => ({}));
      const rep = (lj.reportResponse || []).find((x) => x.reportId === id);
      st = rep && rep.status;
      progress(K, `生成待ち(${st || '確認中'})${Math.round((Date.now() - t0) / 1000)}秒`);
      if (st && /NO_DATA|EMPTY/i.test(st)) return { status: 'noData', message: 'この月のトランザクションはありません' };
      if (st && /CANCEL|FAIL|FATAL|ERROR|EXPIRED/i.test(st)) return { status: 'error', message: `生成失敗(${st})` };
    }

    progress(K, 'ダウンロード中');
    const d = await fetch('/payments/reports/api/download-report?reportId=' + encodeURIComponent(id), { credentials: 'include' });
    if (!d.ok) return httpFail('ダウンロード', d.status, await d.text());
    const buf = await d.arrayBuffer();
    await saveBuffer(buf, `A-手数料・出荷数-${month}.csv`, month);
    return { status: 'ok', message: `${Math.max(1, Math.round(buf.byteLength / 1024))}KB` };
  }

  // ───────────────────────── ③ 保管費(在庫保管手数料レポート 月次)
  async function storageFee(month) {
    const K = 'storage';
    const r = monthRange(month);
    const meta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
    const tok = meta && meta.content;
    if (!tok) return { status: 'error', message: 'CSRFトークンが見つかりません(未ログイン or ページ未読込)' };
    const H = { 'anti-csrftoken-a2z': tok };

    const q = new URLSearchParams({
      reportFileFormat: 'CSV',
      reportStartDate: `${r.y}/${r.mm}/01`,
      reportEndDate: `${r.y}/${r.mm}/${r.dd}`,
      xdaysBeforeUntilToday: '-1',
      startDateTimeOffset: '0',
      endDateTimeOffset: '0',
      specialDateOptions: '',
      reportFRPId: '2673',
      language: 'ja_JP',
      disableTimezone: 'false',
    });
    progress(K, 'レポートをリクエスト中');
    const s = await fetch('/reportcentral/api/v1/submitDownloadReport?' + q.toString(), {
      method: 'POST', credentials: 'include', headers: H,
    });
    const stext = await s.text();
    if (!s.ok) return httpFail('リクエスト', s.status, stext);
    let sj;
    try { sj = JSON.parse(stext); } catch (e) { return { status: 'error', message: '応答がJSONではありません' }; }
    const ref = sj.reportReferenceId;
    if (!ref) return { status: 'error', message: 'referenceId が取得できませんでした' };

    let st = sj.reportStatus;
    const t0 = Date.now();
    while (st !== 'Done') {
      if (await isCancelled()) return { status: 'cancelled' };
      if (st === 'Cancelled') {
        // 保管手数料は翌月中旬ごろに確定する。確定前は「データはありません」になる
        const now = new Date();
        const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const prevKey = `${prev.getFullYear()}-${String(prev.getMonth() + 1).padStart(2, '0')}`;
        const curKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        if (month === curKey || (month === prevKey && now.getDate() < 25)) {
          return { status: 'notReady', message: '保管手数料は翌月中旬ごろ確定します' };
        }
        return { status: 'noData', message: 'データはありません' };
      }
      if (st && /Fatal|Fail|Error/i.test(st)) return { status: 'error', message: `生成失敗(${st})` };
      if (Date.now() - t0 > 10 * 60e3) return { status: 'notReady', message: '10分待っても生成が完了しませんでした' };
      await sleep(4000);
      const pr = await fetch('/reportcentral/api/v1/getDownloadReportStatus?referenceIds=' + encodeURIComponent(ref), { credentials: 'include', headers: H });
      if (!pr.ok) continue;
      const pj = await pr.json().catch(() => null);
      st = Array.isArray(pj) ? pj[0] : st;
      progress(K, `生成待ち(${st || '確認中'})${Math.round((Date.now() - t0) / 1000)}秒`);
    }

    progress(K, 'ダウンロード中');
    const d = await fetch(`/reportcentral/api/v1/downloadFile?referenceId=${encodeURIComponent(ref)}&fileFormat=CSV`, { credentials: 'include', headers: H });
    if (!d.ok) return httpFail('ダウンロード', d.status, await d.text());
    const buf = await d.arrayBuffer();
    await saveBuffer(buf, `C-保管費-${month}.csv`, month);
    return { status: 'ok', message: `${Math.max(1, Math.round(buf.byteLength / 1024))}KB` };
  }

  // ───────────────────────── ④ 総売上(ビジネスレポート 売上ダッシュボード)
  async function sales(month) {
    const K = 'sales';
    const r = monthRange(month);
    const body = {
      operationName: 'salesDashboardDownloadQuery',
      variables: {
        input: {
          dashboardMode: 'CUSTOM',
          breakdownType: 'MARKETPLACE_TOTAL',
          fulfillment: 'BOTH',
          fromDate: r.startIso,
          endDate: r.endIso,
          isSundayStart: false,
        },
      },
      query: 'query salesDashboardDownloadQuery($input: GetSalesDashboardDataInput) {\n  getSalesDashboardDownload(input: $input) {\n    url\n    __typename\n  }\n}\n',
    };
    progress(K, 'ダウンロードURLを取得中');
    const res = await fetch('/business-reports/api', {
      method: 'POST',
      credentials: 'include',
      headers: { 'content-type': 'application/json', accept: '*/*' },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (!res.ok) return httpFail('取得', res.status, text);
    let j;
    try { j = JSON.parse(text); } catch (e) { return { status: 'error', message: '応答がJSONではありません(未ログインの可能性)' }; }
    if (j.errors && j.errors.length) return { status: 'error', message: 'APIエラー: ' + String(j.errors[0].message || '').slice(0, 150) };
    const url = j.data && j.data.getSalesDashboardDownload && j.data.getSalesDashboardDownload.url;
    if (!url) return { status: 'error', message: 'ダウンロードURLが返りませんでした' };
    progress(K, 'ダウンロード中');
    await saveUrl(url, `D-総売上-${month}.csv`, month);
    return { status: 'ok' };
  }

  // ───────────────────────── ② 広告費・広告売上(キャンペーンマネージャーの画面操作)
  async function ads(month) {
    const K = 'ads';
    const r = monthRange(month);
    const P = 'campaignOverviewAllCampaigns';

    // エクスポートボタンは ID → data-e2e-id → 表示テキストの順で探す
    const findExport = () =>
      document.getElementById(`${P}:udm-export-dropdown`) ||
      document.querySelector('button[data-e2e-id$="udm-export-dropdown"]') ||
      [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'エクスポート' && b.getAttribute('aria-haspopup'));
    const findDateOpener = () =>
      document.getElementById(`${P}:dateRangeFilter:openContainer`) ||
      document.querySelector('button[data-e2e-id$="dateRangeFilter:openContainer"]');

    progress(K, '広告画面の読み込み待ち(最大10分)');
    const t0 = Date.now();
    const exportBtn = await waitFor(() => {
      const b = findExport();
      if (!b) {
        const sec = Math.round((Date.now() - t0) / 1000);
        const hidden = document.visibilityState === 'hidden' ? '(画面が隠れています)' : '';
        progress(K, `広告画面の読み込み待ち ${sec}秒${hidden}`);
        // 表の部分は画面に入らないと描画されないことがあるため下へスクロール
        window.scrollTo(0, document.body.scrollHeight);
      }
      return b;
    }, 600000, 2000);
    if (!exportBtn) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: '広告画面が10分たっても表示されませんでした。Chromeのウィンドウを他のアプリで隠さず、最前面にしたまま実行してください' };
    }

    // 画面に残っている絞り込みを外す(これが残っていると一部のキャンペーンしか出力されない)
    progress(K, '絞り込みを解除中');
    let cleared = [];
    const searchInput = [...document.querySelectorAll('input')].find((i) => /キャンペーンを探す/.test(i.placeholder || ''));
    if (searchInput && searchInput.value) {
      cleared.push(`検索「${searchInput.value}」`);
      setInputValue(searchInput, '');
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      searchInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
      await sleep(5000);
    }
    const clearFilters = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'すべて削除');
    if (clearFilters) {
      cleared.push('フィルター');
      clearFilters.click();
      await sleep(5000);
    }
    const allPill = [...document.querySelectorAll('[data-testid="ad-product-selector-pill"]')].find((e) => e.id === 'all');
    if (allPill && allPill.getAttribute('aria-selected') !== 'true') {
      cleared.push('広告プロダクト');
      (allPill.querySelector('button') || allPill).click();
      await sleep(5000);
    }
    if (cleared.length) progress(K, `絞り込みを解除: ${cleared.join(' / ')}`);

    // 解除しきれなかった絞り込みが残っていないか確認する
    const leftover = [];
    const si = [...document.querySelectorAll('input')].find((i) => /キャンペーンを探す/.test(i.placeholder || ''));
    if (si && si.value) leftover.push(`検索「${si.value}」`);
    const chip = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /^アクティブステータス/.test((e.textContent || '').trim()));
    if (chip) leftover.push('ステータスのフィルター');
    const pill = [...document.querySelectorAll('[data-testid="ad-product-selector-pill"]')].find((e) => e.id === 'all');
    if (pill && pill.getAttribute('aria-selected') !== 'true') leftover.push('広告プロダクトの選択');

    exportBtn.scrollIntoView({ block: 'center' });
    await sleep(500);
    const opener = await waitFor(findDateOpener, 30000);
    if (!opener) return { status: 'error', message: '日付選択ボタンが見つかりません' };

    const wantLabel = `${r.mm}/01 - ${r.y}/${r.mm}/${r.dd}`;
    const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

    if (norm(opener.textContent) !== wantLabel) {
      progress(K, `期間を ${r.startIso}〜${r.endIso} に設定中`);
      opener.click();
      const opened = await waitFor(() => document.querySelector('button[aria-label="前月に移動"]'), 30000);
      if (!opened) return { status: 'error', message: '日付ピッカーが開きませんでした' };

      const qs = (iso) => document.querySelector(`button[data-iso-date="${iso}"]`);
      for (let i = 0; i < 60 && !qs(r.startIso); i++) {
        const cur = document.querySelector('button[data-iso-date]');
        const curIso = cur && cur.getAttribute('data-iso-date');
        const nav = curIso && curIso > r.startIso ? '前月に移動' : '翌月に移動';
        const b = document.querySelector(`button[aria-label="${nav}"]`);
        if (!b) break;
        b.click();
        await sleep(200);
      }
      const sb = await waitFor(() => qs(r.startIso), 10000);
      if (!sb) return { status: 'error', message: `カレンダーで ${r.startIso} が見つかりません` };
      sb.click();
      await sleep(300);
      for (let i = 0; i < 3 && !qs(r.endIso); i++) {
        const b = document.querySelector('button[aria-label="翌月に移動"]');
        if (!b) break;
        b.click();
        await sleep(250);
      }
      const eb = await waitFor(() => qs(r.endIso), 10000);
      if (!eb) return { status: 'error', message: `カレンダーで ${r.endIso} が見つかりません` };
      eb.click();
      await sleep(300);
      const apply = await waitFor(() => [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '適用'), 10000);
      if (!apply) return { status: 'error', message: '「適用」ボタンが見つかりません' };
      apply.click();

      const ok = await waitFor(() => {
        const o = findDateOpener();
        return o && norm(o.textContent) === wantLabel;
      }, 90000, 1000);
      if (!ok) return { status: 'error', message: '期間の反映を確認できませんでした' };
    }

    // テーブルの再読込を待つ
    progress(K, 'テーブルの更新待ち');
    await sleep(5000);
    await waitFor(() => !document.querySelector('[aria-busy="true"], [data-testid*="skeleton"], [class*="Skeleton"]'), 60000, 1000);
    await sleep(3000);
    if (await isCancelled()) return { status: 'cancelled' };

    // 画面が作る CSV(Blob)をページ側のフックで横取りし、拡張から名前を付けて保存する
    const captured = new Promise((resolve) => {
      const onMsg = (e) => {
        if (e.source !== window || !e.data || (e.data.__amz !== 'adsBlob' && e.data.__amz !== 'adsBlobError')) return;
        window.removeEventListener('message', onMsg);
        resolve(e.data);
      };
      window.addEventListener('message', onMsg);
      setTimeout(() => { window.removeEventListener('message', onMsg); resolve(null); }, 60000);
    });
    window.postMessage({ __amz: 'adsArm' }, '*');

    progress(K, 'エクスポート中');
    const exp2 = findExport();
    if (!exp2) return { status: 'error', message: 'エクスポートボタンが見つかりません(期間変更後)' };
    exp2.scrollIntoView({ block: 'center' });
    await sleep(300);
    exp2.click();
    const dl = await waitFor(() =>
      document.getElementById(`${P}:export`) ||
      document.querySelector('button[data-e2e-id$=":export"]') ||
      [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'ダウンロード'), 30000);
    if (!dl) return { status: 'error', message: 'エクスポートメニューの「ダウンロード」が見つかりません' };
    dl.click();

    progress(K, 'CSVの生成待ち');
    const got = await captured;
    window.postMessage({ __amz: 'adsDisarm' }, '*');
    if (!got) return { status: 'error', message: 'CSVが生成されませんでした(60秒)' };
    if (got.__amz === 'adsBlobError') return { status: 'error', message: 'CSVの読み取りに失敗: ' + got.message };
    const buf = got.buf;
    if (!buf || !buf.byteLength) return { status: 'error', message: 'CSVが空でした' };

    // 画面の件数・合計費用と突き合わせて、取りこぼしがないか確認する
    progress(K, '内容を確認中');
    const text = new TextDecoder('utf-8').decode(buf);
    const chk = inspectAdsCsv(text);
    if (chk.expected != null && chk.rows < chk.expected) {
      return { status: 'error', message: `取りこぼしの疑い: 画面は${chk.expected}件なのにCSVは${chk.rows}件でした。画面の絞り込みを確認して再実行してください` };
    }
    let warn = '';
    if (chk.pageSum != null && chk.sum > 0) {
      const diff = Math.abs(chk.pageSum - chk.sum);
      if (diff > 500 || diff > chk.sum * 0.01) {
        warn += ` / ⚠ 合計費用が画面(¥${chk.pageSum.toLocaleString()})とCSV(¥${chk.sum.toLocaleString()})で¥${diff.toLocaleString()}違います`;
      }
    }
    if (leftover.length) warn += ` / ⚠ 解除できなかった絞り込み: ${leftover.join(' / ')}`;

    progress(K, '保存中');
    await saveBuffer(buf, `B-広告費・広告売上-${month}.csv`, month);
    return {
      status: 'ok',
      message: `${chk.rows}件 / 合計費用 ¥${chk.sum.toLocaleString()}(期間 ${wantLabel})${warn}`,
    };
  }



  // ───────── 取りこぼし検査(画面の「合計: N」とCSVの中身を突き合わせる)
  function parseCsvLine(line) {
    const out = [];
    let cur = '';
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) {
        if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (c === '"') q = false;
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ',') { out.push(cur); cur = ''; }
      else cur += c;
    }
    out.push(cur);
    return out;
  }

  function yen(v) {
    const n = Number(String(v).replace(/[^\d.-]/g, ''));
    return Number.isFinite(n) ? n : 0;
  }

  // 戻り値: { rows, expected, sum, pageSum }
  function inspectAdsCsv(text) {
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    const header = parseCsvLine(lines[0] || '');
    const costIdx = header.findIndex((h) => h.trim() === '合計費用');
    let sum = 0;
    for (const line of lines.slice(1)) {
      const cells = parseCsvLine(line);
      if (costIdx >= 0) sum += yen(cells[costIdx]);
    }
    const body = document.body.innerText;
    const m = body.match(/合計[:：]\s*([\d,]+)/);
    const expected = m ? Number(m[1].replace(/,/g, '')) : null;
    // 「合計: N」以降に並ぶ金額のうち、CSV合計に近いものを探す
    let pageSum = null;
    if (m) {
      const tail = body.slice(body.indexOf(m[0]), body.indexOf(m[0]) + 300);
      for (const mm of tail.matchAll(/[¥￥]([\d,]+)/g)) {
        const v = Number(mm[1].replace(/,/g, ''));
        if (pageSum === null || Math.abs(v - sum) < Math.abs(pageSum - sum)) pageSum = v;
      }
    }
    return { rows: lines.length - 1, expected, sum, pageSum };
  }

  // ───────────────────────── ②' 広告(レポート作成方式:古い月用)
  // 「効果測定とレポート」で Campaign テンプレートのレポートを作り、完了後にCSVを取得する。
  const ADS_REPORT_PREFIX = (month) => `B-広告費・広告売上-${month}`;

  // レポート名の照合。空白や中黒のゆれを吸収し、名前が省略表示されても前半で一致させる。
  const normName = (s) => String(s || '').replace(/\s+/g, '').replace(/･/g, '・');
  function nameMatch(text, name) {
    const t = normName(text), n = normName(name);
    if (!n) return false;
    if (t.includes(n)) return true;
    const head = n.slice(0, 20);
    return head.length >= 12 && t.includes(head);
  }

  // 送信後、作成画面から離れた(=受理された)か、一覧に行が出たかを確認する。
  async function confirmSubmitted(name, ms) {
    return await waitFor(() => {
      if (!/\/reporting\/new/.test(location.pathname + location.search)) return 'left';
      if ([...document.querySelectorAll('[role=row]')].some((x) => nameMatch(x.textContent, name))) return 'listed';
      return null;
    }, ms || 60000, 2000);
  }
  // 送信が通らなかったとき、画面に出ている不備の中身をできるだけ全部拾う
  // (「Fix the following issues」の見出しだけでは原因が分からないため)
  function submitErrorText() {
    const out = [];
    const push = (s) => {
      s = String(s || '').replace(/\s+/g, ' ').trim();
      if (s && s.length < 300 && !out.some((x) => x.includes(s))) out.push(s);
    };
    const leaves = [...document.querySelectorAll('*')].filter((x) => x.children.length === 0);
    const head = leaves.find((x) => /Fix the following issues|次の問題を修正|以下の問題/.test(x.textContent || ''));
    if (head) {
      // 見出しを含むまとまり(箇条書きの不備一覧)ごと取る
      let box = head.closest('[role=alert],[role=status],[aria-live]') || head.parentElement;
      for (let i = 0; i < 3 && box && box.innerText.trim() === head.textContent.trim(); i++) box = box.parentElement;
      push(box ? box.innerText : head.textContent);
    }
    document.querySelectorAll('[role=alert],[aria-live=assertive]').forEach((e) => push(e.innerText));
    document.querySelectorAll('[aria-invalid=true]').forEach((e) => {
      const lab = e.id && document.querySelector(`label[for="${CSS.escape(e.id)}"]`);
      push(`不備の欄: ${(lab && lab.textContent) || e.id || e.name || e.tagName}`);
    });
    leaves
      .filter((x) => (x.textContent || '').length < 150 && /入力してください|選択してください|必須|無効|required|invalid|must |cannot|can't|at least|exceed|before|after/i.test(x.textContent || ''))
      .forEach((x) => push(x.textContent));
    return out.slice(0, 8).join(' | ').slice(0, 700);
  }

  // 送信直前の画面の状態(不備の原因を後から追えるようにログに残す)
  function formSnapshot() {
    const rowText = (re) => {
      const lab = [...document.querySelectorAll('label, [id$="-row"] *')].find((e) => e.children.length === 0 && re.test(e.textContent.trim()));
      let p = lab;
      for (let i = 0; i < 6 && p; i++) {
        p = p.parentElement;
        if (p && /-row$/.test(p.id || '')) break;
      }
      return p ? p.innerText.replace(/\s+/g, ' ').trim().slice(0, 80) : '?';
    };
    const nameInput = document.getElementById('report-name-form:report-name-control-component-0');
    const period = document.getElementById('report-range-form:date-range-row-control-component-0');
    return [
      `名前=${nameInput ? nameInput.value : '?'}`,
      `期間=${period ? period.textContent.trim() : '?'}`,
      `広告プロダクト=${rowText(/^(広告プロダクト|Ad product)$/)}`,
      `アカウント=${rowText(/^(アカウント|Accounts)$/)}`,
      `表示言語=${/Submit|Change/.test(document.body.innerText.slice(0, 2000)) ? '英語' : '日本語'}`,
    ].join(' / ');
  }

  // 画面の文言は日本語/英語どちらでも探せるようにする
  const T = {
    save: /^(保存|Save|Apply|適用)$/,
    submit: /^(送信|Submit)$/,
    change: /^(変更|Change)$/,
    adProduct: /^(広告プロダクト|Ad product)$/,
  };
  const findButton = (re, root = document) => [...root.querySelectorAll('button')].find((b) => re.test(b.textContent.trim()));

  // ───────── レポート作成画面の「列のカスタマイズ」
  const colLabel = (c) => ((c.closest('label') || c.parentElement || {}).textContent || '').trim();
  const colBoxes = () => [...document.querySelectorAll('input[type=checkbox]')].filter((c) => !/^filter-form/.test(String(c.id)));
  const isCheckedBox = (labels) => colBoxes().some((c) => c.checked && labels.includes(colLabel(c)));

  // 右側の「選択済みの列」一覧を読む。列の一覧は表示中のタブ(サイズ/指標)の分しか
  // チェックボックスが無いので、選択状態の確認はこちらで行う。読めなければ null
  function selectedColumns() {
    const t = document.body.innerText;
    const a = t.indexOf('Sortable Item 1');
    if (a < 0) return null;
    const rest = t.slice(a);
    const b = rest.search(/\n(レポート期間|Report period)\n/);
    return (b > 0 ? rest.slice(0, b) : rest.slice(0, 20000))
      .split('\n').map((s) => s.trim())
      .filter((s) => s && !/^Sortable Item|^削除$|^Delete$|^collapse$|^すべて削除$|^Remove all$|件の指標が選択されました|metrics selected/.test(s));
  }
  const checkedColumns = () => selectedColumns() || colBoxes().filter((c) => c.checked).map(colLabel).filter(Boolean);
  const isChecked = (labels) => {
    const s = selectedColumns();
    return s ? s.some((x) => labels.includes(x)) : isCheckedBox(labels);
  };

  async function clearColumnSearch() {
    const inp = document.getElementById('column-selection-search-input');
    if (inp && inp.value) { setInputValue(inp, ''); await sleep(1000); }
  }

  // 候補の名前(日本語/英語)のどれかで列を探してチェックする。チェックできた名前を返す
  async function pickColumnAny(labels) {
    const inp = document.getElementById('column-selection-search-input');
    if (!inp) return null;
    for (const label of labels) {
      setInputValue(inp, label);
      await sleep(2000);
      const cb = colBoxes().find((c) => colLabel(c) === label && !c.disabled);
      if (!cb) continue;
      if (!cb.checked) { (cb.closest('label') || cb).click(); await sleep(1200); }
      if (cb.checked) return label;
    }
    return null;
  }

  // Amazon は「時間」の列と「詳細レベル」(アカウント/キャンペーン/広告グループ/広告)の列を
  // 最低1つずつ要求する。テンプレートの既定で入っていないことがあるので、無ければ入れる。
  const TIME_COLS = ['日付範囲', '期間', 'レポート期間', 'Date range', '年', 'Year', '月', 'Month', '週', 'Week', '日付', 'Date', '日', 'Day'];
  const LEVEL_COLS = [
    'キャンペーン名', 'キャンペーンID', 'Campaign name', 'Campaign ID',
    '広告グループ名', '広告グループID', 'Ad group name', 'Ad group ID',
    '広告主アカウント名', '広告主アカウントID', 'Advertiser account name', 'Advertiser account ID',
  ];
  async function ensureRequiredColumns() {
    const added = [];
    await clearColumnSearch();
    if (!isChecked(TIME_COLS)) {
      // 期間の列(1か月分を1行にまとめる)→ だめなら「月」
      const got = (await pickColumnAny(['日付範囲', '期間', 'Date range'])) || (await pickColumnAny(['月', 'Month']));
      await clearColumnSearch();
      if (!got || !isChecked(TIME_COLS)) return { added, error: '必須の「時間」の列(期間/月)をチェックできませんでした' };
      added.push(got);
    }
    // ID列だけでは足りないことがあるため、名前の列は必ず入れる(分析にも必要)
    for (const labels of [['キャンペーン名', 'Campaign name'], ['広告グループ名', 'Ad group name']]) {
      if (isChecked(labels)) continue;
      const got = await pickColumnAny(labels);
      if (got) added.push(got);
    }
    await clearColumnSearch();
    if (!isChecked(LEVEL_COLS)) return { added, error: '必須の「詳細レベル」の列(キャンペーン名/広告グループ名)をチェックできませんでした' };
    return { added };
  }

  // 検索用語レポート(ChatGPT 分析用)に入れる列。[表示名, [画面の列名の候補(日本語/英語)]]
  // 「検索用語」(実際に検索された語句)と「ターゲティング」(出稿側のキーワード等)は別の列。
  // ACOS はこのレポートでは選べない(合計費用 ÷ 売上 で計算できる)。
  const ST_REQUIRED = [
    ['検索用語', ['検索用語', 'Search term']],
    ['ターゲティング', ['ターゲティング', 'Targeting']],
    ['ターゲティングマッチタイプ', ['ターゲティングマッチタイプ', 'Targeting match type']],
    ['キャンペーン名', ['キャンペーン名', 'Campaign name']],
    ['広告グループ名', ['広告グループ名', 'Ad group name']],
    ['インプレッション', ['インプレッション', 'Impressions']],
    ['クリック数', ['クリック数', 'Clicks']],
    ['合計費用(広告費)', ['合計費用', 'Total cost']],
    ['商品購入数(購入数)', ['商品購入数', 'Purchases']],
    ['売上(広告売上)', ['売上', 'Sales']],
  ];
  const ST_OPTIONAL = [
    ['CPC', ['CPC']],
    ['CTR', ['CTR']],
    ['購入率(CVR)', ['購入率', 'Purchase rate']],
    ['ROAS', ['ROAS']],
    ['キャンペーンID', ['キャンペーンID', 'Campaign ID']],
    ['広告グループID', ['広告グループID', 'Ad group ID']],
  ];

  // 既定の列には頼らず(読み込みの途中で操作すると既定の列が入らないことがある)、必要な列を1つずつ選ぶ
  async function selectSearchTermColumns() {
    const added = [];
    const picked = new Set();
    for (const [name, labels] of [...ST_REQUIRED, ...ST_OPTIONAL]) {
      if (isChecked(labels)) continue;
      const got = await pickColumnAny(labels);
      if (got) { added.push(got); picked.add(name); }
    }
    await clearColumnSearch();
    await sleep(500);
    const panel = !!selectedColumns();
    const ok = ([name, labels]) => isChecked(labels) || (!panel && picked.has(name));
    return {
      added,
      missing: ST_REQUIRED.filter((c) => !ok(c)).map(([n]) => n),
      optionalMissing: ST_OPTIONAL.filter((c) => !ok(c)).map(([n]) => n),
    };
  }

  function setInputValue(input, value) {
    const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // レポートを作成して送信するところまで
  async function adsReportCreate(month, reportName) {
    const K = 'adsReport';
    const r = monthRange(month);
    progress(K, 'レポート作成画面の読み込み待ち(最大10分)');
    const t0 = Date.now();
    const nameInput = await waitFor(() => {
      const i = [...document.querySelectorAll('input')].find((x) => /^Campaign\s*-/.test(x.value || ''));
      if (!i) {
        const hidden = document.visibilityState === 'hidden' ? '(画面が隠れています)' : '';
        progress(K, `レポート作成画面の読み込み待ち ${Math.round((Date.now() - t0) / 1000)}秒${hidden}`);
      }
      return i;
    }, 600000, 2000);
    if (!nameInput) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: 'レポート作成画面が10分たっても表示されませんでした。Chromeのウィンドウを最前面にしたまま実行してください' };
    }

    const name = reportName || `${ADS_REPORT_PREFIX(month)}-${Date.now()}`;
    setInputValue(nameInput, name);

    progress(K, `期間を ${r.startIso}〜${r.endIso} に設定中`);
    const periodBtn = await waitFor(() => [...document.querySelectorAll('button')].find((b) => /過去7日間|過去30日間|\d+年\d+月\d+日/.test(b.textContent) && b.textContent.length < 60), 30000);
    if (!periodBtn) return { status: 'error', message: '「レポート期間」のボタンが見つかりません' };
    periodBtn.scrollIntoView({ block: 'center' });
    await sleep(300);
    periodBtn.click();

    const opened = await waitFor(() => document.querySelector('button[aria-label="前月に移動"]'), 30000);
    if (!opened) return { status: 'error', message: '日付ピッカーが開きませんでした' };

    const qs = (iso) => document.querySelector(`button[data-iso-date="${iso}"]`);
    for (let i = 0; i < 80 && !qs(r.startIso); i++) {
      const cur = document.querySelector('button[data-iso-date]');
      const curIso = cur && cur.getAttribute('data-iso-date');
      const nav = curIso && curIso > r.startIso ? '前月に移動' : '翌月に移動';
      const b = document.querySelector(`button[aria-label="${nav}"]`);
      if (!b) break;
      b.click();
      await sleep(180);
    }
    const sb = await waitFor(() => qs(r.startIso), 10000);
    if (!sb) return { status: 'error', message: `カレンダーで ${r.startIso} が見つかりません` };
    sb.click();
    await sleep(300);
    for (let i = 0; i < 3 && !qs(r.endIso); i++) {
      const b = document.querySelector('button[aria-label="翌月に移動"]');
      if (!b) break;
      b.click();
      await sleep(250);
    }
    const eb = await waitFor(() => qs(r.endIso), 10000);
    if (!eb) return { status: 'error', message: `カレンダーで ${r.endIso} が見つかりません` };
    eb.click();
    await sleep(300);
    const save = await waitFor(() => [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '保存'), 10000);
    if (!save) return { status: 'error', message: '日付ピッカーの「保存」が見つかりません' };
    save.click();
    await sleep(1500);

    progress(K, 'レポートを送信中');
    const send = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '送信');
    if (!send) return { status: 'error', message: '「送信」ボタンが見つかりません' };
    send.click();

    // 「レポート名はすでに存在します」等のエラーを拾う
    await sleep(2500);
    const err = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /すでに存在します|already exists/.test(e.textContent || ''));
    if (err) return { status: 'error', message: `レポート名が重複しました(${name})` };

    // 一覧の描画は遅れることがある。作成画面から離れていれば受理されたとみなす。
    const okSubmit = await confirmSubmitted(name, 90000);
    if (!okSubmit) {
      const msg = submitErrorText();
      return { status: 'error', message: msg ? `送信できませんでした: ${msg}` : '送信しても作成画面から進みませんでした' };
    }
    return { status: 'created', message: `レポートを作成しました(${okSubmit === 'listed' ? '一覧で確認' : '一覧の表示待ち'})`, name };
  }

  // 一覧から対象レポートの状態を見て、完了していればダウンロードURLを返す
  async function adsReportPick(month, reportName) {
    const K = 'adsReport';
    const name = reportName || ADS_REPORT_PREFIX(month);
    progress(K, 'レポートの状態を確認中');
    const row = await waitFor(() => [...document.querySelectorAll('[role=row]')].find((x) => nameMatch(x.textContent, name)), 180000, 2000);
    if (!row) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      const rows = [...document.querySelectorAll('[role=row]')];
      return { status: 'notFound', message: `レポート「${name}」が一覧に見つかりません(一覧の行数 ${rows.length})` };
    }
    const text = row.textContent;
    if (/エラー|失敗|キャンセル/.test(text)) return { status: 'error', message: 'レポートの作成に失敗しました' };
    if (!/完了/.test(text)) return { status: 'pending', message: '生成中' };

    const act = [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'アクション');
    if (!act) return { status: 'error', message: '行のアクションボタンが見つかりません' };
    act.click();
    const link = await waitFor(() => [...document.querySelectorAll('a')].find((a) => a.textContent.trim() === '最新版をダウンロードする' && a.getAttribute('href')), 10000);
    if (!link) return { status: 'error', message: 'ダウンロードのリンクが見つかりません' };
    const url = new URL(link.getAttribute('href'), location.origin).href;
    document.body.click();
    return { status: 'ok', url };
  }

  // 拡張から取得できなかったときの保険:画面のリンクをそのままクリックする
  // (Chrome の通常のダウンロードになり、ファイル名は Amazon が付けた名前のまま)
  async function adsReportClick(month, reportName) {
    const K = 'adsReport';
    const name = reportName || ADS_REPORT_PREFIX(month);
    const row = await waitFor(() => [...document.querySelectorAll('[role=row]')].find((x) => nameMatch(x.textContent, name)), 60000, 2000);
    if (!row) return { status: 'error', message: `レポート「${name}」が一覧に見つかりません` };
    const act = [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'アクション');
    if (!act) return { status: 'error', message: '行のアクションボタンが見つかりません' };
    act.click();
    const link = await waitFor(() => [...document.querySelectorAll('a')].find((a) => a.textContent.trim() === '最新版をダウンロードする' && a.getAttribute('href')), 10000);
    if (!link) return { status: 'error', message: 'ダウンロードのリンクが見つかりません' };
    progress(K, 'ブラウザのダウンロードで取得中');
    link.click();
    await sleep(3000);
    return { status: 'ok' };
  }


  // ───────────────────────── ⑤ 検索用語レポート(SP / SB)
  // 「効果測定とレポート」の Search term テンプレートでレポートを作る。
  // 既存のA〜Dの処理には一切触れない独立した処理。
  async function searchTermCreate(month, opts) {
    const K = 'searchTerm';
    const o = opts || {};
    const adProduct = o.adProduct || 'SPONSORED_PRODUCTS';
    const name = o.name || `検索用語-${month}-${Date.now()}`;
    const r = monthRange(month);

    // 今月を指定した場合は、今日までを終わりにする(未来日は選べないため)
    const today = new Date();
    const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const endIso = r.endIso > todayIso ? todayIso : r.endIso;

    progress(K, 'レポート作成画面の読み込み待ち(最大10分)');
    const t0 = Date.now();
    const nameInput = await waitFor(() => {
      const i = document.getElementById('report-name-form:report-name-control-component-0');
      if (!i) {
        const hidden = document.visibilityState === 'hidden' ? '(画面が隠れています)' : '';
        progress(K, `レポート作成画面の読み込み待ち ${Math.round((Date.now() - t0) / 1000)}秒${hidden}`);
      }
      return i;
    }, 600000, 2000);
    if (!nameInput) {
      if (/signin/.test(location.href)) return { status: 'error', message: '広告コンソールにログインしてください' };
      return { status: 'error', message: 'レポート作成画面が表示されませんでした' };
    }
    setInputValue(nameInput, name);

    // 広告プロダクトを1つだけにする
    progress(K, `広告プロダクトを ${o.tag || ''} に設定中`);
    const openChange = () => {
      const lab = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && T.adProduct.test(e.textContent.trim()));
      let p = lab;
      for (let i = 0; i < 6 && p; i++) {
        p = p.parentElement;
        const b = p && findButton(T.change, p);
        if (b) return b;
      }
      return null;
    };
    const PRODUCTS = ['SPONSORED_PRODUCTS', 'SPONSORED_BRANDS', 'SPONSORED_DISPLAY', 'SPONSORED_TELEVISION', 'AMAZON_DSP'];
    const box = (k) => document.getElementById(`filter-form:ad-product-row-control-component-0-${k}-option`);
    if (!box(PRODUCTS[0])) {
      const b = openChange();
      if (!b) return { status: 'error', message: '広告プロダクトの「変更」ボタンが見つかりません' };
      b.click();
      await waitFor(() => box(PRODUCTS[0]), 15000);
    }
    for (let pass = 0; pass < 3; pass++) {
      let done = true;
      for (const k of PRODUCTS) {
        const c = box(k);
        if (!c) continue;
        if (c.checked !== (k === adProduct)) { done = false; (c.closest('label') || c).click(); await sleep(700); }
      }
      if (done) break;
    }
    const sel = box(adProduct);
    if (!sel || !sel.checked) return { status: 'error', message: `広告プロダクト(${o.tag || adProduct})を選べませんでした` };
    const saveFilter = findButton(T.save);
    if (saveFilter) { saveFilter.click(); await sleep(2500); }

    // 列を選ぶ(必須の列が選べなければ送信しない)
    progress(K, '列を設定中');
    const added = [];
    const cols = await selectSearchTermColumns();
    added.push(...cols.added);
    if (cols.missing.length) {
      return { status: 'error', message: `必須の列を選べませんでした: ${cols.missing.join('・')}【選択中の列: ${checkedColumns().join('・') || 'なし'}】` };
    }

    // 送信に必須の「時間」と「詳細レベル」の列を確認し、無ければ入れる(2026-10 から必須)
    const req = await ensureRequiredColumns();
    if (req.error) return { status: 'error', message: `${req.error}【選択中の列: ${checkedColumns().join('・') || 'なし'}】` };
    if (req.added.length) added.push(...req.added);

    // 期間
    progress(K, `期間を ${r.startIso}〜${endIso} に設定中`);
    const periodBtn = await waitFor(() => document.getElementById('report-range-form:date-range-row-control-component-0')
      || [...document.querySelectorAll('button')].find((b) => /過去7日間|過去30日間|\d+年\d+月\d+日|Last 7 days|Last 30 days/.test(b.textContent) && b.textContent.length < 60), 30000);
    if (!periodBtn) return { status: 'error', message: '「レポート期間」のボタンが見つかりません' };
    periodBtn.scrollIntoView({ block: 'center' });
    await sleep(400);
    periodBtn.click();
    const opened = await waitFor(() => document.querySelector('button[aria-label="前月に移動"]'), 30000);
    if (!opened) return { status: 'error', message: '日付ピッカーが開きませんでした' };
    const qs = (iso) => document.querySelector(`button[data-iso-date="${iso}"]`);
    for (let i = 0; i < 80 && !qs(r.startIso); i++) {
      const cur = document.querySelector('button[data-iso-date]');
      const curIso = cur && cur.getAttribute('data-iso-date');
      const nav = curIso && curIso > r.startIso ? '前月に移動' : '翌月に移動';
      const b = document.querySelector(`button[aria-label="${nav}"]`);
      if (!b) break;
      b.click();
      await sleep(180);
    }
    const sb = await waitFor(() => qs(r.startIso), 10000);
    if (!sb) return { status: 'error', message: `カレンダーで ${r.startIso} が見つかりません` };
    sb.click();
    await sleep(300);
    for (let i = 0; i < 3 && !qs(endIso); i++) {
      const b = document.querySelector('button[aria-label="翌月に移動"]');
      if (!b) break;
      b.click();
      await sleep(250);
    }
    const eb = await waitFor(() => qs(endIso), 10000);
    if (!eb) return { status: 'error', message: `カレンダーで ${endIso} が見つかりません` };
    eb.click();
    await sleep(300);
    const savePeriod = await waitFor(() => findButton(T.save), 10000);
    if (!savePeriod) return { status: 'error', message: '日付ピッカーの「保存」が見つかりません' };
    savePeriod.click();
    await sleep(1500);

    // 期間を変えたことや既定の列の読み込みで列が戻されていないか、送信直前にもう一度確認する
    const cols2 = await selectSearchTermColumns();
    added.push(...cols2.added);
    if (cols2.missing.length) {
      return { status: 'error', message: `必須の列を選べませんでした: ${cols2.missing.join('・')}【選択中の列: ${checkedColumns().join('・') || 'なし'}】` };
    }
    const req2 = await ensureRequiredColumns();
    if (req2.error) return { status: 'error', message: `${req2.error}【選択中の列: ${checkedColumns().join('・') || 'なし'}】` };
    if (req2.added.length) added.push(...req2.added);
    const optNote = cols2.optionalMissing.length ? ` / 選べなかった任意の列: ${cols2.optionalMissing.join('・')}` : '';

    progress(K, 'レポートを送信中');
    const snap = formSnapshot();
    const send = document.getElementById('urc_frb_create_report_button') || findButton(T.submit);
    if (!send) return { status: 'error', message: `「送信」ボタンが見つかりません(${snap})` };
    send.click();

    await sleep(2500);
    const err = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /すでに存在します|already exists/.test(e.textContent || ''));
    if (err) return { status: 'error', message: `レポート名が重複しました(${name})` };

    // 一覧の描画は遅れることがある。作成画面から離れていれば受理されたとみなし、
    // 行の確認はこのあとバックグラウンドが一覧を開き直して行う。
    const okSubmit = await confirmSubmitted(name, 90000);
    if (!okSubmit) {
      const msg = submitErrorText();
      return {
        status: 'error',
        message: `${msg ? `送信できませんでした: ${msg}` : '送信しても作成画面から進みませんでした'}【送信時の画面: ${snap}】【選択中の列: ${checkedColumns().join('・') || 'なし'}】`,
      };
    }
    return {
      status: 'created',
      message: `作成${okSubmit === 'listed' ? '' : '(一覧の表示待ち)'}(期間 ${r.startIso}〜${endIso} / 追加した列 ${[...new Set(added)].join('・') || 'なし(既定で選択済み)'}${optNote})`,
      name, startIso: r.startIso, endIso,
    };
  }

  const RUNNERS = { tx: transaction, storage: storageFee, sales, ads, adsReportCreate, adsReportPick, adsReportClick, searchTermCreate };

  window.__AMZDL = {
    async run(kind, month, extra) {
      const fn = RUNNERS[kind];
      if (!fn) return { status: 'error', message: '未知の種類: ' + kind };
      try {
        return await fn(month, extra);
      } catch (e) {
        if (e instanceof CancelledError) return { status: 'cancelled', message: '中止しました' };
        return { status: 'error', message: String((e && e.message) || e).slice(0, 300) };
      }
    },
  };
})();

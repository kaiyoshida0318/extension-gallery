// Service Worker: ジョブ実行・タブ管理・保存・状態管理
importScripts('fsstore.js');

const KINDS = {
  tx:      { label: 'FBA手数料・販売手数料・出荷数', url: 'https://sellercentral.amazon.co.jp/payments/reports-repository', match: 'https://sellercentral.amazon.co.jp/payments/reports-repository*' },
  ads:     { label: '広告費・広告売上',             url: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns', match: 'https://advertising.amazon.co.jp/campaign-manager/all-campaigns*' },
  storage: { label: '保管費',                       url: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1', match: 'https://sellercentral.amazon.co.jp/reportcentral/STORAGE_FEE_CHARGES/1*' },
  adsReport: {
    label: '広告費・広告売上(レポート作成)',
    url: 'https://advertising.amazon.co.jp/reporting/new?templateId=campaign',
    match: 'https://advertising.amazon.co.jp/reporting*',
    listUrl: 'https://advertising.amazon.co.jp/reporting',
  },
  searchTerm: {
    label: '検索用語レポート(SP/SB)',
    url: 'https://advertising.amazon.co.jp/reporting/new?templateId=search_term',
    match: 'https://advertising.amazon.co.jp/reporting*',
    listUrl: 'https://advertising.amazon.co.jp/reporting',
  },
  sales:   { label: '総売上',                       url: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html#/dashboard', match: 'https://sellercentral.amazon.co.jp/gp/site-metrics/report.html*' },
};
const ORDER = ['tx', 'ads', 'storage', 'sales'];
const MAX_ATTEMPTS = 2;

// ───────── 状態の書き込みは直列化(レース回避)
let chain = Promise.resolve();
function withState(fn) {
  chain = chain.then(fn).catch((e) => console.error(e));
  return chain;
}

function log(text, level = 'info') {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_logs']);
    const logs = s.amz_logs || [];
    logs.unshift({ at: Date.now(), level, text });
    await chrome.storage.local.set({ amz_logs: logs.slice(0, 300) });
  });
}

function patchJob(patch) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_job']);
    await chrome.storage.local.set({ amz_job: { ...(s.amz_job || {}), ...patch } });
  });
}

function setResult(month, kind, result) {
  return withState(async () => {
    const s = await chrome.storage.local.get(['amz_results']);
    const all = s.amz_results || {};
    all[month] = all[month] || {};
    all[month][kind] = { ...result, at: Date.now() };
    // 古い月は24件まで保持
    const keys = Object.keys(all).sort().reverse();
    for (const k of keys.slice(24)) delete all[k];
    await chrome.storage.local.set({ amz_results: all });
  });
}

async function getJob() {
  await chain;
  const s = await chrome.storage.local.get(['amz_job']);
  return s.amz_job || null;
}

// ───────── タブ管理(タブIDは保持せず、毎回URLで探す)
function waitTabComplete(tabId, timeoutMs = 90000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (fn, v) => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(timer); fn(v); };
    const onUpd = (id, info, tab) => { if (id === tabId && info.status === 'complete') finish(resolve, tab); };
    const timer = setTimeout(() => finish(reject, new Error('ページの読み込みがタイムアウトしました')), timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') finish(resolve, t); }).catch((e) => finish(reject, e));
  });
}

async function getOrCreateTab(kind) {
  const def = KINDS[kind];
  const found = await chrome.tabs.query({ url: def.match });
  let tab;
  if (found.length) {
    tab = found[0];
    // SPA の状態を初期化するため再読み込み
    await chrome.tabs.update(tab.id, { url: def.url });
  } else {
    tab = await chrome.tabs.create({ url: def.url, active: false });
  }
  await sleep(500);
  tab = await waitTabComplete(tab.id);
  const t = await chrome.tabs.get(tab.id);
  if (/\/ap\/signin|\/ap\/mfa|signin/i.test(t.url || '')) {
    throw new Error('ログインが必要です。開いたタブでログインしてから再実行してください');
  }
  return t;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 広告画面(ページ側 = MAIN world)に仕込むフック。
// 画面が CSV を <a download> で保存する瞬間に Blob を横取りし、拡張側へ渡す(実際のダウンロードは止める)
function installAdsBlobHook() {
  if (window.__amzAdsHook) return;
  window.__amzAdsHook = true;
  let armed = false;
  const blobs = new Map();
  const origCreate = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const url = origCreate.apply(this, arguments);
    try { if (obj instanceof Blob) { blobs.set(url, obj); if (blobs.size > 20) blobs.delete(blobs.keys().next().value); } } catch (e) {}
    return url;
  };
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__amz === 'adsArm') armed = true;
    if (e.data.__amz === 'adsDisarm') armed = false;
  });
  const grab = (a) => {
    const href = String(a.href || '');
    if (!armed || !(href.startsWith('blob:') || href.startsWith('data:'))) return false;
    armed = false;
    const blob = blobs.get(href);
    const p = blob ? blob.arrayBuffer() : fetch(href).then((r) => r.arrayBuffer());
    p.then((buf) => window.postMessage({ __amz: 'adsBlob', name: a.download || '', buf }, '*'))
      .catch((err) => window.postMessage({ __amz: 'adsBlobError', message: String(err) }, '*'));
    return true;
  };
  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (grab(this)) return;
    return origClick.apply(this, arguments);
  };
  const origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (this instanceof HTMLAnchorElement && ev && ev.type === 'click' && grab(this)) return true;
    return origDispatch.apply(this, arguments);
  };
}

// 画面が隠れていると広告コンソールの描画が止まるため、requestAnimationFrame を
// タイマーで代替してレンダリングが進むようにする(MAIN world)
function installRenderKick() {
  if (window.__amzRenderKick) return;
  window.__amzRenderKick = true;
  const raf = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = (cb) =>
    (document.visibilityState === 'hidden' ? setTimeout(() => cb(performance.now()), 16) : raf(cb));
}

async function runOnTab(tabId, kind, month, extra) {
  if (kind === 'ads' || String(kind).startsWith('adsReport') || String(kind).startsWith('searchTerm')) {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: installRenderKick });
  }
  if (kind === 'ads') {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: installAdsBlobHook });
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ['injected.js'] });
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (k, m, x) => window.__AMZDL.run(k, m, x),
    args: [kind, month, extra ?? null],
  });
  return res && res.result ? res.result : { status: 'error', message: '注入スクリプトから結果が返りませんでした' };
}

// ───────── 検索用語レポート(SP / SB)。既存のA〜Dとは独立した処理。

// CSV に必ず入っていなければならない列。[表示名, [CSVの見出しの候補]]
// 「検索用語」と「ターゲティング」は別の列として両方必要。
const ST_HEADER_REQUIRED = [
  ['検索用語', ['検索用語', 'Search term']],
  ['ターゲティング', ['ターゲティング', 'Targeting']],
  ['ターゲティングマッチタイプ', ['ターゲティングマッチタイプ', 'Targeting match type']],
  ['キャンペーン名', ['キャンペーン名', 'Campaign name']],
  ['広告グループ名', ['広告グループ名', 'Ad group name']],
  ['インプレッション', ['インプレッション', 'Impressions']],
  ['クリック数', ['クリック数', 'Clicks']],
  ['合計費用(広告費)', ['合計費用', 'Total cost']],
  ['商品購入数(購入数)', ['商品購入数', 'Purchases']],
  ['売上(広告売上)', ['売上', 'Sales']],
];

function parseCsvHeader(line) {
  const out = [];
  let cur = '';
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') q = false;
      else cur += c;
    } else if (c === '"') q = true;
    else if (c === ',') { out.push(cur.trim()); cur = ''; }
    else cur += c;
  }
  out.push(cur.trim());
  return out;
}

// 見出し行を読んで、必須の列が揃っているかを調べる。文字コードは UTF-8 を優先し、だめなら他も試す
function checkSearchTermCsv(bytes) {
  let best = null;
  for (const enc of ['utf-8', 'utf-16le', 'shift_jis']) {
    let text;
    try { text = new TextDecoder(enc).decode(bytes).replace(/^﻿/, ''); } catch (e) { continue; }
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    const header = parseCsvHeader(lines[0] || '');
    const missing = ST_HEADER_REQUIRED.filter(([, alts]) => !alts.some((a) => header.includes(a))).map(([n]) => n);
    const r = { enc, header, missing, rows: Math.max(0, lines.length - 1) };
    if (!best || missing.length < best.missing.length) best = r;
    if (!missing.length) break;
  }
  return best;
}
async function runSearchTermOne(month, adProduct, tag) {
  const def = KINDS.searchTerm;
  const d = new Date();
  const p2 = (n) => String(n).padStart(2, '0');
  const stamp = `${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}`;
  const reportName = `${tag}_検索用語_${month}_${stamp}`;

  let tab = await getOrCreateTab('searchTerm');
  // 作成画面は読み込み直後に URL が書き換わる(?ephemeralAdvertiser=true)ことがあり、
  // そのとき「Frame with ID 0 was removed」で注入が切れる。読み込みを待って1回だけやり直す。
  let created;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      created = await runOnTab(tab.id, 'searchTermCreate', month, { adProduct, tag, name: reportName });
      break;
    } catch (e) {
      const msg = String((e && e.message) || e);
      if (!/Frame with ID|was removed|No frame|frame was detached/i.test(msg)) throw e;
      await sleep(3000);
      await waitTabComplete(tab.id).catch(() => {});
      const now = await chrome.tabs.get(tab.id);
      const path = (() => { try { return new URL(now.url).pathname.replace(/\/$/, ''); } catch (_) { return ''; } })();
      if (path !== '/reporting/new' && path !== '/reporting') throw e;
      if (path === '/reporting') {
        // 送信後に一覧へ移った(=受理された)可能性が高い。一覧で確かめる
        await log(`${tag}: 作成画面から移動しました。一覧で確認します`, 'warn');
        created = { status: 'created', message: '(送信後の画面遷移を確認)' };
        break;
      }
      if (attempt === 2) throw e;
      await log(`${tag}: 画面の読み込み中に切れたため、作り直します`, 'warn');
      tab = await getOrCreateTab('searchTerm');
    }
  }
  if (created.status !== 'created') return { ...created, tag };
  await log(`🔎 ${tag} 検索用語レポートを作成: ${reportName} ${created.message || ''}`);
  await patchJob({ progress: `${tag}: レポートの生成待ち` });

  const t0 = Date.now();
  let misses = 0;
  while (Date.now() - t0 < 25 * 60e3) {
    for (let i = 0; i < 4; i++) {
      const j = await getJob();
      if (j && j.cancel) return { status: 'cancelled', message: '中止しました', tag };
      await sleep(5000);
    }
    await chrome.tabs.update(tab.id, { url: def.listUrl });
    await sleep(1000);
    await waitTabComplete(tab.id);
    const picked = await runOnTab(tab.id, 'adsReportPick', month, reportName);
    if (picked.status === 'ok') {
      await patchJob({ progress: `${tag}: CSVを保存中` });
      let lastErr = '';
      for (const mode of ['include', 'omit']) {
        try {
          const res = await fetch(picked.url, { credentials: mode });
          if (!res.ok) { lastErr = `HTTP ${res.status}`; continue; }
          const bytes = new Uint8Array(await res.arrayBuffer());
          if (!bytes.length) { lastErr = '空のファイル'; continue; }
          // 見出しを検証する。必須の列が欠けていたら保存せず、失敗として通知する
          const chk = checkSearchTermCsv(bytes);
          await log(`🧾 ${tag} CSVの列(${chk.header.length}列): ${chk.header.join('・').slice(0, 900)}`);
          if (chk.missing.length) {
            return {
              status: 'error',
              message: `${tag}: 必須の列が不足しているため保存しませんでした(不足: ${chk.missing.join('・')})`,
              tag,
            };
          }
          const path = await saveToFolder(month, `Amazon_${tag}_検索用語_${month}.csv`, bytes);
          const lines = chk.rows;
          await log(`📊 Amazon_${tag}_検索用語_${month}.csv: ${lines}行 / 必須の列はすべてあり`);
          if (lines <= 0) return { status: 'noData', message: `${tag}: データが0件でした`, tag };
          return { status: 'ok', message: `${tag} ${lines}行・${chk.header.length}列 / ${Math.max(1, Math.round(bytes.length / 1024))}KB`, tag, path };
        } catch (e) {
          lastErr = String((e && e.message) || e);
        }
      }
      await log(`${tag}: フォルダへの保存に失敗(${lastErr})。画面のダウンロードに切り替えます`, 'warn');
      const clicked = await runOnTab(tab.id, 'adsReportClick', month, reportName);
      if (clicked.status !== 'ok') return { status: 'error', message: `${tag}: CSVの取得に失敗: ${lastErr}`, tag };
      // 画面のダウンロードに切り替えた場合は中身を検証できないので、成功扱いにしない
      return { status: 'error', message: `${tag}: ダウンロードフォルダに保存しました(Amazonのファイル名のまま)。列の検証ができていないので中身を確認してください`, tag };
    }
    if (picked.status === 'error') return { ...picked, tag };
    if (picked.status === 'notFound') {
      misses++;
      await log(`${tag}: 一覧にまだ出ていません(${misses}回目)${picked.message ? ': ' + picked.message : ''}`, 'warn');
      if (misses >= 5) return { status: 'error', message: `${tag}: ${picked.message || 'レポートが一覧に現れませんでした'}`, tag };
    }
    await patchJob({ progress: `${tag}: レポートの生成待ち ${Math.round((Date.now() - t0) / 1000)}秒` });
  }
  return { status: 'notReady', message: `${tag}: 25分待っても完了しませんでした`, tag };
}

// SP → SB の順に取得する。SPが失敗してもSBは続ける。
async function runSearchTerm(month) {
  const targets = [
    { adProduct: 'SPONSORED_PRODUCTS', tag: 'SP' },
    { adProduct: 'SPONSORED_BRANDS', tag: 'SB' },
  ];
  const results = [];
  for (const t of targets) {
    const j = await getJob();
    if (j && j.cancel) { results.push({ status: 'cancelled', tag: t.tag, message: '中止しました' }); continue; }
    await patchJob({ progress: `${t.tag} の検索用語レポート` });
    let r;
    try {
      r = await runSearchTermOne(month, t.adProduct, t.tag);
    } catch (e) {
      r = { status: 'error', tag: t.tag, message: `${t.tag}: ${String((e && e.message) || e)}` };
    }
    const mark = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' }[r.status] || '❔';
    await log(`${mark} 検索用語 ${t.tag}: ${r.message || r.status}`, r.status === 'error' ? 'error' : 'info');
    results.push(r);
  }
  const ok = results.filter((r) => r.status === 'ok');
  const ng = results.filter((r) => r.status !== 'ok');
  if (ok.length === 2) return { status: 'ok', message: results.map((r) => r.message).join(' / ') };
  if (ok.length === 1) return { status: 'error', message: `${ok[0].tag}のみ成功。${ng.map((r) => r.message || `${r.tag}失敗`).join(' / ')}` };
  if (results.every((r) => r.status === 'cancelled')) return { status: 'cancelled', message: '中止しました' };
  if (results.every((r) => r.status === 'noData')) return { status: 'noData', message: 'SP・SBとも0件でした' };
  return { status: 'error', message: results.map((r) => r.message || `${r.tag}失敗`).join(' / ') };
}

// ───────── ジョブ実行
// 広告(レポート作成方式):作成 → 完了までページを再読み込みしながら待つ → CSVを保存
async function runAdsReport(month) {
  const K = 'adsReport';
  const def = KINDS[K];
  const tab = await getOrCreateTab(K);
  {
    // レポート名は毎回ユニークにする(Amazon 側で同名のレポートは作れないため)
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const stamp = `${String(d.getFullYear()).slice(2)}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}`;
    const reportName = `B-広告費・広告売上-${month}-${stamp}`;

    const created = await runOnTab(tab.id, 'adsReportCreate', month, reportName);
    if (created.status !== 'created') return created;
    await log(`広告レポートを作成: ${reportName}`);
    await patchJob({ progress: 'レポートの生成待ち' });

    const t0 = Date.now();
    let misses = 0;
    while (Date.now() - t0 < 20 * 60e3) {
      for (let i = 0; i < 4; i++) {
        const j = await getJob();
        if (j && j.cancel) return { status: 'cancelled', message: '中止しました' };
        await sleep(5000);
      }
      await chrome.tabs.update(tab.id, { url: def.listUrl });
      await sleep(1000);
      await waitTabComplete(tab.id);
      const picked = await runOnTab(tab.id, 'adsReportPick', month, reportName);
      if (picked.status === 'ok') {
        await patchJob({ progress: 'CSVを保存中' });
        await log(`広告レポート完了。CSVを取得します`);
        let lastErr = '';
        for (const mode of ['include', 'omit']) {
          try {
            const r = await fetch(picked.url, { credentials: mode });
            if (!r.ok) { lastErr = `HTTP ${r.status}`; continue; }
            const bytes = new Uint8Array(await r.arrayBuffer());
            if (!bytes.length) { lastErr = '空のファイル'; continue; }
            await saveToFolder(month, `B-広告費・広告売上-${month}.csv`, bytes);
            return { status: 'ok', message: `${Math.max(1, Math.round(bytes.length / 1024))}KB(レポート作成方式)` };
          } catch (e) {
            lastErr = String((e && e.message) || e);
          }
        }
        // 保存先フォルダに直接書けなかった場合は、画面のリンクをクリックして
        // 通常のダウンロード(ダウンロードフォルダ・Amazonが付けた名前)にする
        await log(`フォルダへの直接保存に失敗(${lastErr})。画面のダウンロードに切り替えます`, 'warn');
        const clicked = await runOnTab(tab.id, 'adsReportClick', month, reportName);
        if (clicked.status !== 'ok') return { status: 'error', message: `CSVの取得に失敗: ${lastErr}` };
        return { status: 'ok', message: 'ダウンロードフォルダに保存(Amazonのファイル名のまま)' };
      }
      if (picked.status === 'error') return picked;
      if (picked.status === 'notFound') {
        misses++;
        await log(`一覧にまだ出ていません(${misses}回目)${picked.message ? ': ' + picked.message : ''}`, 'warn');
        if (misses >= 5) return { status: 'error', message: picked.message || 'レポートが一覧に現れませんでした' };
      }
      await patchJob({ progress: `レポートの生成待ち ${Math.round((Date.now() - t0) / 1000)}秒` });
    }
    return { status: 'notReady', message: '20分待っても完了しませんでした。時間をおいて再実行してください' };
  }
}

async function runJob(months, kinds) {
  const list = Array.isArray(months) ? months : [months];
  const current = await getJob();
  if (current && current.running) {
    await log('すでに実行中のため、新しい依頼は無視しました', 'warn');
    return;
  }
  const fs = await AMZ_FS.status();
  if (fs.state !== 'granted') {
    const why = fs.state === 'none' ? '保存先フォルダが未設定です' : '保存先フォルダへの書き込み許可が必要です';
    await log(`${why}。ポップアップから設定してください`, 'error');
    await notify(`⚠ 開始できませんでした`, `${why}。ポップアップの「保存先」から設定してください`);
    return;
  }
  // 月フォルダは作らず、常に保存先フォルダへ並べて保存する(ファイル名に月が入っている)
  saveFlat = true;
  await patchJob({
    running: true, month: list[0], months: list, monthIndex: 0,
    kinds, current: null, cancel: false, startedAt: Date.now(), progress: '',
  });
  // 長時間の待機中に Service Worker が停止しないようにする
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  const all = [];
  try {
    for (let i = 0; i < list.length; i++) {
      const j = await getJob();
      if (j && j.cancel) break;
      await patchJob({ month: list[i], monthIndex: i });
      const summary = await runJobInner(list[i], kinds);
      all.push({ month: list[i], summary });
    }
    const j = await getJob();
    await patchJob({ running: false, current: null, progress: '', finishedAt: Date.now() });
    if (all.length === 1) await notifyJobDone(all[0].month, all[0].summary, !!(j && j.cancel));
    else await notifyRangeDone(all, !!(j && j.cancel));
  } catch (e) {
    await log('予期しないエラー: ' + String((e && e.message) || e), 'error');
    await patchJob({ running: false, current: null, progress: '' });
    await notify(`❌ エラーで停止しました`, String((e && e.message) || e).slice(0, 200));
  } finally {
    clearInterval(keepAlive);
  }
}

async function runJobInner(month, kinds) {
  const summary = [];
  savedFolder = '';
  await log(`▶ ${month} 開始: ${kinds.map((k) => KINDS[k].label).join(' / ')}`);

  for (const kind of kinds) {
    const j = await getJob();
    if (j && j.cancel) {
      await setResult(month, kind, { status: 'cancelled', message: '中止しました' });
      summary.push({ kind, status: 'cancelled' });
      continue;
    }
    await patchJob({ current: kind, progress: '開始' });
    await setResult(month, kind, { status: 'running', message: '実行中' });

    let result = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      if (attempt > 1) {
        await log(`${KINDS[kind].label}: リトライ ${attempt}/${MAX_ATTEMPTS}`, 'warn');
        await sleep(8000);
      }
      try {
        if (kind === 'searchTerm') {
          result = await runSearchTerm(month);
          if (result.status !== 'error') break;
          if ((await getJob())?.cancel) break;
          // 列の不足は何度やっても同じなので、やり直さない
          if (/必須の列/.test(result.message || '')) break;
          continue;
        }
        if (kind === 'adsReport') {
          result = await runAdsReport(month);
          if (result.status !== 'error') break;
          if ((await getJob())?.cancel) break;
          continue;
        }
        const tab = await getOrCreateTab(kind);
        result = await runOnTab(tab.id, kind, month);
      } catch (e) {
        result = { status: 'error', message: String((e && e.message) || e) };
      }
      if (result.status === 'cancelled') break;
      if (result.status !== 'error') break;
      if (/ログイン/.test(result.message || '')) break;
      if ((await getJob())?.cancel) break;
    }

    // キャンペーン画面で古い月を選べなかった場合は、レポート作成方式に自動で切り替える
    if (kind === 'ads' && result && result.status === 'error' && /カレンダーで/.test(result.message || '')) {
      await log('カレンダーで対象月を選べないため、レポート作成方式に切り替えます', 'warn');
      await patchJob({ progress: 'レポート作成方式に切り替え中' });
      result = await runAdsReport(month);
    }

    await setResult(month, kind, result);
    summary.push({ kind, status: result.status, message: result.message });
    const mark = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' }[result.status] || '❔';
    await log(`${mark} ${KINDS[kind].label}: ${result.message || result.status}`, result.status === 'error' ? 'error' : 'info');
  }

  const j = await getJob();
  await log(j && j.cancel ? `⏹ ${month} 中止しました` : `■ ${month} 完了`);
  return summary;
}

// 複数月をまとめて実行したときの通知
async function notifyRangeDone(all, cancelled) {
  const flat = all.flatMap((m) => m.summary);
  const ok = flat.filter((r) => r.status === 'ok').length;
  const bad = all.filter((m) => m.summary.some((r) => r.status === 'error')).map((m) => m.month);
  const title = cancelled
    ? `⏹ まとめて取得を中止(${all.length}か月中 ${ok}件 取得)`
    : bad.length
      ? `⚠ まとめて取得 完了(失敗あり ${ok}件 取得)`
      : `✅ まとめて取得 完了(${ok}件)`;
  const body = [
    `対象: ${all.length ? `${all[all.length - 1].month}〜${all[0].month}` : '-'}`,
    bad.length ? `失敗した月: ${bad.join(', ')}` : '失敗なし',
    savedFolder ? `保存先: ${savedFolder}` : '',
  ].filter(Boolean).join('\n');
  await notify(title, body);
}

// ───────── 完了通知
const MARK = { ok: '✅', noData: '⚪', notReady: '⏰', error: '❌', cancelled: '⏹' };
const HEAD = { ok: '取得済み', noData: 'データなし', notReady: '未確定', error: '失敗', cancelled: '中止' };
const SHORT = { tx: 'FBA手数料・販売手数料', ads: '広告費・広告売上', adsReport: '広告費・広告売上(レポート作成)', searchTerm: '検索用語レポート', storage: '保管費', sales: '総売上' };
let savedFolder = ''; // 直近の保存先(通知表示用)
let saveFlat = true;   // 月フォルダを作らず、選んだフォルダ直下に並べる

async function notifyJobDone(month, summary, cancelled) {
  const [yy, mo] = month.split('-');
  const label = `${yy}年${Number(mo)}月`;
  const pending = summary.some((r) => r.status === 'notReady');
  const okCount = summary.filter((r) => r.status === 'ok').length;
  const bad = summary.some((r) => r.status === 'error');
  const title = cancelled
    ? `⏹ ${label} 中止しました(${okCount}/${summary.length}件 取得)`
    : bad
      ? `⚠ ${label} 一部失敗しました(${okCount}/${summary.length}件 取得)`
      : pending
        ? `⏰ ${label} 完了(未確定あり ${okCount}/${summary.length}件 取得)`
        : `✅ ${label} 保存完了(${okCount}/${summary.length}件)`;
  const body = summary
    .map((r) => `${MARK[r.status] || '❔'} ${SHORT[r.kind]}:${HEAD[r.status] || r.status}`)
    .join('\n');
  const tail = okCount > 0 && savedFolder ? `\n保存先: ${savedFolder}` : '';
  await notify(title, body + tail);
}

async function notify(title, message) {
  try {
    await chrome.notifications.create('amz_' + Date.now(), {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message: message || ' ',
      priority: 2,
    });
  } catch (e) {
    console.error('notification failed', e);
  }
}

// ───────── 保存(指定フォルダへ直接書き込み)
function dataUrlToBytes(dataUrl) {
  const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// ───────── B(広告)ファイルの中身チェック
function parseCsvLineBg(line) {
  const out = []; let cur = ''; let q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') q = false;
      else cur += c;
    } else if (c === '"') q = true;
    else if (c === ',') { out.push(cur); cur = ''; }
    else cur += c;
  }
  out.push(cur);
  return out;
}

function bStats(bytes) {
  const text = new TextDecoder('utf-8').decode(bytes);
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return null;
  const header = parseCsvLineBg(lines[0]).map((h) => h.trim().replace(/^"|"$/g, ''));
  const iName = header.findIndex((h) => h === 'キャンペーン名');
  const iCost = header.findIndex((h) => h === '合計費用');
  const iPeriod = header.findIndex((h) => h === '期間');
  const rows = [];
  for (const line of lines.slice(1)) {
    const c = parseCsvLineBg(line);
    const name = iName >= 0 ? String(c[iName] || '').trim() : '';
    const cost = iCost >= 0 ? Number(String(c[iCost] || '').replace(/[^\d.-]/g, '')) || 0 : 0;
    if (name) rows.push({ name, cost });
  }
  const spent = rows.filter((r) => r.cost > 0);
  return {
    rows: rows.length,
    spent: spent.length,
    cost: Math.round(spent.reduce((a, r) => a + r.cost, 0)),
    names: spent.map((r) => r.name),
    hasPeriodColumn: iPeriod >= 0,
  };
}

function monthKeyNow() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

// 月の途中(今月)の B は、ファイル名に「-途中」を付ける
function finalFileName(month, filename) {
  if (/^B-/.test(filename) && month === monthKeyNow()) return filename.replace(/\.csv$/, '-途中.csv');
  return filename;
}

// B を保存したあとに内訳をログに出し、前の月よりキャンペーンが減っていれば警告する
async function reportBStats(month, filename, bytes) {
  const st = bStats(bytes);
  if (!st) return;
  await log(`📊 ${filename}: ${st.rows}行 / 費用が出たキャンペーン ${st.spent}件 / 合計費用 ¥${st.cost.toLocaleString()}`);
  if (st.names.length) await log(`   対象: ${st.names.join(' , ')}`.slice(0, 400));
  if (!st.hasPeriodColumn) await log('   ※このCSVには「期間」列がありません(画面エクスポート形式)', 'warn');

  const s = await chrome.storage.local.get(['amz_bstats']);
  const all = s.amz_bstats || {};
  const prevMonths = Object.keys(all).filter((m) => m < month).sort();
  const prev = prevMonths.length ? all[prevMonths[prevMonths.length - 1]] : null;
  if (prev) {
    if (st.spent < prev.spent) {
      const lost = (prev.names || []).filter((n) => !st.names.includes(n));
      await log(`⚠ キャンペーン数が前(${prevMonths[prevMonths.length - 1]}: ${prev.spent}件)より減っています → ${st.spent}件${lost.length ? ' / 今回入っていない: ' + lost.join(' , ') : ''}`, 'warn');
      await notify('⚠ 広告レポートの確認', `${month}: 費用が出たキャンペーンが${prev.spent}件→${st.spent}件に減っています。絞り込みが残っていないか確認してください`);
    }
  }
  all[month] = { spent: st.spent, rows: st.rows, cost: st.cost, names: st.names, at: Date.now() };
  for (const k of Object.keys(all).sort().slice(0, Math.max(0, Object.keys(all).length - 36))) delete all[k];
  await chrome.storage.local.set({ amz_bstats: all });
}

async function saveToFolder(month, filename, bytes) {
  const name = finalFileName(month, filename);
  const path = await AMZ_FS.writeFile(saveFlat ? '' : month, name, bytes);
  savedFolder = path.slice(0, path.lastIndexOf('/'));
  await log(`💾 保存: ${path}`);
  if (/^B-/.test(name)) {
    try { await reportBStats(month, name, bytes); } catch (e) { await log('内訳チェックに失敗: ' + e.message, 'warn'); }
  }
  return path;
}

// ───────── メッセージ
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case 'amz_start': {
        const kinds = (msg.kinds && msg.kinds.length ? msg.kinds : ORDER).filter((k) => KINDS[k]);
        runJob(msg.months && msg.months.length ? msg.months : msg.month, kinds); // fire-and-forget
        sendResponse({ ok: true });
        break;
      }
      case 'amz_cancel':
        await patchJob({ cancel: true });
        await log('中止を受け付けました(処理中の1件が終わり次第止まります)', 'warn');
        sendResponse({ ok: true });
        break;
      case 'amz_is_cancelled': {
        const j = await getJob();
        sendResponse({ cancelled: !!(j && j.cancel) });
        break;
      }
      case 'amz_progress':
        await patchJob({ progress: msg.msg });
        sendResponse({ ok: true });
        break;
      case 'amz_save_data':
        try {
          const path = await saveToFolder(msg.month, msg.filename, dataUrlToBytes(msg.dataUrl));
          sendResponse({ ok: true, path });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      case 'amz_save_url':
        try {
          const r = await fetch(msg.url);
          if (!r.ok) throw new Error(`ファイル取得に失敗(HTTP ${r.status})`);
          const bytes = new Uint8Array(await r.arrayBuffer());
          const path = await saveToFolder(msg.month, msg.filename, bytes);
          sendResponse({ ok: true, path });
        } catch (e) { sendResponse({ ok: false, error: e.message }); }
        break;
      default:
        sendResponse({ ok: false });
    }
  })();
  return true;
});

// 拡張の再起動で「実行中」のまま固まるのを防ぐ
chrome.runtime.onStartup.addListener(() => patchJob({ running: false, current: null, progress: '' }));
chrome.runtime.onInstalled.addListener(() => patchJob({ running: false, current: null, progress: '' }));

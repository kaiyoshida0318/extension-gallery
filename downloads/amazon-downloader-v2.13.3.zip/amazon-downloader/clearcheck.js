// clearcheck.js  取得済みチェック（✓）を外すボタン（v2.13.2〜。仕様書「取得済みチェックを外すボタン」）
//   各セクション見出しの右端の <button class="mini-clear" data-status-key="…"> を押すと、そのセクションの ✓ を保存しているキーを消すだけ。
//   取得処理・ファイル・ログ・固定した日付には一切触れない。表示は各画面が storage.onChanged で読み直して「未取得」になる。
//   4種まとめてDL のチップの ✓ も suite.js が同じ変化を見て外す。
document.querySelectorAll('.mini-clear[data-status-key]').forEach((b) => {
  b.addEventListener('click', () => {
    chrome.storage.local.remove(b.dataset.statusKey, () => { void chrome.runtime.lastError; });
  });
});

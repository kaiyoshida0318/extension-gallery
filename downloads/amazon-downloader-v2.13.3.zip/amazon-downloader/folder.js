const $ = (id) => document.getElementById(id);
function say(t) { $('msg').textContent = t; }
async function render() {
  const st = await AMZ_FS.status();
  const nameEl = $('name'), stEl = $('state'), permit = $('permit');
  nameEl.textContent = st.name || '未設定';
  nameEl.className = 'state ' + (st.state === 'granted' ? 'ok' : st.state === 'none' ? 'none' : 'warn');
  const label = st.state === 'granted' ? '保存できます' : st.state === 'none' ? '（未設定）' : '許可が必要です';
  stEl.textContent = label;
  stEl.className = 'state ' + (st.state === 'granted' ? 'ok' : st.state === 'none' ? 'none' : 'warn');
  permit.style.display = (st.state === 'prompt' || st.state === 'denied') ? 'inline-block' : 'none';
  // 状態が同じ（granted→granted）でもフォルダ名が変われば他の画面に伝わるよう、名前と時刻も書く（v2.12.17）
  chrome.storage.local.set({ amz_fs_state: st.state, amz_fs_name: st.name || '', amz_fs_ts: Date.now() });
}
$('pick').addEventListener('click', async () => {
  try {
    const h = await window.showDirectoryPicker({ id: 'amz-suite-data', mode: 'readwrite' });
    await AMZ_FS.setRoot(h);
    let p = await h.queryPermission({ mode: 'readwrite' });
    if (p !== 'granted') p = await h.requestPermission({ mode: 'readwrite' });
    say(p === 'granted' ? `「${h.name}」に保存するよう設定しました。取得が終わるまで、拡張のウィンドウかこのタブのどちらかを開いたままにしてください。` : '書き込みが許可されませんでした');
  } catch (e) {
    if (e.name !== 'AbortError') say('設定できませんでした: ' + e.message);
  }
  render();
});
$('permit').addEventListener('click', async () => {
  const p = await AMZ_FS.requestPermission();
  say(p === 'granted' ? '保存を許可しました。止まっていた保存があれば続きから保存します。取得が終わるまで、拡張のウィンドウかこのタブのどちらかを開いたままにしてください。' : '許可されませんでした');
  render();
});
render();

// 作成待ちの間だけ自動で開いたタブ（keeper）なら、その旨を表示
if (new URLSearchParams(location.search).get('keeper') === '1') {
  const n = document.getElementById('keeper-note'); if (n) n.style.display = 'block';
}

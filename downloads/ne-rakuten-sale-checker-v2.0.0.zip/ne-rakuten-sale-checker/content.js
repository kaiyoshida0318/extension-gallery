/* =============================================================
 * NE 楽天セール期間チェッカー  content script
 * ネクストエンジンの受注伝票画面にボタンを追加し、
 * 受注日時が楽天のセール期間中だったかを判定する。
 * 判定後の作業チェックで、備考欄に定型メモを追記する。
 * ============================================================= */
(function () {
  'use strict';

  const DENPYO_PATH = '/Userjyuchu/jyuchuInp';
  const LIST_URL = '/Userjyuchu';
  const STORE_KEY = 'sales';
  const MSG_KEY = 'messages';
  const OPT_KEY = 'options';
  const MEMO_KEY = 'memoTemplates';
  const STAFF_KEY = 'staff';
  const FETCH_KEY = 'lastFetch';

  const DEFAULT_MESSAGES = {
    inSale: 'NEから【評価-削除】【01-実施前確認】の該当するメールを送ってください。',
    outSale: 'NEから【評価-削除】【02-実施時】の該当するメールを送って、NE＆RMSをキャンセル処理してください。'
  };

  // {date} … 作業日の月日（MMDD） / {name} … 担当者名
  const DEFAULT_MEMO = {
    inSale: '【レビュー-削除前】{date}-確認メール送信',
    outSale: '【レビュー削除】{date}-{name}-2000円以下',
    labelIn: 'メール送信完了',
    labelOut: 'メール＆キャンセル完了'
  };

  const DEFAULT_STAFF = { list: [], last: '' };

  const DEFAULT_OPTIONS = { warnNonRakuten: true, rakutenKeyword: '楽' };

  /* ---------- 日時ユーティリティ（すべて日本時間で扱う） ---------- */

  function parseNeDateTime(s) {
    const m = String(s).trim().match(
      /^(\d{4})[\/-](\d{2})[\/-](\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/
    );
    if (!m) return null;
    const d = new Date(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6] || '00'}+09:00`);
    return isNaN(d) ? null : d;
  }

  function parseNeDateRange(s) {
    const m = String(s).trim().match(/^(\d{4})[\/-](\d{2})[\/-](\d{2})$/);
    if (!m) return null;
    const base = `${m[1]}-${m[2]}-${m[3]}`;
    const start = new Date(`${base}T00:00:00+09:00`);
    const end = new Date(`${base}T23:59:59+09:00`);
    return isNaN(start) ? null : { start, end };
  }

  const JST_FMT = new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    weekday: 'short', hour12: false
  });

  function fmtJst(d) {
    if (!(d instanceof Date) || isNaN(d)) return '—';
    const p = {};
    for (const part of JST_FMT.formatToParts(d)) p[part.type] = part.value;
    return `${p.year}/${p.month}/${p.day}(${p.weekday}) ${p.hour}:${p.minute}:${p.second}`;
  }

  // 作業日（今日）の月日 MMDD
  function todayMMDD() {
    const p = {};
    const f = new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', month: '2-digit', day: '2-digit'
    });
    for (const part of f.formatToParts(new Date())) p[part.type] = part.value;
    return `${p.month}${p.day}`;
  }

  // 今月（日本時間）を YYYYMM で返す
  function currentYM() {
    const p = {};
    const f = new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit'
    });
    for (const part of f.formatToParts(new Date())) p[part.type] = part.value;
    return `${p.year}${p.month}`;
  }

  /* ---------- 設定 ---------- */

  let configPromise = null;

  function loadConfig() {
    if (configPromise) return configPromise;
    configPromise = chrome.storage.local
      .get([STORE_KEY, MSG_KEY, OPT_KEY, MEMO_KEY, STAFF_KEY, FETCH_KEY])
      .then((got) => {
        const raw = Array.isArray(got[STORE_KEY]) && got[STORE_KEY].length
          ? got[STORE_KEY]
          : (window.NE_RAKUTEN_SALE_DEFAULTS || []);
        const sales = raw
          .map((s) => ({ ...s, _start: new Date(s.start), _end: new Date(s.end) }))
          .filter((s) => !isNaN(s._start) && !isNaN(s._end))
          .sort((a, b) => a._start - b._start);
        return {
          sales,
          messages: Object.assign({}, DEFAULT_MESSAGES, got[MSG_KEY] || {}),
          options: Object.assign({}, DEFAULT_OPTIONS, got[OPT_KEY] || {}),
          memo: Object.assign({}, DEFAULT_MEMO, got[MEMO_KEY] || {}),
          staff: Object.assign({}, DEFAULT_STAFF, got[STAFF_KEY] || {}),
          lastFetch: got[FETCH_KEY] || null
        };
      });
    return configPromise;
  }

  /* ---------- 判定ロジック ---------- */

  function judgeExact(dt, sales) {
    const hit = sales.find((s) => dt >= s._start && dt <= s._end);
    return hit ? { verdict: 'in', sale: hit } : { verdict: 'out' };
  }

  function judgeDateOnly(range, sales) {
    const covering = sales.filter((s) => s._end >= range.start && s._start <= range.end);
    if (!covering.length) return { verdict: 'out' };
    const full = covering.find((s) => s._start <= range.start && s._end >= range.end);
    if (full) return { verdict: 'in', sale: full };
    return { verdict: 'ambiguous', sales: covering };
  }

  /* ---------- 受注日時の取得（先読みつき） ---------- */

  const DT_RE = /^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}:\d{2}$/;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function waitFor(fn, timeout = 15000, interval = 80) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      (function poll() {
        let v;
        try { v = fn(); } catch (e) { v = null; }
        if (v) return resolve(v);
        if (Date.now() - t0 > timeout) return reject(new Error('timeout'));
        setTimeout(poll, interval);
      })();
    });
  }

  /**
   * 受注伝票管理の一覧を非表示iframeで開き、検索できる状態まで用意しておく。
   *  - 検索APIはCSRFトークンが毎回変わるため直接は叩けない
   *  - content script は隔離ワールドなのでiframe内のページ変数には触れない
   *  → NE自身のボタンをDOMクリックする方式にしている
   */
  let warm = null;

  function prewarm() {
    if (warm) return warm;
    warm = (async () => {
      let step = '一覧の読み込み';
      const fr = document.createElement('iframe');
      fr.setAttribute('aria-hidden', 'true');
      fr.style.cssText =
        'position:fixed;left:-10000px;top:0;width:1400px;height:900px;opacity:0;pointer-events:none;border:0;';
      fr.src = LIST_URL;
      document.body.appendChild(fr);
      try {
        await new Promise((resolve, reject) => {
          fr.onload = resolve;
          fr.onerror = () => reject(new Error('読み込みエラー'));
          setTimeout(() => reject(new Error('読み込みタイムアウト')), 30000);
        });

        let doc = null;
        try { doc = fr.contentDocument; } catch (e) { doc = null; }
        if (!doc) throw new Error('ログイン切れの可能性があります。再ログインしてください');

        step = '詳細検索の起動';
        (await waitFor(() => doc.getElementById('jyuchu_dlg_open'), 20000)).click();

        step = '検索欄の準備';
        const field = await waitFor(
          () => doc.getElementsByName('sea_jyuchu_search_field01')[0], 20000);

        step = '検索条件のクリア';
        const clearBtn = doc.querySelector('[onclick*="searchJyuchu.clear"]');
        if (clearBtn) { clearBtn.click(); await sleep(500); }

        const searchBtn =
          doc.querySelector('[onclick*="searchJyuchu.search"]') ||
          doc.getElementById('ne_dlg_btn3_searchJyuchuDlg');
        if (!searchBtn) throw new Error('検索ボタンが見つかりません');

        return { frame: fr, doc, field, searchBtn };
      } catch (e) {
        fr.remove();
        warm = null;
        throw new Error(`${step}に失敗（${e && e.message ? e.message : e}）`);
      }
    })();
    return warm;
  }

  const dtCache = new Map();

  async function fetchOrderDateTime(denpyoNo, expectedDate) {
    if (dtCache.has(denpyoNo)) return dtCache.get(denpyoNo);
    let result;
    try {
      const ctx = await prewarm();
      ctx.field.value = String(denpyoNo);
      ctx.searchBtn.click();
      const raw = await waitFor(() => {
        const cells = Array.from(ctx.doc.querySelectorAll('td'));
        if (!cells.some((c) => c.innerText.trim() === String(denpyoNo))) return null;
        const dates = cells.map((c) => c.innerText.trim()).filter((v) => DT_RE.test(v));
        if (!dates.length) return null;
        const exact = expectedDate ? dates.find((v) => v.slice(0, 10) === expectedDate) : null;
        return exact || dates[0];
      }, 25000);
      result = { ok: true, raw, date: parseNeDateTime(raw) };
    } catch (e) {
      result = { ok: false, error: e && e.message ? e.message : String(e) };
    } finally {
      if (warm) { warm.then((c) => c.frame.remove()).catch(() => {}); warm = null; }
    }
    dtCache.set(denpyoNo, result);
    return result;
  }

  /* ---------- 備考欄の操作 ---------- */

  const getBikou = () => document.getElementById('bikou');

  function notifyChanged(ta) {
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // メモは備考欄の先頭に入れる（既存の内容は1行下へ送る）
  function prependBikouLine(line) {
    const ta = getBikou();
    if (!ta) return false;
    const cur = String(ta.value);
    ta.value = cur.trim() === '' ? line : line + '\n' + cur.replace(/^\s+/, '');
    notifyChanged(ta);
    flash(ta);
    return true;
  }

  function removeBikouLine(line, prefix) {
    const ta = getBikou();
    if (!ta) return false;
    const lines = String(ta.value).split('\n');
    let i = lines.lastIndexOf(line);
    if (i < 0 && prefix) {
      for (let k = lines.length - 1; k >= 0; k--) {
        if (lines[k].trim().startsWith(prefix)) { i = k; break; }
      }
    }
    if (i < 0) return false;
    lines.splice(i, 1);
    ta.value = lines.join('\n').replace(/\n+$/, '');
    notifyChanged(ta);
    flash(ta);
    return true;
  }

  function bikouHasPrefix(prefix) {
    const ta = getBikou();
    if (!ta || !prefix) return false;
    return String(ta.value).split('\n').some((l) => l.trim().startsWith(prefix));
  }

  function flash(ta) {
    try {
      ta.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      const prev = ta.style.backgroundColor;
      ta.style.transition = 'background-color .4s';
      ta.style.backgroundColor = '#fff3b0';
      setTimeout(() => { ta.style.backgroundColor = prev || ''; }, 900);
    } catch (e) { /* noop */ }
  }

  // テンプレートの「{date}より前の固定部分」＝ 追記済み判定に使う目印
  function memoPrefix(tpl) {
    const i = tpl.indexOf('{');
    return (i > 0 ? tpl.slice(0, i) : tpl).trim();
  }

  function buildMemo(tpl, name) {
    return tpl.replace(/\{date\}/g, todayMMDD()).replace(/\{name\}/g, name || '');
  }

  // 備考から「そのプレフィックスの行」を1本取り出す
  function findBikouLine(prefix) {
    const ta = getBikou();
    if (!ta || !prefix) return null;
    const lines = String(ta.value).split('\n');
    for (let i = lines.length - 1; i >= 0; i--) {
      if (lines[i].trim().startsWith(prefix)) return lines[i];
    }
    return null;
  }

  // 備考の行を差し替える（STEP1のメモ → STEP2のメモ）
  function replaceBikouLine(oldLine, newLine, prefix) {
    const ta = getBikou();
    if (!ta) return false;
    const lines = String(ta.value).split('\n');
    let i = oldLine ? lines.lastIndexOf(oldLine) : -1;
    if (i < 0 && prefix) {
      for (let k = lines.length - 1; k >= 0; k--) {
        if (lines[k].trim().startsWith(prefix)) { i = k; break; }
      }
    }
    if (i < 0) return false;
    lines[i] = newLine;
    ta.value = lines.join('\n');
    notifyChanged(ta);
    flash(ta);
    return true;
  }

  /* ---- 経過日数（STEP1のメモに入っている月日から数える） ---- */

  function jstMidnight(d) {
    const p = {};
    for (const q of new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(d)) p[q.type] = q.value;
    return new Date(`${p.year}-${p.month}-${p.day}T00:00:00+09:00`);
  }

  // 'ABCD'（MMDD）→ いちばん近い過去の日付
  function mmddToDate(mmdd) {
    const m = String(mmdd).match(/^(\d{2})(\d{2})$/);
    if (!m) return null;
    const today = jstMidnight(new Date());
    const y0 = Number(currentYM().slice(0, 4));
    for (const y of [y0, y0 - 1]) {
      const d = new Date(`${y}-${m[1]}-${m[2]}T00:00:00+09:00`);
      if (!isNaN(d) && d <= today) return d;
    }
    return null;
  }

  // STEP1のメモ行から送信日と経過日数を求める
  function step1SentInfo(prefix) {
    const line = findBikouLine(prefix);
    if (!line) return null;
    const m = line.match(/(\d{4})/);
    if (!m) return { line, date: null, days: null };
    const d = mmddToDate(m[1]);
    if (!d) return { line, date: null, days: null };
    const days = Math.round((jstMidnight(new Date()) - d) / 86400000);
    return { line, date: d, days, mmdd: m[1] };
  }

  function fmtMd(d) {
    const p = {};
    for (const q of new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', month: 'numeric', day: 'numeric'
    }).formatToParts(d)) p[q.type] = q.value;
    return `${p.month}/${p.day}`;
  }

  /* ---------- UI 部品 ---------- */

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function getDenpyoInfo() {
    const denpyo = document.getElementById('jyuchu_denpyo_no');
    const bi = document.getElementById('jyuchu_bi');
    const tenpo = document.getElementsByName('tenpo_code')[0];
    return {
      denpyoNo: denpyo ? denpyo.value.trim() : '',
      dateStr: bi ? bi.value.trim() : '',
      shop: tenpo && tenpo.selectedOptions[0] ? tenpo.selectedOptions[0].text.trim() : ''
    };
  }

  /* ---------- 配置 ---------- */

  const PANEL_RIGHT = 12, PANEL_MAX_W = 380, PANEL_MIN_W = 260;

  /**
   * ネクストエンジンのダイアログ（メール送信画面など）が開いているときは、
   * その右端にかからないように判定パネルを細くする。
   * ダイアログを閉じれば元の幅に戻る。
   */
  function blockingRightEdge() {
    let max = 0;
    // 閉じているダイアログは幅・高さが 0 になるので、それで開閉を判定する
    document.querySelectorAll('[id^="ne_dlg_"]').forEach((d) => {
      const r = d.getBoundingClientRect();
      if (r.width < 200 || r.height < 150) return;
      if (r.right > max) max = r.right;
    });
    return max;
  }

  function applyLayout() {
    const btn = document.getElementById('nersc-btn');
    if (!btn || !panel) return;
    const r = btn.getBoundingClientRect();
    const top = Math.round(r.bottom + 8);
    panel.style.top = top + 'px';
    panel.style.maxHeight = `calc(100vh - ${top + 12}px)`;

    const vw = document.documentElement.clientWidth;
    const blocked = blockingRightEdge();
    let w = PANEL_MAX_W;
    if (blocked > 0) {
      const avail = vw - PANEL_RIGHT - (blocked + 8);
      w = Math.max(PANEL_MIN_W, Math.min(PANEL_MAX_W, Math.floor(avail)));
    }
    w = Math.min(w, vw - 24);
    panel.style.width = w + 'px';
  }

  // ダイアログの開閉に追従させる（開いている間だけ軽く見張る）
  let fitTimer = null;
  function startFitWatch() {
    if (fitTimer) return;
    fitTimer = setInterval(() => {
      if (!panel || !panel.classList.contains('nersc-open')) {
        clearInterval(fitTimer); fitTimer = null; return;
      }
      applyLayout();
    }, 600);
  }

  let layoutTimer = null;
  function scheduleLayout(delay) {
    clearTimeout(layoutTimer);
    layoutTimer = setTimeout(applyLayout, delay || 0);
  }

  let panel, panelBody;
  let pendingAction = false;
  let updateDone = false;   // 伝票更新が完了したか（完了後は外側クリックで閉じられる）

  /**
   * 「伝票更新」の完了を見張る。
   * 更新はAjaxでページが再読み込みされないため、最終更新日（saisyu_kousin_bi）が
   * 書き換わったことをもって「更新された」と判断する。
   */
  function watchDenpyoUpdate() {
    const btn = document.getElementById('syusei_btn');
    const stamp = document.getElementById('saisyu_kousin_bi');
    if (!btn || !stamp) return;

    btn.addEventListener('click', () => {
      if (updateDone) return;
      const before = stamp.value;
      const t0 = Date.now();
      const timer = setInterval(() => {
        if (stamp.value !== before) {
          clearInterval(timer);
          updateDone = true;
          if (panel && panel.classList.contains('nersc-open') && panelBody) {
            const n = el('div', 'nersc-updated',
              '伝票を更新しました。伝票内をクリックするとこのパネルは閉じます。');
            panelBody.appendChild(n);
          }
        } else if (Date.now() - t0 > 60000) {
          clearInterval(timer);
        }
      }, 400);
    }, true);
  }

  function ensurePanel() {
    if (panel) return panel;
    panel = el('div', 'nersc-panel');
    const head = el('div', 'nersc-head');
    head.appendChild(el('span', 'nersc-title', '楽天セール期間 判定'));
    const close = el('button', 'nersc-close', '×');
    close.title = '閉じる';
    close.addEventListener('click', () => panel.classList.remove('nersc-open'));
    head.appendChild(close);
    panel.appendChild(head);
    panelBody = el('div', 'nersc-body');
    panel.appendChild(panelBody);
    document.body.appendChild(panel);

    // 伝票更新をするまでは、伝票内をクリックしても閉じない
    //（判定を見ながら作業できるようにするため）。
    // 伝票更新が終わったあとは、伝票内のクリックで閉じる。
    document.addEventListener('mousedown', (ev) => {
      if (!panel.classList.contains('nersc-open')) return;
      if (!updateDone) return;
      const t = ev.target;
      if (panel.contains(t)) return;
      const btn = document.getElementById('nersc-btn');
      if (btn && btn.contains(t)) return;
      panel.classList.remove('nersc-open');
    }, true);

    document.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape' && panel.classList.contains('nersc-open')) {
        panel.classList.remove('nersc-open');
      }
    }, true);

    applyLayout();
    return panel;
  }

  function showPanel(nodes) {
    ensurePanel();
    panelBody.innerHTML = '';
    (Array.isArray(nodes) ? nodes : [nodes]).forEach((n) => panelBody.appendChild(n));
    panel.classList.add('nersc-open');
    applyLayout();
    startFitWatch();
  }

  function kv(label, value) {
    const row = el('div', 'nersc-kv');
    row.appendChild(el('span', 'nersc-k', label));
    const v = el('span', 'nersc-v', value);
    row.appendChild(v);
    row._value = v;
    return row;
  }

  function verdictBox(kind, headline, action) {
    const box = el('div', `nersc-verdict nersc-${kind}`);
    box.appendChild(el('div', 'nersc-verdict-head', headline));
    if (action) box.appendChild(el('div', 'nersc-verdict-action', action));
    return box;
  }

  /* ---------- 作業チェック欄 ---------- */

  /**
   * 選んだ担当者を保存する。選び直すまでこの人が初期選択になる。
   * addToList=true なら、リストに無い名前を末尾に追加する。
   */
  function rememberStaff(cfg, name, addToList) {
    if (!name) return;
    const list = (cfg.staff.list || []).slice();
    if (addToList && !list.includes(name)) list.push(name);
    cfg.staff.list = list;
    cfg.staff.last = name;                       // 画面内のキャッシュも更新
    chrome.storage.local.set({ [STAFF_KEY]: { list, last: name } });
  }

  /* ---- 担当者の選択行 ---- */

  function buildStaffRow(cfg, onChange) {
    const row = el('div', 'nersc-staffrow');
    row.appendChild(el('span', 'nersc-staff-label', '担当者'));

    const sel = document.createElement('select');
    sel.className = 'nersc-staff-select';
    const names = (cfg.staff.list || []).filter(Boolean);
    if (!names.length) {
      const o = document.createElement('option');
      o.value = ''; o.textContent = '（未登録）';
      sel.appendChild(o);
    }
    names.forEach((n) => {
      const o = document.createElement('option');
      o.value = n; o.textContent = n;
      sel.appendChild(o);
    });
    const other = document.createElement('option');
    other.value = '__other__'; other.textContent = '＋ 直接入力';
    sel.appendChild(other);
    if (cfg.staff.last && names.includes(cfg.staff.last)) sel.value = cfg.staff.last;
    row.appendChild(sel);

    const free = document.createElement('input');
    free.type = 'text';
    free.className = 'nersc-staff-input';
    free.placeholder = '担当者名';
    free.hidden = true;
    row.appendChild(free);

    const edit = el('button', 'nersc-staff-edit', '編集');
    edit.type = 'button';
    edit.title = '担当者リストを追加・削除・編集する（設定画面が開きます）';
    edit.addEventListener('click', () => {
      try { chrome.runtime.sendMessage({ type: 'openOptions' }); } catch (e) { /* noop */ }
    });
    row.appendChild(edit);

    sel.addEventListener('change', () => {
      free.hidden = sel.value !== '__other__';
      if (!free.hidden) free.focus();
      if (sel.value && sel.value !== '__other__') rememberStaff(cfg, sel.value);
      if (onChange) onChange();
    });
    free.addEventListener('input', () => { if (onChange) onChange(); });
    free.addEventListener('change', () => {
      const v = free.value.trim();
      if (!v) return;
      rememberStaff(cfg, v, true);
      if (![...sel.options].some((o) => o.value === v)) {
        const o = document.createElement('option');
        o.value = v; o.textContent = v;
        sel.insertBefore(o, other);
      }
      const ph = [...sel.options].find((o) => o.textContent === '（未登録）');
      if (ph) ph.remove();
      sel.value = v;
      free.value = '';
      free.hidden = true;
      if (onChange) onChange();
    });

    const current = () => (sel.value === '__other__' ? free.value.trim() : sel.value);
    return { row, current, setDisabled(d) { sel.disabled = d; free.disabled = d; edit.disabled = d; } };
  }

  /* ---- セール期間外：1ステップだけ ---- */

  function buildActionBlock(cfg) {
    const tpl = cfg.memo.outSale;
    const prefix = memoPrefix(tpl);
    const wrap = el('div', 'nersc-action');

    const staff = buildStaffRow(cfg, () => updatePreview());
    wrap.appendChild(staff.row);

    const cbRow = el('div', 'nersc-cbrow');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'nersc-cb';
    cbRow.appendChild(cb);
    cbRow.appendChild(el('span', 'nersc-cb-label', cfg.memo.labelOut));
    wrap.appendChild(cbRow);

    const preview = el('div', 'nersc-preview');
    wrap.appendChild(preview);
    const status = el('div', 'nersc-status');
    wrap.appendChild(status);

    function updatePreview() {
      preview.textContent = '備考に追記される内容： ' + buildMemo(tpl, staff.current() || '〇〇');
    }
    updatePreview();

    if (bikouHasPrefix(prefix)) {
      cb.checked = true;
      status.textContent = 'この伝票の備考には、すでに同じ種類のメモが入っています。';
      status.className = 'nersc-status nersc-status-done';
    }

    let inserted = null;
    cb.addEventListener('change', () => {
      if (cb.checked) {
        const name = staff.current();
        if (!name) { alert('担当者を選ぶか、直接入力してください。'); cb.checked = false; return; }
        const line = buildMemo(tpl, name);
        if (!prependBikouLine(line)) { alert('備考欄が見つかりませんでした。'); cb.checked = false; return; }
        inserted = line;
        status.textContent = '備考欄に追記しました。「伝票更新」を押して保存してください。';
        status.className = 'nersc-status nersc-status-done';
        rememberStaff(cfg, name, true);
      } else {
        const ok = removeBikouLine(inserted, prefix);
        status.textContent = ok ? '備考欄から取り消しました。' : '備考欄に該当する行が見つかりませんでした。';
        status.className = 'nersc-status';
        inserted = null;
      }
    });
    return wrap;
  }

  /* ---- セール期間中：2ステップ ----
   *  STEP1 … 全額返金してよいか確認するメールを送る → 備考に【レビュー-削除前】
   *  STEP2 … 1週間返信がなければキャンセル・返金 → 備考を【レビュー削除】に置き換える
   *  STEP2 は STEP1 が終わるまで押せない。
   */

  const WAIT_DAYS = 7;

  function buildInSaleSteps(cfg) {
    const tpl1 = cfg.memo.inSale;
    const tpl2 = cfg.memo.outSale;
    const p1 = memoPrefix(tpl1);
    const p2 = memoPrefix(tpl2);

    const wrap = el('div', 'nersc-steps');

    /* ---- STEP 1 ---- */
    const s1 = el('div', 'nersc-step');
    const h1 = el('div', 'nersc-step-head');
    h1.appendChild(el('span', 'nersc-step-no', 'STEP 1'));
    h1.appendChild(el('span', 'nersc-step-title', '確認メールを送る'));
    s1.appendChild(h1);

    const cb1Row = el('div', 'nersc-cbrow');
    const cb1 = document.createElement('input');
    cb1.type = 'checkbox'; cb1.className = 'nersc-cb';
    cb1Row.appendChild(cb1);
    cb1Row.appendChild(el('span', 'nersc-cb-label', cfg.memo.labelIn));
    s1.appendChild(cb1Row);
    const pv1 = el('div', 'nersc-preview', '備考に追記される内容： ' + buildMemo(tpl1, ''));
    s1.appendChild(pv1);
    const st1 = el('div', 'nersc-status');
    s1.appendChild(st1);
    wrap.appendChild(s1);

    /* ---- STEP 2 ---- */
    const s2 = el('div', 'nersc-step');
    const h2 = el('div', 'nersc-step-head');
    h2.appendChild(el('span', 'nersc-step-no', 'STEP 2'));
    h2.appendChild(el('span', 'nersc-step-title', `返信がなければ${WAIT_DAYS}日後にキャンセル・返金`));
    s2.appendChild(h2);

    const staff = buildStaffRow(cfg, () => updatePv2());
    s2.appendChild(staff.row);

    const cb2Row = el('div', 'nersc-cbrow');
    const cb2 = document.createElement('input');
    cb2.type = 'checkbox'; cb2.className = 'nersc-cb';
    cb2Row.appendChild(cb2);
    cb2Row.appendChild(el('span', 'nersc-cb-label', cfg.memo.labelOut));
    s2.appendChild(cb2Row);
    const pv2 = el('div', 'nersc-preview');
    s2.appendChild(pv2);
    const st2 = el('div', 'nersc-status');
    s2.appendChild(st2);
    wrap.appendChild(s2);

    function updatePv2() {
      pv2.textContent = '備考が置き換わる内容： ' + buildMemo(tpl2, staff.current() || '〇〇');
    }
    updatePv2();

    let step1Line = null;   // STEP2で置き換える前のSTEP1の行

    function refresh() {
      const done1 = bikouHasPrefix(p1);
      const done2 = bikouHasPrefix(p2);

      cb1.checked = done1 || done2;
      cb1.disabled = done2;                 // STEP2まで進んだらSTEP1は触らせない
      s1.classList.toggle('nersc-step-done', done1 || done2);

      const info = done1 ? step1SentInfo(p1) : null;
      if (done2) {
        st1.textContent = 'STEP2が完了したため、備考はSTEP2の内容に置き換わっています。';
        st1.className = 'nersc-status nersc-status-done';
      } else if (info && info.date) {
        st1.textContent = `${fmtMd(info.date)} に送信済み（${info.days}日経過）`;
        st1.className = 'nersc-status nersc-status-done';
      } else if (done1) {
        st1.textContent = '送信済み';
        st1.className = 'nersc-status nersc-status-done';
      } else {
        st1.textContent = '';
        st1.className = 'nersc-status';
      }

      // STEP2はSTEP1が終わるまで使えない
      const usable = done1 || done2;
      cb2.disabled = !usable;
      staff.setDisabled(!usable);
      s2.classList.toggle('nersc-step-locked', !usable);
      s2.classList.toggle('nersc-step-done', done2);
      cb2.checked = done2;

      if (!usable) {
        st2.textContent = 'STEP1を終えると入力できるようになります。';
        st2.className = 'nersc-status';
      } else if (done2) {
        st2.textContent = '備考欄を置き換えました。「伝票更新」を押して保存してください。';
        st2.className = 'nersc-status nersc-status-done';
      } else if (info && info.days != null && info.days < WAIT_DAYS) {
        st2.textContent = `メール送信から${info.days}日です。${WAIT_DAYS}日経過していません。`;
        st2.className = 'nersc-status nersc-status-warn';
      } else if (info && info.days != null) {
        st2.textContent = `${info.days}日経過しています。返信がなければ処理してください。`;
        st2.className = 'nersc-status';
      } else {
        st2.textContent = '';
        st2.className = 'nersc-status';
      }
    }

    cb1.addEventListener('change', () => {
      if (cb1.checked) {
        const line = buildMemo(tpl1, '');
        if (!prependBikouLine(line)) { alert('備考欄が見つかりませんでした。'); cb1.checked = false; return; }
        step1Line = line;
      } else {
        removeBikouLine(step1Line, p1);
        step1Line = null;
      }
      refresh();
    });

    cb2.addEventListener('change', () => {
      if (cb2.checked) {
        const name = staff.current();
        if (!name) { alert('担当者を選ぶか、直接入力してください。'); cb2.checked = false; return; }
        const info = step1SentInfo(p1);
        const old = info ? info.line : step1Line;
        if (info && info.days != null && info.days < WAIT_DAYS) {
          if (!confirm(`メール送信から${info.days}日しか経っていません。\nこのままキャンセル・返金の記録を残しますか？`)) {
            cb2.checked = false; return;
          }
        }
        const line = buildMemo(tpl2, name);
        if (!replaceBikouLine(old, line, p1)) {
          alert('備考欄にSTEP1のメモが見つかりませんでした。');
          cb2.checked = false; return;
        }
        step1Line = old;
        rememberStaff(cfg, name, true);
      } else {
        // STEP1のメモに戻す（元の行が分からない場合は今日の日付で作り直す）
        const back = step1Line || buildMemo(tpl1, '');
        replaceBikouLine(null, back, p2);
      }
      refresh();
    });

    refresh();
    return wrap;
  }


  /* ---------- 結果の組み立て ---------- */

  // 月が変わったら「今月分のセール日程を取り込みましょう」と案内する
  function monthlyFetchNotice(cfg) {
    const ym = currentYM();
    if (cfg.lastFetch && cfg.lastFetch.ym === ym) return null;
    const box = el('div', 'nersc-fetch-notice');
    const y = ym.slice(0, 4), m = String(Number(ym.slice(4)));
    box.appendChild(el('span', 'nersc-fetch-text',
      `${y}年${m}月分のセール日程がまだ取り込まれていません。`));
    const b = el('button', 'nersc-fetch-btn', '設定を開いて取得');
    b.type = 'button';
    b.addEventListener('click', () => {
      try { chrome.runtime.sendMessage({ type: 'openOptions' }); } catch (e) { /* noop */ }
    });
    box.appendChild(b);
    return box;
  }

  function buildResultNodes(cfg, info, dtRow, res, extra) {
    const nodes = [];
    pendingAction = false;

    const notice = monthlyFetchNotice(cfg);
    if (notice) nodes.push(notice);

    if (cfg.options.warnNonRakuten &&
        info.shop && !info.shop.includes(cfg.options.rakutenKeyword)) {
      nodes.push(el('div', 'nersc-warn',
        `この伝票の店舗は「${info.shop}」です。楽天以外の店舗の可能性があります。`));
    }
    nodes.push(kv('伝票番号', info.denpyoNo));
    if (info.shop) nodes.push(kv('店舗', info.shop));
    nodes.push(dtRow);

    if (res.verdict === 'in') {
      nodes.push(verdictBox('in', `セール期間中！（${res.sale.name}）`, cfg.messages.inSale));
      if (res.sale.confidence && res.sale.confidence !== 'high') {
        nodes.push(el('div', 'nersc-warn',
          `この期間データの確度は「${res.sale.confidence}」です。${res.sale.note || ''} 念のため楽天側でご確認ください。`));
      }
      nodes.push(buildInSaleSteps(cfg));
    } else if (res.verdict === 'out') {
      nodes.push(verdictBox('out', 'セール期間中ではない！', cfg.messages.outSale));
      nodes.push(buildActionBlock(cfg));
    } else {
      const s = res.sales[0];
      nodes.push(verdictBox('amb', '判定できません（セールの開始日／最終日）',
        `${s.name}と同じ日の注文です。時刻によって結果が変わるため、受注伝票管理の一覧で受注日時をご確認ください。`));
    }
    (extra || []).forEach((n) => nodes.push(n));
    return nodes;
  }

  /* ---------- メイン処理 ---------- */

  async function runCheck(btn) {
    const info = getDenpyoInfo();
    if (!info.denpyoNo) {
      showPanel(el('div', 'nersc-note', '伝票番号が取得できませんでした。'));
      return;
    }

    const cfg = await loadConfig();
    const range = parseNeDateRange(info.dateStr);
    const quick = range ? judgeDateOnly(range, cfg.sales) : { verdict: 'ambiguous', sales: [] };

    // 日付だけで結論が出るケース（大多数）は待たずに即表示
    if (quick.verdict !== 'ambiguous') {
      const dtRow = kv('受注日時', `${info.dateStr}  （時刻を取得中…）`);
      showPanel(buildResultNodes(cfg, info, dtRow, quick));
      fetchOrderDateTime(info.denpyoNo, info.dateStr).then((r) => {
        if (!dtRow.isConnected) return;
        dtRow._value.textContent = (r.ok && r.date) ? fmtJst(r.date) : info.dateStr;
      }).catch(() => {
        if (dtRow.isConnected) dtRow._value.textContent = info.dateStr;
      });
      return;
    }

    // 開始日／最終日は時刻が要る
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = '判定中…';
    showPanel(el('div', 'nersc-note', 'セールの開始日／最終日のため、受注日時を確認しています…'));

    try {
      const lookup = await fetchOrderDateTime(info.denpyoNo, info.dateStr);
      if (lookup.ok && lookup.date) {
        showPanel(buildResultNodes(cfg, info, kv('受注日時', fmtJst(lookup.date)),
          judgeExact(lookup.date, cfg.sales)));
      } else {
        showPanel(buildResultNodes(cfg, info, kv('受注日', info.dateStr || '—'), quick, [
          el('div', 'nersc-warn',
            `受注日時（時刻）の取得に失敗しました：${lookup.error || '原因不明'}`)
        ]));
      }
    } catch (e) {
      showPanel(el('div', 'nersc-warn', `エラーが発生しました: ${e.message}`));
    } finally {
      btn.disabled = false;
      btn.textContent = label;
    }
  }

  /* ---------- 起動 ---------- */

  function injectButton() {
    if (document.getElementById('nersc-btn')) return;
    // CSS の white-space: pre-line と組み合わせて「楽天セール / 判定」の2行にする
    const btn = el('button', 'nersc-btn', '楽天セール\n判定');
    btn.id = 'nersc-btn';
    btn.type = 'button';
    btn.title = 'この注文が楽天のセール期間中だったかを判定します';
    btn.addEventListener('click', () => runCheck(btn));
    const warmUp = () => { prewarm().catch(() => {}); };
    btn.addEventListener('mouseenter', warmUp, { once: true });
    btn.addEventListener('focus', warmUp, { once: true });
    document.body.appendChild(btn);

    applyLayout();
    scheduleLayout(1200);
    window.addEventListener('load', () => scheduleLayout(200));
    window.addEventListener('resize', () => scheduleLayout(150));

    watchDenpyoUpdate();

    // 月が変わっていないかを確認してツールバーのバッジを更新してもらう
    try { chrome.runtime.sendMessage({ type: 'checkMonth' }); } catch (e) { /* noop */ }

    loadConfig().then((cfg) => {
      const range = parseNeDateRange(getDenpyoInfo().dateStr);
      if (range && judgeDateOnly(range, cfg.sales).verdict === 'ambiguous') warmUp();
    }).catch(() => {});
  }

  function boot() {
    if (!location.pathname.startsWith(DENPYO_PATH)) return;
    waitFor(() => document.getElementById('jyuchu_denpyo_no'), 20000, 150)
      .then(injectButton)
      .catch(() => {});
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();

/* NE 楽天セール期間チェッカー  service worker */

const FETCH_KEY = 'lastFetch';

// ツールバーアイコンをクリックしたら設定画面を開く
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});

function currentYM() {
  const p = {};
  for (const part of new Intl.DateTimeFormat('ja-JP', {
    timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit'
  }).formatToParts(new Date())) p[part.type] = part.value;
  return `${p.year}${p.month}`;
}

/**
 * 今月分のセール日程をまだ取り込んでいなければ、
 * ツールバーのアイコンに「!」バッジを出して知らせる。
 */
async function updateBadge() {
  try {
    const got = await chrome.storage.local.get([FETCH_KEY]);
    const lf = got[FETCH_KEY];
    const needs = !lf || lf.ym !== currentYM();
    await chrome.action.setBadgeText({ text: needs ? '!' : '' });
    if (needs) {
      await chrome.action.setBadgeBackgroundColor({ color: '#bf0000' });
      await chrome.action.setTitle({
        title: '今月分の楽天セール日程がまだ取り込まれていません（クリックで設定画面）'
      });
    } else {
      await chrome.action.setTitle({ title: 'NE 楽天セール期間チェッカーの設定を開く' });
    }
  } catch (e) { /* noop */ }
}

chrome.runtime.onInstalled.addListener(updateBadge);
chrome.runtime.onStartup.addListener(updateBadge);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[FETCH_KEY]) updateBadge();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  // 判定パネルの「設定を開く」「編集」から
  if (msg.type === 'openOptions') {
    chrome.runtime.openOptionsPage();
    sendResponse({ ok: true });
    return false;
  }
  // 伝票を開くたびに月をチェックしてバッジを更新する
  if (msg.type === 'checkMonth') {
    updateBadge();
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

updateBadge();

/*
 * 楽天市場 セール期間データ（初期値）
 * ------------------------------------------------------------------
 * ここは「工場出荷時の初期データ」です。
 * 実際に判定で使われるのは chrome.storage に保存されたデータで、
 * 設定画面（拡張機能アイコンをクリック）からいつでも編集・追加できます。
 *
 * 収録対象は以下の4種類に限定しています。
 *   ・楽天お買い物マラソン
 *   ・楽天スーパーSALE
 *   ・楽天ブラックフライデー
 *   ・楽天大感謝祭
 *
 * start / end は日本時間（+09:00）で書いてください。
 * 楽天のセールは通常「開始日 20:00:00 〜 最終日 01:59:59」です。
 * （4月中旬・4月下旬・8月下旬・10月中旬・10月下旬の短期マラソンは終了が 09:59:59）
 *
 * confidence:
 *   high   … 楽天カレンダー等の複数ソースで一致
 *   medium … おおむね確からしいが単独ソース寄り
 *   low    … 要確認。判定結果に注意表示が出ます
 */
window.NE_RAKUTEN_SALE_DEFAULTS = [
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-01-09T20:00:00+09:00","end":"2024-01-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-01-24T20:00:00+09:00","end":"2024-01-28T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-02-04T20:00:00+09:00","end":"2024-02-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-02-19T20:00:00+09:00","end":"2024-02-23T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2024-03-04T20:00:00+09:00","end":"2024-03-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-03-21T20:00:00+09:00","end":"2024-03-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-04-04T20:00:00+09:00","end":"2024-04-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-04-14T20:00:00+09:00","end":"2024-04-17T09:59:59+09:00","confidence":"high","note":"短期開催。終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-04-24T20:00:00+09:00","end":"2024-04-27T09:59:59+09:00","confidence":"high","note":"短期開催。終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-05-09T20:00:00+09:00","end":"2024-05-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-05-23T20:00:00+09:00","end":"2024-05-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2024-06-04T20:00:00+09:00","end":"2024-06-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-06-22T20:00:00+09:00","end":"2024-06-26T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-07-04T20:00:00+09:00","end":"2024-07-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-07-19T20:00:00+09:00","end":"2024-07-26T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-08-04T20:00:00+09:00","end":"2024-08-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-08-24T20:00:00+09:00","end":"2024-08-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2024-09-04T20:00:00+09:00","end":"2024-09-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-09-19T20:00:00+09:00","end":"2024-09-24T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-10-04T20:00:00+09:00","end":"2024-10-09T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-10-14T20:00:00+09:00","end":"2024-10-17T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-10-24T20:00:00+09:00","end":"2024-10-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2024-11-04T20:00:00+09:00","end":"2024-11-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天ブラックフライデー","type":"blackfriday","start":"2024-11-21T20:00:00+09:00","end":"2024-11-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2024-12-04T20:00:00+09:00","end":"2024-12-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天大感謝祭","type":"daikanshasai","start":"2024-12-19T20:00:00+09:00","end":"2024-12-26T01:59:59+09:00","confidence":"high","note":""},

  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-01-09T20:00:00+09:00","end":"2025-01-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-01-24T20:00:00+09:00","end":"2025-01-29T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-02-04T20:00:00+09:00","end":"2025-02-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-02-19T20:00:00+09:00","end":"2025-02-23T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2025-03-04T20:00:00+09:00","end":"2025-03-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-03-21T20:00:00+09:00","end":"2025-03-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-04-04T20:00:00+09:00","end":"2025-04-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-04-14T20:00:00+09:00","end":"2025-04-17T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-04-24T20:00:00+09:00","end":"2025-04-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-05-09T20:00:00+09:00","end":"2025-05-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-05-23T20:00:00+09:00","end":"2025-05-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2025-06-04T20:00:00+09:00","end":"2025-06-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-06-22T20:00:00+09:00","end":"2025-06-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-07-04T20:00:00+09:00","end":"2025-07-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-07-19T20:00:00+09:00","end":"2025-07-26T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-08-04T20:00:00+09:00","end":"2025-08-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-08-24T20:00:00+09:00","end":"2025-08-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2025-09-04T20:00:00+09:00","end":"2025-09-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-09-19T20:00:00+09:00","end":"2025-09-24T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-10-04T20:00:00+09:00","end":"2025-10-09T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-10-14T20:00:00+09:00","end":"2025-10-17T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-10-24T20:00:00+09:00","end":"2025-10-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2025-11-04T20:00:00+09:00","end":"2025-11-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天ブラックフライデー","type":"blackfriday","start":"2025-11-20T20:00:00+09:00","end":"2025-11-27T01:59:59+09:00","confidence":"high","note":"エントリーは11/12 10:00〜。ポイントアップ期間は11/20 20:00〜"},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2025-12-04T20:00:00+09:00","end":"2025-12-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天大感謝祭","type":"daikanshasai","start":"2025-12-19T20:00:00+09:00","end":"2025-12-26T01:59:59+09:00","confidence":"high","note":""},

  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-01-09T20:00:00+09:00","end":"2026-01-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-01-24T20:00:00+09:00","end":"2026-01-29T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-02-04T20:00:00+09:00","end":"2026-02-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-02-19T20:00:00+09:00","end":"2026-02-23T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2026-03-04T20:00:00+09:00","end":"2026-03-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-03-20T20:00:00+09:00","end":"2026-03-26T01:59:59+09:00","confidence":"high","note":"2026年は20日開始"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-04-04T20:00:00+09:00","end":"2026-04-10T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-04-14T20:00:00+09:00","end":"2026-04-17T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-04-24T20:00:00+09:00","end":"2026-04-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-05-09T20:00:00+09:00","end":"2026-05-16T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-05-23T20:00:00+09:00","end":"2026-05-27T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2026-06-04T20:00:00+09:00","end":"2026-06-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-06-20T20:00:00+09:00","end":"2026-06-26T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-07-04T20:00:00+09:00","end":"2026-07-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-07-19T20:00:00+09:00","end":"2026-07-26T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-08-04T20:00:00+09:00","end":"2026-08-11T01:59:59+09:00","confidence":"high","note":""},
  {"name":"楽天お買い物マラソン","type":"marathon","start":"2026-08-24T20:00:00+09:00","end":"2026-08-27T09:59:59+09:00","confidence":"high","note":"終了が09:59"},
  {"name":"楽天スーパーSALE","type":"supersale","start":"2026-09-04T20:00:00+09:00","end":"2026-09-11T01:59:59+09:00","confidence":"high","note":"公式告知済み。モバイル会員先行は9/3 20:00〜9/4 19:59"}
];

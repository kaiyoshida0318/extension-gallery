/* NE 楽天セール期間チェッカー 設定画面 */
(function () {
  'use strict';

  const STORE_KEY = 'sales';
  const MSG_KEY = 'messages';
  const OPT_KEY = 'options';

  const DEFAULT_MESSAGES = {
    inSale: 'NEから【評価-削除】【01-実施前確認】の該当するメールを送ってください。',
    outSale: 'NEから【評価-削除】【02-実施時】の該当するメールを送って、NE＆RMSをキャンセル処理してください。'
  };
  const DEFAULT_OPTIONS = { warnNonRakuten: true, rakutenKeyword: '楽' };

  const MEMO_KEY = 'memoTemplates';
  const STAFF_KEY = 'staff';
  const DEFAULT_MEMO = {
    inSale: '【レビュー-削除前】{date}-確認メール送信',
    outSale: '【レビュー削除】{date}-{name}-2000円以下',
    labelIn: 'メール送信完了',
    labelOut: 'メール＆キャンセル完了'
  };
  const DEFAULT_STAFF = { list: [], last: '' };

  const FETCH_KEY = 'lastFetch';

  function currentYM() {
    const p = {};
    for (const part of new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit'
    }).formatToParts(new Date())) p[part.type] = part.value;
    return `${p.year}${p.month}`;
  }

  function todayMMDD() {
    const p = {};
    for (const part of new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date())) p[part.type] = part.value;
    return `${p.month}${p.day}`;
  }

  function renderMemoPreview() {
    const names = ($('staffList').value || '').split('\n').map((s) => s.trim()).filter(Boolean);
    const sample = names[0] || '〇〇';
    const f = (t) => t.replace(/\{date\}/g, todayMMDD()).replace(/\{name\}/g, sample);
    $('memoPreview').innerHTML =
      '今日の日付で入る内容：<br>' +
      '　セール期間中 → <b>' + f($('memoIn').value) + '</b><br>' +
      '　セール期間外 → <b>' + f($('memoOut').value) + '</b>';
  }

  const TYPES = [
    ['supersale', 'スーパーSALE'],
    ['marathon', 'お買い物マラソン'],
    ['blackfriday', 'ブラックフライデー'],
    ['daikanshasai', '大感謝祭'],
    ['other', 'その他']
  ];
  const CONFS = ['high', 'medium', 'low'];

  const $ = (id) => document.getElementById(id);
  const tbody = document.querySelector('#tbl tbody');

  /* ---- ISO(+09:00) <-> datetime-local(JST) ---- */

  function isoToLocalInput(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '';
    const p = {};
    for (const part of new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Tokyo',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    }).formatToParts(d)) p[part.type] = part.value;
    const hour = p.hour === '24' ? '00' : p.hour;
    return `${p.year}-${p.month}-${p.day}T${hour}:${p.minute}:${p.second}`;
  }

  function localInputToIso(v) {
    if (!v) return '';
    const s = v.length === 16 ? v + ':00' : v;
    return s + '+09:00';
  }

  /* ---- 表の描画 ---- */

  function addRow(item) {
    const tr = document.createElement('tr');

    const tdName = document.createElement('td');
    const name = document.createElement('input');
    name.type = 'text';
    name.value = item.name || '';
    name.className = 'f-name';
    tdName.appendChild(name);

    const tdType = document.createElement('td');
    const type = document.createElement('select');
    type.className = 'f-type';
    TYPES.forEach(([v, label]) => {
      const o = document.createElement('option');
      o.value = v; o.textContent = label;
      type.appendChild(o);
    });
    type.value = item.type || 'other';
    tdType.appendChild(type);

    const tdStart = document.createElement('td');
    const start = document.createElement('input');
    start.type = 'datetime-local'; start.step = '1';
    start.value = isoToLocalInput(item.start);
    start.className = 'f-start';
    tdStart.appendChild(start);

    const tdEnd = document.createElement('td');
    const end = document.createElement('input');
    end.type = 'datetime-local'; end.step = '1';
    end.value = isoToLocalInput(item.end);
    end.className = 'f-end';
    tdEnd.appendChild(end);

    const tdConf = document.createElement('td');
    const conf = document.createElement('select');
    conf.className = 'f-conf';
    CONFS.forEach((c) => {
      const o = document.createElement('option');
      o.value = c; o.textContent = c;
      conf.appendChild(o);
    });
    conf.value = item.confidence || 'high';
    tdConf.appendChild(conf);

    const tdDel = document.createElement('td');
    const del = document.createElement('button');
    del.className = 'tiny';
    del.textContent = '削除';
    del.addEventListener('click', () => tr.remove());
    tdDel.appendChild(del);

    tr.dataset.note = item.note || '';
    if ((item.confidence || 'high') === 'low') tr.className = 'conf-low';
    conf.addEventListener('change', () => {
      tr.className = conf.value === 'low' ? 'conf-low' : '';
    });

    [tdName, tdType, tdStart, tdEnd, tdConf, tdDel].forEach((td) => tr.appendChild(td));
    tbody.appendChild(tr);
  }

  function render(list) {
    tbody.innerHTML = '';
    list.forEach(addRow);
  }

  function collect() {
    return Array.from(tbody.querySelectorAll('tr')).map((tr) => ({
      name: tr.querySelector('.f-name').value.trim(),
      type: tr.querySelector('.f-type').value,
      start: localInputToIso(tr.querySelector('.f-start').value),
      end: localInputToIso(tr.querySelector('.f-end').value),
      confidence: tr.querySelector('.f-conf').value,
      note: tr.dataset.note || ''
    })).filter((x) => x.name && x.start && x.end);
  }

  /* ---- 読み込み・保存 ---- */

  async function load() {
    const got = await chrome.storage.local.get([STORE_KEY, MSG_KEY, OPT_KEY, MEMO_KEY, STAFF_KEY]);
    const sales = Array.isArray(got[STORE_KEY]) && got[STORE_KEY].length
      ? got[STORE_KEY]
      : (window.NE_RAKUTEN_SALE_DEFAULTS || []);
    render(sales);

    const msg = Object.assign({}, DEFAULT_MESSAGES, got[MSG_KEY] || {});
    $('msgIn').value = msg.inSale;
    $('msgOut').value = msg.outSale;

    const opt = Object.assign({}, DEFAULT_OPTIONS, got[OPT_KEY] || {});
    $('warnNonRakuten').checked = !!opt.warnNonRakuten;
    $('rakutenKeyword').value = opt.rakutenKeyword;

    const memo = Object.assign({}, DEFAULT_MEMO, got[MEMO_KEY] || {});
    $('memoIn').value = memo.inSale;
    $('memoOut').value = memo.outSale;
    $('labelIn').value = memo.labelIn;
    $('labelOut').value = memo.labelOut;

    const staff = Object.assign({}, DEFAULT_STAFF, got[STAFF_KEY] || {});
    $('staffList').value = (staff.list || []).join('\n');

    ['memoIn', 'memoOut', 'staffList'].forEach((id) =>
      $(id).addEventListener('input', renderMemoPreview));
    renderMemoPreview();
    renderFetchState();
  }

  async function save() {
    const sales = collect();
    const bad = sales.find((s) => new Date(s.start) > new Date(s.end));
    if (bad) {
      alert(`「${bad.name}」の開始が終了より後になっています。`);
      return;
    }
    const prev = await chrome.storage.local.get([STAFF_KEY]);
    const names = ($('staffList').value || '').split('\n').map((s) => s.trim()).filter(Boolean);

    await chrome.storage.local.set({
      [STORE_KEY]: sales,
      [MSG_KEY]: { inSale: $('msgIn').value, outSale: $('msgOut').value },
      [OPT_KEY]: {
        warnNonRakuten: $('warnNonRakuten').checked,
        rakutenKeyword: $('rakutenKeyword').value || '楽'
      },
      [MEMO_KEY]: {
        inSale: $('memoIn').value,
        outSale: $('memoOut').value,
        labelIn: $('labelIn').value || DEFAULT_MEMO.labelIn,
        labelOut: $('labelOut').value || DEFAULT_MEMO.labelOut
      },
      [STAFF_KEY]: {
        list: names,
        last: ((prev[STAFF_KEY] || {}).last && names.includes(prev[STAFF_KEY].last))
          ? prev[STAFF_KEY].last : (names[0] || '')
      }
    });
    const st = $('status');
    st.textContent = `保存しました（${sales.length}件）`;
    setTimeout(() => { st.textContent = ''; }, 3000);
  }

  /* ---- ボタン ---- */

  $('add').addEventListener('click', () =>
    addRow({ name: '', type: 'marathon', start: '', end: '', confidence: 'high' })
  );

  $('sort').addEventListener('click', () => {
    const list = collect().sort((a, b) => new Date(a.start) - new Date(b.start));
    render(list);
  });

  $('reset').addEventListener('click', () => {
    if (confirm('表の内容を初期データに戻します。よろしいですか？')) {
      render(window.NE_RAKUTEN_SALE_DEFAULTS || []);
    }
  });

  $('toJson').addEventListener('click', () => {
    $('json').value = JSON.stringify(collect(), null, 2);
  });

  $('fromJson').addEventListener('click', () => {
    try {
      const list = JSON.parse($('json').value);
      if (!Array.isArray(list)) throw new Error('配列ではありません');
      render(list);
      alert(`${list.length}件を表に取り込みました。「保存する」を押すと反映されます。`);
    } catch (e) {
      alert('JSONを読み取れませんでした: ' + e.message);
    }
  });

  $('save').addEventListener('click', save);

  /* ---- 楽天カレンダーから取得 ---- */

  const CAL_ORIGIN = 'https://calendar.rakuten.co.jp/*';
  const CAL_URL = 'https://calendar.rakuten.co.jp/cal/8607';

  // イベント名 → 収録する4種類への振り分け
  const NAME_RULES = [
    { re: /ブラックフライデー/, name: '楽天ブラックフライデー', type: 'blackfriday' },
    { re: /大感謝祭/,           name: '楽天大感謝祭',           type: 'daikanshasai' },
    { re: /スーパー(セール|SALE)/, name: '楽天スーパーSALE',    type: 'supersale' },
    { re: /お買い物マラソン/,   name: '楽天お買い物マラソン',   type: 'marathon' }
  ];
  // 対象外（トラベル・先行セール・ポイント系など）
  const EXCLUDE = /トラベル|先行|5と0|ご愛顧|ワンダフル|育児|勝ったら倍|超ポイントバック|モバイル|ポイントアップ祭|イーグルス/;

  function classify(title) {
    if (!title || EXCLUDE.test(title)) return null;
    for (const r of NAME_RULES) if (r.re.test(title)) return r;
    return null;
  }

  // 楽天の終了時刻「01:59」は 01:59:59 まで含む
  function endTimeToIso(t) {
    if (!t) return '23:59:59';
    const m = String(t).match(/^(\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (!m) return '23:59:59';
    const sec = (m[2] === '59' && (!m[3] || m[3] === '00')) ? '59' : (m[3] || '00');
    return `${m[1]}:${m[2]}:${sec}`;
  }

  function parseCalendarHtml(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const tag = doc.getElementById('__NEXT_DATA__');
    if (!tag) throw new Error('カレンダーの中身を読み取れませんでした（ページ構成が変わった可能性）');
    const j = JSON.parse(tag.textContent);
    const box = j?.props?.pageProps?.data?.calendarEventResponse?.data?.event_searches;
    if (!box) throw new Error('イベント情報が見つかりませんでした');
    const rows = Array.isArray(box) ? box : Object.values(box);

    const out = [];
    for (const x of rows) {
      const title = (x.cal_event || {}).event_title || '';
      const hit = classify(title);
      if (!hit) continue;
      if (!x.view_start_date || !x.event_start_time) continue;
      out.push({
        name: hit.name,
        type: hit.type,
        start: `${x.view_start_date}T${x.event_start_time}+09:00`,
        end: `${x.view_end_date || x.view_start_date}T${endTimeToIso(x.event_end_time)}+09:00`,
        confidence: 'high',
        note: `楽天カレンダーから取得（元の名称：${title}）`
      });
    }
    return out;
  }

  function fmt(iso) {
    const d = new Date(iso);
    const p = {};
    for (const q of new Intl.DateTimeFormat('ja-JP', {
      timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', weekday: 'short', hour12: false
    }).formatToParts(d)) p[q.type] = q.value;
    return `${p.year}/${p.month}/${p.day}(${p.weekday}) ${p.hour}:${p.minute}`;
  }

  async function renderFetchState() {
    const el = $('fetchState');
    if (!el) return;
    const got = await chrome.storage.local.get([FETCH_KEY]);
    const lf = got[FETCH_KEY];
    const ym = currentYM();
    const label = `${ym.slice(0, 4)}年${Number(ym.slice(4))}月`;
    if (lf && lf.ym === ym) {
      const d = new Date(lf.at);
      el.innerHTML = `<span style="color:#16702c;font-weight:600">✓ ${label}分は取得済みです</span>` +
        `<span style="color:#888"> （${d.toLocaleString('ja-JP')}）</span>`;
    } else {
      el.innerHTML = `<span style="color:#a36200;font-weight:600">● ${label}分はまだ取得していません。</span>` +
        `<span style="color:#888"> 月が変わったら一度押してください。</span>`;
    }
  }

  $('fetchCal').addEventListener('click', async () => {
    const st = $('fetchStatus');
    const box = $('fetchResult');
    box.innerHTML = '';
    st.textContent = '楽天へのアクセス許可を確認しています…';

    let granted = false;
    try {
      granted = await chrome.permissions.request({ origins: [CAL_ORIGIN] });
    } catch (e) {
      granted = false;
    }
    if (!granted) {
      st.textContent = 'アクセスが許可されなかったため取得できません。';
      return;
    }

    st.textContent = '取得中…';
    let found;
    try {
      const res = await fetch(CAL_URL, { credentials: 'omit' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      found = parseCalendarHtml(await res.text());
    } catch (e) {
      st.textContent = '取得に失敗しました：' + (e.message || e);
      return;
    }

    // 取得できた時点で「今月分は確認済み」として記録する（案内メッセージが消える）
    await chrome.storage.local.set({
      [FETCH_KEY]: { ym: currentYM(), at: new Date().toISOString(), found: found.length }
    });
    renderFetchState();

    // すでに表にあるものは除く（開始日時が同じなら同一とみなす）
    const existing = new Set(collect().map((s) => new Date(s.start).getTime()));
    const fresh = found.filter((s) => !existing.has(new Date(s.start).getTime()));

    st.textContent = `対象セール ${found.length} 件を検出。うち未登録は ${fresh.length} 件です。`;
    if (!fresh.length) {
      box.innerHTML = '<div class="hint">追加できる新しいセールはありませんでした。</div>';
      return;
    }

    const list = document.createElement('div');
    fresh.forEach((s, i) => {
      const row = document.createElement('label');
      row.style.cssText = 'display:flex;gap:8px;align-items:flex-start;padding:6px 8px;border:1px solid #e6e6e6;border-radius:6px;margin-bottom:6px;background:#fff';
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.checked = true; cb.dataset.idx = String(i);
      cb.className = 'fetch-pick';
      const txt = document.createElement('div');
      txt.innerHTML = `<b>${s.name}</b><br><span style="font-size:12px;color:#555">${fmt(s.start)} 〜 ${fmt(s.end)}</span>`;
      row.appendChild(cb); row.appendChild(txt);
      list.appendChild(row);
    });
    box.appendChild(list);

    const btn = document.createElement('button');
    btn.className = 'primary';
    btn.textContent = 'チェックしたものを表に追加';
    btn.addEventListener('click', () => {
      const picks = [...box.querySelectorAll('.fetch-pick')]
        .filter((c) => c.checked).map((c) => fresh[Number(c.dataset.idx)]);
      if (!picks.length) return;
      const merged = collect().concat(picks)
        .sort((a, b) => new Date(a.start) - new Date(b.start));
      render(merged);
      box.innerHTML = '';
      st.textContent = `${picks.length}件を表に追加しました。内容を確認して「保存する」を押してください。`;
    });
    box.appendChild(btn);
  });

  load();
})();

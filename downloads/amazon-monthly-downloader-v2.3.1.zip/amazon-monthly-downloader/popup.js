const $ = (id) => document.getElementById(id);
const LABELS = { tx: 'FBA手数料・販売手数料・出荷数', ads: '広告費・広告売上', adsReport: '広告費・広告売上(レポート作成)', storage: '保管費', sales: '総売上' };
const DEFAULT_SUB = { tx: 'トランザクション', ads: 'キャンペーン', adsReport: '効果測定とレポートでCSVを作って取得', storage: '在庫保管手数料', sales: '売上ダッシュボード' };
const ORDER = ['tx', 'ads', 'storage', 'sales'];

const pad = (n) => String(n).padStart(2, '0');
const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;

function buildMonths() {
  const sel = $('month');
  const now = new Date();
  for (let i = 0; i < 24; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const o = document.createElement('option');
    o.value = keyOf(d);
    o.textContent = `${d.getFullYear()}年${d.getMonth() + 1}月${i === 0 ? '(今月・途中)' : i === 1 ? '(先月)' : ''}`;
    sel.appendChild(o);
  }
}

let shownMonth = null; // いま表示している月(離れたら結果をクリアする)

async function init() {
  buildMonths();
  const s = await chrome.storage.local.get(['amz_month']);
  const lastMonth = keyOf(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1));
  const saved = s.amz_month;
  $('month').value = saved && [...$('month').options].some((o) => o.value === saved) ? saved : lastMonth;
  shownMonth = currentMonth();
  await render();
}

// 月を切り替えたら、前に見ていた月の取得結果(マーカー)を消す。
// 実行中のジョブの月は消さない。
async function clearResults(month) {
  if (!month) return;
  const s = await chrome.storage.local.get(['amz_results', 'amz_job']);
  const job = s.amz_job || {};
  if (job.running && job.month === month) return;
  const all = s.amz_results || {};
  if (!all[month]) return;
  delete all[month];
  await chrome.storage.local.set({ amz_results: all });
}

function currentMonth() { return $('month').value; }

function step(delta) {
  const sel = $('month');
  const i = sel.selectedIndex - delta; // 選択肢は新しい順
  if (i >= 0 && i < sel.options.length) {
    sel.selectedIndex = i;
    sel.dispatchEvent(new Event('change'));
  }
}

async function render() {
  const s = await chrome.storage.local.get(['amz_results', 'amz_job', 'amz_logs']);
  const month = currentMonth();
  const res = (s.amz_results || {})[month] || {};
  const job = s.amz_job || {};
  const running = !!job.running;

  for (const btn of document.querySelectorAll('.kind')) {
    const k = btn.dataset.kind;
    const r = res[k];
    let st = r ? r.status : '';
    const isCurrent = running && job.month === month && job.current === k;
    if (isCurrent) st = 'running';
    else if (st === 'running') st = 'cancelled'; // 途中で拡張が止まった等の残骸
    btn.dataset.st = st;
    const sub = btn.querySelector('.s');
    if (!r) sub.textContent = DEFAULT_SUB[k];
    else if (st === 'running') sub.textContent = job.progress || '実行中…';
    else if (r.status === 'running') sub.textContent = '中断されました';
    else {
      const head = { ok: '取得済み', noData: 'データなし', notReady: '未確定', error: '失敗', cancelled: '中止' }[st] || '';
      sub.textContent = [head, r.message].filter(Boolean).join(':');
      sub.title = r.at ? new Date(r.at).toLocaleString('ja-JP') : '';
    }
    btn.disabled = running;
  }
  $('runAll').disabled = running;
  $('retry').disabled = running;

  $('job').classList.toggle('on', running);
  if (running) {
    const idx = (job.kinds || []).indexOf(job.current);
    $('jobCur').textContent = `${job.month.replace('-', '年')}月 ${job.current ? LABELS[job.current] : '準備中'}${idx >= 0 ? `(${idx + 1}/${job.kinds.length})` : ''}`;
    $('jobPg').textContent = job.cancel ? '中止待ち…' : (job.progress || '');
  }

  const box = $('logs');
  box.textContent = '';
  for (const l of (s.amz_logs || []).slice(0, 80)) {
    const div = document.createElement('div');
    div.className = l.level;
    const t = document.createElement('time');
    const d = new Date(l.at);
    t.textContent = `${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    div.append(t, document.createTextNode(l.text));
    box.appendChild(div);
  }
}

let fsState = { state: 'none' };
const FS_LABEL = { none: '未設定', granted: 'OK', prompt: '要許可', denied: '拒否' };

async function renderDest() {
  try { fsState = await AMZ_FS.status(); } catch (e) { fsState = { state: 'none' }; }
  $('destName').textContent = fsState.name || 'フォルダを選んでください';
  $('destState').textContent = FS_LABEL[fsState.state] || fsState.state;
  $('destState').className = 'st ' + fsState.state;
  $('destBtn').textContent = fsState.state === 'none' ? '設定' : fsState.state === 'granted' ? '変更' : '保存を許可';
  $('dest').classList.toggle('warn', fsState.state !== 'granted');
}

function openFolderPage() {
  chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
}

async function start(kinds) {
  await renderDest();
  if (fsState.state !== 'granted') { openFolderPage(); return; }
  const month = currentMonth();
  chrome.runtime.sendMessage({ type: 'amz_start', month, kinds }); // 応答は待たない
}

$('month').addEventListener('change', async () => {
  const left = shownMonth;
  shownMonth = currentMonth();
  if (left && left !== shownMonth) await clearResults(left);
  await chrome.storage.local.set({ amz_month: shownMonth });
  render();
});
$('prev').addEventListener('click', () => step(-1));
$('next').addEventListener('click', () => step(1));
$('runAll').addEventListener('click', () => start(ORDER));
for (const btn of document.querySelectorAll('.kind')) {
  btn.addEventListener('click', () => start([btn.dataset.kind]));
}
$('destBtn').addEventListener('click', openFolderPage);

// ───────── 説明モーダル
// 取得できなくなる境目は「2026/09/18 時点で 2025/07/15 あたり」= 約430日(14か月)前。
// その日数を今日から逆算して表示する。
const ADS_LIMIT_DAYS = 430;
function renderHelpLimit() {
  const now = new Date();
  const edge = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ADS_LIMIT_DAYS);
  const firstOk = new Date(edge.getFullYear(), edge.getMonth() + 1, 1); // 通常ボタンで取れる最も古い月
  const lastNg = new Date(edge.getFullYear(), edge.getMonth(), 1);
  $('helpLimit').textContent = `目安: 今日から約${ADS_LIMIT_DAYS}日(約14か月)前まで`;
  $('helpDetail').innerHTML =
    `境目はおよそ <b>${edge.getFullYear()}年${edge.getMonth() + 1}月${edge.getDate()}日</b> です。<br>` +
    `・${firstOk.getFullYear()}年${firstOk.getMonth() + 1}月 以降 … 通常の「広告費・広告売上」でOK<br>` +
    `・${lastNg.getFullYear()}年${lastNg.getMonth() + 1}月 以前 … このボタン(レポート作成)を使う<br>` +
    `境目の月は、まず通常ボタンを試して、ダメならこちらを押してください。`;
}
$('helpBtn').addEventListener('click', (e) => { e.stopPropagation(); renderHelpLimit(); $('help').classList.add('on'); });
$('helpClose').addEventListener('click', () => $('help').classList.remove('on'));
$('help').addEventListener('click', (e) => { if (e.target === $('help')) $('help').classList.remove('on'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('help').classList.remove('on'); });
$('stop').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'amz_cancel' }));
$('retry').addEventListener('click', async () => {
  const s = await chrome.storage.local.get(['amz_results']);
  const res = (s.amz_results || {})[currentMonth()] || {};
  const kinds = ORDER.filter((k) => !res[k] || ['error', 'notReady', 'cancelled', 'running'].includes(res[k].status));
  if (kinds.length) start(kinds);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.amz_results || changes.amz_job || changes.amz_logs)) render();
  if (area === 'local' && changes.amz_fs_state) renderDest();
});

renderDest();
init();

// B2クラウド(newb2web)の全ページで動く。
// ・「1件ずつ発行」画面なら、その場でネコポスとして自動入力(登録・印刷はしない)
// ・それ以外の画面なら、B2のメニューをクリックして「1件ずつ発行」へ進む(URL直打ちはB2がエラーにするため)
(function () {
  'use strict';
  // 二重読み込み防止(拡張を入れ直した後の古いスクリプトは無視して動く)
  if (window.__nekoB2Alive && window.__nekoB2Alive()) return;
  window.__nekoB2Alive = () => { try { return !!chrome.runtime.id; } catch (e) { return false; } };
  const N = NEKO;
  const MAX_HOPS = 4;
  const isSingle = () => /single_issue_reg\.html/.test(location.pathname);
  let busy = false;

  function field(key) {
    const list = Array.from(document.querySelectorAll('[data-key="' + key + '"]'))
      .filter(el => (el.tagName === 'INPUT' && (el.type === 'text' || el.type === '')) || el.tagName === 'TEXTAREA');
    return list.find(N.visible) || list[0] || null;
  }

  // 値を入れて input/change だけ発火(フォーカス移動や keyup はB2側の処理を誘発するので使わない)
  function setField(key, value) {
    const el = field(key);
    if (!el) return false;
    el.value = value == null ? '' : String(value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  async function selectNekopos() {
    const r = document.querySelector('input[name="serviceType"][value="A"]');
    if (!r) return false;
    if (!r.checked) {
      r.click();
      await N.sleep(700);
    }
    await N.waitFor(() => N.visible(field('shipment.consignee_name')), 5000);
    return r.checked;
  }

  // 品名の右に、NEの商品名メモ(付箋)を出す
  function showItemMemo(d) {
    document.querySelectorAll('[data-nekopos-memo]').forEach(el => el.remove());
    const itemEl = field('shipment.item_name1');
    if (!itemEl) return;
    const list = (d.itemDetails && d.itemDetails.length)
      ? d.itemDetails
      : (d.items || []).map(name => ({ name, code: '', qty: '' }));

    const memo = document.createElement('div');
    memo.setAttribute('data-nekopos-memo', '1');
    memo.style.cssText = 'display:inline-block;vertical-align:top;margin:0 0 0 10px;max-width:420px;padding:6px 10px 7px;' +
      'background:#fff8c4;border:1px solid #e6cf5a;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.15);' +
      'font:12px/1.5 sans-serif;color:#333;text-align:left;white-space:normal;user-select:text;';
    const title = document.createElement('div');
    title.style.cssText = 'font-weight:bold;color:#7a5d00;margin-bottom:2px;';
    title.textContent = '📝 NEの商品名(伝票 ' + (d.denpyoNo || '') + ')';
    memo.appendChild(title);
    if (!list.length) {
      const none = document.createElement('div');
      none.textContent = '商品名を読み取れませんでした';
      memo.appendChild(none);
    }
    list.forEach((it, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'padding:2px 0;' + (i ? 'border-top:1px dashed #e6cf5a;' : '');
      const name = document.createElement('span');
      name.textContent = it.name;
      row.appendChild(name);
      const meta = [it.code, it.qty ? '×' + it.qty : ''].filter(Boolean).join(' ');
      if (meta) {
        const m = document.createElement('span');
        m.style.cssText = 'color:#8a7a3a;margin-left:6px;white-space:nowrap;';
        m.textContent = '(' + meta + ')';
        row.appendChild(m);
      }
      memo.appendChild(row);
    });
    itemEl.insertAdjacentElement('afterend', memo);
  }

  async function fill(d, s) {
    const warnings = [];
    if (!(await selectNekopos())) warnings.push('送り状の種類で「ネコポス」を選べませんでした。手で選んでください。');

    const a = N.splitAddress(d.addr1, d.addr2);
    warnings.push(...a.warnings);

    const name = N.normSpace(d.name);
    if (N.byteLen(name) > 32) warnings.push('お届け先名が全角16文字を超えています。B2で短くしてください。');
    const kana = N.cutBytes(N.toHalfKana(d.kana), 50)[0];
    const tel = N.formatTel(d.tel);
    if (!tel) warnings.push('電話番号が空です。');
    const mgmt = s.mgmtSource === 'jyuchu' ? d.jyuchuNo : s.mgmtSource === 'none' ? '' : d.denpyoNo;

    const map = [
      ['shipment.consignee_telephone_display', tel],
      ['shipment.consignee_zip_code', N.formatZip(d.zip)],
      ['shipment.consignee_address1', a.pref],
      ['shipment.consignee_address2', a.city],
      ['shipment.consignee_address3', a.a3],
      ['shipment.consignee_address4', a.a4],
      ['shipment.consignee_department1', a.dept],
      ['shipment.consignee_department2', ''],
      ['shipment.consignee_name', name],
      ['shipment.consignee_name_kana', kana],
      ['shipment.shipment_number', mgmt ? N.cutBytes(mgmt, 50)[0] : ''],
      // 品名はあえて空にする(B2でエラーにして、毎回手で入力する運用)
      ['shipment.item_name1', ''],
    ];

    const p = s.shipper;
    map.push(
      ['shipment.shipper_telephone_display', N.formatTel(p.tel)],
      ['shipment.shipper_zip_code', N.formatZip(p.zip)],
      ['shipment.shipper_address1', p.addr1 || ''],
      ['shipment.shipper_address2', p.addr2 || ''],
      ['shipment.shipper_address3', p.addr3 || ''],
      ['shipment.shipper_address4', p.addr4 || ''],
      ['shipment.shipper_name', p.name || ''],
      ['shipment.shipper_name_kana', N.cutBytes(N.toHalfKana(p.kana), 50)[0]],
      ['shipment.shipper_code', p.code || ''],
    );
    if (!p.tel || !p.zip || !p.addr2 || !p.addr3 || !p.name) warnings.push('ご依頼主の必須項目(電話・郵便番号・市区郡町村・町番地・名称)に空欄があります。「設定」で入れてください。');

    const failed = [];
    for (const [k, v] of map) if (!setField(k, v)) failed.push(k.replace('shipment.', ''));
    if (failed.length) warnings.push('入力できなかった欄があります(B2の画面が変わった可能性):' + failed.join(', '));

    N.log('B2', 'filled', {
      denpyo: d.denpyoNo, name: N.maskName(d.name), tel: N.maskTel(d.tel), zip: d.zip,
      ne_addr1: d.addr1, ne_addr2: d.addr2,
      b2: { pref: a.pref, city: a.city, a3: a.a3, a4: a.a4, dept: a.dept },
      failed, warnings,
    });

    // 品名は手入力なので、NEの商品名を品名の横にメモとして出し、品名の欄までスクロールしてカーソルを置く
    showItemMemo(d);
    const itemEl = field('shipment.item_name1');
    if (itemEl) {
      if (typeof itemEl.scrollIntoView === 'function') itemEl.scrollIntoView({ block: 'center' });
      itemEl.focus();
    }
    return warnings;
  }

  async function doFill(pending, trigger) {
    // B2側の初期読み込み(請求先など)が終わるのを待ってから入力する
    await N.waitFor(() => field('shipment.consignee_zip_code'), 20000);
    await N.waitFor(() => { const s = document.getElementById('select_invoice'); return s && s.options.length > 0; }, 8000);
    if (trigger === 'load') await N.sleep(600);
    await N.clearPending();
    const d = pending.data;
    const warnings = await fill(d, await N.getSettings());
    let html = '<b>🐈 伝票 ' + N.esc(d.denpyoNo) + '/' + N.esc(d.name) + ' 様 をネコポスで入力しました。</b><br>品名を入力し、内容を確認してから「印刷内容の確認へ」に進んでください。';
    if (warnings.length) html += '<ul style="margin:6px 0 0 18px;padding:0">' + warnings.map(w => '<li>' + N.esc(w) + '</li>').join('') + '</ul>';
    N.showBar(html, warnings.length ? '#b26a00' : '#00843d');
    return 'filled';
  }

  // 「1件ずつ発行」へ、B2のメニューをクリックして進む
  async function goToSingle(pending) {
    if ((pending.hops || 0) >= MAX_HOPS) {
      N.log('B2', 'give_up', { path: location.pathname, hops: pending.hops });
      N.showBar('🐈 自動で「1件ずつ発行」に進めませんでした。B2のメニューから「1件ずつ発行」を開くと、送り先が入ります。', '#b26a00');
      pending.hops = 0; // 手で開いたときに入力できるよう戻しておく
      await N.savePending(pending);
      return 'give_up';
    }
    let el = N.findClickable({ href: 'single_issue_reg', texts: ['1件ずつ発行'] });
    let what = 'single';
    if (!el) { el = N.findClickable({ href: 'main_menu', texts: ['メインメニュー', 'B2クラウドTOP', 'B2クラウドトップ'] }); what = 'menu'; }
    N.log('B2', 'navigate_click', { path: location.pathname, target: what, el: N.describe(el), hops: pending.hops || 0 });
    if (!el) {
      N.showBar('🐈 B2のメニューから「1件ずつ発行」を開いてください。開くと送り先が自動で入ります。', '#b26a00');
      return 'no_link';
    }
    pending.hops = (pending.hops || 0) + 1;
    await N.savePending(pending);
    el.click();
    return 'clicked_' + what;
  }

  async function handle(trigger) {
    if (busy) return 'busy';
    busy = true;
    try {
      if (N.isSystemErrorPage()) {
        N.log('B2', 'system_error_page', { path: location.pathname, referrer: N.pathOf(document.referrer), trigger });
        const pending = await N.getPending();
        if (pending) {
          pending.hops = 0;
          await N.savePending(pending);
          N.showBar('🐈 B2がエラー画面になりました。「ログイン画面へ」からログインし直してください。ログインすると、送り先の入力まで自動で進みます。', '#b00020', false);
        }
        return 'error_page';
      }
      const pending = await N.getPending();
      if (!pending) return 'no_pending';
      if (isSingle()) {
        // 同じURLでも「印刷内容の確認」など入力欄が無い段階のことがあるので、入力欄が見えるか確かめる
        const form = await N.waitFor(() => { const f = field('shipment.consignee_zip_code'); return f && N.visible(f) ? f : null; }, 10000);
        if (form) return await doFill(pending, trigger);
        N.log('B2', 'single_without_form', { title: document.title });
      }
      return await goToSingle(pending);
    } catch (e) {
      N.log('B2', 'exception', { path: location.pathname, msg: String(e && e.message || e) });
      N.showBar('自動入力でエラーが発生しました:' + N.esc(e.message), '#b00020');
      return 'exception';
    } finally {
      busy = false;
    }
  }

  // 「ネコポスへ」が押されたとき、すでに開いているB2タブに background から届く
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'GO') {
      handle('message').then(r => sendResponse({ ok: true, result: r }));
      return true;
    }
    if (msg && msg.type === 'PING') { sendResponse({ ok: true, path: location.pathname }); }
  });

  // ページの記録(エラー画面に至る流れを追うため。URLのパラメータは残さない)
  N.getPending().then(p => N.log('B2', 'page_load', { path: location.pathname, title: document.title, referrer: N.pathOf(document.referrer), pending: !!p, hops: p ? p.hops || 0 : null }));
  window.addEventListener('error', e => N.log('B2', 'window_error', { path: location.pathname, msg: e.message, file: N.pathOf(e.filename || ''), line: e.lineno }));

  handle('load');
})();

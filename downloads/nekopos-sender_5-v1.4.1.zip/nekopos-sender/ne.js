// ネクストエンジン 受注伝票画面:送り先を読み取ってB2へ送るボタン
(function () {
  'use strict';
  if (window.__nekoNeAlive && window.__nekoNeAlive()) return;
  window.__nekoNeAlive = () => { try { return !!chrome.runtime.id; } catch (e) { return false; } };
  // 拡張を入れ直す前の古いボタンが残っていたら消す
  document.querySelectorAll('[data-nekopos-ui]').forEach(el => el.remove());

  const val = id => {
    const el = document.getElementById(id);
    return el ? String(el.value || '').trim() : '';
  };

  // 明細(見出し行も tbody 内の普通の行なので、見出しの文字から列を探す)
  function readItems() {
    const table = document.getElementById('jyuchuMeisai_tablene_table');
    if (!table) return [];
    const rows = Array.from(table.rows);
    const norm = s => String(s || '').replace(/\s/g, '').toLowerCase();
    let headIdx = -1;
    const col = { name: 4, code: 3, qty: -1 };
    rows.some((tr, i) => {
      const cells = Array.from(tr.cells);
      if (!cells.some(td => norm(td.innerText) === '商品名')) return false;
      headIdx = i;
      cells.forEach(td => {
        const t = norm(td.innerText);
        if (t === '商品名') col.name = td.cellIndex;
        else if (t === '商品cd' || t === '商品コード') col.code = td.cellIndex;
        else if (t === '受注数') col.qty = td.cellIndex;
      });
      return true;
    });
    const cellText = (tr, i) => (i >= 0 && tr.cells[i] ? tr.cells[i].innerText.trim() : '');
    const items = [];
    rows.slice(headIdx + 1).forEach(tr => {
      const name = cellText(tr, col.name);
      if (!name || name === '商品名') return;
      items.push({ name, code: cellText(tr, col.code), qty: cellText(tr, col.qty) });
    });
    return items;
  }

  function readSlip() {
    const sel = document.getElementById('hasou_kbn');
    const itemDetails = readItems();
    return {
      denpyoNo: val('jyuchu_denpyo_no') || val('kensaku_denpyo_no'),
      jyuchuNo: val('tenpo_denpyo_no'),
      name: val('hasou_name'),
      kana: val('hasou_kana'),
      zip: val('hasou_yubin_bangou'),
      addr1: val('hasou_jyusyo1'),
      addr2: val('hasou_jyusyo2'),
      tel: val('hasou_denwa'),
      hasouKbn: sel && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex].text : '',
      items: itemDetails.map(x => x.name),
      itemDetails,
    };
  }

  // ---- 画面右上のボタン ----
  const BTN = 'border:0;border-radius:6px;color:#fff;font-weight:bold;cursor:pointer;font-family:sans-serif;box-shadow:0 1px 4px rgba(0,0,0,.3);';
  const wrap = document.createElement('div');
  wrap.setAttribute('data-nekopos-ui', '1');
  wrap.style.cssText = 'position:absolute;top:6px;z-index:2147483647;width:210px;font:12px/1.5 sans-serif;display:flex;flex-direction:column;gap:5px;';

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = '🐈 ネコポスへ';
  btn.title = 'この伝票の送り先とご依頼主をB2クラウド「1件ずつ発行」に自動入力します';
  btn.style.cssText = BTN + 'width:100%;height:38px;background:#00843d;font-size:15px;';

  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:5px;';
  const loginBtn = document.createElement('button');
  loginBtn.type = 'button';
  loginBtn.textContent = 'ログイン';
  loginBtn.title = 'ヤマトビジネスメンバーズのログイン画面を開きます';
  loginBtn.style.cssText = BTN + 'flex:1;height:28px;background:#f5a200;font-size:13px;';
  const setBtn = document.createElement('button');
  setBtn.type = 'button';
  setBtn.textContent = '設定';
  setBtn.title = 'ご依頼主などの設定を開きます';
  setBtn.style.cssText = BTN + 'flex:1;height:28px;background:#555;font-size:13px;';
  row.append(loginBtn, setBtn);

  const toast = document.createElement('div');
  toast.style.cssText = 'display:none;padding:7px 10px;border-radius:6px;background:#222;color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.3);white-space:pre-wrap;';

  wrap.append(btn, row, toast);
  document.body.appendChild(wrap);

  // 伝票の右端(アシスタント欄など)のさらに右の空きスペースに置く。
  // ウィンドウが狭くて入らないときは、伝票ボタンを隠さないよう右下に置く。
  function contentRight() {
    let r = 0;
    ['assistant_area', 'meisaiinfo_area'].forEach(id => {
      const el = document.getElementById(id);
      if (el) r = Math.max(r, el.getBoundingClientRect().right + window.scrollX);
    });
    return r || 1080;
  }
  function place() {
    const left = contentRight() + 12;
    const s = wrap.style;
    if (window.innerWidth >= left + 210 + 8) {
      s.position = 'absolute'; s.left = left + 'px'; s.top = '6px'; s.right = 'auto'; s.bottom = 'auto';
    } else {
      s.position = 'fixed'; s.left = 'auto'; s.top = 'auto'; s.right = '12px'; s.bottom = '12px';
    }
  }
  place();
  window.addEventListener('resize', place);
  setTimeout(place, 1000);

  let toastTimer;
  function showToast(msg, color, ms) {
    toast.textContent = msg;
    toast.style.background = color || '#222';
    toast.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.style.display = 'none'; }, ms || 6000);
  }

  async function send(msg) {
    try {
      const res = await chrome.runtime.sendMessage(msg);
      if (!res || !res.ok) throw new Error((res && res.error) || '不明なエラー');
      return res;
    } catch (e) {
      showToast('動きませんでした:' + e.message + '\n拡張機能を再読み込みして、伝票を開き直してください。', '#b00020', 10000);
      return null;
    }
  }

  btn.addEventListener('click', async () => {
    const d = readSlip();
    const missing = [];
    if (!d.name) missing.push('送り先名');
    if (!d.zip) missing.push('郵便番号');
    if (!d.addr1) missing.push('住所');
    if (missing.length) {
      showToast('送り先の「' + missing.join('・') + '」が空です。', '#b00020');
      return;
    }
    btn.disabled = true;
    NEKO.log('NE', 'click_send', { denpyo: d.denpyoNo, name: NEKO.maskName(d.name), items: d.items.length, hasouKbn: d.hasouKbn });
    const res = await send({ type: 'SEND_TO_B2', data: d });
    if (res) {
      let msg = d.name + ' 様(伝票 ' + d.denpyoNo + ')をB2へ送りました。';
      if (d.hasouKbn && !/ネコポス/.test(d.hasouKbn)) msg += '\n※発送方法は「' + d.hasouKbn + '」です。';
      if (res.mode === 'login') msg += '\nヤマトのページを開きました。ログイン画面ならログインしてください。そのまま「1件ずつ発行」まで自動で進みます。';
      if (res.multipleB2Tabs) msg += '\n※B2のタブが複数開いています。エラーの原因になるので1つにしてください。';
      showToast(msg, '#00843d', 8000);
    }
    setTimeout(() => { btn.disabled = false; }, 1500);
  });

  loginBtn.addEventListener('click', () => send({ type: 'OPEN_LOGIN' }));
  setBtn.addEventListener('click', () => send({ type: 'OPEN_SETTINGS' }));
})();

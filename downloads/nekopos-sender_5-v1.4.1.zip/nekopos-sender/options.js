(async function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const keys = ['tel', 'zip', 'addr1', 'addr2', 'addr3', 'addr4', 'name', 'kana', 'code'];
  const limits = { addr2: 24, addr3: 32, addr4: 32, name: 32 }; // バイト数(全角=2)
  const required = { tel: '電話番号', zip: '郵便番号', addr2: '市区郡町村', addr3: '町・番地', name: '名称' };

  const s = await NEKO.getSettings();
  const fillShipper = sh => keys.forEach(k => { $('s_' + k).value = sh[k] || ''; });

  document.querySelector('input[name=mgmt][value="' + s.mgmtSource + '"]').checked = true;
  fillShipper(s.shipper);

  function check() {
    let ok = true;
    document.querySelectorAll('.err').forEach(e => { e.textContent = ''; });
    keys.forEach(k => {
      const v = $('s_' + k).value.trim();
      const err = document.querySelector('.err[data-for="' + k + '"]');
      if (!err) return;
      if (required[k] && !v) { err.textContent = '入力してください'; ok = false; }
      else if (limits[k] && NEKO.byteLen(v) > limits[k]) { err.textContent = '長すぎます(全角' + limits[k] / 2 + '文字まで)'; ok = false; }
    });
    return ok;
  }
  keys.forEach(k => $('s_' + k).addEventListener('input', check));
  check();

  $('reset').addEventListener('click', () => { fillShipper(NEKO.DEFAULT_SETTINGS.shipper); check(); });

  // ---------- ログ ----------
  const pad = (n, w) => String(n).padStart(w || 2, '0');
  const fmtTime = t => { const d = new Date(t); return pad(d.getMonth() + 1) + '/' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) + '.' + pad(d.getMilliseconds(), 3); };
  async function buildLogText() {
    const { logs } = await chrome.storage.local.get('logs');
    const list = Array.isArray(logs) ? logs : [];
    const cur = await NEKO.getSettings();
    const head = [
      '=== NE→B2 ネコポス送り ログ ===',
      'バージョン: ' + chrome.runtime.getManifest().version,
      '出力日時: ' + new Date().toLocaleString('ja-JP'),
      'ブラウザ: ' + navigator.userAgent,
      '設定: 管理番号=' + cur.mgmtSource + ' / ご依頼主入力あり=' + !!(cur.shipper && cur.shipper.name),
      '件数: ' + list.length,
      '',
    ];
    const lines = list.map(e => fmtTime(e.t) + ' [' + e.src + '] ' + e.ev + (e.detail ? ' ' + JSON.stringify(e.detail) : ''));
    return head.concat(lines).join('\n');
  }
  async function showLogs() {
    const text = await buildLogText();
    $('logText').value = text;
    $('logText').scrollTop = $('logText').scrollHeight;
  }
  const flash = m => { $('logMsg').textContent = m; setTimeout(() => { $('logMsg').textContent = ''; }, 2500); };
  $('logCopy').addEventListener('click', async () => {
    const text = await buildLogText();
    try { await navigator.clipboard.writeText(text); }
    catch (e) { $('logText').value = text; $('logText').select(); document.execCommand('copy'); }
    flash('コピーしました。Claudeに貼り付けてください');
  });
  $('logSave').addEventListener('click', async () => {
    const text = await buildLogText();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
    const d = new Date();
    a.download = 'nekopos-log-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.txt';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  $('logReload').addEventListener('click', showLogs);
  $('logClear').addEventListener('click', async () => {
    if (!confirm('ログをすべて消しますか?')) return;
    await chrome.storage.local.set({ logs: [] });
    await showLogs();
    flash('消しました');
  });
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.logs) showLogs(); });
  showLogs();

  $('save').addEventListener('click', async () => {
    if (!check() && !confirm('入力に問題がある欄があります。このまま保存しますか?')) return;
    const shipper = {};
    keys.forEach(k => { shipper[k] = $('s_' + k).value.trim(); });
    await chrome.storage.sync.set({
      settings: {
        v: NEKO.SETTINGS_VERSION,
        mgmtSource: document.querySelector('input[name=mgmt]:checked').value,
        shipper,
      },
    });
    $('saved').textContent = '保存しました';
    setTimeout(() => { $('saved').textContent = ''; }, 2500);
  });
})();

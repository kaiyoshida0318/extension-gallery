// 受け取った送り先を保存し、B2のタブを「1件ずつ発行」へ進める。
// B2はURL直打ちや2つ目のタブを「システムエラー」にするので、
// ・B2のタブが開いていれば、そのタブの中でメニューをクリックして進む(または、その場で入力)
// ・開いていなければ、ログイン画面を1つだけ開き、ログイン後のトップから自動で進む
const LOGIN_URL = 'https://bmypage.kuronekoyamato.co.jp/bmypage/servlet/jp.co.kuronekoyamato.wur.hmp.servlet.user.HMPLGI0010JspServlet';
const B2_MATCH = 'https://newb2web.kuronekoyamato.co.jp/*';
const BMY_MATCH = 'https://bmypage.kuronekoyamato.co.jp/*';
const MAX_LOGS = 500;

// ---------- ログ(書き込みはここだけで行い、順番に処理する) ----------
let logQueue = Promise.resolve();
function addLog(entry) {
  logQueue = logQueue.then(async () => {
    const { logs } = await chrome.storage.local.get('logs');
    const list = Array.isArray(logs) ? logs : [];
    list.push(entry);
    if (list.length > MAX_LOGS) list.splice(0, list.length - MAX_LOGS);
    await chrome.storage.local.set({ logs: list });
  }).catch(() => {});
  return logQueue;
}
const log = (ev, detail) => addLog({ t: Date.now(), src: 'BG', ev, detail: detail || null });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const fail = e => { log('error', { type: msg.type, msg: String(e && e.message || e) }); sendResponse({ ok: false, error: String(e && e.message || e) }); };
  if (!msg) return;
  if (msg.type === 'LOG') {
    addLog(msg.entry).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === 'SEND_TO_B2') {
    sendToB2(msg.data).then(sendResponse, fail);
    return true;
  }
  if (msg.type === 'OPEN_LOGIN') {
    openLogin().then(() => sendResponse({ ok: true }), fail);
    return true;
  }
  if (msg.type === 'OPEN_SETTINGS') {
    chrome.runtime.openOptionsPage().then(() => sendResponse({ ok: true }), fail);
    return true;
  }
});

async function findYamatoTabs() {
  const b2 = await chrome.tabs.query({ url: B2_MATCH });
  const bmy = await chrome.tabs.query({ url: BMY_MATCH });
  return { b2, bmy };
}

async function focusTab(t) {
  await chrome.tabs.update(t.id, { active: true });
  await chrome.windows.update(t.windowId, { focused: true });
}

// タブの中の拡張(b2.js / bmy.js)に「進めて」と伝える。いなければ差し込んでから伝える
async function poke(tab, kind) {
  const files = kind === 'b2' ? ['common.js', 'b2.js'] : ['common.js', 'bmy.js'];
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: 'GO' });
  } catch (e) {
    log('poke_no_script', { kind, err: String(e.message || e) });
    // 拡張を入れ直した直後など、ページに拡張が入っていない。差し込むと読み込み時に自動で進む
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files });
    return { ok: true, result: 'injected' };
  }
}

async function sendToB2(data) {
  await chrome.storage.local.set({ pending: { data, ts: Date.now(), hops: 0 } });
  const { b2, bmy } = await findYamatoTabs();
  log('send', { denpyo: data.denpyoNo, b2Tabs: b2.length, bmyTabs: bmy.length, hasouKbn: data.hasouKbn });

  // B2のタブがあればそれを使う(複数あるとB2がエラーにしやすいので注意を出す)
  const tab = b2.find(t => t.active) || b2[0] || bmy.find(t => t.active) || bmy[0];
  if (tab) {
    const kind = b2.includes(tab) ? 'b2' : 'bmy';
    await focusTab(tab);
    const res = await poke(tab, kind);
    log('poked', { kind, path: safePath(tab.url), result: res && res.result });
    return { ok: true, mode: kind, result: res && res.result, multipleB2Tabs: b2.length > 1 };
  }
  // どちらも無ければ、ログイン画面を新しいウィンドウで1つ開く(ログイン済みならトップが開き、そこから自動で進む)
  await chrome.windows.create({ url: LOGIN_URL, focused: true, type: 'normal' });
  log('opened_login_window', {});
  return { ok: true, mode: 'login' };
}

// ログイン画面を「ヤマト専用のウィンドウ」で開く。
// ヤマトのタブが既にあれば増やさず(複数タブはB2のエラーの原因)、そのタブを専用ウィンドウに移してからログイン画面にする
async function openLogin() {
  const { b2, bmy } = await findYamatoTabs();
  const tab = b2[0] || bmy[0];
  if (!tab) {
    await chrome.windows.create({ url: LOGIN_URL, focused: true, type: 'normal' });
    log('login_new_window', {});
    return;
  }
  const win = await chrome.windows.get(tab.windowId, { populate: true });
  if (win.tabs && win.tabs.length > 1) {
    // ネクストエンジンなど他のタブと同じウィンドウにいるので、ヤマトのタブだけ新しいウィンドウへ移す
    await chrome.windows.create({ tabId: tab.id, focused: true, type: 'normal' });
    log('login_move_tab_to_window', {});
  }
  await chrome.tabs.update(tab.id, { url: LOGIN_URL, active: true });
  const t = await chrome.tabs.get(tab.id);
  await chrome.windows.update(t.windowId, { focused: true });
  log('login_reuse_tab', {});
}

function safePath(u) { try { return new URL(u).pathname; } catch (e) { return ''; } }

// アイコンをクリックしたら設定画面
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

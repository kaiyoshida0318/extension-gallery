// 共通ヘルパー(ネクストエンジン側・B2側の両方で読み込む)
var NEKO = (function () {
  'use strict';

  const SETTINGS_VERSION = 3;
  const DEFAULT_SETTINGS = {
    v: SETTINGS_VERSION,
    mgmtSource: 'denpyo',   // お客様管理番号に入れるもの: denpyo=NE伝票番号 / jyuchu=受注番号 / none=入れない
    itemMode: 'slip',       // 品名: slip=伝票の商品名 / fixed=固定の文字
    itemFixed: '',
    // ご依頼主(お届け先と一緒に毎回入力する)
    shipper: {
      tel: '09093159659',
      zip: '221-0842',
      addr1: '神奈川県',
      addr2: '横浜市神奈川区',
      addr3: '泉町17-10',
      addr4: '白土ビル2F',
      name: 'ゆかい屋-KAIRY　吉田',
      kana: '',
      code: '',
    },
  };

  const PREFS = ['北海道','青森県','岩手県','宮城県','秋田県','山形県','福島県','茨城県','栃木県','群馬県',
    '埼玉県','千葉県','東京都','神奈川県','新潟県','富山県','石川県','福井県','山梨県','長野県','岐阜県',
    '静岡県','愛知県','三重県','滋賀県','京都府','大阪府','兵庫県','奈良県','和歌山県','鳥取県','島根県',
    '岡山県','広島県','山口県','徳島県','香川県','愛媛県','高知県','福岡県','佐賀県','長崎県','熊本県',
    '大分県','宮崎県','鹿児島県','沖縄県'];

  // 市区郡町村の切り出し(紛らわしい市名は先に列挙)
  const CITY_RE = new RegExp(
    '^(?:' +
      '(?:旭川|伊達|石狩|盛岡|奥州|田村|南相馬|那須塩原|東村山|武蔵村山|羽村|十日町|上越|富山|野々市|大町|' +
      '蒲郡|四日市|姫路|大和郡山|廿日市|下松|岩国|田川|大村|宮古|富良野|別府|佐伯|黒部|小諸|塩尻|玉野|周南|市川|市原)市' +
      '|(?:余市|高市|[^市]{2,3}?)郡(?:玉村|大町|.{1,5}?)[町村]' +
      '|(?:.{1,4}市)?[^町]{1,4}?区' +
      '|.{1,7}?[市町村]' +
    ')'
  );

  // B2の文字数制限は「バイト数」(全角=2・半角=1)で考える
  function isHalf(ch) {
    const c = ch.charCodeAt(0);
    return c <= 0x7e || (c >= 0xff61 && c <= 0xff9f);
  }
  function byteLen(s) {
    let n = 0;
    for (const ch of String(s || '')) n += isHalf(ch) ? 1 : 2;
    return n;
  }
  // 先頭から maxBytes バイトまでで切る → [収まった部分, はみ出し]
  function cutBytes(s, maxBytes) {
    s = String(s || '');
    let n = 0, i = 0;
    const chars = Array.from(s);
    for (; i < chars.length; i++) {
      const w = isHalf(chars[i]) ? 1 : 2;
      if (n + w > maxBytes) break;
      n += w;
    }
    return [chars.slice(0, i).join(''), chars.slice(i).join('')];
  }
  // できれば空白の位置で切る
  function cutBytesNice(s, maxBytes) {
    const [head, rest] = cutBytes(s, maxBytes);
    if (!rest) return [head, ''];
    const sp = Math.max(head.lastIndexOf(' '), head.lastIndexOf('　'));
    if (sp > head.length / 2) return [head.slice(0, sp).trim(), (head.slice(sp) + rest).trim()];
    return [head, rest];
  }

  function normSpace(s) {
    return String(s || '').replace(/　/g, ' ').replace(/\s+/g, ' ').trim();
  }

  // 「柞原町732番地ボヌール柞原A201」→ ["柞原町732番地", "ボヌール柞原A201"]
  // 最初の数字から、番地として続く文字(数字・ハイフン・丁目・番地・号・の・条 など)が途切れた所で切る
  const DIGIT = /[0-9０-９]/;
  const STREET_CONT = /[0-9０-９\-－ー‐−―の之丁目番地号条線]/;
  const AFTER_JO = /[東西南北]/; // 北海道の「北1条西2丁目」用
  function splitStreet(s) {
    s = normSpace(s);
    if (!s) return ['', ''];
    let i = s.search(DIGIT);
    if (i < 0) {
      // 番地に数字がない(漢数字など)ときは空白で分けられれば分ける
      const sp = s.indexOf(' ');
      return sp > 0 ? [s.slice(0, sp), s.slice(sp + 1).trim()] : [s, ''];
    }
    while (i < s.length) {
      const ch = s[i];
      if (STREET_CONT.test(ch)) { i++; continue; }
      if (AFTER_JO.test(ch) && s[i - 1] === '条') { i++; continue; }
      break;
    }
    // 末尾のハイフンや「の」は番地側に残さない
    let j = i;
    while (j > 0 && /[\-－ー‐−―の之]/.test(s[j - 1]) && !/[0-9０-９]/.test(s[j - 1])) j--;
    return [s.slice(0, j).trim(), s.slice(j).trim()];
  }

  // 住所1・住所2 → B2の 都道府県 / 市区郡町村 / 町・番地 / 建物・部屋番号
  function splitAddress(addr1, addr2) {
    const warnings = [];
    // NEの住所1/住所2は伝票によって区切り位置がまちまち(市まで/番地まで等)なので、つなげてから分け直す
    let rest = normSpace(String(addr1 || '') + ' ' + String(addr2 || ''));
    let pref = '';
    for (const p of PREFS) {
      if (rest.startsWith(p)) { pref = p; rest = rest.slice(p.length).trim(); break; }
    }
    if (!pref) warnings.push('都道府県が読み取れませんでした。住所欄を確認してください。');

    // 空白を無視して市区町村を判定し、元の文字列からその分だけ取り出す
    const compact = rest.replace(/ /g, '');
    const m = compact.match(CITY_RE);
    let city = '';
    if (m) {
      let need = m[0].length, i = 0;
      while (i < rest.length && need > 0) { if (rest[i] !== ' ') need--; i++; }
      city = rest.slice(0, i).replace(/ /g, '');
      rest = rest.slice(i).trim();
    } else {
      warnings.push('市区町村が読み取れませんでした。住所欄を確認してください。');
    }

    // 残りを「町・番地」と「マンション・ビル名」に分ける
    let [a3, a4] = splitStreet(rest);
    let dept = '';
    if (!a3) warnings.push('町・番地が読み取れませんでした。住所欄を確認してください。');

    if (byteLen(city) > 24) {
      const [h, r] = cutBytes(city, 24);
      city = h; a3 = (r + a3).trim();
    }
    if (byteLen(a3) > 32) {
      const [h, r] = cutBytesNice(a3, 32);
      a3 = h; a4 = (r + ' ' + a4).trim();
      warnings.push('町・番地が長いため、一部を「建物・部屋番号」に回しました。');
    }
    if (byteLen(a4) > 32) {
      const [h, r] = cutBytesNice(a4, 32);
      a4 = h; dept = r;
      warnings.push('建物名が長いため、はみ出した分を「会社・部門名1」に入れました。');
      if (byteLen(dept) > 50) warnings.push('住所が長すぎて入りきりません。B2の画面で調整してください。');
    }
    return { pref, city, a3, a4, dept, warnings };
  }

  function formatZip(z) {
    const d = String(z || '').replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xfee0)).replace(/\D/g, '');
    return d.length === 7 ? d.slice(0, 3) + '-' + d.slice(3) : d;
  }

  function formatTel(t) {
    return String(t || '')
      .replace(/[０-９－ー‐]/g, c => (c >= '０' && c <= '９') ? String.fromCharCode(c.charCodeAt(0) - 0xfee0) : '-')
      .replace(/[^\d-]/g, '');
  }

  // カナ → 半角カナ(B2の「略称ｶﾅ」は半角)
  const FULL = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンァィゥェォッャュョーヮヰヱヵヶ・';
  const HALF = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜｦﾝｧｨｩｪｫｯｬｭｮｰﾜｲｴｶｹ･';
  const DAKU = { 'ガ':'ｶ','ギ':'ｷ','グ':'ｸ','ゲ':'ｹ','ゴ':'ｺ','ザ':'ｻ','ジ':'ｼ','ズ':'ｽ','ゼ':'ｾ','ゾ':'ｿ',
    'ダ':'ﾀ','ヂ':'ﾁ','ヅ':'ﾂ','デ':'ﾃ','ド':'ﾄ','バ':'ﾊ','ビ':'ﾋ','ブ':'ﾌ','ベ':'ﾍ','ボ':'ﾎ','ヴ':'ｳ' };
  const HANDAKU = { 'パ':'ﾊ','ピ':'ﾋ','プ':'ﾌ','ペ':'ﾍ','ポ':'ﾎ' };
  function toHalfKana(s) {
    let out = '';
    for (let ch of String(s || '')) {
      const c = ch.charCodeAt(0);
      if (c >= 0x3041 && c <= 0x3096) ch = String.fromCharCode(c + 0x60);       // ひらがな→カタカナ
      if (ch === '　') { out += ' '; continue; }
      if (ch >= '！' && ch <= '～') { out += String.fromCharCode(ch.charCodeAt(0) - 0xfee0); continue; }
      if (DAKU[ch]) { out += DAKU[ch] + 'ﾞ'; continue; }
      if (HANDAKU[ch]) { out += HANDAKU[ch] + 'ﾟ'; continue; }
      const i = FULL.indexOf(ch);
      if (i >= 0) { out += HALF[i]; continue; }
      if (isHalf(ch)) out += ch;            // 漢字など半角にできない文字は落とす
    }
    return out.replace(/\s+/g, ' ').trim();
  }

  async function getSettings() {
    const s = await chrome.storage.sync.get('settings');
    let saved = s.settings || {};
    // 旧バージョンで保存された設定(ご依頼主が空)は初期値で上書き
    if ((saved.v || 1) < 2) saved = Object.assign({}, saved, { shipper: undefined });
    // v2の初期名称のまま保存されていたら、新しい初期名称に置き換える
    if ((saved.v || 1) < 3 && saved.shipper && saved.shipper.name === '株式会社解 吉田開') {
      saved = Object.assign({}, saved, { shipper: Object.assign({}, saved.shipper, { name: DEFAULT_SETTINGS.shipper.name }) });
    }
    const v = Object.assign({}, DEFAULT_SETTINGS, saved);
    v.shipper = Object.assign({}, DEFAULT_SETTINGS.shipper, saved.shipper || {});
    v.v = SETTINGS_VERSION;
    return v;
  }

  // ---------- ページ操作の共通部品 ----------
  const PENDING_TTL = 15 * 60 * 1000; // 「ネコポスへ」から15分以内のものだけ自動で進める
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  async function waitFor(fn, timeout) {
    const end = Date.now() + (timeout || 15000);
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(200);
    }
    return null;
  }
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ログ(書き込みは background にまとめて任せる)
  function log(src, ev, detail) {
    try {
      chrome.runtime.sendMessage({ type: 'LOG', entry: { t: Date.now(), src, ev, detail: detail || null } }).catch(() => {});
    } catch (e) { /* 拡張の再読み込み直後などは無視 */ }
  }
  // ログに残す個人情報は伏せる
  function maskName(n) {
    const a = Array.from(String(n || '').replace(/\s/g, ''));
    return a.length ? a[0] + '＊'.repeat(Math.min(Math.max(a.length - 1, 1), 4)) : '';
  }
  function maskTel(t) {
    const d = String(t || '').replace(/\D/g, '');
    return d ? '***' + d.slice(-4) : '';
  }
  const pathOf = u => { if (!u) return ''; try { return new URL(u, location.href).pathname; } catch (e) { return ''; } };

  async function getPending() {
    const { pending } = await chrome.storage.local.get('pending');
    if (!pending) return null;
    if (Date.now() - pending.ts > PENDING_TTL) { await chrome.storage.local.remove('pending'); return null; }
    return pending;
  }
  async function savePending(p) { await chrome.storage.local.set({ pending: p }); }
  async function clearPending() { await chrome.storage.local.remove('pending'); }

  // ヤマトの「システムエラー」画面か
  function isSystemErrorPage() {
    const heads = Array.from(document.querySelectorAll('h1,h2,h3,.title,.page_title')).map(e => e.innerText).join(' ');
    if (/システムエラー/.test(heads) || /システムエラー/.test(document.title)) return true;
    const body = (document.body && document.body.innerText || '').slice(0, 3000);
    return /システムエラー/.test(body) && /ログイン画面へ/.test(body);
  }

  // 文字やリンク先から、押せる要素を探す(一番小さい=一番具体的な要素を選ぶ)
  function findClickable(opts) {
    const cands = [];
    if (opts.href) {
      document.querySelectorAll('a[href]').forEach(a => {
        if (a.getAttribute('href').indexOf(opts.href) >= 0 && visible(a)) cands.push(a);
      });
      if (cands.length) return cands[0];
    }
    const texts = opts.texts || [];
    document.querySelectorAll('a, button, input[type=button], input[type=submit], [onclick], li, div').forEach(el => {
      if (!visible(el)) return;
      const t = (el.innerText || el.value || '').replace(/\s+/g, '');
      if (!t || t.length > 80) return;
      if (texts.some(x => t.indexOf(x) >= 0)) cands.push(el);
    });
    cands.sort((a, b) => (a.innerText || '').length - (b.innerText || '').length);
    // a/button を優先
    return cands.find(el => /^(A|BUTTON|INPUT)$/.test(el.tagName)) || cands[0] || null;
  }
  const describe = el => el ? el.tagName + (el.id ? '#' + el.id : '') + ' "' + (el.innerText || el.value || '').replace(/\s+/g, ' ').trim().slice(0, 30) + '"' + (el.getAttribute && el.getAttribute('href') ? ' href=' + pathOf(el.getAttribute('href')) : '') : null;

  // 画面上部のお知らせ
  let bar;
  function showBar(html, color, closable) {
    if (!document.body) return;
    if (!bar) {
      bar = document.createElement('div');
      bar.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;max-width:640px;width:calc(100% - 32px);padding:10px 14px;border-radius:8px;color:#fff;font:13px/1.6 sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.35);';
      document.body.appendChild(bar);
    }
    bar.style.background = color || '#00843d';
    bar.innerHTML = html + (closable === false ? '' : '<div style="margin-top:6px;text-align:right"><button type="button" data-act="close" style="padding:2px 10px;cursor:pointer;color:#222">閉じる</button></div>');
    bar.style.display = 'block';
    const c = bar.querySelector('[data-act=close]');
    if (c) c.onclick = () => { bar.style.display = 'none'; };
  }

  return { PENDING_TTL, sleep, visible, waitFor, esc, log, maskName, maskTel, pathOf, getPending, savePending, clearPending,
    isSystemErrorPage, findClickable, describe, showBar,
    DEFAULT_SETTINGS, SETTINGS_VERSION, byteLen, cutBytes, splitAddress, formatZip, formatTel, toHalfKana, normSpace, getSettings };
})();

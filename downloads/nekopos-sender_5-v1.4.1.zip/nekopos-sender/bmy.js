// ヤマトビジネスメンバーズ(bmypage)の全ページで動く。
// 「ネコポスへ」の続きがあるとき、ログイン後のトップから「送り状発行システムB2クラウド」を自動でクリックする。
(function () {
  'use strict';
  if (window.__nekoBmyAlive && window.__nekoBmyAlive()) return;
  window.__nekoBmyAlive = () => { try { return !!chrome.runtime.id; } catch (e) { return false; } };
  const N = NEKO;
  const MAX_HOPS = 4;
  let busy = false;

  const hasLoginForm = () => Array.from(document.querySelectorAll('input[type=password]')).some(N.visible);

  async function handle(trigger) {
    if (busy) return 'busy';
    busy = true;
    try {
      if (N.isSystemErrorPage()) {
        N.log('BMY', 'system_error_page', { path: location.pathname, referrer: N.pathOf(document.referrer), trigger });
        const p = await N.getPending();
        if (p) {
          p.hops = 0;
          await N.savePending(p);
          N.showBar('🐈 エラー画面になりました。「ログイン画面へ」からログインし直してください。ログインすると、送り先の入力まで自動で進みます。', '#b00020', false);
        }
        return 'error_page';
      }
      const pending = await N.getPending();
      if (!pending) return 'no_pending';

      if (hasLoginForm()) {
        N.log('BMY', 'login_needed', { path: location.pathname });
        N.showBar('🐈 ログインしてください。ログインすると、B2の「1件ずつ発行」まで自動で進んで送り先が入ります。', '#00843d', false);
        return 'login_needed';
      }
      if ((pending.hops || 0) >= MAX_HOPS) {
        N.log('BMY', 'give_up', { path: location.pathname, hops: pending.hops });
        N.showBar('🐈 自動で進めませんでした。「送り状発行システムB2クラウド」→「1件ずつ発行」を開くと、送り先が入ります。', '#b26a00');
        pending.hops = 0;
        await N.savePending(pending);
        return 'give_up';
      }
      // ログイン直後はメニューの描画を少し待つ
      const el = await N.waitFor(() => N.findClickable({ texts: ['送り状発行システムB2クラウド'] }) || N.findClickable({ texts: ['B2クラウド'] }), 8000);
      N.log('BMY', 'navigate_click', { path: location.pathname, el: N.describe(el), hops: pending.hops || 0 });
      if (!el) {
        N.showBar('🐈 「送り状発行システムB2クラウド」を開いてください。開くと「1件ずつ発行」まで自動で進みます。', '#b26a00');
        return 'no_link';
      }
      pending.hops = (pending.hops || 0) + 1;
      await N.savePending(pending);
      el.click();
      return 'clicked_b2';
    } catch (e) {
      N.log('BMY', 'exception', { path: location.pathname, msg: String(e && e.message || e) });
      return 'exception';
    } finally {
      busy = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'GO') {
      handle('message').then(r => sendResponse({ ok: true, result: r }));
      return true;
    }
    if (msg && msg.type === 'PING') { sendResponse({ ok: true, path: location.pathname }); }
  });

  N.getPending().then(p => N.log('BMY', 'page_load', { path: location.pathname, referrer: N.pathOf(document.referrer), pending: !!p, login_form: hasLoginForm() }));
  handle('load');
})();

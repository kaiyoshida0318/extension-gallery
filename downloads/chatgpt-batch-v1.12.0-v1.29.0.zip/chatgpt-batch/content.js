// ChatGPT 画像一括送信 — content script (v1.2)
// ChatGPTを開いたときだけ右上にボタンを出し、パネルから画像＋指示文を設定間隔で1枚ずつ送信する。
(() => {
  if (window.__cgbLoaded) return;
  window.__cgbLoaded = true;

  const HOST_ID = 'cgb-host';
  const PUSH_ID = 'cgb-push-style';
  const DRY_RUN = !!window.__CGB_DRYRUN; // テスト用：送信ボタンを押す直前で止める
  const MIN_W = 320, WIDE_AT = 680;
  const defW = () => Math.max(MIN_W, Math.round(window.innerWidth * 0.49));
  const VERSION = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return '1.29.0'; } })();
  // ChatGPTは前に開いたチャットを見えない<main>として残すことがある。いま表示中のmainを選ぶ
  function chatMain() {
    const mains = [...document.querySelectorAll('main')];
    if (mains.length <= 1) return mains[0] || document;
    const area = m => { const r = m.getBoundingClientRect(); return r.width * r.height; };
    const shown = mains.filter(m => area(m) > 0 && !m.closest('[hidden], [inert], [aria-hidden="true"]'));
    return shown.sort((x, y) => area(y) - area(x))[0] || mains[mains.length - 1];
  }
  const CHANGELOG = [
    ['1.29.0', '画像右上の「⬇ ダウンロード」と画像DLの「⬇ ダウンロード（右上に）」は、Chromeのダウンロード（画面右上のアイコン）に保存。保存先は⚙設定で変更可'],
    ['1.28.0', '右側に「⚙ 設定」を追加：画像右上の「⬇ ダウンロード」の保存先（デスクトップ／好きなフォルダ／保存先と同じ／ダウンロードフォルダ）を選べる'],
    ['1.27.1', '画像の右上のダウンロードボタンを大きく見やすく。生成直後の画像にも付くように見つけ方を強化'],
    ['1.27.0', 'チャットに出た生成画像の右上に「⬇ DL」ボタン：押すとデスクトップに日時の名前（例：2026-10-21_13-57-32.png）で保存'],
    ['1.26.1', '画像DLなどパネル内で、マウスを乗せてホイールを回すとスクロールできない問題を修正'],
    ['1.26.0', '送信中の画面：左上に今の送信状況、その下に本物のチャットの最新のやり取り（生成途中の画像も）をリアルタイム表示'],
    ['1.25.0', '「① 反映」「② 実行」の2段階に：テンプレ・zip用テンプレは①反映で各画像の指示に入れ、確認してから②実行。下に浮かぶ操作バー'],
    ['1.24.0', '送信先を一番上に3つ横並び（「現在選択しているチャット」を追加）。送信間隔は上部の右に。左側の設定欄と「動作の記録」をなくし、画像一覧を広く'],
    ['1.23.1', '一括送信から「全画像に共通で付ける指示」と「指示テンプレ」の欄を削除（テンプレは「📝 テンプレ編集」で管理）'],
    ['1.23.0', '上部に「📦 zip用テンプレ編集」を追加：zip用テンプレはここで作成・編集。直した文章は✓の画像の指示にすぐ反映'],
    ['1.22.0', '「画像を追加」「zipを追加」に分割。各画像に「📦 zip添付」：✓の画像だけzipを添付し、zip用テンプレを指示に入れる'],
    ['1.21.1', 'zipは「参考ファイル」に：送る一覧の画像すべてに、毎回一緒に添付して送信'],
    ['1.21.0', '一括送信にzipファイルも追加できるように（zipはそのまま1件として添付して送信）'],
    ['1.20.0', '保存のたびに日時の名前のフォルダ（例：2026-10-19_1224）を作り、その中に画像を保存（一番下で切り替え可）'],
    ['1.19.1', '共通の指示：「テンプレに保存」を外し、テンプレ選択 → 入力欄 → 全体へ反映 の順に'],
    ['1.19.0', '上部を「一括送信／テンプレ編集／画像DL／ログ」に。テンプレ編集ページ：全文の確認・自動保存・並べ替え・複製・まとめて削除（元に戻す付き）'],
    ['1.18.0', '共通の指示は最初は空欄に。すぐ下に「全体へ反映」「テンプレに保存」。テンプレは名前を押すとその場で確認・編集'],
    ['1.17.2', '「新しいタブ」「開く」を押しても今の画面のまま、裏で新しいタブを開く'],
    ['1.17.1', '画像DL：DLボタンが押した瞬間に「保存中…」に変わり進み具合を表示。保存した画像には大きな✓'],
    ['1.17.0', '送信先は「新規（今回分まとめて）」を上・標準に、「毎回新しいチャット」を下に（指定URLは削除）。共通の指示に「いつも入れるテンプレ」。テンプレ欄を小さく'],
    ['1.16.0', '送信先に「新規（今回分はまとめて1つに）」を追加：1枚目で新しいチャットを作り、残りも同じチャットへ'],
    ['1.15.0', '画像DL：横に並べる数（×2〜×5）と選択クリア。スクロールで画面から消えた画像も一覧に残す'],
    ['1.14.0', '保存先の住所を全部表示（たどれない場合は貼り付けて登録）。「📜 ログ」を追加：画像を作ったページの一覧'],
    ['1.13.2', '画像DL：常に横2列。狭くなるとまずボタン側が縮み、ボタンがかなり狭くなってから画像が縮む'],
    ['1.13.1', '画像DL：画像の表示を縦横2倍に。「保存先へDL」「デスクトップにDL」を縦並びに'],
    ['1.13.0', '画像DL：大きい「全選択／全選択解除」切り替えボタン。最初は未選択。画像クリックで選択を切り替え（拡大は🔍）'],
    ['1.12.0', '画像DL：「全件選択／全件解除」の行を追加。DLボタンを「保存先へDL」と「デスクトップにDL」の2つに'],
    ['1.11.2', 'ChatGPTが前のチャットを見えない状態で残すようになり、画像DLが0枚・送信先がずれる問題を修正（表示中の画面だけを対象に）'],
    ['1.11.1', '2枚以上の生成（右側にサムネイルが並ぶ表示）で全部の画像を取得。チャット移動・読み込み直し時に一覧が更新されない問題を修正'],
    ['1.11.0', '画像DLの名称：初期値は薄い見本（x-01, x-02…）。空のまま保存するとその名前、連番は「ベース名-01」形式'],
    ['1.10.2', 'バージョン番号のみ更新（中身は1.10.1と同じ）'],
    ['1.10.1', '2枚まとめて生成したときに片方を取りこぼす問題を修正（画面外の画像・遅れて出る画像にも対応、DL一覧を自動更新）'],
    ['1.10.0', '保存先フォルダを選べるように（一番下の「保存先」で選択・切り替え・記憶）'],
    ['1.9.0', '「⬇ 画像DL」を追加：開いているチャットの画像を一覧表示し、名前を付けてダウンロード'],
    ['1.8.0', '「＋ 画像を追加」欄を縦に広げてドロップしやすく'],
    ['1.7.0', '生成画像をツールからダウンロード（自動DL・1枚ずつ・まとめてDL）'],
    ['1.6.0', '画像一覧に「一括でテンプレ」バー（全部に追加／置き換え／空欄だけ／全消し）'],
    ['1.5.0', '左に指示・設定、右に画像の2列レイアウト。開いたときの幅を画面の約半分に'],
    ['1.4.0', 'バージョン表示と更新履歴を追加'],
    ['1.3.0', 'OKを押すと進捗画面に切り替え（カウントダウン・経過時間・終了予定）'],
    ['1.2.0', '送信先の選択（最近の項目／URL入力）、指示テンプレ、パネル幅の調整'],
    ['1.1.0', 'ChatGPTを開いたときだけ右上にボタンを表示'],
    ['1.0.0', '初版'],
  ];

  // ---------- ドロップ・キー入力をChatGPT本体に奪われないようにする（最優先で登録） ----------
  const inPanel = e => e.composedPath().some(n => n && n.id === HOST_ID);
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(type => {
    window.addEventListener(type, e => {
      if (!inPanel(e)) return;
      e.stopImmediatePropagation();
      e.preventDefault();
      if (type === 'drop') panelApi?.onDrop(e);
      else if (type === 'dragleave') panelApi?.onDragLeave(e);
      else panelApi?.onDragOver(e);
    }, true);
  });
  // マウスホイール：ChatGPT側がホイールを止めてしまうことがあるので、パネルの中は自分でスクロールする
  const canScroll = (el, dy, dx) => {
    if (!el || el.nodeType !== 1) return false;
    const cs = getComputedStyle(el);
    if (dy) {
      if (!/(auto|scroll)/.test(cs.overflowY) || el.scrollHeight <= el.clientHeight + 1) return false;
      return dy > 0 ? el.scrollTop + el.clientHeight < el.scrollHeight - 1 : el.scrollTop > 0;
    }
    if (!/(auto|scroll)/.test(cs.overflowX) || el.scrollWidth <= el.clientWidth + 1) return false;
    return dx > 0 ? el.scrollLeft + el.clientWidth < el.scrollWidth - 1 : el.scrollLeft > 0;
  };
  window.addEventListener('wheel', e => {
    if (e.ctrlKey || !inPanel(e)) return; // Ctrl+ホイール（拡大縮小）はそのまま
    const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight : 1;
    let dy = e.deltaY * unit, dx = e.deltaX * unit;
    if (e.shiftKey && !dx) { dx = dy; dy = 0; }
    const path = e.composedPath();
    const sc = path.find(n => n && n.nodeType === 1 && n.id !== HOST_ID && canScroll(n, dy, dx));
    e.stopImmediatePropagation(); e.preventDefault();
    if (sc) { if (dy) sc.scrollTop += dy; if (dx) sc.scrollLeft += dx; }
  }, { capture: true, passive: false });
  ['keydown', 'keyup', 'keypress', 'paste'].forEach(type => {
    window.addEventListener(type, e => { if (inPanel(e)) e.stopImmediatePropagation(); }, true);
  });

  let panelApi = null;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const collator = new Intl.Collator('ja', { numeric: true, sensitivity: 'base' });

  // ---------- 設定の保存（拡張のストレージ。なければ localStorage） ----------
  const hasCS = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const cache = {};
  const store = {
    async load() {
      if (hasCS) {
        try { Object.assign(cache, await chrome.storage.local.get(null)); return; } catch (e) {}
      }
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k.startsWith('cgb_')) cache[k.slice(4)] = JSON.parse(localStorage.getItem(k));
        }
      } catch (e) {}
    },
    get(k, d) { return k in cache ? cache[k] : d; },
    set(k, v) {
      cache[k] = v;
      if (hasCS) { try { chrome.storage.local.set({ [k]: v }); return; } catch (e) {} }
      try { localStorage.setItem('cgb_' + k, JSON.stringify(v)); } catch (e) {}
    },
  };

  // ---------- ChatGPT画面の操作 ----------
  const cg = {
    composer() { const m = chatMain(); return m.querySelector('.ProseMirror[contenteditable="true"]') || m.querySelector('#prompt-textarea') || document.querySelector('.ProseMirror[contenteditable="true"]') || document.querySelector('#prompt-textarea'); },
    form() { return this.composer()?.closest('form') || null; },
    submitBtn() {
      const f = this.form(); if (!f) return null;
      return f.querySelector('button[type="submit"]') ||
        f.querySelector('[data-testid="send-button"], #composer-submit-button') ||
        [...f.querySelectorAll('button')].find(b => /^(送信|Send)/i.test(b.getAttribute('aria-label') || ''));
    },
    isGenerating() {
      const scope = this.form() || document;
      return !![...scope.querySelectorAll('button')].find(b => /停止|stop/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.dataset.testid || '')));
    },
    imageInput() {
      const f = this.form();
      const ins = [...(f || document).querySelectorAll('input[type="file"]')].concat(f ? [...document.querySelectorAll('input[type="file"]')] : []);
      return ins.find(i => i.accept === 'image/*') || ins.find(i => /image/.test(i.accept)) || ins[0] || null;
    },
    newChatBtn() {
      return document.querySelector('[data-testid="create-new-chat-button"]') ||
        [...document.querySelectorAll('button, a')].find(e => /^(新しいチャット|New chat)$/i.test((e.getAttribute('aria-label') || e.innerText || '').trim())) ||
        document.querySelector('a[href="/"]');
    },
    // サイドバーの「最近の項目」などから、開けるチャット/プロジェクト/GPTの一覧を集める
    recentLinks() {
      const seen = new Set(), out = [];
      document.querySelectorAll('nav a[href], aside a[href], a[href^="/c/"], a[href^="/g/"]').forEach(a => {
        const href = a.getAttribute('href');
        if (!/^\/(c|g)\//.test(href) || seen.has(href) || a.closest('#' + HOST_ID)) return;
        const title = (a.innerText || a.getAttribute('aria-label') || '').trim().split('\n')[0];
        if (!title) return;
        seen.add(href); out.push({ href, title });
      });
      return out;
    },
    async waitFor(fn, timeout, label) {
      const t0 = Date.now();
      while (Date.now() - t0 < timeout) {
        try { const v = fn(); if (v) return v; } catch (e) {}
        await sleep(300);
      }
      throw new Error(`${label}（${Math.round(timeout / 1000)}秒待っても変化なし）`);
    },
    async openNewChat() {
      const b = this.newChatBtn();
      if (!b) { log('「新しいチャット」ボタンが見つからないため、今のチャットに送ります'); return; }
      b.click();
      await sleep(1500);
      await this.waitFor(() => this.composer(), 15000, '入力欄が見つかりません');
    },
    // ページを再読み込みせずに指定URLへ移動（再読み込みすると一覧が消えるため）
    async openUrl(raw) {
      let u;
      try { u = new URL(raw, location.origin); } catch (e) { throw new Error('送信先URLの形式が正しくありません'); }
      if (u.origin !== location.origin) throw new Error('送信先は chatgpt.com のURLにしてください');
      const path = u.pathname + u.search;
      const samePlace = () => location.pathname + location.search === path || (chatIdOf(path) && chatIdOf(location.pathname) === chatIdOf(path));
      if (!samePlace()) {
        const link = [...document.querySelectorAll('a[href]')].find(a => a.getAttribute('href') === path && !a.closest('#' + HOST_ID));
        if (link) link.click();
        else {
          history.pushState({}, '', path);
          window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
        }
        await this.waitFor(samePlace, 10000, '送信先のページに移動できません');
        await sleep(2000);
      }
      await this.waitFor(() => this.composer(), 15000, '送信先に入力欄が見つかりません');
    },
    fileInput() {
      const f = this.form();
      const ins = [...(f || document).querySelectorAll('input[type="file"]')].concat(f ? [...document.querySelectorAll('input[type="file"]')] : []);
      return ins.find(i => i.accept === '') || ins.find(i => !/image|video/.test(i.accept)) || ins[0] || null;
    },
    async attach(file) {
      const zip = /\.zip$/i.test(file.name) || /zip/i.test(file.type);
      // 添付できたかの目印：画像なら入力欄の画像が増える／zipなら入力欄にファイル名が出る
      const count = () => {
        const f = this.form(); if (!f) return 0;
        if (!zip) return f.querySelectorAll('img').length;
        return [...f.querySelectorAll('button, [aria-label], div, span')].filter(e => (e.getAttribute('aria-label') || '').startsWith(file.name) || (e.childElementCount === 0 && (e.textContent || '').trim() === file.name)).length;
      };
      const before = count();
      const inp = zip ? this.fileInput() : this.imageInput();
      let ok = false;
      if (inp) {
        const dt = new DataTransfer(); dt.items.add(file);
        inp.files = dt.files;
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        ok = await this.waitFor(() => count() > before, 15000, '').catch(() => false);
      }
      if (!ok) { // 予備：貼り付けで添付
        const c = this.composer(); c.focus();
        const dt = new DataTransfer(); dt.items.add(file);
        c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        await this.waitFor(() => count() > before, 15000, zip ? 'zipを添付できませんでした' : '画像を添付できませんでした');
      }
    },
    typeText(text) {
      const c = this.composer(); c.focus();
      text.split('\n').forEach((line, i) => {
        if (i > 0) c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', shiftKey: true, bubbles: true, cancelable: true }));
        if (line) document.execCommand('insertText', false, line);
      });
    },
    // 生成画像（ChatGPTの画像ギャラリー内のimg）
    // 複数枚生成のとき右側に並ぶサムネイル（「生成画像2を表示」ボタン）
    thumbImgs(scope) {
      return [...(scope || document).querySelectorAll('button img, [role="button"] img, [role="tab"] img')].filter(i => {
        const b = i.closest('button, [role="button"], [role="tab"]');
        const label = (b?.getAttribute('aria-label') || b?.title || '');
        return /生成画像\s*\d+\s*を表示|(show|view)\s+generated\s+image|generated\s+image\s*\d+/i.test(label);
      });
    },
    generatedImgs() {
      const main = chatMain();
      const thumbs = this.thumbImgs(main);
      const thumbSrc = new Set(thumbs.map(i => i.currentSrc || i.src));
      const set = new Set(main.querySelectorAll('[data-testid="generated-image-gallery"] img, [data-testid="generated-image-preview"] img, img[alt^="生成画像"], img[alt^="Generated image"]'));
      thumbs.forEach(i => set.add(i));
      // 予備：ギャラリー外でも「生成画像」らしい大きな画像（添付画像・アイコンは除く）
      main.querySelectorAll('img').forEach(i => {
        if (set.has(i) || i.closest('form')) return;
        if (/添付|Uploaded|avatar|アイコン|icon/i.test(i.alt || '')) return;
        const big = i.naturalWidth >= 512 && i.naturalHeight >= 512;
        if (big && /画像|image/i.test(i.alt || '') && i.closest('[data-message-author-role="assistant"], [data-turn="assistant"], article, [data-content-search-turn-key]')) set.add(i);
      });
      // 画面の順番に並べる。サムネイル列がある返答は、大きい表示（マウスを乗せた1枚）ではなくサムネイルの順番を使う
      return [...set]
        .filter(i => !i.closest('#' + HOST_ID))
        .filter(i => thumbs.includes(i) || !thumbSrc.has(i.currentSrc || i.src))
        .sort((a, b) => a === b ? 0 : (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    },
    // 自分が送った添付画像（ギャラリー外のimgの最後）
    lastUserImg() {
      const main = chatMain();
      const gens = new Set(this.generatedImgs()), thumbs = new Set(this.thumbImgs(main));
      const all = [...main.querySelectorAll('img')].filter(i => !i.closest('[data-testid="generated-image-gallery"]') && !gens.has(i) && !thumbs.has(i) && !i.closest('#' + HOST_ID) && !i.closest('form'));
      return all[all.length - 1] || null;
    },
    async collectNew(before) {
      const pick = () => {
        const anchor = this.lastUserImg();
        const seen = new Set();
        return this.generatedImgs().filter(i => {
          const src = i.currentSrc || i.src;
          if (!src || before.has(src) || seen.has(src)) return false;
          if (anchor && !(anchor.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
          if (/^data:|^about:/.test(src)) return false; // 生成途中のぼかしプレビューなど
          seen.add(src); return true; // 画面外で未読み込み（lazy）の画像も取りこぼさない
        });
      };
      // 2枚目以降が遅れて出てくる・途中のぼかし画像が仕上がり画像に差し替わることがあるため、
      // 画像の枚数とURLが一定時間変わらなくなるまで待つ
      const t0 = Date.now(); let sig = '', stableSince = Date.now(), imgs = [];
      while (Date.now() - t0 < 120000) {
        imgs = pick();
        const now = imgs.map(i => i.currentSrc || i.src).join('|');
        if (now !== sig) { sig = now; stableSince = Date.now(); }
        if (imgs.length && Date.now() - stableSince > 8000) break;
        if (!imgs.length && Date.now() - t0 > 30000) break;
        await sleep(700);
      }
      const out = [], got = new Set();
      for (const i of imgs) {
        const src = i.currentSrc || i.src;
        if (got.has(src)) continue; got.add(src);
        try {
          const b = await (await fetch(src)).blob();
          if (b.size > 2048 && /^image\//.test(b.type || 'image/')) out.push(b);
        } catch (e) { log('生成画像の取得に失敗：' + e.message); }
      }
      if (imgs.length) log(`生成画像を${out.length}枚取得（画面上で${imgs.length}枚検出）`);
      return out;
    },
    async send(file, text, phase = () => {}, extras = []) {
      await this.waitFor(() => this.composer(), 15000, '入力欄が見つかりません（ログイン切れ？）');
      await this.waitFor(() => !this.isGenerating(), 10 * 60000, '前の生成が終わりません');
      phase('attach');
      await this.attach(file);
      for (const x of extras) { await sleep(400); await this.attach(x); } // 参考ファイルも一緒に
      phase('type');
      if (text) this.typeText(text);
      phase('upload');
      const btn = await this.waitFor(() => { const b = this.submitBtn(); return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true' ? b : null; }, 120000, '送信ボタンが押せる状態になりません');
      await sleep(1200);
      if (DRY_RUN) { phase('gen'); await sleep(1500); log('[テスト] 送信直前で停止'); return { url: location.href, images: [] }; }
      const before = new Set(this.generatedImgs().map(i => i.currentSrc || i.src));
      btn.click();
      phase('gen');
      await this.waitFor(() => this.isGenerating() || /\/c\//.test(location.pathname), 30000, '送信後に反応がありません').catch(e => log(e.message));
      const t0 = Date.now(); let quietSince = 0;
      while (Date.now() - t0 < 15 * 60000) {
        if (this.isGenerating()) quietSince = 0;
        else if (!quietSince) quietSince = Date.now();
        else if (Date.now() - quietSince > 4000 && Date.now() - t0 > 6000) break;
        await sleep(500);
      }
      phase('collect');
      const images = await this.collectNew(before);
      return { url: location.href, images };
    },
  };

  // ---------- 状態 ----------
  const state = { items: [], running: false, timer: null, nextAt: 0, busy: false, open: false, width: 0, runItems: [], refs: [], tplEditIdx: null, mode: 'send', runView: false, current: null, phase: '', startedAt: 0, endedAt: 0, stopReason: '', destLabel: '' };
  let uid = 0, root = null;
  const $ = id => root.getElementById(id);

  // 新しいタブを、今の画面から動かずに裏で開く（拡張の裏側の処理に頼む。だめなら普通に開く）
  function openBgTab(url) {
    const abs = new URL(url, location.origin).href;
    try {
      chrome.runtime.sendMessage({ type: 'cgb-open-tab', url: abs }, r => {
        if (chrome.runtime.lastError || !r || !r.ok) window.open(abs, '_blank', 'noopener');
      });
    } catch (e) { window.open(abs, '_blank', 'noopener'); }
  }

  function log(msg) {
    const t = new Date().toLocaleTimeString('ja-JP');
    console.log('[画像一括送信]', msg);
    const el = root?.getElementById('log'); if (el) el.textContent = `[${t}] ${msg}\n` + el.textContent;
  }
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---------- 見た目 ----------
  const CSS = `
  :host{all:initial}
  [hidden]{display:none !important}
  *{box-sizing:border-box;font-family:"Hiragino Sans","Noto Sans JP","Yu Gothic UI",Meiryo,sans-serif}
  .tabs{position:fixed;right:16px;top:64px;z-index:2147483646;display:flex;flex-direction:column;gap:6px;align-items:flex-end}
  .tab{background:#1f6f5c;color:#fff;border:0;border-radius:99px;
    padding:8px 14px;cursor:pointer;font-size:13px;font-weight:700;box-shadow:0 2px 10px rgba(0,0,0,.2);display:flex;align-items:center;gap:6px}
  .tab:hover{background:#185a4a}
  .tab.running{background:#b4541a}
  .tab.dl{background:#2f4f7a}
  .tab.dl:hover{background:#243d60}
  .tab.lg{background:#6b5a2f}
  .tab.lg:hover{background:#574924}
  .tab.st{background:#5b5f66}
  .tab.st:hover{background:#45484e}
  .setcard{display:flex;flex-direction:column;gap:6px}
  .setcard .sth{font-size:14px}
  .qopts{display:flex;flex-direction:column;gap:6px}
  .qopt{display:flex;align-items:center;gap:10px;border:1px solid var(--line);border-radius:10px;padding:9px 12px;cursor:pointer;background:var(--panel)}
  .qopt:hover{border-color:var(--accent)}
  .qopt.on{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset;background:var(--drop)}
  .qopt input{margin:0;accent-color:var(--accent);width:16px;height:16px}
  .qopt span{flex:1;min-width:0;display:flex;flex-direction:column}
  .qopt b{font-size:13px}
  .qopt small{font-size:11px;color:var(--sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .qsok{font-size:12px;color:var(--accent);font-weight:700;min-height:16px}
  .tpbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:6px 10px}
  .tpundo{display:flex;gap:8px;align-items:center;background:#fff4e5;border:1px solid #f0b46a;color:#7a4a10;border-radius:8px;padding:6px 10px;font-size:12px}
  .tpgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:8px}
  .tpc{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px;display:flex;flex-direction:column;gap:6px}
  .tpc.sel{border-color:var(--err);box-shadow:0 0 0 1px var(--err) inset}
  .tpc .top{display:flex;gap:6px;align-items:center}
  .tpc .top input[type=text]{flex:1;min-width:0;font-weight:700;padding:5px 8px}
  .tpc .no{font-size:12px;font-weight:800;color:var(--accent);min-width:18px;text-align:center}
  .tpc textarea{min-height:90px;resize:vertical;line-height:1.5}
  .tpc .bt{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
  .tpc .bt .btn{padding:3px 8px;font-size:11px}
  .tpc .st{font-size:11px;color:var(--sub);margin-left:auto}
  .tpc .st.ok{color:var(--accent)}
  .hl{display:flex;flex-direction:column;gap:6px}
  .hl .day{font-size:12px;font-weight:700;color:var(--sub);margin:6px 0 0}
  .hi{display:grid;grid-template-columns:64px 1fr auto;gap:10px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
  .hi.cur{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .hi .th{width:64px;height:64px;border-radius:6px;background:var(--chip);object-fit:cover;display:block}
  .hi .th.none{display:flex;align-items:center;justify-content:center;color:var(--sub);font-size:20px}
  .hi .tt{font-weight:700;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .hi .mt{font-size:11px;color:var(--sub);display:flex;gap:8px;flex-wrap:wrap;margin-top:2px}
  .hi .mt .bt{background:var(--drop);color:var(--accent);border-radius:99px;padding:0 6px}
  .hi .pr{font-size:11px;color:var(--sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
  .hi .ac{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}
  .hi .ac .btn{padding:4px 8px;font-size:11px}
  .modes{margin-left:4px;width:auto;flex-wrap:wrap}
  .tpc.using{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .tpc .usebadge{font-size:11px;font-weight:800;color:var(--accent);white-space:nowrap}
  #tplView.zmode .tpc .no{color:#b7791f}
  .modes button{padding:4px 5px;font-size:11.5px;letter-spacing:-.2px;flex:none;white-space:nowrap}
  .hd-l{display:flex;align-items:center;min-width:0}
  .hd-l>b{white-space:nowrap;flex:none}
  .hd-l{flex-wrap:wrap;row-gap:6px}
  .ivl{display:flex;align-items:center;gap:3px;margin-left:4px;padding:2px 3px 2px 5px;border:1px solid var(--line);border-radius:8px;background:var(--bg);white-space:nowrap}
  .ivl>span{font-size:12px;font-weight:700;color:var(--sub)}
  .ivl input[type=number]{width:38px;padding:3px 6px;font-size:12px}
  .ivl select{width:auto;padding:3px 2px;font-size:12px}
  .ivl .chk{margin:0 0 0 3px;gap:3px}
  .destbar{display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--line);background:var(--panel)}
  .destbar .dl0{font-size:12px;font-weight:700;color:var(--sub);white-space:nowrap}
  .dseg{flex:1;min-width:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr))}
  .dseg button{text-align:left;padding:7px 10px;font-size:13px;border-left:1px solid var(--line);min-width:0}
  .dseg button:first-child{border-left:0}
  .dseg button small{display:block;font-size:11px;font-weight:400;opacity:.85;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dseg button:disabled{cursor:default}
  .igrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:8px;align-items:start}
  .panel.wide .item{grid-template-columns:22px 96px 1fr}
  .panel.wide .thumb{width:96px;height:96px}
  .panel.wide textarea.pr{min-height:72px}
  .dlbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
  .dlbar .bl{font-size:12px;font-weight:700}
  .dlbar input[type=text]{width:auto;flex:1;min-width:140px;padding:4px 8px;font-size:12px}
  .dlgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  .dli{display:grid;grid-template-columns:20px minmax(56px,192px) minmax(120px,1fr);min-width:0;overflow:hidden;gap:8px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
  .dli{transition:border-color .12s, background .12s}
  .vseg{flex-direction:column}
  .vseg button{text-align:left;padding:8px 10px;font-size:13px;border-top:1px solid var(--line)}
  .vseg button:first-child{border-top:0}
  .vseg button small{display:block;font-size:11px;font-weight:400;opacity:.8;margin-top:1px}
  .colseg{width:auto}
  .colseg button{flex:none;padding:4px 12px;font-weight:700}
  .dlgrid.compact .dli{grid-template-columns:1fr;position:relative;align-items:stretch;gap:6px;padding:6px}
  .dlgrid.compact .dli .ck{position:absolute;left:12px;top:12px;z-index:2;width:18px;height:18px}
  .dlgrid.compact .dli .pic{width:100%}
  .dlgrid.compact .dli.on .pic::after{left:auto;right:6px;top:6px}
  .dlgrid.compact .dli .acts{margin-top:6px;gap:4px}
  .dlgrid.compact .dli .acts .btn{padding:5px 4px;font-size:11px}
  .dlgrid.compact .dli .nmrow input{padding:4px 6px;font-size:11px}
  .dli.on{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset;background:var(--drop)}
  .dli .ck{width:16px;height:16px;cursor:pointer;accent-color:var(--accent)}
  .dli .pic{position:relative;width:100%;aspect-ratio:1/1;min-width:0;cursor:pointer}
  .dli img{width:100%;height:100%;object-fit:contain;background:var(--chip);border-radius:6px;display:block}
  .dli.on .pic::after{content:"✓";position:absolute;left:4px;top:4px;width:22px;height:22px;border-radius:50%;background:var(--accent);color:var(--accent-ink);font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;box-shadow:0 1px 3px rgba(0,0,0,.3)}
  .dli .savedmark{position:absolute;inset:0;border-radius:6px;background:rgba(255,255,255,.55);display:none;flex-direction:column;align-items:center;justify-content:center;pointer-events:none;z-index:1}
  .dli.saved .savedmark{display:flex;animation:cgbPop .35s ease-out}
  .dli .savedmark .ck2{width:58%;max-width:110px;aspect-ratio:1/1;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:clamp(22px,5vw,64px);font-weight:900;box-shadow:0 4px 14px rgba(0,0,0,.35);line-height:1}
  .dli .savedmark .tx{margin-top:6px;font-size:12px;font-weight:800;color:#fff;background:var(--accent);border-radius:99px;padding:2px 10px;box-shadow:0 2px 6px rgba(0,0,0,.25);white-space:nowrap}
  .dli.saved{border-color:var(--accent)}
  @keyframes cgbPop{0%{opacity:0;transform:scale(1.6)}70%{opacity:1;transform:scale(.95)}100%{transform:scale(1)}}
  .dlbtns .big.busy{background:linear-gradient(90deg,#b4541a var(--p,0%),#e0a070 var(--p,0%));border-color:#b4541a;color:#fff;cursor:progress;opacity:1}
  .dlbtns .big.fin{background:#15803d;border-color:#15803d;color:#fff;opacity:1;animation:cgbFlash .6s ease-out}
  @keyframes cgbFlash{0%{transform:scale(1.04)}100%{transform:scale(1)}}
  .dli .acts .btn.busy{background:#b4541a;border-color:#b4541a;color:#fff}
  .dli .acts .btn.fin{background:#15803d;border-color:#15803d;color:#fff}
  .dli .zbtn{position:absolute;z-index:2;right:3px;bottom:3px;border:0;border-radius:6px;background:rgba(0,0,0,.55);color:#fff;font-size:11px;padding:2px 5px;cursor:zoom-in}
  .seltoggle{width:100%;padding:12px;font-size:15px;font-weight:700;border-radius:8px;cursor:pointer;border:2px solid var(--accent);background:var(--panel);color:var(--accent)}
  .seltoggle.all{background:var(--accent);color:var(--accent-ink)}
  .dli .nmrow{display:flex;gap:4px;align-items:center}
  .dli .nmrow input{flex:1;min-width:0;padding:5px 7px;font-size:12px}
  .dli .nmrow input::placeholder{color:var(--sub);opacity:.55}
  .dli .ext{font-size:11px;color:var(--sub)}
  .dli .sz{font-size:11px;color:var(--sub);margin-top:4px}
  .dli .acts{display:grid;grid-template-columns:1fr;gap:6px;margin-top:10px}
  .dli .acts .btn{padding:8px 6px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dli .ok{display:block;margin-top:3px;min-height:14px}
  .dlsel{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .dlsel .cnt{font-size:12px;color:var(--sub)}
  .dlsel .desk{margin-left:auto;font-size:11px;color:var(--sub);display:flex;gap:6px;align-items:center}
  .dlbtns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .dlbtns .big{padding:10px 6px;font-size:13px}
  .dli .ok{font-size:11px;color:var(--accent)}
  .dli .kind{font-size:10px;padding:0 6px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .savebar{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .savebar .sl{font-size:12px;font-weight:700;white-space:nowrap}
  .savebar select{width:auto;flex:1;min-width:180px;padding:5px 8px;font-size:12px}
  .savepath{display:flex;gap:6px;align-items:center;font-size:12px;color:var(--ink);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:5px 8px}
  .savepath #savePath{flex:1;min-width:0;word-break:break-all;line-height:1.4}
  .savepath .ph{color:var(--sub);font-size:11px;margin-left:4px}
  .savepath input{flex:1;min-width:0;padding:5px 7px;font-size:12px}
  .zoom{position:fixed;inset:0;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;z-index:2147483647;cursor:zoom-out}
  .zoom img{max-width:92vw;max-height:92vh;border-radius:6px}
  .panel{position:fixed;right:0;top:0;bottom:0;max-width:100vw;z-index:2147483647;background:var(--bg);color:var(--ink);
    border-left:1px solid var(--line);display:flex;flex-direction:column;font-size:13px;line-height:1.5}
  .panel.light{--bg:#f7f6f2;--panel:#fff;--ink:#1d1d1b;--sub:#6b6a64;--line:#e3e1da;--accent:#1f6f5c;--accent-ink:#fff;--err:#b42318;--chip:#efeee8;--drop:#e6f2ec}
  .panel.dark{--bg:#18191b;--panel:#222326;--ink:#ecebe6;--sub:#9b9a94;--line:#35363c;--accent:#4fb393;--accent-ink:#0d1f19;--err:#f07a6e;--chip:#2b2c31;--drop:#1d2d27}
  .grip{position:absolute;left:-4px;top:0;bottom:0;width:8px;cursor:ew-resize;z-index:2}
  .grip::after{content:"";position:absolute;left:3px;top:50%;width:2px;height:40px;margin-top:-20px;border-radius:2px;background:var(--line)}
  .grip:hover::after,.grip.on::after{background:var(--accent)}
  .hd{position:relative;display:flex;align-items:center;justify-content:space-between;gap:6px;padding:10px 42px 10px 10px;border-bottom:1px solid var(--line);background:var(--panel)}
  .hd b{font-size:14px}
  .ver{font-size:11px;font-weight:600;color:var(--sub);background:var(--chip);border:0;border-radius:99px;padding:1px 8px;margin-left:6px;cursor:pointer;vertical-align:1px}
  .ver:hover{color:var(--ink)}
  .clog{padding:8px 14px;border-bottom:1px solid var(--line);background:var(--panel);font-size:12px}
  .clog div{display:flex;gap:8px;margin:2px 0}
  .clog b{min-width:40px;color:var(--accent);font-variant-numeric:tabular-nums}
  .x{border:0;background:none;color:var(--sub);font-size:18px;cursor:pointer;line-height:1}
  .hd .x{position:absolute;right:8px;top:12px}
  .hd .x.gear{right:25px;top:13px;font-size:16px}
  .hd .x.gear.on{color:var(--accent)}
  .status{padding:6px 14px;font-size:12px;color:var(--sub);border-bottom:1px solid var(--line);font-variant-numeric:tabular-nums}
  .body{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column}
  .col{display:flex;flex-direction:column;gap:10px;padding:12px 14px}
  .stack{display:flex;flex-direction:column;gap:10px}
  .panel.wide .body{flex-direction:row;overflow:hidden}
  .panel.wide .col{overflow:auto;min-height:0}
  .panel.wide #colL{flex:0 0 42%;max-width:440px;border-right:1px solid var(--line)}
  .panel.wide #colR{flex:1;min-width:0}
  .drop.slim{min-height:84px;padding:14px 12px;display:flex;flex-direction:column;gap:2px;align-items:center;justify-content:center;text-align:center}
  .drop.slim strong{font-size:14px}
  .drop.slim .dsub{font-size:11px}
  .drop:hover{border-color:var(--accent)}
  .drop.over{border-style:solid;transform:scale(1.01)}
  .drop .dsub{display:block}
  .refs{background:#fbf6ea;border:1px solid #e3cf9f;border-radius:10px;padding:8px 10px}
  .refhd{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap;font-size:12px;color:#7a5a1a}
  .reflist{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
  .refchip{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #d9bf82;border-radius:99px;padding:3px 4px 3px 10px;font-size:12px;max-width:100%}
  .refchip button{border:0;background:#f1e3bf;border-radius:50%;width:18px;height:18px;line-height:18px;font-size:10px;cursor:pointer;color:#7a5a1a;padding:0}
  .bulk{display:flex;gap:6px;align-items:center;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
  .bulk .bl{font-size:12px;font-weight:700;color:var(--ink)}
  .bulk select{width:auto;flex:1;min-width:140px;max-width:260px;padding:4px 6px;font-size:12px}
  .bulk #bulkMode{flex:0 1 auto;min-width:0}
  .live{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:8px}
  .lvhd{display:flex;justify-content:space-between;align-items:center;gap:8px}
  .lvhd b{font-size:13px}
  .lvst{font-size:11px;border-radius:99px;padding:1px 8px;background:var(--chip);color:var(--sub);white-space:nowrap}
  .lvst.gen{background:var(--drop);color:var(--accent);font-weight:700}
  .lvst.gen::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--accent);margin-right:5px;animation:lvp 1s infinite}
  @keyframes lvp{50%{opacity:.25}}
  .lvempty{font-size:12px;color:var(--sub);text-align:center;padding:16px 0}
  .lvu{align-self:flex-end;max-width:88%;background:var(--chip);border-radius:14px 14px 4px 14px;padding:7px 10px;display:flex;flex-direction:column;gap:5px;align-items:flex-end}
  .lvu .im{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}
  .lvu .im img{width:56px;height:56px;object-fit:cover;border-radius:6px;background:var(--panel)}
  .lvu .tx{font-size:12px;white-space:pre-wrap;word-break:break-word;max-height:90px;overflow:auto}
  .lvu .fl{font-size:11px;color:#8a5a00}
  .lva{display:flex;flex-direction:column;gap:6px}
  .lva .tx{font-size:12px;color:var(--ink);white-space:pre-wrap;word-break:break-word;max-height:110px;overflow:auto}
  .lva .md{display:flex;gap:6px;flex-wrap:wrap}
  .lva .md img,.lva .md canvas{flex:0 1 auto;width:auto;height:auto;max-width:calc(50% - 3px);max-height:200px;object-fit:contain;border-radius:8px;background:var(--chip);border:1px solid var(--line)}
  .lva .md.one img,.lva .md.one canvas{max-width:100%;max-height:230px}
  .lvwho{font-size:10px;font-weight:700;color:var(--sub)}
  .actbar{position:sticky;bottom:10px;z-index:5;display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px 12px;margin-top:6px;background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:0 8px 24px rgba(0,0,0,.14),0 2px 6px rgba(0,0,0,.08);transition:transform .15s,box-shadow .15s}
  .actbar:hover{transform:translateY(-3px);box-shadow:0 14px 32px rgba(0,0,0,.2),0 3px 8px rgba(0,0,0,.1)}
  .actinfo{flex:1 1 180px;min-width:0;font-size:12px;color:var(--sub);line-height:1.5}
  .actinfo b{color:var(--ink)}
  .actinfo .pd{color:#a86a00;font-weight:700}
  .actinfo .ok{color:var(--accent);font-weight:700}
  .actbar .big{width:auto;flex:0 0 auto;min-width:150px;padding:10px 16px}
  .act1{background:var(--panel)}
  .act1.pend{background:#fff4dc;border-color:#e0a63a;color:#8a5a00;font-weight:700}
  .panel.dark .act1.pend{background:#3a2e14;color:#f3c36b}
  .act1:disabled,.act2:disabled{opacity:.55;cursor:default}
  .item.pend{box-shadow:inset 4px 0 0 #e0a63a}
  .pendtag{font-size:10px;font-weight:700;color:#8a5a00;background:#fff4dc;border:1px solid #f0cf8a;border-radius:99px;padding:0 6px;white-space:nowrap}
  .zipck{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:#7a5a1a;background:#fbf6ea;border:1px solid #e3cf9f;border-radius:99px;padding:1px 8px 1px 4px;cursor:pointer;white-space:nowrap}
  .zipck input{margin:0;accent-color:#b08a3e}
  .item.zipon{border-color:#d9bf82;background:#fffaf0}
  .irow{display:flex;gap:6px;align-items:center;margin-top:4px;flex-wrap:wrap}
  .irow .tsel{width:auto;max-width:180px;margin:0;flex:none}
  .irow .meta{margin:0}
  .drops{display:grid;grid-template-columns:3fr 2fr;gap:8px}
  .dropzip{border-color:#e3cf9f;background:#fffaf0}
  .dropzip.over{border-color:#b08a3e;background:#fbf0d6}
  .drop{border:2px dashed var(--line);border-radius:10px;padding:16px 10px;text-align:center;color:var(--sub);cursor:pointer;background:var(--panel)}
  .drop.over{border-color:var(--accent);background:var(--drop);color:var(--ink)}
  .drop strong{display:block;color:var(--ink);font-size:14px}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .card > summary{cursor:pointer;font-size:13px;font-weight:700;color:var(--ink)}
  .lbl{font-size:11px;color:var(--sub);margin:8px 0 3px;display:block}
  .lbl:first-child{margin-top:0}
  .row{display:flex;gap:6px;align-items:center}
  .grow{flex:1;min-width:0}
  input[type=number],input[type=text],select,textarea{width:100%;padding:6px 8px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--ink);font-size:13px}
  textarea{resize:vertical;min-height:52px}
  .chk{display:flex;gap:6px;align-items:center;font-size:12px;margin-top:6px;color:var(--ink)}
  .chk input{margin:0}
  .seg{display:flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
  .seg button{flex:1;border:0;background:var(--bg);color:var(--sub);padding:6px;font-size:12px;cursor:pointer}
  .seg button.on{background:var(--accent);color:var(--accent-ink);font-weight:700}
  .btn{border:1px solid var(--line);background:var(--panel);color:var(--ink);padding:6px 10px;border-radius:6px;font-size:12px;cursor:pointer;white-space:nowrap}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-ink);font-weight:700}
  .btn.danger{color:var(--err)}
  .btn.sm{padding:3px 8px;font-size:11px}
  .big{width:100%;padding:10px;font-size:14px}
  .hint{font-size:11px;color:var(--sub);margin-top:3px}
  .lh{display:flex;justify-content:space-between;align-items:center}
  .lh b{font-size:13px}
  .item{display:grid;grid-template-columns:22px 64px 1fr;gap:8px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
  .num{font-weight:800;color:var(--accent);font-size:16px;text-align:center}
  .thumb{width:64px;height:64px;object-fit:contain;background:var(--chip);border-radius:6px}
  .fn{font-size:11px;color:var(--sub);display:flex;justify-content:space-between;gap:4px;word-break:break-all;margin-bottom:3px}
  .fn button{border:0;background:none;color:var(--sub);cursor:pointer;font-size:11px;padding:0;white-space:nowrap}
  .tsel{margin-top:4px;font-size:11px;padding:3px 6px;color:var(--sub)}
  .meta{display:flex;gap:6px;align-items:center;margin-top:4px;font-size:11px;flex-wrap:wrap}
  .badge{padding:1px 8px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .badge.run{background:var(--drop);color:var(--accent)}
  .badge.done{background:var(--accent);color:var(--accent-ink)}
  .badge.err{border:1px solid var(--err);color:var(--err);background:none}
  .meta a{color:var(--accent)}
  .meta .em{color:var(--err);flex-basis:100%}
  .meta button{border:0;background:none;color:var(--accent);cursor:pointer;font-size:11px;padding:0;text-decoration:underline}
  .empty{color:var(--sub);text-align:center;padding:24px 8px;border:1px dashed var(--line);border-radius:10px;font-size:12px}
  .tplcard{padding:6px 10px}
  .tplhead{border:0;background:none;padding:2px 0;font-size:12px;color:var(--sub);cursor:pointer;font-weight:600}
  .tplhead:hover{color:var(--ink)}
  .btn.xs{padding:0 8px;font-size:13px;line-height:20px;border-radius:5px}
  .tpl{border:1px solid var(--line);border-radius:6px;padding:3px 6px;margin-top:4px;background:var(--bg);display:flex;align-items:center;gap:4px}
  .tpl .nm2{flex:1;min-width:0;font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border:0;background:none;text-align:left;color:var(--ink);cursor:pointer;padding:2px 0}
  .tpl .nm2:hover{color:var(--accent)}
  .tpl.open{border-color:var(--accent);border-bottom-left-radius:0;border-bottom-right-radius:0}
  .tpled{border:1px solid var(--accent);border-top:0;border-radius:0 0 6px 6px;padding:6px 8px;background:var(--panel)}
  .tpled textarea{min-height:70px}
  .tpl .btn{padding:1px 6px;font-size:11px}
  .tpl .btn.on{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
  .tpl .tn{font-weight:700;font-size:12px;display:flex;justify-content:space-between;gap:6px;align-items:center}
  .tpl .tt{font-size:11px;color:var(--sub);white-space:pre-wrap;max-height:48px;overflow:hidden;margin-top:2px}
  .tpl .ta{display:flex;gap:4px;margin-top:4px;flex-wrap:wrap}
  .ft{padding:10px 14px;border-top:1px solid var(--line);background:var(--panel);display:flex;flex-direction:column;gap:6px}
  .hero{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px}
  .hero-top{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--sub);font-variant-numeric:tabular-nums}
  .hero-main{display:flex;gap:12px;align-items:center;margin:12px 0 10px}
  .hero-main img{width:64px;height:64px;object-fit:contain;background:var(--chip);border-radius:8px;flex:none}
  .hero-main img[src=""]{display:none}
  .now{font-size:13px;color:var(--sub)}
  .now b{color:var(--ink);font-size:15px}
  .big-num{font-size:34px;font-weight:800;letter-spacing:.02em;color:var(--accent);font-variant-numeric:tabular-nums;line-height:1.1}
  .big-num small{font-size:12px;font-weight:600;color:var(--sub);margin-left:6px;letter-spacing:0}
  .steps{display:flex;gap:4px;margin-top:2px;flex-wrap:wrap}
  .steps span{font-size:10px;padding:1px 6px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .steps span.on{background:var(--accent);color:var(--accent-ink)}
  .steps span.ok{color:var(--accent)}
  .bar{height:8px;border-radius:99px;background:var(--chip);overflow:hidden;margin-top:6px}
  .bar div{height:100%;background:var(--accent);width:0;transition:width .4s}
  .stats{display:flex;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px;color:var(--sub);flex-wrap:wrap;font-variant-numeric:tabular-nums}
  .stats .e{color:var(--err)}
  .dest{font-size:11px;color:var(--sub);margin-top:8px;word-break:break-all}
  .rl{display:flex;flex-direction:column;gap:4px}
  .ri{display:grid;grid-template-columns:20px 40px 1fr auto;gap:8px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font-size:12px}
  .ri.cur{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .ri img{width:40px;height:40px;object-fit:contain;background:var(--chip);border-radius:4px}
  .ri .n{font-weight:800;color:var(--accent);text-align:center}
  .ri .nm{min-width:0}
  .ri .nm div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ri .nm .p{color:var(--sub);font-size:11px}
  .ri .st{text-align:right;font-size:11px;color:var(--sub);white-space:nowrap;font-variant-numeric:tabular-nums}
  .ri .st a{color:var(--accent);display:block}
  .ri{grid-template-columns:20px 40px 1fr auto auto}
  .gens{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
  .gens img{width:40px;height:40px;object-fit:cover;border-radius:4px;border:2px solid var(--accent);cursor:pointer;background:var(--chip)}
  .gens img:hover{opacity:.8}
  .gens .btn{padding:2px 8px;font-size:11px}
  .meta .gens img{width:34px;height:34px}
  details.log-box summary{cursor:pointer;font-size:12px;color:var(--sub)}
  .log{font-size:11px;color:var(--sub);max-height:100px;overflow:auto;white-space:pre-wrap;font-family:ui-monospace,Menlo,Consolas,monospace}
  `;

  const HTML = `
  <div class="tabs" id="tabs"><button class="tab" id="tab" title="画像一括送信パネルを開く (v__VER__)">📷 一括送信</button><button class="tab dl" id="tabDl" title="開いているチャットの画像を一覧でダウンロード">⬇ 画像DL</button><button class="tab lg" id="tabLog" title="画像を作ったページの一覧">📜 ログ</button><button class="tab st" id="tabSet" title="設定（画像右上のダウンロードの保存先など）">⚙ 設定</button></div>
  <div class="zoom" id="zoom" hidden><img id="zoomImg" alt=""></div>
  <div class="panel light" id="panel" hidden>
    <div class="grip" id="grip" title="ドラッグで幅を変更（ダブルクリックで元の幅）"></div>
    <div class="hd"><div class="hd-l"><b>ChatGPTツール<button class="ver" id="ver" title="押すと更新履歴"></button></b><div class="seg modes" id="modeSeg"><button data-mode="send" class="on">📷 一括送信</button><button data-mode="tpl">📝 テンプレ編集</button><button data-mode="ztpl">📦 zip用テンプレ編集</button><button data-mode="dl">⬇ 画像DL</button><button data-mode="log">📜 ログ</button></div>
      <div class="ivl" id="ivlBox" title="前の生成が終わってから数え始めます"><span>⏱ 送信間隔</span>
        <input type="number" id="ival" min="1" value="1"><select id="iunit"><option value="1">秒ごと</option><option value="60" selected>分ごと</option><option value="3600">時間ごと</option></select>
        <label class="chk" title="1枚目は待たずにすぐ送ります"><input type="checkbox" id="firstNow" checked>1枚目すぐ</label></div></div><button class="x gear" id="setBtn" title="設定（画像右上のダウンロードの保存先など）">⚙</button><button class="x" id="close" title="閉じる">×</button></div>
    <div class="clog" id="clog" hidden></div>
    <div class="status" id="status">待機中</div>
    <div class="destbar" id="destBar"><span class="dl0">送信先</span>
      <div class="seg dseg" id="destSeg">
        <button data-dest="one" class="on">🆕 新規（今回分まとめて）<small>1枚目で新しいチャットを作り、残りも同じチャットへ</small></button>
        <button data-dest="cur">💬 現在選択しているチャット<small id="destCurName">—</small></button>
        <button data-dest="new">🔁 毎回新しいチャット<small>1枚ごとに別のチャットを作る</small></button>
      </div></div>
    <div class="body">
      <div class="col" id="colL" hidden>
        <div id="runL" class="stack" hidden>
          <div class="hero">
            <div class="hero-top"><span class="badge run" id="rvState">実行中</span><span id="rvElapsed">経過 0:00</span></div>
            <div class="hero-main">
              <img id="rvThumb" src="" alt="">
              <div style="min-width:0;flex:1">
                <div class="now" id="rvNow">準備中…</div>
                <div class="big-num" id="rvBig">--:--</div>
                <div class="steps" id="rvSteps"></div>
              </div>
            </div>
            <div class="bar"><div id="rvBar"></div></div>
            <div class="stats"><span id="rvDone">0 / 0 完了</span><span id="rvErr"></span><span id="rvEta"></span></div>
            <div class="dest" id="rvDest"></div>
          </div>
          <div class="live" id="live">
            <div class="lvhd"><b>💬 チャットの最新</b><span class="lvst" id="liveState"></span></div>
            <div id="liveBody"><div class="lvempty">送信が始まると、ここにチャットの最新のやり取りが出ます</div></div>
          </div>
        </div>

      </div>

      <div class="col" id="colR">
        <div id="setupR" class="stack">
          <div class="lh"><b id="count">画像一覧（0枚）</b><button class="btn danger sm" id="clear">全部クリア</button></div>
          <div class="drops">
            <div class="drop" id="drop"><strong>🖼 画像を追加</strong><span class="dsub">ドロップ／クリック（名前順に並びます）</span>
              <input type="file" id="file" accept="image/*" multiple hidden></div>
            <div class="drop dropzip" id="dropZip"><strong>📦 zipを追加</strong><span class="dsub">参考ファイル（✓を付けた画像に一緒に添付）</span>
              <input type="file" id="fileZip" accept=".zip,application/zip,application/x-zip-compressed" multiple hidden></div>
          </div>
          <div class="refs" id="refs" hidden>
            <div class="refhd"><b>📦 参考ファイル（zip）</b><span class="hint" style="margin:0">各画像の「📦 zip添付」に✓を付けたものだけに、一緒に添付して送ります</span></div>
            <div class="reflist" id="refList"></div>
            <div class="row" style="margin-top:6px;flex-wrap:wrap;gap:6px">
              <span class="hint" style="margin:0;white-space:nowrap">zip用テンプレ</span>
              <select id="zipTpl" style="width:auto;flex:1;min-width:140px;max-width:240px;padding:3px 6px;font-size:12px"></select>
              <button class="btn sm" id="zipTplEdit" title="zip用テンプレ編集を開く">📝</button>
              <button class="btn sm" id="zipAllOn" title="全部の画像に✓を付ける">全部に✓</button>
              <button class="btn sm" id="zipAllOff" title="全部の画像の✓を外す">全部外す</button>
            </div>
            <div class="hint" style="margin-top:3px">下の「① 反映」を押すと、✓を付けた画像の指示欄にzip用テンプレの文章が入ります（✓を外して反映すると消えます）。文章は上の「📦 zip用テンプレ編集」で作成・編集できます。</div>
          </div>
          <div class="bulk" id="bulk" hidden>
            <span class="bl">一括でテンプレ</span>
            <select id="bulkTpl"></select>
            <select id="bulkMode" title="テンプレの入れ方"><option value="add">全部の後ろに追加</option><option value="replace">全部置き換え</option><option value="empty">空欄の画像だけ</option></select>
            <button class="btn sm danger" id="bulkClear" title="全部の画像の指示を消す">指示を全消し</button>
            <span class="hint" style="margin:0;flex-basis:100%">選んだら下の「① 反映」で各画像の指示に入ります</span>
          </div>
          <div id="items"></div>
          <div class="actbar" id="actBar">
            <div class="actinfo" id="actInfo"></div>
            <button class="btn big act1" id="reflect" title="テンプレ・zip用テンプレを、各画像の指示欄に入れます">① 反映</button>
            <button class="btn primary big act2" id="start" disabled title="反映した指示で送信を始めます">② 実行（送信開始）</button>
          </div>
        </div>
        <div id="runR" class="stack" hidden>
          <div class="lh"><b>送信の順番</b><button class="btn sm primary" id="dlAll" hidden>生成画像をまとめてDL</button></div>
          <div class="rl" id="rvList"></div>
        </div>
      </div>

      <div class="col" id="tplView" hidden style="flex:1;min-width:0">
        <div class="lh"><b id="tpTitle">指示テンプレ</b>
          <div class="row"><input type="text" id="tpQ" placeholder="名前・文章で絞り込み" style="width:200px">
          <button class="btn sm primary" id="tpNew">＋ 新しいテンプレ</button></div></div>
        <div class="tpbar" id="tpBar">
          <label class="chk" style="margin:0"><input type="checkbox" id="tpAll">全部選ぶ</label>
          <button class="btn sm danger" id="tpDelSel" disabled>選んだものを削除</button>
          <span class="hint" id="tpHint" style="margin:0 0 0 auto">文章は直すと自動で保存されます。削除は「元に戻す」で取り消せます。</span>
        </div>
        <div class="tpundo" id="tpUndo" hidden><span id="tpUndoMsg"></span><button class="btn sm" id="tpUndoBtn">↶ 元に戻す</button></div>
        <div class="tpgrid" id="tpList"></div>
      </div>

      <div class="col" id="setView" hidden style="flex:1;min-width:0">
        <div class="lh"><b>⚙ 設定</b></div>
        <div class="card setcard">
          <b class="sth">🖼 チャットの画像の右上「⬇ ダウンロード」と、画像DLの「⬇ ダウンロード（右上に）」</b>
          <label class="chk"><input type="checkbox" id="qsShow" checked>チャットの生成画像の右上にボタンを表示する</label>
          <span class="lbl">保存する場所</span>
          <div class="qopts" id="qsOpts">
            <label class="qopt" data-v="dl"><input type="radio" name="qs" value="dl"><span><b>⬇ ダウンロード（右上に）</b><small>Chromeのダウンロードに保存（画面右上のダウンロードのアイコンに出ます）</small></span></label>
            <label class="qopt" data-v="desk"><input type="radio" name="qs" value="desk"><span><b>🖥 デスクトップ</b><small id="qsDeskName"></small></span><button type="button" class="btn sm" id="qsDeskPick">選び直す</button></label>
            <label class="qopt" data-v="own"><input type="radio" name="qs" value="own"><span><b>📂 好きなフォルダ</b><small id="qsOwnName"></small></span><button type="button" class="btn sm" id="qsOwnPick">フォルダを選ぶ</button></label>
            <label class="qopt" data-v="save"><input type="radio" name="qs" value="save"><span><b>📁 一番下の「保存先」と同じ</b><small id="qsSaveName"></small></span></label>
          </div>
          <label class="chk"><input type="checkbox" id="qsSub">日時のフォルダ（例：2026-10-21_1737）を作って、その中に保存する</label>
          <div class="hint">ファイル名は保存した日時になります（例：<span id="qsEx"></span>）。設定はすぐに反映されます。</div>
          <div class="qsok" id="qsOk"></div>
        </div>
      </div>

      <div class="col" id="logView" hidden style="flex:1;min-width:0">
        <div class="lh"><b id="histTitle">画像を作ったページ</b>
          <div class="row"><input type="text" id="histQ" placeholder="ページ名で絞り込み" style="width:200px">
          <button class="btn sm danger" id="histClear">履歴を全部消す</button></div></div>
        <div class="hint" style="margin-top:-4px">生成画像があるチャットを開いたときと、一括送信で作ったときに自動で記録します（このPCのChromeに保存）。</div>
        <div id="histList" class="hl"></div>
      </div>

      <div class="col" id="dlView" hidden style="flex:1;min-width:0">
        <div class="lh"><b id="dlTitle">このチャットの画像</b>
          <div class="row"><label class="chk" style="margin:0"><input type="checkbox" id="dlIncUser">添付した画像も表示</label>
          <button class="btn sm" id="dlRefresh">↻ 読み込み直す</button></div></div>
        <div class="dlbar">
          <span class="bl">名前をまとめて付ける</span>
          <input type="text" id="dlBase" placeholder="例：商品A">
          <button class="btn sm" id="dlNumber" title="ベース名_01, _02 … の連番を付ける">連番を付ける</button>

        </div>
        <div class="dlbar">
          <span class="bl">横に並べる数</span>
          <div class="seg colseg" id="dlColSeg"><button data-c="2">×2</button><button data-c="3">×3</button><button data-c="4">×4</button><button data-c="5">×5</button></div>
          <button class="btn sm" id="dlClearSel" title="選んでいる画像のチェックを全部外す">選択クリア</button>
          <span class="hint" style="margin:0 0 0 auto">一度表示された画像は、スクロールで画面から消えても残ります</span>
        </div>
        <div class="dlgrid" id="dlList"></div>
      </div>
    </div>
    <div class="ft" id="ft">
      <button class="seltoggle" id="dlSelToggle" hidden>☑ 全選択</button>
      <div class="savebar">
        <span class="sl">保存先</span>
        <select id="saveDir"></select>
        <button class="btn sm" id="savePick" title="保存するフォルダを選ぶ">📁 フォルダを選ぶ</button>
        <button class="btn sm" id="saveForget" title="このフォルダを一覧から外す" hidden>外す</button>
        <label class="chk" id="autoDlBox" style="margin:0 0 0 auto" title="送信中、生成された画像を保存先へ自動でダウンロードします（保存名：元のファイル名_gen.png）"><input type="checkbox" id="autoDl" checked>生成画像を自動DL</label>
        <label class="chk" style="margin:0" title="保存のたびに「2026-10-19_1224」のような日時の名前のフォルダを作り、その中に保存します"><input type="checkbox" id="timeFolder" checked>日時のフォルダを作って保存</label>
      </div>
      <div class="savepath" id="savePathRow"><span id="savePath"></span><button class="btn sm" id="savePathEdit" hidden>✎ 住所を入力</button></div>
      <form class="savepath" id="savePathEditor" hidden>
        <input type="text" id="savePathInput" placeholder="エクスプローラーの上のアドレス欄をコピーして貼り付け（例：C:&#92;Users&#92;…&#92;Desktop&#92;携帯トイレ&#92;02-生成した画像）">
        <button type="submit" class="btn sm primary" id="savePathOk">保存</button><button type="button" class="btn sm" id="savePathCancel">やめる</button>
      </form>
      <div id="dlFoot" hidden style="display:flex;flex-direction:column;gap:6px">
        <div class="dlsel">
          <span class="cnt" id="dlCount"></span>
          <span class="desk"><span id="deskName">⬇ 右のボタンの保存先：Chromeのダウンロード（右上）</span><button class="btn sm" id="deskPick" title="保存先を変える">⚙ 設定で変更</button></span>
        </div>
        <div class="dlbtns">
          <button class="btn primary big" id="dlSelSave">⬇ 選択した画像を保存先へDL</button>
          <button class="btn big" id="dlSelDesk">⬇ 選択した画像をダウンロード（右上に）</button>
        </div>
      </div>
      <button class="btn danger big" id="stop" hidden>停止</button>
      <button class="btn big" id="back" hidden>設定画面に戻る</button>
    </div>
  </div>`;

  // ---------- ChatGPT本体を右側だけ狭くする ----------
  function applyLayout() {
    const maxW = Math.max(MIN_W, Math.round(window.innerWidth * 0.75));
    const w = Math.min(Math.max(state.width, MIN_W), maxW);
    $('panel').style.width = w + 'px';
    $('panel').classList.toggle('wide', w >= WIDE_AT);
    let st = document.getElementById(PUSH_ID);
    if (!st) { st = document.createElement('style'); st.id = PUSH_ID; (document.head || document.documentElement).appendChild(st); }
    st.textContent = state.open ? `
      html{margin-right:${w}px !important}
      #root > div{width:100% !important;max-width:100% !important}
      header.fixed{right:${w}px !important;width:auto !important;max-width:calc(100vw - ${w}px) !important}` : '';
  }

  function setOpen(o) {
    state.open = o;
    $('panel').hidden = !o; $('tabs').hidden = o;
    applyLayout();
  }

  function initResize() {
    const grip = $('grip');
    let dragging = false;
    grip.addEventListener('pointerdown', e => {
      dragging = true; grip.classList.add('on'); grip.setPointerCapture(e.pointerId);
      document.documentElement.style.userSelect = 'none'; e.preventDefault();
    });
    grip.addEventListener('pointermove', e => {
      if (!dragging) return;
      state.width = Math.round(window.innerWidth - e.clientX);
      applyLayout();
    });
    const end = e => {
      if (!dragging) return;
      dragging = false; grip.classList.remove('on');
      try { grip.releasePointerCapture(e.pointerId); } catch (_) {}
      document.documentElement.style.userSelect = '';
      state.width = parseInt($('panel').style.width, 10) || defW();
      store.set('panelWidth', state.width);
    };
    grip.addEventListener('pointerup', end);
    grip.addEventListener('pointercancel', end);
    grip.addEventListener('dblclick', () => { state.width = defW(); store.set('panelWidth', null); applyLayout(); });
    window.addEventListener('resize', () => { if (!store.get('panelWidth', null)) state.width = defW(); if (state.open) applyLayout(); });
  }

  // ---------- 送信先 ----------
  // 開くたびに上の「新規（今回分まとめて）」から始める
  let destCur = 'one';
  function destMode() { return destCur; }
  // 「現在選択しているチャット」の下に、今開いているチャット名を出す
  function updDestCur() {
    const el = root?.getElementById('destCurName'); if (!el || state.running) return;
    const t = chatIdOf(location.pathname) ? `「${chatTitle()}」` : '（チャットが開かれていません）';
    if (el.textContent !== t) { el.textContent = t; el.title = t; }
  }
  function setDest(m) {
    destCur = ['new', 'cur'].includes(m) ? m : 'one';
    root.querySelectorAll('#destSeg button').forEach(b => b.classList.toggle('on', b.dataset.dest === destCur));
  }
  // ---------- テンプレ ----------
  const tpls = () => store.get('templates', []);
  function saveTpls(list) { store.set('templates', list); renderTpls(); }
  function insertInto(ta, text) {
    ta.value = ta.value.trim() ? ta.value.replace(/\s+$/, '') + '\n' + text : text;
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function tplOptions() {
    return `<option value="">＋ テンプレを入れる…</option>` + tpls().map((t, i) => `<option value="${i}">${esc(t.name)}</option>`).join('');
  }
  function renderTpls() {
    const list = tpls();
    root.querySelectorAll('select.tsel').forEach(s => { s.innerHTML = tplOptions(); });
    renderZipTpl();
    const bs = $('bulkTpl'), keep = bs.value;
    bs.innerHTML = '<option value="">（使わない）</option>' + list.map(t => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('');
    bs.value = list.some(t => t.name === keep) ? keep : '';
    updPend();
  }
  function applyTplToItems(text, mode) {
    if (mode === true) mode = 'empty'; else if (mode === false) mode = 'add';
    let n = 0;
    state.items.forEach(it => {
      if (it.status !== 'wait') return;
      const has = !!it.prompt.trim();
      if (mode === 'empty' && has) return;
      if (mode === 'clear') { it.applied = {}; if (has) { it.prompt = ''; n++; } return; }
      it.prompt = mode === 'replace' || !has ? text : it.prompt.replace(/\s+$/, '') + '\n' + text; n++;
    });
    root.querySelectorAll('.item').forEach(el => {
      const it = state.items.find(x => x.id === +el.dataset.id); if (it) el.querySelector('textarea.pr').value = it.prompt;
    });
    log(mode === 'clear' ? `${n}枚の指示を消しました` : `テンプレを${n}枚に入れました`);
    updPend();
    return n;
  }

  // ---------- 組み立て ----------
  function build() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement('div'); host.id = HOST_ID;
    document.documentElement.appendChild(host);
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>${HTML}`;
    const newTabLink = e => {
      const a = e.composedPath().find(n => n && n.tagName === 'A' && n.target === '_blank');
      if (!a || (e.type === 'auxclick' && e.button !== 1)) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      openBgTab(a.getAttribute('href'));
      const t = a.textContent; a.textContent = '✓ 裏で開きました'; setTimeout(() => { a.textContent = t; }, 1500);
    };
    root.addEventListener('click', newTabLink, true);
    root.addEventListener('auxclick', newTabLink, true);

    const dark = matchMedia('(prefers-color-scheme: dark)').matches || document.documentElement.classList.contains('dark');
    $('panel').classList.replace('light', dark ? 'dark' : 'light');

    $('ver').textContent = 'v' + VERSION;
    $('tab').title = $('tab').title.replace('__VER__', VERSION);
    $('clog').innerHTML = CHANGELOG.map(([v, t]) => `<div><b>v${v}</b><span>${esc(t)}</span></div>`).join('');
    $('ver').onclick = () => { $('clog').hidden = !$('clog').hidden; };
    log('ChatGPT 画像一括送信 v' + VERSION + ' を読み込みました');
    state.width = store.get('panelWidth', null) || defW();
    $('tab').onclick = () => { setOpen(true); setMode('send'); };
    $('tabDl').onclick = () => { setOpen(true); setMode('dl'); };
    $('tabLog').onclick = () => { setOpen(true); setMode('log'); };
    $('tabSet').onclick = () => { setOpen(true); setMode('set'); };
    $('setBtn').onclick = () => setMode(state.mode === 'set' ? 'send' : 'set');
    initQuickSet();
    initHist();
    initTplPage();
    root.querySelectorAll('#modeSeg button').forEach(b => b.onclick = () => setMode(b.dataset.mode));
    initDl();
    initSaveBar();
    $('close').onclick = () => setOpen(false);
    initResize();
    initImgButtons();
    setOpen(false); // 最初はボタンだけ

    [['ival', 'value'], ['iunit', 'value'], ['firstNow', 'checked'], ['autoDl', 'checked']].forEach(([id, prop]) => {
      const v = store.get(id, null); if (v !== null) $(id)[prop] = v;
      $(id).addEventListener('change', () => store.set(id, $(id)[prop]));
    });

    // 送信先
    root.querySelectorAll('#destSeg button').forEach(b => b.onclick = () => { if (!state.running) setDest(b.dataset.dest); });
    setDest('one');
    updDestCur(); setInterval(() => { if (state.open) updDestCur(); }, 1500);

    const flash = (id, msg) => { const b = $(id), t = b.textContent; b.textContent = msg; setTimeout(() => b.textContent = t, 1200); };
    $('bulkTpl').onchange = updPend; $('bulkMode').onchange = updPend;
    $('reflect').onclick = () => { const n = reflectAll(); if (!n) return; $('reflect').textContent = `✓ ${n}枚に反映しました`; setTimeout(updPend, 1400); };
    let clearArmed = 0;
    $('bulkClear').onclick = () => {
      if (Date.now() - clearArmed > 3000) { clearArmed = Date.now(); $('bulkClear').textContent = 'もう一度押すと消去'; setTimeout(() => $('bulkClear').textContent = '指示を全消し', 3000); return; }
      clearArmed = 0; $('bulkClear').textContent = '指示を全消し'; applyTplToItems('', 'clear');
    };

    // ドロップ
    $('drop').onclick = () => $('file').click();
    $('dropZip').onclick = () => $('fileZip').click();
    // テンプレを変えたら、✓の付いた画像の指示も入れ替える
    $('zipTpl').onchange = e => { useZipTpl(e.target.value); };
    const zipAll = on => { state.items.filter(it => it.status === 'wait').forEach(it => { it.useZip = on; }); render(); };
    $('zipAllOn').onclick = () => zipAll(true);
    $('zipAllOff').onclick = () => zipAll(false);
    $('fileZip').onchange = e => { addFiles(e.target.files, 'zip'); e.target.value = ''; };
    $('file').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
    panelApi = {
      onDragOver(e) { const z = e.composedPath().some(n => n && n.id === 'dropZip'); $('dropZip').classList.toggle('over', z); $('drop').classList.toggle('over', !z); },
      onDragLeave(e) { if (!e.relatedTarget || !inPanel({ composedPath: () => [e.relatedTarget, ...ancestors(e.relatedTarget)] })) { $('drop').classList.remove('over'); $('dropZip').classList.remove('over'); } },
      onDrop(e) {
        const z = e.composedPath().some(n => n && n.id === 'dropZip');
        $('drop').classList.remove('over'); $('dropZip').classList.remove('over');
        if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files, z ? 'zip' : null);
      },
    };

    let armed = 0;
    $('clear').onclick = () => {
      if (state.running) return log('停止してからクリアしてください');
      if (Date.now() - armed > 3000) { armed = Date.now(); $('clear').textContent = 'もう一度押すとクリア'; setTimeout(() => $('clear').textContent = '全部クリア', 3000); return; }
      state.items.forEach(it => URL.revokeObjectURL(it.url));
      state.items = []; state.refs = []; renderRefs(); render(); $('clear').textContent = '全部クリア';
    };

    $('start').onclick = start;
    $('stop').onclick = () => stop('停止しました');
    $('back').onclick = () => { showView(false); render(); };
    $('dlAll').onclick = async () => { const n = await downloadAll(state.runItems); log(`まとめて${n}枚ダウンロード`); };
    window.addEventListener('beforeunload', e => { if (state.running) { e.preventDefault(); e.returnValue = ''; } });

    renderTpls();
    render();
  }

  function ancestors(n) { const a = []; while (n) { n = n.parentNode || n.host; if (n) a.push(n); } return a; }

  const isZip = f => /\.zip$/i.test(f.name) || /zip/i.test(f.type);
  // zipは中身を表示できないので、「ZIP」のアイコンを見本として使う
  const ZIP_ICON = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" rx="10" fill="#f3efe4"/><path d="M28 14h28l14 14v54a4 4 0 0 1-4 4H28a4 4 0 0 1-4-4V18a4 4 0 0 1 4-4z" fill="#fff" stroke="#b08a3e" stroke-width="3"/><path d="M56 14v14h14" fill="none" stroke="#b08a3e" stroke-width="3"/><g fill="#b08a3e"><rect x="40" y="18" width="6" height="5"/><rect x="46" y="24" width="6" height="5"/><rect x="40" y="30" width="6" height="5"/><rect x="46" y="36" width="6" height="5"/></g><rect x="22" y="54" width="52" height="20" rx="4" fill="#b08a3e"/><text x="48" y="69" font-family="Arial,sans-serif" font-size="14" font-weight="700" fill="#fff" text-anchor="middle">ZIP</text></svg>');
  const previewUrl = f => isZip(f) ? ZIP_ICON : URL.createObjectURL(f);
  function addFiles(list, only) {
    const all = [...list];
    const zips = all.filter(isZip);
    if (only === 'zip' && !zips.length) return log('zipファイルが見つかりませんでした');
    zips.forEach(f => { state.refs = state.refs.filter(r => r.name !== f.name); state.refs.push(f); });
    if (zips.length) { renderRefs(); log(`参考ファイルに追加：${zips.map(f => f.name).join('、')}`); }
    const files = only === 'zip' ? [] : all.filter(f => f.type.startsWith('image/'));
    if (!files.length) { if (!zips.length) log('画像またはzipのファイルが見つかりませんでした'); return; }
    for (const f of files) {
      const ex = state.items.find(it => it.file.name === f.name);
      if (ex) { URL.revokeObjectURL(ex.url); ex.file = f; ex.url = previewUrl(f); continue; }
      state.items.push({ id: ++uid, file: f, url: previewUrl(f), prompt: '', status: 'wait' });
    }
    state.items.sort((a, b) => collator.compare(a.file.name, b.file.name));
    render();
    log(`${files.length}枚追加（合計${state.items.length}枚）`);
  }

  // zip用テンプレ（「📦 zip用テンプレ編集」で管理。使うものは名前で覚える）
  const ztpls = () => store.get('zipTemplates', []);
  function saveZtpls(list) { store.set('zipTemplates', list); renderZipTpl(); updPend(); }
  const zipTplText = () => { const n = store.get('zipTpl', ''); const t = ztpls().find(x => x.name === n); return t ? t.text.trim() : ''; };
  // ---------- ① 反映：テンプレ・zip用テンプレを各画像の指示に入れる（② 実行の前に） ----------
  // it.applied … 前回の反映で入れた文章。反映し直すときは、それを取り除いてから今の設定で入れ直す
  const cutPiece = (p, piece) => piece && p.includes(piece) ? p.replace(piece, '').replace(/\n{3,}/g, '\n\n').trim() : p;
  function ownText(it) { const a = it.applied || {}; return cutPiece(cutPiece(it.prompt, a.zip), a.bulk).trim(); }
  function bulkSetting() {
    const n = root?.getElementById('bulkTpl')?.value || ''; const t = n && tpls().find(x => x.name === n);
    return t && t.text.trim() ? { text: t.text.trim(), mode: $('bulkMode').value } : null;
  }
  function desired(it) {
    const bs = bulkSetting(), a = it.applied || {}; let bulk = '', mode = '', src = '';
    if (bs) {
      mode = bs.mode; src = bs.text;
      if (bs.mode !== 'empty') bulk = bs.text;
      // 「空欄の画像だけ」は反映したときの判断を保つ（反映後に手で書き足しても入れ直さない）
      else if (a.mode === 'empty' && a.src === bs.text) bulk = a.bulk || '';
      else bulk = ownText(it) ? '' : bs.text;
    }
    return { bulk, mode, src, zip: it.useZip ? zipTplText() : '' };
  }
  function isPending(it) {
    if (it.status !== 'wait') return false;
    const a = it.applied || {}, d = desired(it);
    return (a.bulk || '') !== d.bulk || (a.mode || '') !== d.mode || (a.zip || '') !== d.zip;
  }
  function reflectItem(it) {
    const d = desired(it);
    const own = d.mode === 'replace' ? '' : ownText(it);
    it.prompt = [own, d.bulk, d.zip].filter(Boolean).join('\n');
    it.applied = d;
  }
  function reflectAll() {
    if (state.running) return 0;
    const list = state.items.filter(isPending);
    list.forEach(reflectItem);
    if (list.length) { syncPrompts(); log(`${list.length}枚の指示に反映しました`); }
    updPend();
    return list.length;
  }
  // 反映待ちの数を数えて、下の「① 反映」「② 実行」と各画像の印を切り替える
  function updPend() {
    if (!root || !root.getElementById('reflect')) return 0;
    const wait = state.items.filter(it => it.status === 'wait');
    const pend = wait.filter(isPending);
    root.querySelectorAll('.item').forEach(el => {
      const it = state.items.find(x => x.id === +el.dataset.id); const on = !!it && pend.includes(it);
      el.classList.toggle('pend', on); const tg = el.querySelector('.pendtag'); if (tg) tg.hidden = !on;
    });
    const r = $('reflect'), st = $('start');
    r.disabled = state.running || !pend.length; r.classList.toggle('pend', !!pend.length);
    r.textContent = pend.length ? `① 反映（${pend.length}枚）` : '① 反映';
    st.disabled = state.running || !wait.length || !!pend.length;
    const zn = wait.filter(it => it.useZip).length;
    $('actInfo').innerHTML = !wait.length ? '画像を追加して指示を書いてください'
      : pend.length ? `<span class="pd">反映待ち ${pend.length}枚</span>：「① 反映」で指示を作ってから「② 実行」できます`
      : `<span class="ok">✓ 反映済み</span>　送信する画像 <b>${wait.length}枚</b>${zn && state.refs.length ? `（zip添付 ${zn}枚）` : ''}・内容を確認して「② 実行」`;
    return pend.length;
  }
  function useZipTpl(name) {
    store.set('zipTpl', name); renderZipTpl(); updPend();
    log(name ? `zip用テンプレを「${name}」にしました` : 'zip用テンプレを使わない設定にしました');
  }
  function renderZipTpl() {
    const sel = root?.getElementById('zipTpl'); if (!sel) return;
    const cur = store.get('zipTpl', ''), l = ztpls();
    sel.innerHTML = `<option value="">${l.length ? '（使わない）' : '（まだありません → 📝で作成）'}</option>` + l.map(t => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('');
    sel.value = l.some(t => t.name === cur) ? cur : '';
  }
  // 参考ファイル（zip）：✓を付けた画像に、毎回一緒に添付する
  function renderRefs() {
    const box = $('refs'); if (!box) return;
    box.hidden = !state.refs.length;
    $('refList').innerHTML = state.refs.map((f, i) => `<span class="refchip" title="${esc(f.name)}（${Math.max(1, Math.round(f.size / 1024))}KB）">📦 ${esc(f.name)}<button data-i="${i}" title="外す">✕</button></span>`).join('');
    $('refList').querySelectorAll('button').forEach(b => b.onclick = () => { if (state.running) return; state.refs.splice(+b.dataset.i, 1); renderRefs(); });
    renderZipTpl();
  }
  function syncPrompts() { root.querySelectorAll('.item').forEach(el => { const it = state.items.find(x => x.id === +el.dataset.id); if (it) el.querySelector('textarea.pr').value = it.prompt; }); }
  function render() {
    const box = $('items');
    $('count').textContent = `画像一覧（${state.items.length}枚）`;
    $('drop').classList.toggle('slim', state.items.length > 0);
    $('dropZip').classList.toggle('slim', state.items.length > 0);
    $('bulk').hidden = !state.items.length;

    if (!state.items.length) { box.className = ''; box.innerHTML = '<div class="empty">画像をドロップすると、ここに 1番・2番・3番… と並びます。<br>それぞれに指示を書いて「OK」を押してください。</div>'; return; }
    box.querySelectorAll('.empty').forEach(e => e.remove());
    box.className = 'igrid';
    const existing = new Map([...box.querySelectorAll('.item')].map(el => [+el.dataset.id, el]));
    state.items.forEach((it, i) => {
      const el = existing.get(it.id) || buildRow(it);
      existing.delete(it.id);
      el.querySelector('.num').textContent = i + 1;
      el.querySelector('.thumb').src = it.url;
      el.querySelector('.fn span').textContent = it.file.name;
      const locked = state.running && it.status !== 'wait';
      el.querySelector('textarea.pr').disabled = locked;
      el.querySelector('select.tsel').disabled = locked;
      el.querySelector('.zk').checked = !!it.useZip; el.querySelector('.zk').disabled = locked;
      el.classList.toggle('zipon', !!it.useZip);
      el.querySelector('.fn button').style.visibility = state.running ? 'hidden' : '';
      renderMeta(el, it);
      box.appendChild(el);
    });
    existing.forEach(el => el.remove());
    updPend();
  }

  function buildRow(it) {
    const el = document.createElement('div');
    el.className = 'item'; el.dataset.id = it.id;
    el.innerHTML = `<div class="num"></div><img class="thumb" alt="">
      <div><div class="fn"><span></span><button>✕ 外す</button></div>
      <textarea class="pr" rows="2" placeholder="この画像への指示（例：背景を夕焼けの海辺に変えて）"></textarea>
      <div class="irow"><select class="tsel">${tplOptions()}</select><label class="zipck" title="✓を付けると、この画像を送るときに参考ファイル（zip）も一緒に添付します（「① 反映」でzip用テンプレの文章が指示に入ります）"><input type="checkbox" class="zk">📦 zip添付</label><span class="pendtag" hidden>未反映</span><div class="meta"></div></div></div>`;
    const ta = el.querySelector('textarea.pr');
    ta.value = it.prompt;
    el.querySelector('.zk').onchange = e => { it.useZip = e.target.checked; el.classList.toggle('zipon', it.useZip); updPend(); };
    ta.addEventListener('input', () => { it.prompt = ta.value; updPend(); });
    el.querySelector('select.tsel').onchange = e => {
      const t = tpls()[+e.target.value]; if (t) insertInto(ta, t.text); e.target.value = '';
    };
    el.querySelector('.fn button').onclick = () => { URL.revokeObjectURL(it.url); state.items = state.items.filter(x => x !== it); render(); };
    return el;
  }

  function renderMeta(el, it) {
    const m = el.querySelector('.meta');
    const label = { wait: '未送信', run: '送信・生成中…', done: '完了', err: 'エラー' }[it.status];
    m.innerHTML = `<span class="badge ${it.status}">${label}</span>`;
    if (it.results?.length) { const g = document.createElement('span'); g.innerHTML = gensHtml(it); m.appendChild(g.firstChild); bindGens(m, it); }
    if (it.chatUrl) { const a = document.createElement('a'); a.href = it.chatUrl; a.textContent = 'チャットを開く'; a.target = '_blank'; m.appendChild(a); }
    if ((it.status === 'done' || it.status === 'err') && !state.running) {
      const b = document.createElement('button'); b.textContent = 'もう一度送る';
      b.onclick = () => { setResults(it, []); Object.assign(it, { status: 'wait', error: null, chatUrl: null }); render(); };
      m.appendChild(b);
    }
    if (it.status === 'err') { const d = document.createElement('div'); d.className = 'em'; d.textContent = it.error; m.appendChild(d); }
  }

  // ---------- 保存先フォルダ ----------
  // 選んだフォルダはこのブラウザ内（IndexedDB）に覚えておき、次回からプルダウンで切り替えられる
  const idb = {
    open() {
      return new Promise((ok, ng) => {
        const r = indexedDB.open('cgb-save', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('kv');
        r.onsuccess = () => ok(r.result); r.onerror = () => ng(r.error);
      });
    },
    async get(k) { const db = await this.open(); return new Promise(ok => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => ok(q.result); q.onerror = () => ok(undefined); }); },
    async set(k, v) { const db = await this.open(); return new Promise(ok => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = () => ok(); t.onerror = () => ok(); }); },
  };
  const save = { dirs: [], idx: -1 };
  const canPickDir = typeof window.showDirectoryPicker === 'function';
  const curDir = () => save.idx >= 0 ? save.dirs[save.idx] : null;

  async function loadSaveDirs() {
    try { save.dirs = (await idb.get('dirs')) || []; } catch (e) { save.dirs = []; }
    save.idx = Math.min(store.get('saveIdx', -1), save.dirs.length - 1);
    renderSaveBar();
    computeAllRel();
  }
  async function persistDirs() { try { await idb.set('dirs', save.dirs); } catch (e) {} store.set('saveIdx', save.idx); }

  // フォルダの住所：Chromeはフォルダの場所（C:\…）を教えてくれないため、
  // ①自分で貼り付けた住所 ②デスクトップや他の登録フォルダからたどれる場合はその道筋 ③フォルダ名だけ、の順で表示
  const dirLabel = d => d ? (d.label || (d.rel ? d.rel.join(' › ') : null)) : null;
  async function computeRel(d) {
    if (!d || d.label) return;
    const roots = [];
    if (desk.handle) roots.push({ h: desk.handle, name: /desktop|デスクトップ/i.test(desk.handle.name) ? 'デスクトップ' : desk.handle.name });
    save.dirs.forEach(o => { if (o !== d && o.handle) roots.push({ h: o.handle, name: o.label || o.name }); });
    let best = null;
    for (const r of roots) {
      try {
        const p = await r.h.resolve(d.handle);
        if (p && p.length) { const cand = [r.name, ...p]; if (!best || cand.join('').length > best.join('').length) best = cand; }
      } catch (e) {}
    }
    d.rel = best;
  }
  async function computeAllRel() {
    for (const d of save.dirs) await computeRel(d);
    renderSaveBar();
  }

  function renderSaveBar() {
    const sel = $('saveDir'); if (!sel) return;
    sel.innerHTML = `<option value="-1">📥 ダウンロードフォルダ（いつもの場所）</option>` +
      save.dirs.map((d, i) => `<option value="${i}">📁 ${esc(dirLabel(d) || d.name)}</option>`).join('') +
      (canPickDir ? `<option value="pick">＋ 別のフォルダを選ぶ…</option>` : '');
    sel.value = String(save.idx);
    $('savePick').hidden = !canPickDir;
    $('saveForget').hidden = save.idx < 0;
    const d = curDir(), lab = dirLabel(d);
    if (root.getElementById('autoDlWhere')) $('autoDlWhere').textContent = d ? `保存先：📁 ${lab || d.name}` : '保存先：ダウンロードフォルダ';
    // 住所の行
    $('savePath').innerHTML = !d ? '📥 Chromeの設定で決めているダウンロード先に保存します'
      : lab ? `📁 <b>${esc(lab)}</b>`
      : `📁 … › <b>${esc(d.name)}</b><span class="ph">（上の階層はChromeの仕様で取れません。「住所を入力」で表示できます）</span>`;
    $('savePathEdit').hidden = !d;
    $('savePathEdit').textContent = d && d.label ? '✎ 住所を直す' : '✎ 住所を入力';
  }

  async function pickDir() {
    try {
      const h = await window.showDirectoryPicker({ id: 'cgb-save', mode: 'readwrite', startIn: curDir()?.handle || 'downloads' });
      let i = -1;
      for (let k = 0; k < save.dirs.length; k++) { try { if (await save.dirs[k].handle.isSameEntry(h)) { i = k; break; } } catch (e) {} }
      const entry = i >= 0 ? save.dirs.splice(i, 1)[0] : { name: h.name, handle: h };
      save.dirs.unshift(entry); save.dirs = save.dirs.slice(0, 8); save.idx = 0;
      await computeRel(entry);
      await persistDirs(); log(`保存先を「${dirLabel(entry) || h.name}」にしました`);
    } catch (e) { if (e.name !== 'AbortError') log('フォルダを選べませんでした：' + e.message); }
    renderSaveBar();
  }

  // ---------- デスクトップ ----------
  // ブラウザからは決まった場所へ直接書けないため、最初の1回だけデスクトップを選んでもらい、その場所を覚えておく
  const desk = { handle: null };
  async function loadDesktop() { try { desk.handle = (await idb.get('desktop')) || null; } catch (e) { desk.handle = null; } renderDeskName(); computeAllRel(); }
  function renderDeskName() {
    const el = root?.getElementById('deskName'); if (!el) return;
    el.textContent = `⬇ 右のボタンの保存先：${quickWhere()}`;
    $('deskPick').hidden = false;
  }
  async function pickDesktop() {
    try {
      const h = await window.showDirectoryPicker({ id: 'cgb-desktop', mode: 'readwrite', startIn: 'desktop' });
      desk.handle = h; await idb.set('desktop', h); computeAllRel();
      log(`デスクトップの保存場所を「${h.name}」にしました`);
    } catch (e) { if (e.name !== 'AbortError') log('デスクトップを選べませんでした：' + e.message); }
    renderDeskName();
    return desk.handle;
  }
  // ユーザー操作の直後に呼ぶ：未設定なら選択画面、設定済みなら書き込み許可を確認
  async function ensureDesktop() {
    if (!canPickDir) return false;
    if (!desk.handle) return !!(await pickDesktop());
    return ensureHandlePermission(desk.handle, true);
  }
  async function ensureHandlePermission(handle, interactive) {
    try {
      if (await handle.queryPermission({ mode: 'readwrite' }) === 'granted') return true;
      if (!interactive) return false;
      return (await handle.requestPermission({ mode: 'readwrite' })) === 'granted';
    } catch (e) { return false; }
  }

  // ユーザー操作の直後に呼ぶと、必要ならフォルダへの書き込み許可を確認する
  async function ensureDirPermission(interactive) {
    const d = curDir(); if (!d) return true;
    try {
      if (await d.handle.queryPermission({ mode: 'readwrite' }) === 'granted') return true;
      if (!interactive) return false;
      return (await d.handle.requestPermission({ mode: 'readwrite' })) === 'granted';
    } catch (e) { return false; }
  }

  async function uniqueName(dir, name) {
    const dot = name.lastIndexOf('.'), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : '';
    for (let n = 1; n < 1000; n++) {
      const cand = n === 1 ? name : `${base} (${n})${ext}`;
      try { await dir.getFileHandle(cand); } catch (e) { return cand; } // 存在しなければ使う
    }
    return `${base}_${Date.now()}${ext}`;
  }

  // 日時フォルダ：まとめて保存したものは同じフォルダに入る
  const pad2 = n => String(n).padStart(2, '0');
  const stampName = t => { const d = new Date(t); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}_${pad2(d.getHours())}${pad2(d.getMinutes())}`; };
  const useTimeFolder = () => !!(root && $('timeFolder') ? $('timeFolder').checked : store.get('timeFolder', true));
  // 1枚ずつ保存するときは、10分以内なら同じ日時フォルダにまとめる
  const single = { t: 0 };
  function singleStamp() { const now = Date.now(); if (now - single.t > 10 * 60000) single.t0 = now; single.t = now; return single.t0; }
  function blobToDataURL(blob) { return new Promise((ok, ng) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => ng(r.error); r.readAsDataURL(blob); }); }

  // 保存先フォルダがあればそこへ、なければ通常のダウンロード
  // target: 'save'＝一番下の保存先 ／ 'desk'＝デスクトップ
  // stamp：日時フォルダの時刻（同じ時刻を渡したものは同じフォルダに入る）
  async function saveBlob(blob, filename, interactive = false, target = 'save', stamp = null) {
    // stamp=false：日時フォルダを作らない ／ {force:時刻}：設定に関係なく日時フォルダを作る
    const sub = stamp === false ? '' : stamp && stamp.force ? stampName(stamp.force) : useTimeFolder() ? stampName(stamp || Date.now()) : '';
    const d = target === 'desk' ? (desk.handle ? { name: desk.handle.name, handle: desk.handle } : null)
      : target === 'own' ? (quick.handle ? { name: quick.handle.name, handle: quick.handle } : null)
      : target === 'dl' ? null : curDir();
    if (target === 'desk' && !d) log('デスクトップが未設定のため、ダウンロードフォルダに保存しました');
    if (d) {
      try {
        if (await ensureHandlePermission(d.handle, interactive)) {
          const dir = sub ? await d.handle.getDirectoryHandle(sub, { create: true }) : d.handle;
          const name = await uniqueName(dir, filename);
          const fh = await dir.getFileHandle(name, { create: true });
          const w = await fh.createWritable(); await w.write(blob); await w.close();
          return `${target === 'desk' ? '🖥' : '📁'} ${d.name}/${sub ? sub + '/' : ''}${name}`;
        }
        log(`「${d.name}」への書き込み許可がないため、ダウンロードフォルダに保存しました（保存先の「許可」を押すと次から直接保存されます）`);
      } catch (e) { log(`「${d.name}」に保存できなかったため、ダウンロードフォルダに保存しました：${e.message}`); }
    }
    // ダウンロードフォルダ：日時フォルダを作るとき・「ダウンロード（右上に）」は、拡張の裏側の処理（Chromeのダウンロード）に頼む
    if (sub || target === 'dl') {
      try {
        const dataUrl = await blobToDataURL(blob);
        const r = await new Promise(ok => { try { chrome.runtime.sendMessage({ type: 'cgb-download', url: dataUrl, filename: `${sub ? sub + '/' : ''}${filename}` }, res => ok(chrome.runtime.lastError ? null : res)); } catch (e) { ok(null); } });
        if (r && r.ok) return `📥 ${sub ? sub + '/' : ''}${filename}`;
        if (sub) log('日時フォルダを作れなかったため、ダウンロードフォルダに直接保存しました' + (r && r.error ? `：${r.error}` : ''));
      } catch (e) {}
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return `📥 ${filename}`;
  }

  // ---------- チャットの生成画像の右上に「⬇ DL」ボタン：押すとデスクトップに日時の名前で保存 ----------
  const ov = { root: null, wrap: null, map: new Map(), raf: 0 };
  const fileStamp = () => { const d = new Date(); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}_${pad2(d.getHours())}-${pad2(d.getMinutes())}-${pad2(d.getSeconds())}`; };
  function ovTargets() {
    const main = chatMain(); if (!main) return [];
    const thumbs = new Set(cg.thumbImgs(main));
    const out = [];
    const cands = new Set(main.querySelectorAll('[data-testid="generated-image-gallery"] img, [data-testid="generated-image-preview"] img, img[alt^="生成画像"], img[alt^="Generated image"], [data-message-author-role="assistant"] img'));
    // 予備：ChatGPTの返事の欄（見出し「ChatGPT の発言」）にある大きな画像
    main.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(h => { if (LBL_A.test(h.textContent.trim())) h.parentElement.querySelectorAll('img').forEach(i => cands.add(i)); });
    cands.forEach(i => {
      if (/添付|Uploaded|avatar|アイコン|icon/i.test(i.alt || '')) return;
      if (thumbs.has(i) || i.closest('form') || !(i.currentSrc || i.src)) return;
      const r = i.getBoundingClientRect(); if (r.width < 140 || r.height < 140) return;
      const cs = getComputedStyle(i); if (cs.opacity === '0' || cs.visibility === 'hidden') return;
      // 同じ場所に重なった画像（ぼかした背景など）は1つにまとめる
      const dup = out.find(o => Math.abs(o.r.left - r.left) < 8 && Math.abs(o.r.top - r.top) < 8 && Math.abs(o.r.width - r.width) < 16);
      if (dup) { if (/^(生成画像|Generated image)/i.test(i.alt || '') && !/^(生成画像|Generated image)/i.test(dup.img.alt || '')) { dup.img = i; dup.r = r; } return; }
      out.push({ img: i, r });
    });
    return out;
  }
  function ovScan() {
    if (!ov.wrap) return;
    if (!store.get('quickShow', true)) { ov.map.forEach(b => b.remove()); ov.map.clear(); return; }
    const ts = ovTargets(), keep = new Set(ts.map(t => t.img));
    ov.map.forEach((b, img) => { if (!keep.has(img)) { if (!b.dataset.busy) { b.remove(); ov.map.delete(img); } } });
    ts.forEach(({ img }) => {
      if (ov.map.has(img)) return;
      const b = document.createElement('button'); b.className = 'b'; b.textContent = '⬇ ダウンロード';
      b.addEventListener('mouseenter', () => { if (!b.dataset.busy) b.title = `${quickWhere()}に保存（ファイル名は保存した日時）。保存先は「⚙ 設定」で変えられます`; });
      ['pointerdown', 'mousedown', 'mouseup'].forEach(t => b.addEventListener(t, e => e.stopPropagation()));
      b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); imgQuickSave(img, b); });
      ov.wrap.appendChild(b); ov.map.set(img, b);
    });
    ovPlace();
  }
  function ovPlace() {
    ov.raf = 0;
    const main = chatMain(); const mr = main ? main.getBoundingClientRect() : { top: 0, bottom: innerHeight, left: 0, right: innerWidth };
    const dlg = [...document.querySelectorAll('[role="dialog"]')].find(d => { const r = d.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !d.closest('#' + HOST_ID); });
    ov.map.forEach((b, img) => {
      const r = img.getBoundingClientRect();
      const top = Math.max(r.top, mr.top) + 8; // 縦長の画像は、スクロールしても右上に付いてくる
      const show = img.isConnected && r.width > 0 && top < Math.min(r.bottom, mr.bottom) - 40 && r.right > mr.left && r.left < mr.right && !(dlg && !dlg.contains(img));
      b.style.display = show ? '' : 'none';
      if (show) { b.style.top = top + 'px'; b.style.right = (document.documentElement.clientWidth - Math.min(r.right, mr.right) + 8) + 'px'; }
    });
  }
  const ovSchedule = () => { if (!ov.raf) ov.raf = requestAnimationFrame(ovPlace); };
  async function imgQuickSave(img, b) {
    if (b.dataset.busy) return;
    b.dataset.busy = '1'; b.className = 'b busy'; b.textContent = '保存中…';
    const done = (ok, msg) => { b.className = 'b ' + (ok ? 'fin' : 'ng'); b.textContent = msg; setTimeout(() => { delete b.dataset.busy; b.className = 'b'; b.textContent = '⬇ ダウンロード'; }, ok ? 2200 : 3500); };
    try {
      // クリック直後に：初回は場所を選ぶ画面、その後は書き込み許可の確認
      const tgt = quickTarget();
      if (!(await ensureQuick())) return done(false, 'キャンセルしました');
      const src = img.currentSrc || img.src;
      const blob = await (await fetch(src)).blob();
      const name = `${fileStamp()}.${extOf(blob.type)}`;
      const where = await saveBlob(blob, name, true, tgt, quickStamp());
      log(`保存しました：${where}`);
      done(true, '✓ 保存しました'); b.title = where;
    } catch (e) { log('保存できませんでした：' + e.message); done(false, '✕ 失敗'); }
  }
  // ---------- ⚙ 設定：画像右上「⬇ ダウンロード」の保存先 ----------
  const quick = { handle: null };
  const quickTarget = () => { const t = store.get('quickTarget', 'dl'); return ['desk', 'own', 'save', 'dl'].includes(t) ? t : 'dl'; };
  // ボタンに出す短い名前
  function quickLabel() {
    const t = quickTarget();
    return t === 'dl' ? 'ダウンロード（右上に）' : t === 'desk' ? 'デスクトップにDL' : t === 'own' ? (quick.handle ? `「${quick.handle.name}」にDL` : '選んだフォルダにDL') : '保存先へDL';
  }
  const quickStamp = t => store.get('quickSub', false) ? { force: t || Date.now() } : false;
  // クリック直後に呼ぶ：初回は場所を選ぶ画面、その後は書き込み許可の確認。やめたらfalse
  async function ensureQuick() {
    const tgt = quickTarget();
    if (tgt === 'desk' && !(await ensureDesktop()) && canPickDir && !desk.handle) return false;
    if (tgt === 'own') { if (!quick.handle) { if (canPickDir && !(await pickQuickDir())) return false; } else await ensureHandlePermission(quick.handle, true); }
    if (tgt === 'save') await ensureDirPermission(true);
    return true;
  }
  function quickWhere() {
    const t = quickTarget();
    if (t === 'desk') return desk.handle ? `デスクトップ（${desk.handle.name}）` : 'デスクトップ';
    if (t === 'own') return quick.handle ? `「${quick.handle.name}」` : '選んだフォルダ';
    if (t === 'save') return curDir() ? `「${curDir().name}」` : 'ダウンロードフォルダ';
    return 'Chromeのダウンロード（右上）';
  }
  async function pickQuickDir() {
    try {
      const h = await window.showDirectoryPicker({ id: 'cgb-quick', mode: 'readwrite', startIn: quick.handle || 'pictures' });
      quick.handle = h; await idb.set('quickDir', h);
      log(`画像右上のダウンロードの保存先を「${h.name}」にしました`);
      return h;
    } catch (e) { if (e.name !== 'AbortError') log('フォルダを選べませんでした：' + e.message); return null; }
  }
  function renderQuickSet() {
    if (!root || !root.getElementById('qsOpts')) return;
    const t = quickTarget();
    root.querySelectorAll('#qsOpts .qopt').forEach(l => { const on = l.dataset.v === t; l.classList.toggle('on', on); l.querySelector('input').checked = on; });
    $('qsShow').checked = store.get('quickShow', true);
    $('qsSub').checked = store.get('quickSub', false);
    $('qsDeskName').textContent = !canPickDir ? 'このブラウザでは直接保存できないため、ダウンロードフォルダに保存します' : desk.handle ? `「${desk.handle.name}」に保存` : '未設定（初めて押したときに場所を選びます）';
    $('qsDeskPick').hidden = !canPickDir;
    $('qsOwnName').textContent = quick.handle ? `「${quick.handle.name}」に保存` : 'まだ選んでいません（右のボタンで選びます）';
    $('qsOwnPick').hidden = !canPickDir; $('qsOwnPick').textContent = quick.handle ? '選び直す' : 'フォルダを選ぶ';
    $('qsSaveName').textContent = curDir() ? `今は「${curDir().name}」` : '今は「ダウンロードフォルダ」';
    $('qsEx').textContent = `${fileStamp()}.png`;
    renderDeskName();
  }
  function initQuickSet() {
    idb.get('quickDir').then(h => { quick.handle = h || null; renderQuickSet(); }).catch(() => {});
    const ok = msg => { $('qsOk').textContent = '✓ ' + msg; clearTimeout(ok.t); ok.t = setTimeout(() => { $('qsOk').textContent = ''; }, 2500); };
    root.querySelectorAll('#qsOpts input[name=qs]').forEach(r => r.onchange = async () => {
      if (r.value === 'own' && !quick.handle) { if (!(await pickQuickDir())) { renderQuickSet(); return; } }
      if (r.value === 'desk' && !desk.handle && canPickDir) await pickDesktop();
      store.set('quickTarget', r.value); renderQuickSet(); ok(`保存する場所を${quickWhere()}にしました`);
    });
    $('qsDeskPick').onclick = async e => { e.preventDefault(); if (await pickDesktop()) { store.set('quickTarget', 'desk'); renderQuickSet(); ok(`保存する場所を${quickWhere()}にしました`); } };
    $('qsOwnPick').onclick = async e => { e.preventDefault(); if (await pickQuickDir()) { store.set('quickTarget', 'own'); renderQuickSet(); ok(`保存する場所を${quickWhere()}にしました`); } };
    $('qsShow').onchange = e => { store.set('quickShow', e.target.checked); ovScan(); ok(e.target.checked ? '画像の右上にボタンを表示します' : '画像の右上のボタンを隠しました'); };
    $('qsSub').onchange = e => { store.set('quickSub', e.target.checked); ok(e.target.checked ? '日時のフォルダを作って保存します' : '日時のフォルダは作らずに保存します'); };
  }

  function initImgButtons() {
    if (document.getElementById('cgb-ov')) return;
    const h = document.createElement('div'); h.id = 'cgb-ov';
    document.documentElement.appendChild(h);
    ov.root = h.attachShadow({ mode: 'open' });
    ov.root.innerHTML = `<style>
      :host{all:initial}
      .b{position:fixed;z-index:2147483600;top:-100px;right:-200px;border:2px solid #fff;border-radius:99px;padding:7px 14px;font:700 13px/1.2 "Hiragino Sans","Noto Sans JP","Yu Gothic UI",Meiryo,sans-serif;
        background:rgba(31,111,92,.92);color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.3);white-space:nowrap;transition:transform .12s,background .12s}
      .b:hover{background:#1f6f5c;transform:translateY(-1px) scale(1.04)}
      .b.busy{background:#b4541a;cursor:progress}
      .b.fin{background:#15803d}
      .b.ng{background:#c0392b}
    </style><div id="w"></div>`;
    ov.wrap = ov.root.getElementById('w');
    setInterval(ovScan, 700);
    window.addEventListener('scroll', ovSchedule, { capture: true, passive: true });
    window.addEventListener('resize', ovSchedule, { passive: true });
    ovScan();
  }

  function initSaveBar() {
    $('saveDir').onchange = async e => {
      if (e.target.value === 'pick') { e.target.value = String(save.idx); await pickDir(); return; }
      save.idx = +e.target.value; await persistDirs(); renderSaveBar();
      if (curDir()) await ensureDirPermission(true);
      log(curDir() ? `保存先を「${curDir().name}」に切り替え` : '保存先をダウンロードフォルダに切り替え');
    };
    $('savePick').onclick = pickDir;
    $('timeFolder').checked = store.get('timeFolder', true);
    $('timeFolder').onchange = () => { store.set('timeFolder', $('timeFolder').checked); log($('timeFolder').checked ? '日時のフォルダを作って保存します' : '日時のフォルダは作らずに保存します'); };
    const openEditor = o => { $('savePathRow').hidden = o; $('savePathEditor').hidden = !o; if (o) { $('savePathInput').value = curDir()?.label || ''; $('savePathInput').focus(); } };
    $('savePathEdit').onclick = () => openEditor(true);
    $('savePathCancel').onclick = () => openEditor(false);
    const savePathLabel = async () => {
      const d = curDir(); if (!d) return openEditor(false);
      const v = $('savePathInput').value.trim().replace(/^"+|"+$/g, '');
      d.label = v || null;
      if (v && !v.replace(/[\\/]+$/, '').endsWith(d.name)) log(`入力した住所の最後が「${d.name}」ではありません。違うフォルダの住所になっていないか確認してください`);
      if (!v) await computeRel(d);
      await persistDirs(); openEditor(false); renderSaveBar(); computeAllRel();
      log(v ? `保存先の住所を「${v}」にしました` : '保存先の住所を消しました');
    };
    $('savePathEditor').onsubmit = e => { e.preventDefault(); savePathLabel(); };
    $('saveForget').onclick = async () => {
      const d = curDir(); if (!d) return;
      save.dirs.splice(save.idx, 1); save.idx = -1; await persistDirs(); renderSaveBar();
      log(`「${d.name}」を保存先の一覧から外しました`);
    };
    loadSaveDirs();
  }

  // ---------- 生成画像のダウンロード ----------
  function setResults(it, blobs) {
    (it.results || []).forEach(r => URL.revokeObjectURL(r.url));
    it.results = (blobs || []).map(b => ({ blob: b, url: URL.createObjectURL(b) }));
  }
  function dlName(it, k) {
    const base = it.file.name.replace(/\.[^.]+$/, '');
    const r = it.results[k];
    const ext = (r.blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '');
    return `${base}_gen${it.results.length > 1 ? k + 1 : ''}.${ext}`;
  }
  async function downloadOne(it, k, interactive = false, stamp = null) {
    const where = await saveBlob(it.results[k].blob, dlName(it, k), interactive, 'save', stamp || state.startedAt || null);
    log('保存：' + where);
  }
  async function downloadItem(it, interactive = false, stamp = null) {
    if (interactive) await ensureDirPermission(true);
    for (let k = 0; k < (it.results || []).length; k++) { await downloadOne(it, k, false, stamp); await sleep(300); }
    if (it.results?.length) log(`${it.file.name} の生成画像を${it.results.length}枚ダウンロード`);
  }
  async function downloadAll(list) {
    await ensureDirPermission(true);
    const targets = list.filter(it => it.results?.length);
    const stamp = Date.now();
    for (const it of targets) await downloadItem(it, false, stamp);
    return targets.reduce((n, it) => n + it.results.length, 0);
  }
  function gensHtml(it) {
    if (!it.results?.length) return '';
    return `<span class="gens">${it.results.map((r, k) => `<img src="${r.url}" data-k="${k}" title="クリックでダウンロード：${esc(dlName(it, k))}">`).join('')}<button class="btn" data-dl="1">DL</button></span>`;
  }
  function bindGens(scope, it) {
    scope.querySelectorAll('.gens img').forEach(img => img.onclick = () => downloadOne(it, +img.dataset.k, true));
    const b = scope.querySelector('.gens [data-dl]'); if (b) b.onclick = () => downloadItem(it, true);
  }

  // ---------- 画像DL（開いているチャットの画像一覧） ----------
  const dl = { list: [], names: new Map(), done: new Map(), sel: new Set(), path: '', timer: null };
  const safeName = s => String(s).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120);
  // チャット名：サイドバーで今のURLを指している項目を優先（ページ名は切り替えが遅れることがある）
  const chatTitle = () => {
    const path = location.pathname;
    const a = [...document.querySelectorAll('nav a[href], aside a[href]')].find(x => x.getAttribute('href') === path && !x.closest('#' + HOST_ID));
    const t = (a?.innerText || '').trim().split('\n')[0] || (document.title || '').replace(/\s*[-|]\s*ChatGPT\s*$/i, '');
    return safeName(t) || 'ChatGPT';
  };
  const extOf = type => ((type || '').split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '') || 'png';

  // 名前が空のときの見本・保存名：x-01, x-02 …
  const defaultDlName = i => `x-${String(Math.max(0, i) + 1).padStart(2, '0')}`;

  function setMode(m) {
    state.mode = m;
    root.querySelectorAll('#modeSeg button').forEach(b => b.classList.toggle('on', b.dataset.mode === m));
    $('setBtn').classList.toggle('on', m === 'set');
    const isDl = m === 'dl', isLog = m === 'log', isTpl = m === 'tpl' || m === 'ztpl', isSet = m === 'set';
    if (isTpl) tpSwitchKind(m);
    $('colL').hidden = isDl || isLog || isTpl || isSet || !state.runView; $('colR').hidden = isDl || isLog || isTpl || isSet;
    $('setView').hidden = !isSet;
    $('destBar').hidden = m !== 'send' || !!state.runView;
    $('autoDlBox').hidden = m !== 'send';
    $('dlView').hidden = !isDl; $('logView').hidden = !isLog; $('tplView').hidden = !isTpl;
    $('ft').hidden = isLog || isTpl || isSet;
    $('dlFoot').hidden = !isDl; $('dlSelToggle').hidden = !isDl;
    clearInterval(dl.timer); dl.timer = null;
    if (isDl) {
      $('start').hidden = true; $('stop').hidden = true; $('back').hidden = true;
      refreshDl();
      dl.timer = setInterval(dlWatch, 700);
    } else if (isLog) {
      renderHist();
    } else if (isTpl) {
      renderTplPage();
    } else if (isSet) {
      renderQuickSet();
    } else {
      showView(!!state.runView);
    }
  }

  // 画面に今ある画像を、上から順に集める（生成画像も添付画像も。表示するかどうかは後で決める）
  function scanChatImages() {
    const main = chatMain();
    const genList = cg.generatedImgs();
    const gens = new Set(genList);
    const thumbSrc = new Set(cg.thumbImgs(main).map(i => i.currentSrc || i.src));
    const seen = new Set(), out = [];
    const ordered = [...new Set([...main.querySelectorAll('img'), ...genList])]
      .sort((a, b) => a === b ? 0 : (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    ordered.forEach(i => {
      if (!gens.has(i) && thumbSrc.has(i.currentSrc || i.src)) return; // 大きい表示はサムネイル側で数える
      if (i.closest('#' + HOST_ID) || i.closest('form')) return;
      const src = i.currentSrc || i.src;
      if (!src || seen.has(src) || /^data:|^about:/.test(src)) return;
      const isGen = gens.has(i);
      const isUser = !isGen && (/添付|Uploaded/i.test(i.alt || '') || (i.naturalWidth >= 200 && i.naturalHeight >= 200));
      if (!isGen && !isUser) return;
      if (dl.prevSrcs && dl.prevSrcs.has(src)) return;
      seen.add(src);
      out.push({ src, kind: isGen ? 'gen' : 'user', w: i.naturalWidth, h: i.naturalHeight, el: i });
    });
    return out;
  }

  // ---- 一度見つけた画像は一覧に残す ----
  // ChatGPTはスクロールで画面外の画像を消したり、同じ画像を別のURLで出し直したりするため、
  // 見つけた時点で画像の中身を取っておき、中身（ハッシュ）で同じ画像かどうかを判断する
  Object.assign(dl, { acc: [], byKey: new Map(), srcMap: new Map(), ingesting: false, again: false });
  function scrollerOf(el) {
    let p = el && el.parentElement;
    while (p && p !== document.body) {
      const oy = getComputedStyle(p).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight) return p;
      p = p.parentElement;
    }
    return document.scrollingElement;
  }
  const absY = el => { try { const sc = scrollerOf(el); return el.getBoundingClientRect().top + (sc ? sc.scrollTop : 0); } catch (e) { return null; } };
  async function hashBlob(blob) {
    try {
      const buf = await crypto.subtle.digest('SHA-1', await blob.arrayBuffer());
      return [...new Uint8Array(buf)].slice(0, 12).map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (e) { return 'sz' + blob.size + '-' + blob.type; }
  }
  function resetAcc() {
    dl.acc.forEach(e => URL.revokeObjectURL(e.src));
    dl.acc = []; dl.byKey = new Map(); dl.srcMap = new Map();
  }
  function rebuildList() { dl.list = dl.acc.filter(e => e.kind === 'gen' || $('dlIncUser').checked); }

  // 新しく見つけた画像を、画面上の前後関係を手がかりに正しい位置へ差し込む
  function insertEntry(entry, scan, idx) {
    for (let j = idx - 1; j >= 0; j--) {
      const k = dl.srcMap.get(scan[j].src), p = k ? dl.acc.findIndex(x => x.key === k) : -1;
      if (p >= 0) { dl.acc.splice(p + 1, 0, entry); return; }
    }
    for (let j = idx + 1; j < scan.length; j++) {
      const k = dl.srcMap.get(scan[j].src), p = k ? dl.acc.findIndex(x => x.key === k) : -1;
      if (p >= 0) { dl.acc.splice(p, 0, entry); return; }
    }
    // 前後に手がかりがないとき（大きくスクロールしたとき）は、縦の位置で並べる
    if (entry.y != null) {
      const p = dl.acc.findIndex(x => x.y != null && x.y > entry.y);
      if (p >= 0) { dl.acc.splice(p, 0, entry); return; }
    }
    dl.acc.push(entry);
  }

  async function ingest() {
    if (dl.ingesting) { dl.again = true; return; }
    dl.ingesting = true;
    let changed = false;
    try {
      do {
        dl.again = false;
        const path = location.pathname;
        const scan = scanChatImages();
        for (let idx = 0; idx < scan.length; idx++) {
          const it = scan[idx];
          if (location.pathname !== path) break;
          const y = absY(it.el);
          let key = dl.srcMap.get(it.src);
          if (key) { const e = dl.byKey.get(key); if (e) { if (y != null) e.y = y; if (!e.w && it.w) { e.w = it.w; e.h = it.h; changed = true; } } continue; }
          let blob;
          try { blob = await (await fetch(it.src)).blob(); } catch (err) { continue; }
          if (!blob || blob.size < 2048 || !/^image\//.test(blob.type || 'image/')) continue;
          key = await hashBlob(blob);
          if (location.pathname !== path) break;
          dl.srcMap.set(it.src, key);
          if (dl.byKey.has(key)) { const e = dl.byKey.get(key); if (it.kind === 'gen' && e.kind !== 'gen') { e.kind = 'gen'; changed = true; } continue; }
          let w = it.w, h = it.h;
          if (!w) { try { const bm = await createImageBitmap(blob); w = bm.width; h = bm.height; bm.close(); } catch (e) {} }
          const entry = { key, src: URL.createObjectURL(blob), blob, kind: it.kind, w, h, y };
          dl.byKey.set(key, entry);
          insertEntry(entry, scan, idx);
          changed = true;
        }
      } while (dl.again);
    } finally {
      dl.ingesting = false;
    }
    if (changed) { rebuildList(); renderDl(); }
    renderDlTitle();
  }

  // 画面の監視：チャットを移ったら一覧を切り替え、同じチャットでは新しく出てきた画像を足していく
  function dlSig() { return location.pathname + '|' + scanChatImages().map(e => e.src).join('|'); }
  function dlWatch() {
    if (!state.open || state.mode !== 'dl') return;
    try {
      if (location.pathname !== dl.path) {
        dl.prevSrcs = new Set(dl.srcMap.keys()); // 移動直後に残っている前のチャットの画像は出さない
        dl.settleUntil = Date.now() + 8000; dl.loading = true; refreshDl(); return;
      }
      const sig = dlSig();
      if (sig !== dl.sig) { dl.sig = sig; refreshDl(); if (dl.loading) dl.settleUntil = Math.max(dl.settleUntil, Date.now() + 4000); }
      else if (dl.loading && Date.now() > dl.settleUntil) { dl.loading = false; dl.prevSrcs = null; refreshDl(); }
    } catch (e) { log('画像一覧の更新でエラー：' + e.message); }
  }
  function renderDlTitle() {
    $('dlTitle').textContent = `「${chatTitle()}」の画像（${dl.list.length}枚）${dl.loading || dl.ingesting ? ' 読み込み中…' : ''}`;
  }
  function refreshDl(manual) {
    if (manual) { dl.loading = true; dl.settleUntil = Date.now() + 6000; }
    if (location.pathname !== dl.path) { resetAcc(); rebuildList(); renderDl(); }
    dl.path = location.pathname;
    dl.sig = dlSig();
    $('dlBase').placeholder = '例：商品A（空のまま押すと x-01, x-02…）';
    renderDlTitle();
    ingest();
  }

  // 横に並べる数
  function applyCols() {
    const n = Math.min(5, Math.max(2, +store.get('dlCols', 2) || 2));
    const g = $('dlList');
    g.style.gridTemplateColumns = `repeat(${n}, minmax(0, 1fr))`;
    g.classList.toggle('compact', n >= 3);
    root.querySelectorAll('#dlColSeg button').forEach(b => b.classList.toggle('on', +b.dataset.c === n));
  }

  function renderDl() {
    const box = $('dlList');
    if (!dl.list.length) {
      box.innerHTML = dl.loading || dl.ingesting
        ? '<div class="empty" style="grid-column:1/-1">画像を探しています…</div>'
        : '<div class="empty" style="grid-column:1/-1">このチャットに生成画像が見つかりません。<br>自分が添付した画像は「添付した画像も表示」にチェックすると出ます。</div>';
      updateDlBtn(); return;
    }
    box.innerHTML = dl.list.map((e, i) => `
      <div class="dli${dl.sel.has(e.key) ? ' on' : ''}${dl.done.has(e.key) ? ' saved' : ''}" data-i="${i}">
        <input type="checkbox" class="ck" ${dl.sel.has(e.key) ? 'checked' : ''}>
        <div class="pic" title="クリックで選択／解除"><img src="${esc(e.src)}" alt=""><div class="savedmark"><div class="ck2">✓</div><div class="tx">保存済み</div></div><button class="zbtn" title="拡大して見る">🔍</button></div>
        <div style="min-width:0">
          <div class="nmrow"><input type="text" class="nm" value="${esc(dl.names.get(e.key) || '')}" placeholder="${esc(defaultDlName(i))}"><span class="ext">.${esc(extOf(e.blob.type))}</span></div>
          <div class="sz"><span class="kind">${e.kind === 'gen' ? '生成' : '添付'}</span> ${e.w && e.h ? `${e.w}×${e.h}` : ''}</div>
          <div class="acts"><button class="btn sm primary dlb" data-t="save" title="一番下の「保存先」に保存">⬇ 保存先へDL</button><button class="btn sm dlb" data-t="quick" title="${esc(quickWhere())}に保存（⚙ 設定で変更できます）">⬇ ${esc(quickLabel())}</button></div>
          <span class="ok">${esc(dl.done.get(e.key) || '')}</span>
        </div>
      </div>`).join('');
    box.querySelectorAll('.dli').forEach(row => {
      const e = dl.list[+row.dataset.i];
      row.querySelector('.nm').addEventListener('input', ev => dl.names.set(e.key, ev.target.value));
      const ck = row.querySelector('.ck');
      const setSel = on => { on ? dl.sel.add(e.key) : dl.sel.delete(e.key); ck.checked = on; row.classList.toggle('on', on); updateDlBtn(); };
      ck.onchange = () => setSel(ck.checked);
      row.querySelector('.pic').onclick = () => setSel(!dl.sel.has(e.key)); // 画像クリックで選択を切り替え
      row.querySelector('.zbtn').onclick = ev => { ev.stopPropagation(); $('zoomImg').src = e.src; $('zoom').hidden = false; };
      row.querySelectorAll('.dlb').forEach(b => b.onclick = async () => {
        const t = b.dataset.t, orig = b.textContent;
        b.classList.add('busy'); b.textContent = '⏳ 保存中…'; b.disabled = true;
        let ok = false;
        if (t === 'quick') { if (await ensureQuick()) ok = await dlOne(e, row, quickTarget(), quickStamp()); }
        else { await ensureDirPermission(true); ok = await dlOne(e, row, t); }
        b.classList.remove('busy'); b.disabled = false;
        if (ok) { b.classList.add('fin'); b.textContent = '✓ 保存しました'; }
        else b.textContent = '✕ 失敗';
        setTimeout(() => { b.classList.remove('fin'); b.textContent = orig; }, 2200);
      });
    });
    updateDlBtn();
  }

  function updateDlBtn() {
    const n = dl.list.filter(e => dl.sel.has(e.key)).length;
    if (dl.busy) { $('dlCount').textContent = `${n} / ${dl.list.length}枚 選択中`; return; }
    const all = dl.list.length > 0 && n === dl.list.length;
    const tg = $('dlSelToggle');
    tg.textContent = all ? `☐ 全選択解除（${n}枚を解除）` : `☑ 全選択（${dl.list.length}枚）`;
    tg.classList.toggle('all', !all); tg.disabled = !dl.list.length;
    $('dlCount').textContent = `${n} / ${dl.list.length}枚 選択中`;
    $('dlSelSave').textContent = `⬇ 選択した画像を保存先へDL（${n}枚）`;
    $('dlSelDesk').textContent = `⬇ 選択した${n}枚を${quickLabel()}`;
    $('dlSelSave').disabled = $('dlSelDesk').disabled = !n;
    $('dlClearSel').disabled = !n;
  }

  async function dlOne(e, row, target = 'save', stamp = null) {
    const ok = row?.querySelector('.ok');
    try {
      if (ok) ok.textContent = '保存中…';
      const blob = e.blob;
      const ext = extOf(blob.type);
      const name = safeName(dl.names.get(e.key) || '') || defaultDlName(dl.list.indexOf(e));
      const where = await saveBlob(blob, `${name}.${ext}`, false, target, stamp == null ? singleStamp() : stamp);
      const label = (where.startsWith('🖥') ? '✓ デスクトップに保存' : where.startsWith('📁') ? '✓ 保存先に保存' : '✓ ダウンロードに保存');
      dl.done.set(e.key, label);
      if (ok) { ok.textContent = label; ok.title = where; }
      if (row) { row.classList.remove('saved'); void row.offsetWidth; row.classList.add('saved'); } // 画像に大きい✓
      log('保存：' + where);
      return true;
    } catch (err) {
      if (ok) ok.textContent = '失敗しました';
      log('画像のダウンロードに失敗：' + err.message);
      return false;
    }
  }

  function initDl() {
    $('dlRefresh').onclick = () => refreshDl(true);
    $('dlIncUser').onchange = () => { store.set('dlIncUser', $('dlIncUser').checked); rebuildList(); renderDl(); renderDlTitle(); };
    $('dlIncUser').checked = !!store.get('dlIncUser', false);
    $('dlNumber').onclick = () => {
      const base = safeName($('dlBase').value) || 'x';
      dl.list.forEach((e, i) => dl.names.set(e.key, `${base}-${String(i + 1).padStart(2, '0')}`));
      renderDl();
    };
    root.querySelectorAll('#dlColSeg button').forEach(b => b.onclick = () => { store.set('dlCols', +b.dataset.c); applyCols(); });
    applyCols();
    $('dlClearSel').onclick = () => { dl.list.forEach(e => dl.sel.delete(e.key)); renderDl(); };
    $('dlSelToggle').onclick = () => {
      const all = dl.list.length > 0 && dl.list.every(e => dl.sel.has(e.key));
      dl.list.forEach(e => all ? dl.sel.delete(e.key) : dl.sel.add(e.key));
      renderDl();
    };
    const dlSelected = async target => {
      if (dl.busy) return;
      const btn = $(target === 'quick' ? 'dlSelDesk' : 'dlSelSave'), other = $(target === 'quick' ? 'dlSelSave' : 'dlSelDesk');
      const rows = [...$('dlList').querySelectorAll('.dli')].filter(r => dl.sel.has(dl.list[+r.dataset.i].key));
      if (!rows.length) return;
      dl.busy = true;
      btn.classList.add('busy'); btn.disabled = true; other.disabled = true;
      const show = k => { btn.style.setProperty('--p', `${Math.round(k / rows.length * 100)}%`); btn.textContent = `⏳ 保存中… ${k} / ${rows.length}枚`; };
      show(0);
      let ok = 0;
      try {
        const stamp = Date.now(); // このボタン1回分は同じ日時フォルダに入れる
        let tgt = target, st = stamp;
        if (target === 'quick') { if (!(await ensureQuick())) return; tgt = quickTarget(); st = quickStamp(stamp); } else await ensureDirPermission(true);
        for (let k = 0; k < rows.length; k++) {
          const row = rows[k];
          row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          if (await dlOne(dl.list[+row.dataset.i], row, tgt, st)) ok++;
          show(k + 1); await sleep(300);
        }
      } finally {
        btn.classList.remove('busy'); btn.style.removeProperty('--p');
        btn.classList.add('fin'); btn.textContent = ok === rows.length ? `✓ ${ok}枚 保存しました` : `✓ ${ok}枚 保存（${rows.length - ok}枚 失敗）`;
        setTimeout(() => { btn.classList.remove('fin'); dl.busy = false; updateDlBtn(); }, 2500);
      }
    };
    $('dlSelSave').onclick = () => dlSelected('save');
    $('dlSelDesk').onclick = () => dlSelected('quick');
    $('deskPick').onclick = () => setMode('set');
    loadDesktop();
    $('zoom').onclick = () => { $('zoom').hidden = true; };
  }


  // ---------- テンプレ編集ページ（指示テンプレ／zip用テンプレ 共通） ----------
  const tp = { sel: new Set(), undo: null, undoTimer: null, kind: 'tpl' };
  const isZ = () => tp.kind === 'ztpl';
  const tpGet = () => isZ() ? ztpls() : tpls();
  const tpSave = l => isZ() ? saveZtpls(l) : saveTpls(l);
  function tplPageNotify() { if ((state.mode === 'tpl' || state.mode === 'ztpl') && state.open) renderTplPage(); }
  function tpSwitchKind(k) {
    if (tp.kind === k) return;
    tp.kind = k; tp.sel.clear(); tp.undo = null; clearTimeout(tp.undoTimer);
    $('tpUndo').hidden = true; $('tpQ').value = '';
  }
  function renderTplPage(focusIdx) {
    const z = isZ(), list = tpGet(), using = store.get('zipTpl', '');
    $('tplView').classList.toggle('zmode', z);
    $('tpNew').textContent = z ? '＋ 新しいzip用テンプレ' : '＋ 新しいテンプレ';
    $('tpHint').textContent = z
      ? '「使用中」のテンプレの文章が、一括送信で「📦 zip添付」に✓を付けた画像の指示に「① 反映」で入ります。直すと自動で保存されます。'
      : '文章は直すと自動で保存されます。削除は「元に戻す」で取り消せます。';
    const q = $('tpQ').value.trim().toLowerCase();
    const shown = list.map((t, i) => ({ t, i })).filter(({ t }) => !q || t.name.toLowerCase().includes(q) || t.text.toLowerCase().includes(q));
    $('tpTitle').textContent = `${z ? '📦 zip用テンプレ' : '指示テンプレ'}（${q ? `${shown.length} / ` : ''}${list.length}件）`;
    [...tp.sel].forEach(i => { if (i >= list.length) tp.sel.delete(i); });
    const box = $('tpList');
    if (!list.length) { box.innerHTML = `<div class="empty" style="grid-column:1/-1">まだ${z ? 'zip用テンプレ' : 'テンプレ'}がありません。右上の「${z ? '＋ 新しいzip用テンプレ' : '＋ 新しいテンプレ'}」から作れます。${z ? '<br>作ったテンプレの文章が、zip添付に✓を付けた画像の指示に入ります。' : ''}</div>`; updTpBar(); return; }
    if (!shown.length) { box.innerHTML = '<div class="empty" style="grid-column:1/-1">見つかりません</div>'; updTpBar(); return; }
    box.innerHTML = shown.map(({ t, i }) => {
      const inUse = z && t.name === using;
      return `
      <div class="tpc${tp.sel.has(i) ? ' sel' : ''}${inUse ? ' using' : ''}" data-i="${i}">
        <div class="top"><input type="checkbox" class="ck" ${tp.sel.has(i) ? 'checked' : ''} title="選ぶ"><span class="no">${i + 1}</span>
          <input type="text" class="en" value="${esc(t.name)}" placeholder="名前">${inUse ? '<span class="usebadge">✓ 使用中</span>' : ''}</div>
        <textarea class="et" placeholder="${z ? 'zipを添付するときに入れる文章（例：添付のzipの中の画像を参考にしてください）' : '指示の文章'}">${esc(t.text)}</textarea>
        <div class="bt">
          <button class="btn sm" data-a="up" title="上へ" ${i === 0 ? 'disabled' : ''}>↑</button>
          <button class="btn sm" data-a="down" title="下へ" ${i === list.length - 1 ? 'disabled' : ''}>↓</button>
          <button class="btn sm" data-a="dup" title="同じ内容でもう1つ作る">複製</button>
          ${z
            ? `<button class="btn sm${inUse ? '' : ' primary'}" data-a="use" title="zip添付に✓を付けた画像に、このテンプレを使う" ${inUse ? 'disabled' : ''}>${inUse ? '✓ 使用中' : 'これを使う'}</button>`
            : `<button class="btn sm" data-a="all" title="一括送信の画像すべての指示欄に入れる">全画像に入れる</button>`}
          <button class="btn sm danger" data-a="del" title="削除" style="margin-left:auto">🗑 削除</button>
          <span class="st" style="margin-left:6px">${t.text.length}文字</span>
        </div>
      </div>`; }).join('');
    box.querySelectorAll('.tpc').forEach(card => {
      const i = +card.dataset.i, en = card.querySelector('.en'), et = card.querySelector('.et'), st = card.querySelector('.st');
      const fit = () => { et.style.height = 'auto'; et.style.height = Math.min(Math.max(et.scrollHeight + 2, 90), 420) + 'px'; };
      fit();
      let timer = null;
      const autosave = () => {
        fit(); st.textContent = '保存中…'; st.classList.remove('ok');
        clearTimeout(timer);
        timer = setTimeout(() => {
          const l = tpGet(); if (!l[i]) return;
          const name = en.value.trim() || '（名前なし）';
          if (z && l[i].name === store.get('zipTpl', '') && name !== l[i].name) store.set('zipTpl', name);
          l[i] = { name, text: et.value };
          tpSave(l);
          const n = z && name === store.get('zipTpl', '') ? state.items.filter(isPending).length : 0;
          st.textContent = `✓ 保存しました（${et.value.length}文字）${n ? `・一括送信で「① 反映」を押すと${n}枚の指示に入ります` : ''}`; st.classList.add('ok');
        }, 500);
      };
      en.addEventListener('input', autosave); et.addEventListener('input', autosave);
      card.querySelector('.ck').onchange = e => { e.target.checked ? tp.sel.add(i) : tp.sel.delete(i); card.classList.toggle('sel', e.target.checked); updTpBar(); };
      const move = d => { const l = tpGet(), j = i + d; if (j < 0 || j >= l.length) return; [l[i], l[j]] = [l[j], l[i]]; tp.sel.clear(); tpSave(l); renderTplPage(); };
      card.querySelector('[data-a=up]').onclick = () => move(-1);
      card.querySelector('[data-a=down]').onclick = () => move(1);
      card.querySelector('[data-a=dup]').onclick = () => { const l = tpGet(); l.splice(i + 1, 0, { name: l[i].name + '（コピー）', text: l[i].text }); tp.sel.clear(); tpSave(l); renderTplPage(i + 1); };
      if (z) {
        card.querySelector('[data-a=use]').onclick = () => { useZipTpl(tpGet()[i]?.name || ''); renderTplPage(); };
      } else {
        card.querySelector('[data-a=all]').onclick = e => { const n = applyTplToItems(et.value.trim(), 'add'); flashEl(e.target, `✓ ${n}枚に入れました`); };
      }
      card.querySelector('[data-a=del]').onclick = () => tpDelete([i]);
    });
    if (focusIdx != null) { const c = box.querySelector(`.tpc[data-i="${focusIdx}"]`); if (c) { c.scrollIntoView({ block: 'nearest' }); c.querySelector('.en').focus(); c.querySelector('.en').select(); } }
    updTpBar();
  }
  function flashEl(b, msg) { const t = b.textContent; b.textContent = msg; setTimeout(() => b.textContent = t, 1400); }
  function updTpBar() {
    const n = tp.sel.size, total = tpGet().length;
    $('tpDelSel').disabled = !n; $('tpDelSel').textContent = n ? `選んだ ${n}件を削除` : '選んだものを削除';
    $('tpAll').checked = total > 0 && n === total;
    $('tpBar').hidden = !total;
  }
  // 削除は即実行。8秒間は「元に戻す」で取り消せる
  function tpDelete(idxs) {
    const l = tpGet(); const set = new Set(idxs);
    const removed = l.map((t, i) => ({ t, i })).filter(x => set.has(x.i));
    if (!removed.length) return;
    tp.undo = l.slice();
    tpSave(l.filter((_, i) => !set.has(i)));
    tp.sel.clear();
    $('tpUndoMsg').textContent = removed.length === 1 ? `「${removed[0].t.name}」を削除しました` : `${removed.length}件の${isZ() ? 'zip用テンプレ' : 'テンプレ'}を削除しました`;
    $('tpUndo').hidden = false;
    clearTimeout(tp.undoTimer); tp.undoTimer = setTimeout(() => { $('tpUndo').hidden = true; tp.undo = null; }, 8000);
    log($('tpUndoMsg').textContent);
    renderTplPage();
  }
  function initTplPage() {
    $('tpQ').addEventListener('input', () => renderTplPage());
    $('tpNew').onclick = () => {
      const l = tpGet(), z = isZ();
      l.unshift({ name: z ? '新しいzip用テンプレ' : '新しいテンプレ', text: '' });
      tp.sel.clear(); tpSave(l);
      if (z && !ztpls().some(t => t.name === store.get('zipTpl', ''))) useZipTpl(l[0].name);
      $('tpQ').value = ''; renderTplPage(0);
    };
    $('tpAll').onchange = e => { tp.sel = new Set(e.target.checked ? tpGet().map((_, i) => i) : []); renderTplPage(); };
    $('tpDelSel').onclick = () => tpDelete([...tp.sel]);
    $('tpUndoBtn').onclick = () => { if (!tp.undo) return; tpSave(tp.undo); tp.undo = null; $('tpUndo').hidden = true; log('削除を元に戻しました'); renderTplPage(); };
    $('zipTplEdit').onclick = () => setMode('ztpl');
  }

  // ---------- ログ：画像を作ったページの履歴 ----------
  const HIST_MAX = 300;
  const chatIdOf = path => (String(path).match(/\/c\/([0-9a-z-]{8,})/i) || [])[1] || null;
  async function histLoad() {
    if (hasCS) { try { const r = await chrome.storage.local.get('history'); return r.history || []; } catch (e) {} }
    return store.get('history', []);
  }
  let histCache = null, histBusy = Promise.resolve();
  // 他のタブと同時に書いても消えないよう、書く直前に読み直してから足す
  function histUpsert(path, patch) {
    const id = chatIdOf(path); if (!id) return Promise.resolve();
    histBusy = histBusy.then(async () => {
      const list = await histLoad();
      let e = list.find(x => x.id === id);
      const now = Date.now();
      if (!e) { e = { id, path, title: '', count: 0, batch: 0, firstAt: now, lastAt: now, thumb: null, prompt: '' }; list.unshift(e); }
      const before = JSON.stringify(e);
      if (patch.title) e.title = patch.title;
      if (patch.path) e.path = patch.path;
      if (patch.count != null) e.count = Math.max(e.count || 0, patch.count);
      if (patch.batchAdd) e.batch = (e.batch || 0) + patch.batchAdd;
      if (patch.thumb && !e.thumb) e.thumb = patch.thumb;
      if (patch.prompt) e.prompt = patch.prompt;
      if (JSON.stringify(e) !== before) e.lastAt = now; else return;
      list.sort((a, b) => b.lastAt - a.lastAt);
      const cut = list.slice(0, HIST_MAX);
      histCache = cut; store.set('history', cut);
      if (state.mode === 'log' && state.open) renderHist();
    }).catch(err => log('ログの保存でエラー：' + err.message));
    return histBusy;
  }
  function makeThumb(img) {
    try {
      const w = img.naturalWidth, h = img.naturalHeight; if (!w || !h) return null;
      const S = 80, c = document.createElement('canvas'); c.width = c.height = S;
      const k = Math.max(S / w, S / h); c.getContext('2d').drawImage(img, (S - w * k) / 2, (S - h * k) / 2, w * k, h * k);
      return c.toDataURL('image/jpeg', 0.7);
    } catch (e) { return null; }
  }
  // 開いているチャットに生成画像があれば記録（数秒ごと）
  function histWatch() {
    try {
      const path = location.pathname; if (!chatIdOf(path)) return;
      const imgs = cg.generatedImgs().filter(i => !/^data:|^about:/.test(i.currentSrc || i.src));
      if (!imgs.length) return;
      const n = new Set(imgs.map(i => i.currentSrc || i.src)).size;
      const key = path + '|' + n + '|' + chatTitle();
      if (histWatch.last === key) return;
      histWatch.last = key;
      const first = imgs.find(i => i.complete && i.naturalWidth);
      histUpsert(path, { path, title: chatTitle(), count: n, thumb: first ? makeThumb(first) : null });
    } catch (e) {}
  }
  function goToChat(path) {
    const id = chatIdOf(path);
    const link = [...document.querySelectorAll('a[href]')].find(a => !a.closest('#' + HOST_ID) && id && chatIdOf(a.getAttribute('href')) === id);
    if (link) { link.click(); return; }
    history.pushState({}, '', path);
    window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
  }
  const dayLabel = t => {
    const d = new Date(t), today = new Date(); const y = new Date(); y.setDate(today.getDate() - 1);
    const same = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    return same(d, today) ? '今日' : same(d, y) ? '昨日' : d.toLocaleDateString('ja-JP', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' });
  };
  async function renderHist() {
    const list = histCache || (histCache = await histLoad());
    const q = $('histQ').value.trim().toLowerCase();
    const shown = list.filter(e => !q || (e.title || '').toLowerCase().includes(q) || (e.prompt || '').toLowerCase().includes(q));
    $('histTitle').textContent = `画像を作ったページ（${shown.length}件${q ? ` / 全${list.length}件` : ''}）`;
    const box = $('histList');
    if (!shown.length) { box.innerHTML = `<div class="empty">${q ? '見つかりません' : 'まだ記録がありません。生成画像のあるチャットを開くか、一括送信をすると記録されます。'}</div>`; return; }
    const curId = chatIdOf(location.pathname);
    let html = '', lastDay = '';
    shown.forEach(e => {
      const dl_ = dayLabel(e.lastAt);
      if (dl_ !== lastDay) { html += `<div class="day">${esc(dl_)}</div>`; lastDay = dl_; }
      const time = new Date(e.lastAt).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
      html += `<div class="hi${e.id === curId ? ' cur' : ''}" data-id="${esc(e.id)}">
        ${e.thumb ? `<img class="th" src="${e.thumb}" alt="">` : '<div class="th none">🖼</div>'}
        <div style="min-width:0">
          <div class="tt" title="${esc(e.title || '')}">${esc(e.title || '（名前なし）')}${e.id === curId ? ' <span style="color:var(--accent);font-weight:600">← 今ここ</span>' : ''}</div>
          <div class="mt"><span>${time}</span><span>生成画像 ${e.count || 0}枚</span>${e.batch ? `<span class="bt">一括送信 ${e.batch}枚</span>` : ''}</div>
          ${e.prompt ? `<div class="pr" title="${esc(e.prompt)}">指示：${esc(e.prompt)}</div>` : ''}
        </div>
        <div class="ac">
          <button class="btn sm primary" data-a="open">開く</button>
          <button class="btn sm" data-a="dl">画像DLで開く</button>
          <a class="btn sm" data-a="tab" href="${esc(e.path)}" target="_blank" style="text-decoration:none">新しいタブ</a>
          <button class="btn sm danger" data-a="del" title="この記録を消す">×</button>
        </div>
      </div>`;
    });
    box.innerHTML = html;
    box.querySelectorAll('.hi').forEach(row => {
      const e = shown.find(x => x.id === row.dataset.id);
      row.querySelector('[data-a=open]').onclick = () => { goToChat(e.path); setTimeout(renderHist, 1500); };
      row.querySelector('[data-a=dl]').onclick = () => { goToChat(e.path); setMode('dl'); };
      row.querySelector('[data-a=del]').onclick = async () => {
        await histBusy;
        const l = (await histLoad()).filter(x => x.id !== e.id);
        histCache = l; store.set('history', l); renderHist();
      };
    });
  }
  function initHist() {
    $('histQ').addEventListener('input', renderHist);
    let armed = 0;
    $('histClear').onclick = async () => {
      if (Date.now() - armed > 3000) { armed = Date.now(); $('histClear').textContent = 'もう一度押すと全部消えます'; setTimeout(() => $('histClear').textContent = '履歴を全部消す', 3000); return; }
      armed = 0; $('histClear').textContent = '履歴を全部消す';
      await histBusy; histCache = []; store.set('history', []); renderHist(); log('ログ（画像を作ったページ）を全部消しました');
    };
    setInterval(histWatch, 4000);
    setTimeout(histWatch, 2500);
  }

  // ---------- 実行 ----------
  const PHASES = [['nav', '送信先を開く'], ['attach', '画像を添付'], ['type', '指示を入力'], ['upload', 'アップロード'], ['gen', '生成待ち'], ['collect', '画像を取得']];
  const PHASE_TEXT = { nav: '送信先を開いています', attach: '画像を添付しています', type: '指示を入力しています', upload: 'アップロード完了を待っています', gen: 'ChatGPTの生成を待っています', collect: '生成画像を取り込んでいます' };
  const intervalMs = () => Math.max(1, +$('ival').value || 1) * (+$('iunit').value) * 1000;
  const fmt = ms => {
    const s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
  };
  const clock = t => new Date(t).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });

  function setStatus(t) {
    $('status').textContent = t;
    const tab = $('tab');
    tab.classList.toggle('running', state.running);
    const m = state.running && t.match(/(\d+)\/(\d+)/);
    tab.textContent = m ? `📷 実行中 ${m[1]}/${m[2]}` : '📷 一括送信';
  }

  // ---------- 送信中：本物のチャットの最新のやり取りをそのまま映す ----------
  const live = { sig: '', cvs: [] };
  const openZoom = src => { $('zoomImg').src = src; $('zoom').hidden = false; };
  const LBL_U = /^(あなたの発言|You said)/i, LBL_A = /^(ChatGPT\s*の発言|ChatGPT said)/i;
  function lastTurnParts() {
    const main = chatMain(); if (!main) return null;
    let turns = [...main.querySelectorAll('[data-turn-key]')].filter(t => !t.parentElement.closest('[data-turn-key]'));
    if (!turns.length) turns = [...main.querySelectorAll('[data-testid^="conversation-turn"], article')];
    const t = turns[turns.length - 1]; if (!t) return null;
    const heads = [...t.querySelectorAll('h1,h2,h3,h4,h5,h6')];
    let u = heads.filter(h => LBL_U.test(h.textContent.trim())).pop()?.parentElement || null;
    let a = heads.filter(h => LBL_A.test(h.textContent.trim())).pop()?.parentElement || null;
    if (!u && !a) { u = [...t.querySelectorAll('[data-message-author-role="user"]')].pop() || null; a = [...t.querySelectorAll('[data-message-author-role="assistant"]')].pop() || null; }
    if (!u && !a) a = t;
    const stEl = t.querySelector('[data-talvt-turn-state]');
    const gen = stEl ? stEl.dataset.talvtTurnState !== 'complete' : cg.isGenerating();
    return { t, u, a, gen };
  }
  const cleanText = el => { if (!el) return ''; const c = el.cloneNode(true); c.querySelectorAll('h1,h2,h3,h4,h5,h6,.sr-only,button,svg,style,script,canvas').forEach(x => x.remove()); return (c.innerText || c.textContent || '').replace(/\n{3,}/g, '\n\n').trim(); };
  function updLive() {
    const body = root?.getElementById('liveBody'); if (!body || $('runL').hidden) return;
    const p = lastTurnParts();
    const stEl = $('liveState');
    if (!p) { stEl.className = 'lvst'; stEl.textContent = ''; if (live.sig !== 'none') { live.sig = 'none'; body.innerHTML = '<div class="lvempty">まだやり取りがありません（チャットの準備中…）</div>'; } return; }
    stEl.className = 'lvst' + (p.gen ? ' gen' : ''); stEl.textContent = p.gen ? '生成中' : '✓ 完了';
    const uImgs = p.u ? [...p.u.querySelectorAll('img')].filter(i => (i.currentSrc || i.src) && !i.closest('[data-testid="generated-image-gallery"]')).slice(-4) : [];
    const uText = cleanText(p.u).slice(0, 600);
    const aText = cleanText(p.a);
    const aImgs = p.a ? [...p.a.querySelectorAll('img')].filter(i => { const r = i.getBoundingClientRect(); return (i.currentSrc || i.src) && (i.naturalWidth > 120 || r.width > 120) && !i.closest('[data-testid="generated-image-gallery"] button[aria-label*="表示"]'); }) : [];
    const gallery = p.a ? [...p.a.querySelectorAll('[data-testid="generated-image-gallery"] img, [data-testid="generated-image-preview"] img')] : [];
    const seen = new Set(); const media = [...gallery, ...aImgs].filter(i => { const s = i.currentSrc || i.src; if (seen.has(s)) return false; seen.add(s); return (i.naturalWidth || 0) > 60 || i.getBoundingClientRect().width > 60; }).slice(0, 4);
    const canv = p.a && !media.length ? [...p.a.querySelectorAll('canvas')].filter(c => c.width > 40 && c.height > 40 && getComputedStyle(c).opacity !== '0').slice(0, 2) : [];
    const sig = [uImgs.map(i => i.currentSrc || i.src).join(','), uText, aText.slice(-500), media.map(i => i.currentSrc || i.src).join(','), canv.length].join('|');
    if (sig !== live.sig) {
      live.sig = sig;
      const tail = aText.length > 500 ? '…' + aText.slice(-500) : aText;
      body.innerHTML = `${p.u ? `<div class="lvu"><span class="lvwho">あなた</span>${uImgs.length ? `<div class="im">${uImgs.map(() => '<img alt="">').join('')}</div>` : ''}${uText ? `<div class="tx">${esc(uText)}</div>` : ''}</div>` : ''}
        <div class="lva"><span class="lvwho">ChatGPT</span>${tail ? `<div class="tx">${esc(tail)}</div>` : (p.gen ? '<div class="tx" style="color:var(--sub)">返事を待っています…</div>' : '')}
        ${media.length || canv.length ? `<div class="md${media.length + canv.length === 1 ? ' one' : ''}">${media.map(() => '<img alt="">').join('')}${canv.map(() => '<canvas></canvas>').join('')}</div>` : ''}</div>`;
      body.querySelectorAll('.lvu .im img').forEach((im, i) => { im.src = uImgs[i].currentSrc || uImgs[i].src; });
      body.querySelectorAll('.lva .md img').forEach((im, i) => { im.src = media[i].currentSrc || media[i].src; im.title = 'クリックで拡大'; im.style.cursor = 'zoom-in'; im.onclick = () => openZoom(im.src); });
      live.cvs = [...body.querySelectorAll('.lva .md canvas')];
      [...body.querySelectorAll('.tx')].forEach(x => { x.scrollTop = x.scrollHeight; });
    }
    // 生成途中のプレビュー（ChatGPTのcanvas）は毎回写し直す
    live.cvs.forEach((dst, i) => { const src = canv[i]; if (!src) return; try { if (dst.width !== src.width) dst.width = src.width; if (dst.height !== src.height) dst.height = src.height; const x = dst.getContext('2d'); x.clearRect(0, 0, dst.width, dst.height); x.drawImage(src, 0, 0); } catch (e) {} });
  }

  function showView(run) {
    state.runView = run;
    if (state.mode !== 'send') return;
    $('colL').hidden = !run; $('destBar').hidden = run;
    $('setupR').hidden = run; $('runL').hidden = !run; $('runR').hidden = !run;
    $('start').hidden = run; $('stop').hidden = !(run && state.running); $('back').hidden = !(run && !state.running);
  }

  // 進捗画面の描画
  function renderRun() {
    if ($('runL').hidden) return;
    updLive();
    const now = Date.now();
    const total = state.runItems.length;
    const done = state.runItems.filter(i => i.status === 'done').length;
    const err = state.runItems.filter(i => i.status === 'err').length;
    const waiting = state.runItems.filter(i => i.status === 'wait');
    const cur = state.current;
    const end = state.endedAt || now;

    $('rvElapsed').textContent = `経過 ${fmt(end - state.startedAt)}　（開始 ${clock(state.startedAt)}）`;
    $('rvBar').style.width = total ? `${Math.round((done + err) / total * 100)}%` : '0%';
    $('rvDone').textContent = `${done + err} / ${total} 処理済み`;
    $('rvErr').textContent = err ? `エラー ${err}件` : '';
    $('rvErr').className = err ? 'e' : '';

    // 1枚あたりの所要時間（完了分の平均）から終了予定を出す
    const durs = state.runItems.filter(i => i.status === 'done' && i.endedAt).map(i => i.endedAt - i.startedAt);
    const avg = durs.length ? durs.reduce((a, b) => a + b, 0) / durs.length : 0;

    const st = $('rvState');
    if (!state.running) {
      st.className = 'badge ' + (state.stopReason === 'done' ? 'done' : 'err');
      st.textContent = state.stopReason === 'done' ? '完了' : '停止';
      $('rvThumb').src = '';
      $('rvNow').innerHTML = state.stopReason === 'done' ? '<b>すべて終わりました</b>' : '<b>停止しました</b>';
      $('rvBig').innerHTML = `${fmt(end - state.startedAt)}<small>かかりました</small>`;
      $('rvSteps').innerHTML = '';
      $('rvEta').textContent = avg ? `1枚あたり平均 ${fmt(avg)}` : '';
    } else if (cur) {
      st.className = 'badge run'; st.textContent = '送信中';
      const n = state.items.indexOf(cur) + 1;
      $('rvThumb').src = cur.url;
      $('rvNow').innerHTML = `<b>${n}番</b>「${esc(cur.file.name)}」— ${PHASE_TEXT[state.phase] || '処理中'}`;
      $('rvBig').innerHTML = `${fmt(now - cur.startedAt)}<small>経過</small>`;
      const idx = PHASES.findIndex(p => p[0] === state.phase);
      $('rvSteps').innerHTML = PHASES.map(([k, l], i) => `<span class="${i < idx ? 'ok' : i === idx ? 'on' : ''}">${i < idx ? '✓ ' : ''}${l}</span>`).join('');
      const est = avg ? Math.max(0, avg - (now - cur.startedAt)) + waiting.length * (intervalMs() + avg) : 0;
      $('rvEta').textContent = est ? `終了予定 ${clock(now + est)}ごろ（あと約${fmt(est)}）` : '';
    } else {
      const next = waiting[0];
      st.className = 'badge'; st.textContent = '待機中';
      if (next) {
        const n = state.items.indexOf(next) + 1;
        $('rvThumb').src = next.url;
        $('rvNow').innerHTML = `次は <b>${n}番</b>「${esc(next.file.name)}」を送信`;
        $('rvBig').innerHTML = `${fmt(state.nextAt - now)}<small>後に送信</small>`;
        $('rvSteps').innerHTML = `<span>送信予定 ${new Date(state.nextAt).toLocaleTimeString('ja-JP')}</span>`;
        const est = avg ? Math.max(0, state.nextAt - now) + waiting.length * avg + (waiting.length - 1) * intervalMs() : 0;
        $('rvEta').textContent = est ? `終了予定 ${clock(now + est)}ごろ（あと約${fmt(est)}）` : (done ? '' : '1枚目が終わると終了予定を表示します');
      }
    }
    const zn = state.runItems.filter(i => i.useZip).length;
    $('rvDest').textContent = '送信先：' + (state.destLabel || '') + ((state.runRefs || []).length && zn ? ` ／ 参考ファイル：${state.runRefs.map(f => f.name).join('、')}（✓の${zn}枚に添付）` : '');

    // 一覧
    const list = $('rvList');
    if (list.childElementCount !== total) {
      list.innerHTML = state.runItems.map(it => `<div class="ri" data-id="${it.id}"><div class="n"></div><img alt=""><div class="nm"><div></div><div class="p"></div></div><div class="gc"></div><div class="st"></div></div>`).join('');
    }
    state.runItems.forEach((it, i) => {
      const el = list.children[i];
      el.classList.toggle('cur', it === cur);
      el.querySelector('.n').textContent = state.items.indexOf(it) + 1;
      if (el.querySelector('img').src !== it.url) el.querySelector('img').src = it.url;
      el.querySelector('.nm div').textContent = it.file.name;
      el.querySelector('.nm .p').textContent = (it.useZip && (state.runRefs || []).length ? '📦 ' : '') + (it.sentText || it.prompt || '（指示なし）');
      let s;
      if (it.status === 'done') s = `<span style="color:var(--accent)">✓ 完了 ${fmt(it.endedAt - it.startedAt)}</span>`;
      else if (it.status === 'err') s = `<span style="color:var(--err)" title="${esc(it.error || '')}">✕ エラー</span>`;
      else if (it.status === 'run') s = `<span style="color:var(--accent)">● ${fmt(now - it.startedAt)}</span>`;
      else s = it === waiting[0] && !cur && state.running ? `あと ${fmt(state.nextAt - now)}` : '待機';
      if (it.chatUrl) s += `<a href="${esc(it.chatUrl)}" target="_blank">開く</a>`;
      const stEl = el.querySelector('.st'); if (stEl.innerHTML !== s) stEl.innerHTML = s;
      const gc = el.querySelector('.gc'), key = (it.results || []).map(r => r.url).join('|');
      if (gc.dataset.key !== key) { gc.dataset.key = key; gc.innerHTML = gensHtml(it); bindGens(gc, it); }
    });
    const nImgs = state.runItems.reduce((n, it) => n + (it.results?.length || 0), 0);
    $('dlAll').hidden = !nImgs;
    $('dlAll').textContent = `生成画像をまとめてDL（${nImgs}枚）`;
  }

  function start() {
    if (!state.items.some(it => it.status === 'wait')) return;
    if (updPend()) { flashStart('先に「① 反映」を押してください'); return; }
    if (!cg.composer()) return setStatus('ChatGPTの入力欄が見つかりません。ログインしているか確認してください');
    const curPath = location.pathname;
    if (destMode() === 'cur' && !chatIdOf(curPath)) { setStatus('送信先「現在選択しているチャット」：チャットが開かれていません。送りたいチャットを左の一覧から開いてから、もう一度押してください'); flashStart('チャットを開いてください'); return; }
    state.running = true;
    state.startedAt = Date.now(); state.endedAt = 0; state.current = null; state.phase = ''; state.stopReason = '';
    state.runItems = state.items.filter(it => it.status === 'wait');
    state.batchChat = destMode() === 'cur' ? curPath : null;
    state.runRefs = state.refs.slice();
    state.destLabel = destMode() === 'one' ? '新規チャット（今回分はまとめて1つに）' : destMode() === 'cur' ? `現在選択しているチャット：${chatTitle()}` : '毎回新しいチャット';
    $('rvList').innerHTML = '';
    showView(true);
    render();
    state.nextAt = $('firstNow').checked ? Date.now() : Date.now() + intervalMs();
    state.timer = setInterval(tick, 500);
    log(`開始：${state.runItems.length}枚 → ${state.destLabel}`);
    tick();
  }
  function flashStart(msg) { const b = $('start'), t = b.textContent; b.textContent = msg; setTimeout(() => { b.textContent = t; }, 1800); }
  function stop(msg, reason = 'stop') {
    state.running = false; clearInterval(state.timer); state.timer = null;
    state.endedAt = Date.now(); state.stopReason = reason;
    setStatus(msg); log(msg);
    showView(true); render(); renderRun();
  }
  async function tick() {
    if (!state.running) return;
    if (state.busy) { renderRun(); return; }
    const it = state.items.find(i => i.status === 'wait');
    const doneN = state.runItems.filter(i => i.status === 'done' || i.status === 'err').length;
    if (!it) {
      const ok = state.runItems.filter(i => i.status === 'done').length;
      return stop(`すべて完了（成功 ${ok} / エラー ${doneN - ok}）`, 'done');
    }
    if (!state.runItems.includes(it)) state.runItems.push(it);
    const left = state.nextAt - Date.now();
    if (left > 0) {
      setStatus(`実行中 ${doneN}/${state.runItems.length} ・ 次の送信まで ${fmt(left)}`);
      renderRun();
      return;
    }
    state.busy = true;
    const n = state.items.indexOf(it) + 1;
    setStatus(`実行中 ${doneN}/${state.runItems.length} ・ ${n}番を送信・生成中…`);
    it.status = 'run'; it.startedAt = Date.now(); state.current = it;
    const phase = p => { state.phase = p; renderRun(); };
    render(); phase('nav');
    log(`${n}番「${it.file.name}」を送信`);
    try {
      if (destMode() !== 'new' && state.batchChat) await cg.openUrl(location.origin + state.batchChat);
      else await cg.openNewChat();
      const text = it.prompt.trim();
      it.sentText = text;
      const res = await cg.send(it.file, text, phase, it.useZip ? (state.runRefs || []) : []);
      it.chatUrl = res.url;
      setResults(it, res.images);
      if (destMode() === 'one' && !state.batchChat) {
        const pth = new URL(res.url).pathname;
        if (chatIdOf(pth)) { state.batchChat = pth; state.destLabel = `新規チャット（今回分はまとめて1つに）：${chatTitle()}`; log(`今回分のチャットを作りました：${pth}（以降はここに送ります）`); }
      }
      it.status = 'done'; log(`${n}番 完了（${fmt(Date.now() - it.startedAt)}）${it.results.length ? `・生成画像 ${it.results.length}枚` : '・生成画像なし'}`);
      if (it.results.length) histUpsert(new URL(res.url).pathname, { path: new URL(res.url).pathname, title: chatTitle(), count: it.results.length, batchAdd: it.results.length, prompt: text.slice(0, 120) });
      if (it.results.length && $('autoDl').checked) await downloadItem(it);
    } catch (e) {
      it.status = 'err'; it.error = e.message; log(`${n}番 エラー：${e.message}`);
    }
    it.endedAt = Date.now();
    state.current = null; state.phase = '';
    state.busy = false;
    state.nextAt = Date.now() + intervalMs();
    render(); renderRun();
    if (state.running) tick();
  }

  // ---------- 起動 ----------
  const boot = async () => {
    await store.load();
    // v1.29.0：画像右上のダウンロードは、Chromeのダウンロード（右上）に保存する形を標準に
    if (!store.get('mig129', false)) { store.set('quickTarget', 'dl'); store.set('mig129', true); }
    // v1.23.0：zip用テンプレを別管理に。今まで選んでいた指示テンプレがあれば、それを最初のzip用テンプレとして引き継ぐ
    if (store.get('zipTemplates', null) === null) {
      const cur = store.get('zipTpl', ''), t = tpls().find(x => x.name === cur);
      store.set('zipTemplates', t ? [{ name: t.name, text: t.text }] : []);
      if (!t) store.set('zipTpl', '');
    }
    build();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();

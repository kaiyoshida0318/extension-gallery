// ============================================
// Speed Access - Chrome Extension (GitHub版)
// ============================================

// ============================================
// 配布用の固定設定 (配布者がここを編集してから配布)
// ユーザーはPATだけ入力すればOK
// ============================================
const FIXED_CONFIG = {
  OWNER: 'kaiyoshida0318',                  // ← GitHubユーザー名 (配布者が事前に設定)
  REPO: 'speed-access-data',                // ← リポジトリ名 (配布者が事前に設定)
  FILE_PATH: 'shared-tabs.json',
  BRANCH: 'main'
};

// 実行時設定 (FIXED_CONFIG + ユーザー入力のPAT)
let GITHUB_CONFIG = {
  ...FIXED_CONFIG,
  TOKEN: ''
};
// 最終同期日時 (タブIDごと)
let lastSyncTimes = {};

const EXPORT_VERSION = 1;

// ============================================
// State
// ============================================
let state = {
  tabs: [],
  activeTabId: null
};

let currentEditingTile = null;
let pendingConfirmAction = null;
let pendingImportData = null;

// タイルドラッグ中の状態
let draggedTile = null;  // { tileId, sourceTabId }
let tabHoverTimer = null;  // タブホバーで切替するためのタイマー

// 画像キャッシュ (URL → Base64 dataURL)
const imageCache = new Map();
const cacheFetchingUrls = new Set();  // フェッチ中URL (重複防止)
let imageCacheLoaded = false;

// レイアウト設定のデフォルト
const DEFAULT_LAYOUT = {
  columns: 0,   // 0 = 自動 (auto-fill)
  width: 160,
  height: 160,
  gap: 16,
  headerSpacing: 24
};
// 推奨レイアウト (ユーザーが見つけた使いやすい設定)
const RECOMMENDED_LAYOUT = {
  columns: 6,
  width: 260,
  height: 150,
  gap: 8,
  headerSpacing: 64
};
// 全タブのレイアウト設定 { [tabId]: layout }
let allLayouts = {};
// 現在表示中のレイアウト (アクティブタブの設定)
let layoutSettings = { ...DEFAULT_LAYOUT };

// ============================================
// Storage - 個人データ (chrome.storage.local)
// ============================================
const personalStorage = {
  async load() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessData'], (result) => {
        if (result.speedAccessData) {
          resolve(result.speedAccessData);
        } else {
          // 最初は空 (ユーザーが最初のタブを作る)
          resolve({
            tabs: [],
            activeTabId: null
          });
        }
      });
    });
  },

  async save(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessData: data }, resolve);
    });
  },

  async loadLayout() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLayouts', 'speedAccessLayout'], (result) => {
        // 新形式: タブごとのレイアウト
        if (result.speedAccessLayouts && typeof result.speedAccessLayouts === 'object') {
          resolve(result.speedAccessLayouts);
          return;
        }
        // 旧形式: 単一レイアウト (マイグレーション)
        if (result.speedAccessLayout) {
          const oldLayout = { ...DEFAULT_LAYOUT, ...result.speedAccessLayout };
          // 旧設定を全タブのデフォルトとして扱う
          resolve({ _default: oldLayout });
          return;
        }
        resolve({});
      });
    });
  },

  async saveLayout(allLayouts) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLayouts: allLayouts }, resolve);
    });
  },

  async loadImageCache() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessImageCache'], (result) => {
        resolve(result.speedAccessImageCache || {});
      });
    });
  },

  async saveImageCache(cacheObj) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessImageCache: cacheObj }, resolve);
    });
  },

  async loadSyncConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessSyncConfig'], (result) => {
        resolve(result.speedAccessSyncConfig || null);
      });
    });
  },

  async saveSyncConfig(config) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessSyncConfig: config }, resolve);
    });
  },

  async loadLastSyncTimes() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['speedAccessLastSyncTimes'], (result) => {
        resolve(result.speedAccessLastSyncTimes || {});
      });
    });
  },

  async saveLastSyncTimes(times) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ speedAccessLastSyncTimes: times }, resolve);
    });
  }
};

// ============================================
// Storage - 共有データ (GitHub API)
// ============================================
const sharedStorage = {
  // ファイルごとのSHAをキャッシュ (GitHubの更新にはSHAが必要)
  _fileSha: null,

  isConfigured() {
    return GITHUB_CONFIG.OWNER.trim().length > 0 &&
           GITHUB_CONFIG.REPO.trim().length > 0 &&
           GITHUB_CONFIG.TOKEN.trim().length > 0;
  },

  _apiUrl() {
    return `https://api.github.com/repos/${GITHUB_CONFIG.OWNER.trim()}/${GITHUB_CONFIG.REPO.trim()}/contents/${GITHUB_CONFIG.FILE_PATH.trim()}`;
  },

  _headers() {
    return {
      'Authorization': `Bearer ${GITHUB_CONFIG.TOKEN.trim()}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28'
    };
  },

  // UTF-8文字列をBase64に
  _encodeBase64(str) {
    // 日本語などマルチバイト文字対応
    return btoa(unescape(encodeURIComponent(str)));
  },

  _decodeBase64(str) {
    return decodeURIComponent(escape(atob(str.replace(/\n/g, ''))));
  },

  async fetchAll() {
    if (!this.isConfigured()) {
      throw new Error('GitHub連携の初期セットアップが完了していません。README.mdを確認してください。');
    }

    const url = `${this._apiUrl()}?ref=${GITHUB_CONFIG.BRANCH}&_=${Date.now()}`;
    const res = await fetch(url, {
      headers: this._headers(),
      cache: 'no-store'
    });

    if (res.status === 404) {
      // ファイルがまだ存在しない場合
      this._fileSha = null;
      return {};
    }
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`GitHub API エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const fileData = await res.json();
    this._fileSha = fileData.sha;

    try {
      const content = this._decodeBase64(fileData.content);
      return JSON.parse(content) || {};
    } catch (err) {
      console.error('Parse error:', err);
      return {};
    }
  },

  async saveAll(allData) {
    if (!this.isConfigured()) {
      throw new Error('GitHub連携の初期セットアップが完了していません。');
    }

    // SHAがない場合は取得を試みる
    if (!this._fileSha) {
      try { await this.fetchAll(); } catch {}
    }

    const body = {
      message: `Update shared-tabs.json (${new Date().toISOString()})`,
      content: this._encodeBase64(JSON.stringify(allData, null, 2)),
      branch: GITHUB_CONFIG.BRANCH
    };

    if (this._fileSha) {
      body.sha = this._fileSha;
    }

    const res = await fetch(this._apiUrl(), {
      method: 'PUT',
      headers: {
        ...this._headers(),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      const errText = await res.text();

      // SHAのコンフリクト (他のユーザーが先に書き込んだ) → リトライ
      if (res.status === 409 || errText.includes('does not match')) {
        this._fileSha = null;
        await this.fetchAll();
        return this.saveAll(allData);
      }

      throw new Error(`GitHub 保存エラー (${res.status}): ${errText.slice(0, 100)}`);
    }

    const result = await res.json();
    this._fileSha = result.content?.sha || null;
  },

  async getByCode(code) {
    const all = await this.fetchAll();
    return all[code] || null;
  },

  async saveByCode(code, tabData) {
    const all = await this.fetchAll();
    all[code] = tabData;
    await this.saveAll(all);
  }
};

// ============================================
// Helpers
// ============================================
function getFaviconUrl(url) {
  try {
    const domain = new URL(url).hostname;
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
  } catch {
    return '';
  }
}

// ============================================
// 画像キャッシュ
// ============================================
async function loadImageCacheToMemory() {
  if (imageCacheLoaded) return;
  try {
    const stored = await personalStorage.loadImageCache();
    Object.entries(stored).forEach(([key, value]) => {
      imageCache.set(key, value);
    });
  } catch (err) {
    console.error('Failed to load image cache:', err);
  }
  imageCacheLoaded = true;
}

let saveCacheTimer = null;
function scheduleSaveImageCache() {
  if (saveCacheTimer) clearTimeout(saveCacheTimer);
  saveCacheTimer = setTimeout(async () => {
    saveCacheTimer = null;
    const obj = {};
    imageCache.forEach((value, key) => { obj[key] = value; });
    try {
      await personalStorage.saveImageCache(obj);
    } catch (err) {
      console.error('Failed to save image cache:', err);
    }
  }, 1000);
}

// 画像URLをBase64化してキャッシュ
async function fetchAndCacheImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;  // 既にdata:URLならそのまま
  if (imageCache.has(url)) return imageCache.get(url);
  if (cacheFetchingUrls.has(url)) return null;

  cacheFetchingUrls.add(url);
  try {
    const res = await fetch(url, { mode: 'cors', cache: 'force-cache' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();

    // 200KB以上の画像はキャッシュしない (容量保護)
    if (blob.size > 200 * 1024) {
      cacheFetchingUrls.delete(url);
      return null;
    }

    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    imageCache.set(url, dataUrl);
    scheduleSaveImageCache();
    return dataUrl;
  } catch (err) {
    return null;
  } finally {
    cacheFetchingUrls.delete(url);
  }
}

function getCachedImage(url) {
  if (!url) return null;
  if (url.startsWith('data:')) return url;
  return imageCache.get(url) || null;
}

function getDisplayImageSrc(url) {
  if (!url) return '';
  const cached = getCachedImage(url);
  return cached || url;
}

// 表示中のタイル画像をバックグラウンドでプリフェッチ
function prefetchImages(urls) {
  const CONCURRENT = 4;
  const queue = [...new Set(urls)].filter(u =>
    u && !u.startsWith('data:') && !imageCache.has(u) && !cacheFetchingUrls.has(u)
  );

  let running = 0;
  function runNext() {
    while (running < CONCURRENT && queue.length > 0) {
      const url = queue.shift();
      running++;
      fetchAndCacheImage(url).finally(() => {
        running--;
        runNext();
      });
    }
  }
  runNext();
}

function normalizeUrl(url) {
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (!/^https?:\/\//i.test(trimmed)) {
    return 'https://' + trimmed;
  }
  return trimmed;
}

function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast' + (isError ? ' error' : '');
  setTimeout(() => toast.classList.add('hidden'), 2500);
}

function formatDateForFile(d = new Date()) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// ============================================
// Layout settings
// ============================================
function getLayoutForTab(tabId) {
  if (allLayouts[tabId]) {
    return { ...DEFAULT_LAYOUT, ...allLayouts[tabId] };
  }
  // フォールバック: _default (旧形式マイグレーション用)
  if (allLayouts._default) {
    return { ...DEFAULT_LAYOUT, ...allLayouts._default };
  }
  return { ...DEFAULT_LAYOUT };
}

function applyLayoutSettings() {
  const root = document.documentElement;
  root.style.setProperty('--tile-gap', `${layoutSettings.gap}px`);
  root.style.setProperty('--tile-width', `${layoutSettings.width}px`);
  root.style.setProperty('--tile-height', `${layoutSettings.height}px`);
  root.style.setProperty('--header-spacing', `${layoutSettings.headerSpacing}px`);

  // 画面幅から実際に表示できる列数を計算
  const main = document.querySelector('.main');
  const mainPadding = 80; // 左右40pxずつ
  const availableWidth = (main ? main.clientWidth : window.innerWidth) - mainPadding;
  const tileWithGap = layoutSettings.width + layoutSettings.gap;
  const maxFitColumns = Math.max(1, Math.floor((availableWidth + layoutSettings.gap) / tileWithGap));

  // ユーザー設定列数 (0=自動なら maxFitColumns) と実際に入る列数の小さい方
  let actualColumns;
  if (layoutSettings.columns === 0) {
    actualColumns = maxFitColumns;
  } else {
    actualColumns = Math.min(layoutSettings.columns, maxFitColumns);
  }

  // タイル幅は固定。列数だけが画面幅で変動
  const gridTemplate = `repeat(${actualColumns}, ${layoutSettings.width}px)`;
  root.style.setProperty('--grid-template', gridTemplate);
  root.style.setProperty('--tile-columns', String(actualColumns));
}

// ウィンドウリサイズ時に再計算
let resizeTimer = null;
window.addEventListener('resize', () => {
  if (resizeTimer) clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    applyLayoutSettings();
  }, 50);
});

function loadLayoutForActiveTab() {
  layoutSettings = getLayoutForTab(state.activeTabId);
  applyLayoutSettings();
}

function showLayoutModal() {
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();

  // モーダルのタイトルに対象タブ名を表示
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const titleEl = document.querySelector('#layout-modal .modal-header h2');
  if (titleEl && activeTab) {
    titleEl.textContent = `レイアウト設定: ${activeTab.name}`;
  }

  document.getElementById('layout-modal').classList.remove('hidden');
}

function hideLayoutModal() {
  document.getElementById('layout-modal').classList.add('hidden');
}

// ============================================
// 同期設定モーダル (PATのみ入力)
// ============================================
function showSyncModal() {
  document.getElementById('sync-token').value = GITHUB_CONFIG.TOKEN || '';

  // 固定値表示の更新
  document.getElementById('sync-fixed-info').textContent = `${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;

  updateSyncStatus();
  document.getElementById('sync-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('sync-token').focus(), 50);
}

function hideSyncModal() {
  document.getElementById('sync-modal').classList.add('hidden');
}

function updateSyncStatus() {
  const status = document.getElementById('sync-status');
  const statusVal = document.getElementById('sync-status-value');
  const lastTimeVal = document.getElementById('sync-last-time');

  if (sharedStorage.isConfigured()) {
    status.classList.remove('hidden');
    statusVal.textContent = '設定済み';
    statusVal.className = 'ok';
  } else {
    status.classList.remove('hidden');
    statusVal.textContent = '未設定';
    statusVal.className = 'ng';
  }

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared' && lastSyncTimes[activeTab.id]) {
    const date = new Date(lastSyncTimes[activeTab.id]);
    lastTimeVal.textContent = formatDateTime(date);
  } else if (activeTab && activeTab.type === 'shared') {
    lastTimeVal.textContent = '未同期';
  } else {
    lastTimeVal.textContent = '(共有タブを開いてください)';
  }
}

function formatDateTime(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${yyyy}/${mm}/${dd} ${hh}:${mi}`;
}

async function saveSyncSettings() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  GITHUB_CONFIG.TOKEN = token;

  // SHAキャッシュをリセット
  sharedStorage._fileSha = null;

  await personalStorage.saveSyncConfig({ TOKEN: token });

  hideSyncModal();
  showToast('Personal Access Token を保存しました');

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared') {
    await syncActiveSharedTab();
    renderTiles();
  }
}

async function testSyncConnection() {
  const token = document.getElementById('sync-token').value.trim();

  if (!token) {
    showToast('Personal Access Token を入力してください', true);
    return;
  }

  const statusVal = document.getElementById('sync-status-value');
  document.getElementById('sync-status').classList.remove('hidden');
  statusVal.textContent = '接続中...';
  statusVal.className = '';

  try {
    const url = `https://api.github.com/repos/${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO}`;
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json'
      }
    });

    if (res.ok) {
      statusVal.textContent = '✓ 接続成功';
      statusVal.className = 'ok';
      showToast('接続テストに成功しました');
    } else if (res.status === 401) {
      statusVal.textContent = '✕ トークンが無効';
      statusVal.className = 'ng';
      showToast('トークンが無効です (401)', true);
    } else if (res.status === 404) {
      statusVal.textContent = '✕ リポジトリが見つからない';
      statusVal.className = 'ng';
      showToast(`リポジトリ ${FIXED_CONFIG.OWNER}/${FIXED_CONFIG.REPO} にアクセスできません (404)`, true);
    } else {
      statusVal.textContent = `✕ エラー (${res.status})`;
      statusVal.className = 'ng';
      showToast(`接続エラー: ${res.status}`, true);
    }
  } catch (err) {
    statusVal.textContent = '✕ 接続失敗';
    statusVal.className = 'ng';
    showToast('接続失敗: ' + err.message, true);
  }
}

function updateLayoutValueLabels() {
  const cols = layoutSettings.columns;
  document.getElementById('columns-value').textContent = cols === 0 ? '自動' : `${cols}列`;
  document.getElementById('width-value').textContent = `${layoutSettings.width}px`;
  document.getElementById('height-value').textContent = `${layoutSettings.height}px`;
  document.getElementById('gap-value').textContent = `${layoutSettings.gap}px`;
  document.getElementById('header-spacing-value').textContent = `${layoutSettings.headerSpacing}px`;
}

async function updateLayoutFromSliders() {
  layoutSettings.columns = parseInt(document.getElementById('columns-slider').value, 10);
  layoutSettings.width = parseInt(document.getElementById('width-slider').value, 10);
  layoutSettings.height = parseInt(document.getElementById('height-slider').value, 10);
  layoutSettings.gap = parseInt(document.getElementById('gap-slider').value, 10);
  layoutSettings.headerSpacing = parseInt(document.getElementById('header-spacing-slider').value, 10);
  updateLayoutValueLabels();
  applyLayoutSettings();
  // アクティブタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
}

async function resetLayout() {
  layoutSettings = { ...DEFAULT_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブの設定を削除 (デフォルトに戻す)
  delete allLayouts[state.activeTabId];
  await personalStorage.saveLayout(allLayouts);
  showToast('このタブをデフォルトに戻しました');
}

async function applyRecommendedLayout() {
  layoutSettings = { ...RECOMMENDED_LAYOUT };
  document.getElementById('columns-slider').value = layoutSettings.columns;
  document.getElementById('width-slider').value = layoutSettings.width;
  document.getElementById('height-slider').value = layoutSettings.height;
  document.getElementById('gap-slider').value = layoutSettings.gap;
  document.getElementById('header-spacing-slider').value = layoutSettings.headerSpacing;
  updateLayoutValueLabels();
  applyLayoutSettings();
  // このタブのレイアウトとして保存
  allLayouts[state.activeTabId] = { ...layoutSettings };
  await personalStorage.saveLayout(allLayouts);
  showToast('推奨設定を適用しました');
}

async function applyLayoutToAllTabs() {
  // 現在のレイアウトを全タブに適用
  state.tabs.forEach(tab => {
    allLayouts[tab.id] = { ...layoutSettings };
  });
  await personalStorage.saveLayout(allLayouts);
  showToast('全タブに適用しました');
}

// ============================================
// Sync logic
// ============================================
async function syncActiveSharedTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab || activeTab.type !== 'shared') return;

  try {
    const remote = await sharedStorage.getByCode(activeTab.code);
    if (remote && Array.isArray(remote.tiles)) {
      activeTab.tiles = remote.tiles;
      if (remote.name) activeTab.name = remote.name;
      await personalStorage.save(state);
    }
    // 同期成功 → 時刻を記録
    lastSyncTimes[activeTab.id] = Date.now();
    await personalStorage.saveLastSyncTimes(lastSyncTimes);
  } catch (err) {
    console.error('Sync failed:', err);
    showToast('同期に失敗しました: ' + err.message, true);
  }
}

async function saveSharedTab(tab) {
  try {
    await sharedStorage.saveByCode(tab.code, {
      name: tab.name,
      tiles: tab.tiles
    });
    // 保存成功 → 時刻を記録
    lastSyncTimes[tab.id] = Date.now();
    personalStorage.saveLastSyncTimes(lastSyncTimes).catch(() => {});
  } catch (err) {
    console.error('Save shared failed:', err);
    showToast('共有データの保存に失敗: ' + err.message, true);
    throw err;
  }
}

async function saveActiveTab() {
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  await personalStorage.save(state);
  if (activeTab && activeTab.type === 'shared') {
    await saveSharedTab(activeTab);
  }
}

// ============================================
// Export / Import
// ============================================
function exportData() {
  const exportObj = {
    format: 'speed-access',
    version: EXPORT_VERSION,
    exportedAt: new Date().toISOString(),
    tabs: state.tabs.map(tab => ({
      id: tab.id,
      name: tab.name,
      type: tab.type,
      code: tab.code || null,
      tiles: tab.tiles.map(tile => ({
        title: tile.title,
        url: tile.url,
        image: tile.image || ''
      }))
    }))
  };

  const json = JSON.stringify(exportObj, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `speed-access-export-${formatDateForFile()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('エクスポートしました');
}

function parseImportData(raw) {
  if (!raw || typeof raw !== 'object') {
    throw new Error('無効なファイル形式です');
  }

  if (raw.format === 'speed-access' && Array.isArray(raw.tabs)) {
    return raw.tabs.map(tab => ({
      name: tab.name || 'タブ',
      type: tab.type === 'shared' ? 'shared' : 'personal',
      code: tab.code || null,
      tiles: (tab.tiles || []).map(t => ({
        title: t.title || '',
        url: t.url || '',
        image: t.image || ''
      })).filter(t => t.url)
    }));
  }

  if (Array.isArray(raw.dials)) {
    const groups = Array.isArray(raw.groups) ? raw.groups : [{ id: 0, title: 'Home' }];
    const groupMap = {};
    groups.forEach(g => {
      groupMap[g.id] = {
        name: g.title || 'タブ',
        type: 'personal',
        code: null,
        tiles: []
      };
    });

    const sortedDials = [...raw.dials].sort((a, b) => (a.position || 0) - (b.position || 0));

    sortedDials.forEach(dial => {
      const groupId = dial.idgroup !== undefined ? dial.idgroup : 0;
      if (!groupMap[groupId]) {
        groupMap[groupId] = { name: 'その他', type: 'personal', code: null, tiles: [] };
      }
      if (dial.url) {
        let title = dial.title || '';
        title = title.trim();
        const firstToken = title.split(/\s+/)[0];
        if (firstToken && firstToken.length > 0) {
          title = firstToken;
        }
        if (!title || title === '.') {
          try {
            title = new URL(dial.url).hostname.replace(/^www\./, '');
          } catch {
            title = 'リンク';
          }
        }

        groupMap[groupId].tiles.push({
          title,
          url: dial.url,
          image: dial.thumbnail || ''
        });
      }
    });

    const orderedGroups = groups
      .slice()
      .sort((a, b) => (a.position || 0) - (b.position || 0))
      .map(g => groupMap[g.id])
      .filter(Boolean);

    return orderedGroups;
  }

  throw new Error('対応していないファイル形式です');
}

function renderImportPreview(parsedTabs) {
  const container = document.getElementById('import-preview');
  const html = parsedTabs.map(tab => `
    <div class="import-preview-group">
      <div class="import-preview-group-title">
        <span>${escapeHtml(tab.name)}${tab.type === 'shared' ? ' <span class="tab-badge">共有</span>' : ''}</span>
        <span class="import-preview-group-count">${tab.tiles.length} タイル</span>
      </div>
      <div class="import-preview-items">
        ${tab.tiles.slice(0, 5).map(t => escapeHtml(t.title || t.url)).join(' / ')}
        ${tab.tiles.length > 5 ? ` <span style="color:#999">他 ${tab.tiles.length - 5} 件</span>` : ''}
      </div>
    </div>
  `).join('');
  container.innerHTML = html || '<div style="color:#999;font-size:12px;">インポート可能な項目がありません</div>';
}

async function handleImportFile(file) {
  console.log('[Import] ファイル読み込み開始:', file.name, file.size, 'bytes');
  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    console.log('[Import] JSON パース成功');
    const parsed = parseImportData(raw);
    console.log('[Import] データ変換成功:', parsed.length, '個のタブ');
    parsed.forEach((t, i) => {
      console.log(`  [${i}] "${t.name}" - ${t.tiles.length} タイル`);
    });

    pendingImportData = parsed;
    document.getElementById('import-preview-container').classList.remove('hidden');
    renderImportPreview(parsed);
    document.getElementById('import-execute').disabled = parsed.length === 0;
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('ファイルの読み込みに失敗: ' + err.message, true);
    pendingImportData = null;
    document.getElementById('import-preview-container').classList.add('hidden');
    document.getElementById('import-execute').disabled = true;
  }
}

async function executeImport() {
  if (!pendingImportData) return;

  const mode = document.querySelector('input[name="import-mode"]:checked').value;

  console.log('[Import] モード:', mode);
  console.log('[Import] インポート対象:', pendingImportData.length, '個のタブ');

  try {
    if (mode === 'replace') {
      // replaceモード: 全タブをクリア
      state.tabs = [];
    }

    let firstImportedTabId = null;
    let totalTilesAdded = 0;

    for (const importTab of pendingImportData) {
      const newTab = {
        id: generateId('tab'),
        name: importTab.name,
        type: importTab.type === 'shared' ? 'shared' : 'personal',
        tiles: importTab.tiles.map(t => ({
          id: generateId('tile'),
          title: t.title,
          url: t.url,
          image: t.image
        }))
      };

      if (importTab.type === 'shared' && importTab.code) {
        newTab.code = importTab.code;
      } else {
        newTab.type = 'personal';
        delete newTab.code;
      }

      state.tabs.push(newTab);
      totalTilesAdded += newTab.tiles.length;
      if (!firstImportedTabId) firstImportedTabId = newTab.id;
    }

    // インポートしたタブをアクティブに
    if (firstImportedTabId) {
      state.activeTabId = firstImportedTabId;
    }

    console.log('[Import] 完了:', totalTilesAdded, 'タイル追加');
    console.log('[Import] 保存前のstate:', {
      tabs: state.tabs.length,
      totalTiles: state.tabs.reduce((sum, t) => sum + t.tiles.length, 0),
      activeTabId: state.activeTabId
    });

    // chrome.storage.local の 5MB 制限対策: データサイズを確認
    const dataSize = JSON.stringify(state).length;
    console.log('[Import] データサイズ:', Math.round(dataSize / 1024), 'KB');

    if (dataSize > 4.5 * 1024 * 1024) {
      showToast('データが大きすぎます。画像URLを減らしてください', true);
      return;
    }

    await personalStorage.save(state);
    console.log('[Import] 保存完了');

    // 共有タブはリモートにも保存
    if (sharedStorage.isConfigured()) {
      for (const tab of state.tabs) {
        if (tab.type === 'shared' && tab.code) {
          try { await saveSharedTab(tab); } catch (err) {
            console.warn('[Import] 共有保存失敗:', err);
          }
        }
      }
    }

    hideImportModal();
    showToast(`${pendingImportData.length} 個のタブ / ${totalTilesAdded} 個のタイルをインポートしました`);
    pendingImportData = null;
    render();
  } catch (err) {
    console.error('[Import] エラー:', err);
    showToast('インポートエラー: ' + err.message, true);
  }
}

// ============================================
// Rendering
// ============================================
function render() {
  const app = document.getElementById('app');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  const isSharedTab = activeTab && activeTab.type === 'shared';

  app.innerHTML = `
    <header class="header">
      <div class="header-row">
        <div class="tabs-container" id="tabs-container"></div>
        <div class="header-actions">
          ${isSharedTab ? `
            <div class="shared-code-display" title="このタブの合言葉コード">🔗 共有: ${escapeHtml(activeTab.code)}</div>
            <button class="sync-btn" id="sync-btn" title="最新の共有データを取得">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="23 4 23 10 17 10"/>
                <polyline points="1 20 1 14 7 14"/>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
              </svg>
              同期
            </button>
          ` : ''}
          <button class="header-btn" id="settings-btn" title="設定">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
        </div>
      </div>
    </header>
    <main class="main">
      <div class="tiles-grid" id="tiles-grid"></div>
    </main>
  `;

  renderTabs();
  renderTiles();
  attachMainEvents();
  setupTabDropZones();
}

function renderTabs() {
  const container = document.getElementById('tabs-container');
  container.innerHTML = '';

  state.tabs.forEach((tab) => {
    const btn = document.createElement('div');
    btn.className = 'tab' + (tab.id === state.activeTabId ? ' active' : '');
    btn.dataset.tabId = tab.id;
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('draggable', 'true');

    const sharedLabel = tab.type === 'shared'
      ? '<span class="tab-shared-label">共有</span>'
      : '<span class="tab-shared-label placeholder">&nbsp;</span>';
    btn.innerHTML = `
      <div class="tab-content">
        ${sharedLabel}
        <span class="tab-name">${escapeHtml(tab.name)}</span>
      </div>
      <button class="tab-menu-btn" data-action="menu" type="button" aria-label="タブメニュー">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" pointer-events="none">
          <circle cx="12" cy="12" r="1"/>
          <circle cx="12" cy="5" r="1"/>
          <circle cx="12" cy="19" r="1"/>
        </svg>
      </button>
    `;

    btn.addEventListener('click', (e) => {
      const menuBtn = e.target.closest('[data-action="menu"]');
      if (menuBtn) {
        e.stopPropagation();
        e.preventDefault();
        showTabMenu(tab.id, menuBtn);
        return;
      }
      selectTab(tab.id);
    });

    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTabMenu(tab.id, btn);
    });

    // ドラッグ&ドロップ
    btn.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', tab.id);
      btn.classList.add('dragging');
    });

    btn.addEventListener('dragend', () => {
      btn.classList.remove('dragging');
      document.querySelectorAll('.tab').forEach(el => {
        el.classList.remove('drag-over-left', 'drag-over-right');
      });
    });

    btn.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置で左右どちらに挿入するか判定
      const rect = btn.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      btn.classList.remove('drag-over-left', 'drag-over-right');
      if (e.clientX < midpoint) {
        btn.classList.add('drag-over-left');
      } else {
        btn.classList.add('drag-over-right');
      }
    });

    btn.addEventListener('dragleave', () => {
      btn.classList.remove('drag-over-left', 'drag-over-right');
    });

    btn.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const insertRight = btn.classList.contains('drag-over-right');
      btn.classList.remove('drag-over-left', 'drag-over-right');

      const draggedId = e.dataTransfer.getData('text/plain');
      if (!draggedId || draggedId === tab.id) return;

      const draggedIndex = state.tabs.findIndex(t => t.id === draggedId);
      if (draggedIndex < 0) return;

      const [moved] = state.tabs.splice(draggedIndex, 1);

      let dropIndex = state.tabs.findIndex(t => t.id === tab.id);
      if (dropIndex < 0) {
        state.tabs.push(moved);
      } else {
        if (insertRight) dropIndex += 1;
        state.tabs.splice(dropIndex, 0, moved);
      }

      // タブバーだけ再描画 (タイルグリッドは変化なし)
      renderTabs();
      setupTabDropZones();

      // 保存はバックグラウンド
      personalStorage.save(state).catch(err => console.error('save failed:', err));
    });

    container.appendChild(btn);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tab-add-btn';
  addBtn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  `;
  addBtn.title = 'タブを追加';
  addBtn.addEventListener('click', showAddTabModal);
  container.appendChild(addBtn);
}

function renderTiles() {
  const grid = document.getElementById('tiles-grid');
  const activeTab = state.tabs.find(t => t.id === state.activeTabId);

  // タブが存在しない場合はウェルカム画面
  if (!activeTab) {
    grid.innerHTML = '';
    grid.classList.add('empty-grid');
    const welcome = document.createElement('div');
    welcome.className = 'welcome-screen';
    welcome.innerHTML = `
      <div class="welcome-icon">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="3" width="7" height="7"/>
          <rect x="14" y="3" width="7" height="7"/>
          <rect x="14" y="14" width="7" height="7"/>
          <rect x="3" y="14" width="7" height="7"/>
        </svg>
      </div>
      <h2>Speed Accessへようこそ</h2>
      <p>最初のタブを作成して始めましょう。<br>個人用/共有用を選べます。</p>
      <button class="btn-primary" id="welcome-create-tab">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="12" y1="5" x2="12" y2="19"/>
          <line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        タブを作成
      </button>
    `;
    grid.appendChild(welcome);
    document.getElementById('welcome-create-tab').addEventListener('click', showAddTabModal);
    return;
  }

  grid.classList.remove('empty-grid');
  grid.innerHTML = '';

  activeTab.tiles.forEach((tile) => {
    const tileEl = document.createElement('a');
    tileEl.className = 'tile';
    tileEl.href = tile.url;
    tileEl.dataset.tileId = tile.id;
    tileEl.setAttribute('draggable', 'true');

    // 画像URL: tile.image があればそれ、なければfavicon
    const primaryUrl = tile.image || getFaviconUrl(tile.url);
    const fallbackUrl = getFaviconUrl(tile.url);
    // キャッシュにあれば Base64 を表示、なければ元URL
    const displaySrc = getDisplayImageSrc(primaryUrl);
    const isFavicon = !tile.image;
    const initialClass = isFavicon ? 'favicon' : '';

    const imageHtml = `<img src="${escapeHtml(displaySrc)}" alt="" class="${initialClass}" data-original-url="${escapeHtml(primaryUrl)}" onerror="this.onerror=null;this.src='${escapeHtml(fallbackUrl)}';this.className='favicon';">`;

    tileEl.innerHTML = `
      ${imageHtml}
    `;

    tileEl.title = tile.title;

    tileEl.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showTileMenu(tile, e.clientX, e.clientY);
    });

    // ドラッグ開始 - タイルIDと元タブIDを記録
    tileEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('application/x-tile-id', tile.id);
      e.dataTransfer.setData('application/x-source-tab-id', state.activeTabId);
      // fallback for Firefox/Safari
      e.dataTransfer.setData('text/plain', `tile:${tile.id}`);
      tileEl.classList.add('dragging');
      draggedTile = { tileId: tile.id, sourceTabId: state.activeTabId };
    });

    tileEl.addEventListener('dragend', () => {
      tileEl.classList.remove('dragging');
      document.querySelectorAll('.tile').forEach(el => {
        el.classList.remove('tile-drop-before', 'tile-drop-after');
      });
      document.querySelectorAll('.tile-add').forEach(el => {
        el.classList.remove('tile-drop-before');
      });
      draggedTile = null;
    });

    // ドロップ先としての動作
    tileEl.addEventListener('dragover', (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      // マウス位置でこのタイルの前/後ろに挿入するか判定
      const rect = tileEl.getBoundingClientRect();
      const midpoint = rect.left + rect.width / 2;
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
      if (e.clientX < midpoint) {
        tileEl.classList.add('tile-drop-before');
      } else {
        tileEl.classList.add('tile-drop-after');
      }
    });

    tileEl.addEventListener('dragleave', (e) => {
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');
    });

    tileEl.addEventListener('drop', async (e) => {
      if (!draggedTile) return;
      e.preventDefault();
      e.stopPropagation();

      const insertAfter = tileEl.classList.contains('tile-drop-after');
      tileEl.classList.remove('tile-drop-before', 'tile-drop-after');

      await handleTileDrop(draggedTile, state.activeTabId, tile.id, insertAfter);
    });

    grid.appendChild(tileEl);
  });

  const addBtn = document.createElement('button');
  addBtn.className = 'tile-add';
  addBtn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
    <span>追加</span>
  `;
  addBtn.addEventListener('click', openAddTile);

  // 追加ボタンへのdrop = 末尾に配置
  addBtn.addEventListener('dragover', (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    addBtn.classList.add('tile-drop-before');
  });
  addBtn.addEventListener('dragleave', () => {
    addBtn.classList.remove('tile-drop-before');
  });
  addBtn.addEventListener('drop', async (e) => {
    if (!draggedTile) return;
    e.preventDefault();
    e.stopPropagation();
    addBtn.classList.remove('tile-drop-before');
    // 末尾に配置 (anchorTileId = null を渡す)
    await handleTileDrop(draggedTile, state.activeTabId, null, true);
  });

  grid.appendChild(addBtn);

  if (activeTab.tiles.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = `
      <h3>まだタイルがありません</h3>
      <p>「+ 追加」から最初のリンクを登録しましょう</p>
    `;
    grid.insertBefore(empty, addBtn);
  }

  // 表示中タイルの画像をバックグラウンドでプリフェッチ
  if (imageCacheLoaded) {
    const urlsToPrefetch = activeTab.tiles.map(t => t.image || getFaviconUrl(t.url));
    prefetchImages(urlsToPrefetch);
  }
}

function attachMainEvents() {
  const syncBtn = document.getElementById('sync-btn');
  if (syncBtn) {
    syncBtn.addEventListener('click', async () => {
      syncBtn.classList.add('syncing');
      await syncActiveSharedTab();
      syncBtn.classList.remove('syncing');
      renderTiles();
      showToast('同期しました');
    });
  }

  const settingsBtn = document.getElementById('settings-btn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showSettingsMenu(settingsBtn);
    });
  }
}

// ============================================
// Settings menu
// ============================================
function showSettingsMenu(btnEl) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.innerHTML = `
    <button data-action="layout">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="7" height="7"/>
        <rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/>
        <rect x="3" y="14" width="7" height="7"/>
      </svg>
      レイアウト設定
    </button>
    <button data-action="sync-settings">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="23 4 23 10 17 10"/>
        <polyline points="1 20 1 14 7 14"/>
        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
      </svg>
      同期設定 (PAT)
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="export">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      全データをエクスポート
    </button>
    <button data-action="import">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
      インポート
    </button>
  `;

  btnEl.parentElement.appendChild(menu);

  menu.querySelector('[data-action="layout"]').addEventListener('click', () => {
    menu.remove();
    showLayoutModal();
  });
  menu.querySelector('[data-action="sync-settings"]').addEventListener('click', () => {
    menu.remove();
    showSyncModal();
  });
  menu.querySelector('[data-action="export"]').addEventListener('click', () => {
    menu.remove();
    exportData();
  });
  menu.querySelector('[data-action="import"]').addEventListener('click', () => {
    menu.remove();
    showImportModal();
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 0);
}

// ============================================
// Tab operations
// ============================================
async function selectTab(tabId) {
  state.activeTabId = tabId;
  await personalStorage.save(state);
  // タブごとのレイアウトを適用
  loadLayoutForActiveTab();
  render();

  const activeTab = state.tabs.find(t => t.id === tabId);
  if (activeTab && activeTab.type === 'shared' && sharedStorage.isConfigured()) {
    await syncActiveSharedTab();
    renderTiles();
  }
}

// ============================================
// タイルのドラッグ&ドロップ処理
// ============================================
async function handleTileDrop(dragged, targetTabId, anchorTileId, insertAfter) {
  const sourceTab = state.tabs.find(t => t.id === dragged.sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const tileIndex = sourceTab.tiles.findIndex(t => t.id === dragged.tileId);
  if (tileIndex < 0) return;

  // ソースから取り出し
  const [tile] = sourceTab.tiles.splice(tileIndex, 1);

  // ターゲット側の挿入位置を決定
  let insertIndex;
  if (anchorTileId === null) {
    insertIndex = targetTab.tiles.length;
  } else {
    const anchorIndex = targetTab.tiles.findIndex(t => t.id === anchorTileId);
    if (anchorIndex < 0) {
      insertIndex = targetTab.tiles.length;
    } else {
      insertIndex = insertAfter ? anchorIndex + 1 : anchorIndex;
    }
  }

  targetTab.tiles.splice(insertIndex, 0, tile);

  // 画面はすぐ更新 (タイルグリッドのみ)
  renderTiles();

  // ストレージへの保存はバックグラウンドで (awaitしない)
  personalStorage.save(state).catch(err => console.error('save failed:', err));

  // 共有タブの場合もバックグラウンドで同期
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error('shared save failed:', err));
  }
  if (targetTab.id !== sourceTab.id && targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error('shared save failed:', err));
  }
}

// ============================================
// タブホバーでの自動切替 (ドラッグ中)
// ============================================
function setupTabDropZones() {
  document.querySelectorAll('.tab').forEach((tabEl) => {
    const tabId = tabEl.dataset.tabId;
    if (!tabId) return;

    tabEl.addEventListener('dragover', (e) => {
      // タイルのドラッグ中だけ反応
      if (!draggedTile) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      tabEl.classList.add('tile-drag-over-tab');

      // 既にアクティブなタブなら切替処理不要
      if (tabId === state.activeTabId) return;

      // タイマーが既に動いていれば何もしない
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) return;

      // 既存タイマーをクリア
      if (tabHoverTimer) clearTimeout(tabHoverTimer.timer);

      // 500ms 後にそのタブに切り替え
      const timer = setTimeout(() => {
        if (draggedTile) {
          selectTab(tabId);
        }
        tabHoverTimer = null;
      }, 500);
      tabHoverTimer = { tabId, timer };
    });

    tabEl.addEventListener('dragleave', () => {
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer && tabHoverTimer.tabId === tabId) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
    });

    tabEl.addEventListener('drop', (e) => {
      // タブ自体への drop は「そのタブに切り替え」のみ (タイルのドロップ先はグリッド)
      if (!draggedTile) return;
      e.preventDefault();
      tabEl.classList.remove('tile-drag-over-tab');
      if (tabHoverTimer) {
        clearTimeout(tabHoverTimer.timer);
        tabHoverTimer = null;
      }
      // まだそのタブに切り替わってない場合は切替
      if (tabId !== state.activeTabId) {
        selectTab(tabId);
      }
    });
  });
}

function showTileMenu(tile, x, y) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="edit">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      編集
    </button>
    <button data-action="move">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="9 18 15 12 9 6"/>
      </svg>
      別タブへ移動
    </button>
    <button data-action="copy">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg>
      別タブへコピー
    </button>
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      削除
    </button>
  `;

  document.body.appendChild(menu);

  // 画面外にはみ出さないように位置調整
  menu.style.position = 'fixed';
  const menuRect = menu.getBoundingClientRect();
  let left = x;
  let top = y;
  if (left + menuRect.width > window.innerWidth) left = window.innerWidth - menuRect.width - 8;
  if (top + menuRect.height > window.innerHeight) top = window.innerHeight - menuRect.height - 8;
  menu.style.top = `${top}px`;
  menu.style.left = `${left}px`;

  menu.querySelector('[data-action="edit"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    openEditTile(tile);
  });

  menu.querySelector('[data-action="move"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'move');
  });

  menu.querySelector('[data-action="copy"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    showTabSelector(tile, 'copy');
  });

  menu.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    confirmDeleteTile(tile);
  });

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
        document.removeEventListener('contextmenu', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
    document.addEventListener('contextmenu', closeMenu);
  }, 10);
}

// タブ選択モーダル (移動/コピー用)
function showTabSelector(tile, action) {
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>${action === 'move' ? '移動先のタブを選択' : 'コピー先のタブを選択'}</h2>
        <button class="icon-btn" data-action="close">✕</button>
      </div>
      <div class="modal-body">
        <div class="tab-selector-list" id="tab-selector-list"></div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  const list = modal.querySelector('#tab-selector-list');
  const sourceTabId = state.activeTabId;

  state.tabs.forEach(tab => {
    // 移動の場合、現在のタブは選択肢から除外
    if (action === 'move' && tab.id === sourceTabId) return;

    const item = document.createElement('button');
    item.className = 'tab-selector-item';
    const sharedBadge = tab.type === 'shared' ? '<span class="tab-badge" style="margin-left:6px;">共有</span>' : '';
    const currentBadge = tab.id === sourceTabId ? '<span class="tab-badge" style="margin-left:6px;background:#fef3c7;color:#92400e;">現在</span>' : '';
    item.innerHTML = `
      <span>${escapeHtml(tab.name)}${sharedBadge}${currentBadge}</span>
      <span class="tab-selector-count">${tab.tiles.length} タイル</span>
    `;
    item.addEventListener('click', async () => {
      modal.remove();
      if (action === 'move') {
        await moveTile(tile, sourceTabId, tab.id);
      } else {
        await copyTile(tile, tab.id);
      }
    });
    list.appendChild(item);
  });

  if (list.children.length === 0) {
    list.innerHTML = '<div style="color:#999;padding:20px;text-align:center;font-size:13px;">他のタブがありません</div>';
  }

  modal.querySelector('[data-action="close"]').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

async function moveTile(tile, sourceTabId, targetTabId) {
  const sourceTab = state.tabs.find(t => t.id === sourceTabId);
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!sourceTab || !targetTab) return;

  const idx = sourceTab.tiles.findIndex(t => t.id === tile.id);
  if (idx < 0) return;

  const [moved] = sourceTab.tiles.splice(idx, 1);
  targetTab.tiles.push(moved);

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (sourceTab.type === 'shared' && sourceTab.code) {
    saveSharedTab(sourceTab).catch(err => console.error(err));
  }
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へ移動しました`);
}

async function copyTile(tile, targetTabId) {
  const targetTab = state.tabs.find(t => t.id === targetTabId);
  if (!targetTab) return;

  const copy = {
    id: generateId('tile'),
    title: tile.title,
    url: tile.url,
    image: tile.image
  };
  targetTab.tiles.push(copy);

  renderTiles();

  personalStorage.save(state).catch(err => console.error(err));
  if (targetTab.type === 'shared' && targetTab.code) {
    saveSharedTab(targetTab).catch(err => console.error(err));
  }
  showToast(`「${targetTab.name}」へコピーしました`);
}

function showTabMenu(tabId, btnEl) {
  document.querySelectorAll('.tab-context-menu').forEach(el => el.remove());

  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const convertAction = tab.type === 'shared' ? `
    <button data-action="convert-to-personal">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
      個人タブに変換
    </button>
  ` : `
    <button data-action="convert-to-shared">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="18" cy="5" r="3"/>
        <circle cx="6" cy="12" r="3"/>
        <circle cx="18" cy="19" r="3"/>
        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
      </svg>
      共有タブに変換
    </button>
  `;

  const menu = document.createElement('div');
  menu.className = 'tab-context-menu';
  menu.innerHTML = `
    <button data-action="rename">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      名前を変更
    </button>
    ${convertAction}
    <div class="dropdown-divider"></div>
    <button data-action="delete" class="danger">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
      タブを削除
    </button>
  `;

  document.body.appendChild(menu);

  const rect = btnEl.getBoundingClientRect();
  menu.style.position = 'fixed';
  menu.style.top = `${rect.bottom + 4}px`;
  menu.style.left = `${rect.left}px`;

  menu.querySelector('[data-action="rename"]').addEventListener('click', (e) => {
    e.stopPropagation();
    menu.remove();
    startRenameTab(tabId);
  });

  const convertSharedBtn = menu.querySelector('[data-action="convert-to-shared"]');
  if (convertSharedBtn) {
    convertSharedBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      showConvertToSharedModal(tabId);
    });
  }

  const convertPersonalBtn = menu.querySelector('[data-action="convert-to-personal"]');
  if (convertPersonalBtn) {
    convertPersonalBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmConvertToPersonal(tabId);
    });
  }

  const deleteBtn = menu.querySelector('[data-action="delete"]');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      confirmDeleteTab(tabId);
    });
  }

  setTimeout(() => {
    const closeMenu = (e) => {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }, 10);
}

function startRenameTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const tabBtn = document.querySelector(`.tab[data-tab-id="${tabId}"]`);
  if (!tabBtn) return;

  const nameSpan = tabBtn.querySelector('.tab-name');
  const originalName = tab.name;

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tab-name-input';
  input.value = originalName;
  nameSpan.replaceWith(input);
  input.focus();
  input.select();

  const finish = async (save) => {
    const newName = input.value.trim();
    if (save && newName && newName !== originalName) {
      tab.name = newName;
      await saveActiveTab();
      if (tab.type === 'shared' && tab.id !== state.activeTabId) {
        try { await saveSharedTab(tab); } catch {}
      }
    }
    render();
  };

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
  input.addEventListener('blur', () => finish(true));
}

// ============================================
// タブの種類変換
// ============================================
function showConvertToSharedModal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  if (!sharedStorage.isConfigured()) {
    showToast('GitHub連携が未セットアップです。README.mdを確認してください。', true);
    return;
  }

  // 既存の「新規タブモーダル」を流用して、コード入力だけさせる
  const modal = document.getElementById('tab-modal');
  document.getElementById('tab-name').value = tab.name;
  document.getElementById('tab-code').value = '';
  document.querySelector('input[name="tab-type"][value="shared"]').checked = true;
  document.getElementById('tab-code-group').classList.remove('hidden');

  // タイトル変更
  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '共有タブに変換';

  // 保存ボタンのラベル変更＆ハンドラ差し替え
  const saveBtn = document.getElementById('tab-save');
  saveBtn.textContent = '変換';

  // 既存のクリックイベントを一旦クローンで削除
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);

  newSaveBtn.addEventListener('click', async () => {
    const newName = document.getElementById('tab-name').value.trim();
    const code = document.getElementById('tab-code').value.trim();

    if (!newName) {
      showToast('タブ名を入力してください', true);
      return;
    }
    if (!code || code.length < 3) {
      showToast('合言葉は3文字以上で入力してください', true);
      return;
    }

    try {
      // 既存コードがあるかチェック
      const remote = await sharedStorage.getByCode(code);
      if (remote && Array.isArray(remote.tiles) && remote.tiles.length > 0) {
        // 既存コードが存在する場合、確認
        const useExisting = confirm(
          `合言葉「${code}」には既に ${remote.tiles.length} 個のタイルを持つ共有タブが存在します。\n\n「OK」を押すと既存の共有タブに参加し、このタブの ${tab.tiles.length} 個のタイルは破棄されます。\n「キャンセル」で処理を中止します。\n\n※既存タブを上書きしたい場合は、一度別タブで共有に接続してから手動で削除してください。`
        );
        if (!useExisting) {
          return;
        }
        // 既存の内容を取り込む
        tab.tiles = remote.tiles;
        if (remote.name) tab.name = remote.name;
      } else {
        // 新規作成: このタブの内容を共有タブとして登録
        tab.name = newName;
      }

      tab.type = 'shared';
      tab.code = code;

      await personalStorage.save(state);
      await saveSharedTab(tab);

      hideAddTabModal();
      // モーダルを元に戻す
      if (titleEl) titleEl.textContent = '新しいタブ';
      restoreDefaultTabSaveHandler();

      render();
      showToast('共有タブに変換しました');
    } catch (err) {
      showToast('変換に失敗: ' + err.message, true);
    }
  });

  modal.classList.remove('hidden');
  setTimeout(() => document.getElementById('tab-code').focus(), 50);
}

function restoreDefaultTabSaveHandler() {
  // モーダルを閉じたら、元の「新しいタブ」用のハンドラに戻す
  const saveBtn = document.getElementById('tab-save');
  saveBtn.textContent = '作成';
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
  newSaveBtn.addEventListener('click', handleAddTab);
}

function confirmConvertToPersonal(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab || tab.type !== 'shared') return;

  showConfirm(
    `「${tab.name}」を個人タブに変換しますか？\n\nタブの内容(現在のタイル)はそのまま残り、このブラウザだけで編集・表示するようになります。\n\n※共有データ自体はGitHub上に残ります。他のメンバーには影響しません。`,
    async () => {
      tab.type = 'personal';
      delete tab.code;
      await personalStorage.save(state);
      render();
      showToast('個人タブに変換しました');
    }
  );
}

function confirmDeleteTab(tabId) {
  const tab = state.tabs.find(t => t.id === tabId);
  if (!tab) return;

  showConfirm(
    `「${tab.name}」タブを削除しますか？${tab.type === 'shared' ? '\n※共有データは残ります(他の人の画面からは消えません)。' : '\n中のタイルも全て削除されます。'}`,
    async () => {
      state.tabs = state.tabs.filter(t => t.id !== tabId);
      if (state.activeTabId === tabId) {
        state.activeTabId = state.tabs.length > 0 ? state.tabs[0].id : null;
      }
      // このタブのレイアウト設定も削除
      if (allLayouts[tabId]) {
        delete allLayouts[tabId];
        await personalStorage.saveLayout(allLayouts);
      }
      await personalStorage.save(state);
      loadLayoutForActiveTab();
      render();
      showToast('タブを削除しました');
    }
  );
}

// ============================================
// Add Tab Modal
// ============================================
function showAddTabModal() {
  const modal = document.getElementById('tab-modal');
  document.getElementById('tab-name').value = '';
  document.getElementById('tab-code').value = '';
  document.querySelector('input[name="tab-type"][value="personal"]').checked = true;
  document.getElementById('tab-code-group').classList.add('hidden');

  // タイトル&ハンドラを初期化
  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();

  modal.classList.remove('hidden');
  setTimeout(() => document.getElementById('tab-name').focus(), 50);
}

function hideAddTabModal() {
  document.getElementById('tab-modal').classList.add('hidden');
  // 閉じた時にデフォルト状態に戻す
  const titleEl = document.querySelector('#tab-modal .modal-header h2');
  if (titleEl) titleEl.textContent = '新しいタブ';
  restoreDefaultTabSaveHandler();
}

async function handleAddTab() {
  const name = document.getElementById('tab-name').value.trim();
  const type = document.querySelector('input[name="tab-type"]:checked').value;

  if (!name) {
    showToast('タブ名を入力してください', true);
    return;
  }

  const newTab = {
    id: generateId('tab'),
    name,
    type,
    tiles: []
  };

  if (type === 'shared') {
    const code = document.getElementById('tab-code').value.trim();
    if (!code || code.length < 3) {
      showToast('合言葉は3文字以上で入力してください', true);
      return;
    }
    if (!sharedStorage.isConfigured()) {
      showToast('GitHub連携が未セットアップです。README.mdを確認してください。', true);
      return;
    }
    newTab.code = code;

    try {
      const remote = await sharedStorage.getByCode(code);
      if (remote) {
        newTab.tiles = remote.tiles || [];
        if (remote.name) newTab.name = remote.name;
        showToast(`既存の共有タブを読み込みました`);
      } else {
        showToast(`新しい共有タブを作成しました`);
      }
    } catch (err) {
      showToast('共有データの取得に失敗: ' + err.message, true);
      return;
    }
  }

  state.tabs.push(newTab);
  state.activeTabId = newTab.id;
  await personalStorage.save(state);

  if (type === 'shared') {
    try { await saveSharedTab(newTab); } catch {}
  }

  hideAddTabModal();
  render();
}

// ============================================
// Tile Modal
// ============================================
function openAddTile() {
  currentEditingTile = null;
  document.getElementById('tile-modal-title').textContent = '新しいタイル';
  document.getElementById('tile-title').value = '';
  document.getElementById('tile-url').value = '';
  document.getElementById('tile-image-url').value = '';
  setImagePreview('');
  document.getElementById('tile-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('tile-title').focus(), 50);
}

function openEditTile(tile) {
  currentEditingTile = tile;
  document.getElementById('tile-modal-title').textContent = 'タイルを編集';
  document.getElementById('tile-title').value = tile.title;
  document.getElementById('tile-url').value = tile.url;
  const image = tile.image || '';
  document.getElementById('tile-image-url').value = image.startsWith('data:') ? '' : image;
  setImagePreview(image);
  document.getElementById('tile-modal').classList.remove('hidden');
}

function hideTileModal() {
  document.getElementById('tile-modal').classList.add('hidden');
  currentEditingTile = null;
}

function setImagePreview(src) {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (src) {
    img.src = src;
    preview.classList.remove('hidden');
  } else {
    img.src = '';
    preview.classList.add('hidden');
  }
}

function getTileImageValue() {
  const preview = document.getElementById('tile-image-preview');
  const img = document.getElementById('tile-image-preview-img');
  if (!preview.classList.contains('hidden') && img.src) {
    if (img.src.startsWith('data:')) return img.src;
  }
  const urlInput = document.getElementById('tile-image-url').value.trim();
  return urlInput;
}

async function handleSaveTile() {
  const title = document.getElementById('tile-title').value.trim();
  const rawUrl = document.getElementById('tile-url').value.trim();

  if (!title || !rawUrl) {
    showToast('タイトルとURLは必須です', true);
    return;
  }

  const url = normalizeUrl(rawUrl);
  const image = getTileImageValue();

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (!activeTab) return;

  if (currentEditingTile) {
    const idx = activeTab.tiles.findIndex(t => t.id === currentEditingTile.id);
    if (idx >= 0) {
      activeTab.tiles[idx] = { ...activeTab.tiles[idx], title, url, image };
    }
  } else {
    activeTab.tiles.push({
      id: generateId('tile'),
      title,
      url,
      image
    });
  }

  try {
    await saveActiveTab();
    hideTileModal();
    renderTiles();
  } catch (err) {
    hideTileModal();
    renderTiles();
  }
}

function confirmDeleteTile(tile) {
  showConfirm(`「${tile.title}」を削除しますか？`, async () => {
    const activeTab = state.tabs.find(t => t.id === state.activeTabId);
    if (!activeTab) return;
    activeTab.tiles = activeTab.tiles.filter(t => t.id !== tile.id);
    await saveActiveTab();
    renderTiles();
    showToast('削除しました');
  });
}

// ============================================
// Import Modal
// ============================================
function showImportModal() {
  pendingImportData = null;
  document.getElementById('import-preview-container').classList.add('hidden');
  document.getElementById('import-execute').disabled = true;
  document.getElementById('import-file').value = '';
  document.querySelector('input[name="import-mode"][value="merge"]').checked = true;
  document.getElementById('import-modal').classList.remove('hidden');
}

function hideImportModal() {
  document.getElementById('import-modal').classList.add('hidden');
  pendingImportData = null;
}

// ============================================
// Confirm dialog
// ============================================
function showConfirm(message, onOk) {
  document.getElementById('confirm-message').textContent = message;
  pendingConfirmAction = onOk;
  document.getElementById('confirm-modal').classList.remove('hidden');
}

function hideConfirm() {
  document.getElementById('confirm-modal').classList.add('hidden');
  pendingConfirmAction = null;
}

// ============================================
// Init
// ============================================
async function init() {
  state = await personalStorage.load();
  allLayouts = await personalStorage.loadLayout();
  // 画像キャッシュをメモリに展開 (並列で開始、awaitして完了待ち)
  await loadImageCacheToMemory();

  // 保存されたPATをロード (OWNER/REPOは固定なので読まない)
  const savedConfig = await personalStorage.loadSyncConfig();
  if (savedConfig && savedConfig.TOKEN) {
    GITHUB_CONFIG.TOKEN = savedConfig.TOKEN;
  }
  lastSyncTimes = await personalStorage.loadLastSyncTimes();

  // 旧Homeタブがあれば、通常のタブとして扱う
  const oldHome = state.tabs.find(t => t.id === 'home');
  if (oldHome) {
    oldHome.id = generateId('tab');  // 新しいIDを付与
    // 既存のレイアウト設定を引き継ぐ
    if (allLayouts.home) {
      allLayouts[oldHome.id] = allLayouts.home;
      delete allLayouts.home;
      await personalStorage.saveLayout(allLayouts);
    }
    if (state.activeTabId === 'home') {
      state.activeTabId = oldHome.id;
    }
    await personalStorage.save(state);
  }

  // activeTabId の整合性チェック
  if (state.tabs.length > 0 && (!state.activeTabId || !state.tabs.find(t => t.id === state.activeTabId))) {
    state.activeTabId = state.tabs[0].id;
  }

  loadLayoutForActiveTab();
  render();

  // 全タブの全タイル画像をバックグラウンドでプリフェッチ (タブ切替時の高速化)
  setTimeout(() => {
    const allUrls = [];
    state.tabs.forEach(tab => {
      tab.tiles.forEach(t => {
        allUrls.push(t.image || getFaviconUrl(t.url));
      });
    });
    prefetchImages(allUrls);
  }, 500);

  const activeTab = state.tabs.find(t => t.id === state.activeTabId);
  if (activeTab && activeTab.type === 'shared' && sharedStorage.isConfigured()) {
    await syncActiveSharedTab();
    renderTiles();
  }
}

// ============================================
// Event listeners
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('tile-modal-close').addEventListener('click', hideTileModal);
  document.getElementById('tile-cancel').addEventListener('click', hideTileModal);
  document.getElementById('tile-save').addEventListener('click', handleSaveTile);

  document.getElementById('tile-image-url').addEventListener('input', (e) => {
    setImagePreview(e.target.value.trim());
  });

  document.getElementById('tile-upload-btn').addEventListener('click', () => {
    document.getElementById('tile-image-file').click();
  });
  document.getElementById('tile-image-file').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      showToast('画像は500KB以下にしてください', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      document.getElementById('tile-image-url').value = '';
      setImagePreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  });

  document.getElementById('tile-image-remove').addEventListener('click', () => {
    document.getElementById('tile-image-url').value = '';
    document.getElementById('tile-image-file').value = '';
    setImagePreview('');
  });

  document.getElementById('tab-modal-close').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-cancel').addEventListener('click', hideAddTabModal);
  document.getElementById('tab-save').addEventListener('click', handleAddTab);

  document.querySelectorAll('input[name="tab-type"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const codeGroup = document.getElementById('tab-code-group');
      if (e.target.value === 'shared') {
        codeGroup.classList.remove('hidden');
      } else {
        codeGroup.classList.add('hidden');
      }
    });
  });

  document.getElementById('import-modal-close').addEventListener('click', hideImportModal);
  document.getElementById('import-cancel').addEventListener('click', hideImportModal);
  document.getElementById('import-execute').addEventListener('click', executeImport);

  const dropZone = document.getElementById('import-drop-zone');
  const fileInput = document.getElementById('import-file');

  dropZone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) handleImportFile(file);
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const file = e.dataTransfer.files?.[0];
    if (file) handleImportFile(file);
  });

  document.getElementById('confirm-cancel').addEventListener('click', hideConfirm);
  document.getElementById('confirm-ok').addEventListener('click', () => {
    if (pendingConfirmAction) pendingConfirmAction();
    hideConfirm();
  });

  // Layout modal
  document.getElementById('layout-modal-close').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-done').addEventListener('click', hideLayoutModal);
  document.getElementById('layout-reset').addEventListener('click', resetLayout);
  document.getElementById('layout-recommended').addEventListener('click', applyRecommendedLayout);
  document.getElementById('layout-apply-all').addEventListener('click', applyLayoutToAllTabs);

  // Sync modal
  document.getElementById('sync-modal-close').addEventListener('click', hideSyncModal);
  document.getElementById('sync-cancel').addEventListener('click', hideSyncModal);
  document.getElementById('sync-save').addEventListener('click', saveSyncSettings);
  document.getElementById('sync-test').addEventListener('click', testSyncConnection);

  document.getElementById('columns-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('width-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('height-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('gap-slider').addEventListener('input', updateLayoutFromSliders);
  document.getElementById('header-spacing-slider').addEventListener('input', updateLayoutFromSliders);

  document.getElementById('tile-title').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('tile-url').focus(); }
  });
  document.getElementById('tile-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleSaveTile(); }
  });
  document.getElementById('tab-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const type = document.querySelector('input[name="tab-type"]:checked').value;
      if (type === 'shared') {
        e.preventDefault();
        document.getElementById('tab-code').focus();
      } else {
        e.preventDefault();
        handleAddTab();
      }
    }
  });
  document.getElementById('tab-code').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddTab(); }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      hideTileModal();
      hideAddTabModal();
      hideImportModal();
      hideLayoutModal();
      hideSyncModal();
      hideConfirm();
    }
  });

  init();
});

// purchase-ui.js  ④購入商品データのボタンと表示（本体は background の purchasejob.js）
(function () {
  const $ = (id) => document.getElementById(id);
  const run = $('p-run'), cancel = $('p-cancel'), st = $('status'), badge = $('done');
  const LOG_KEY = 'purchase_logs';
  let first = true;
  const add = (text) => {
    if (first) { st.textContent = ''; first = false; }
    st.textContent += (st.textContent ? '\n' : '') + text;
    st.scrollTop = st.scrollHeight;
  };
  const busy = (job) => !!(job && (job.state === 'starting' || job.state === 'waiting'));
  let running = false;
  const render = (job, status) => {
    const b = busy(job);
    run.disabled = b || running;
    cancel.disabled = !b;
    const s = (status || {}).state;
    badge.classList.remove('done', 'pending');
    if (b || s === 'pending') { badge.textContent = '⏳ 作成中'; badge.classList.add('pending'); }
    else if (s === 'done') { badge.textContent = '✓ 取得済み'; badge.classList.add('done'); }
    else badge.textContent = '未取得';
  };
  let cur = { job: null, status: null };
  const refresh = async () => {
    const s = await chrome.storage.local.get(['purchase_job', 'purchase_status']);
    cur = { job: s.purchase_job || null, status: s.purchase_status || null };
    render(cur.job, cur.status);
    if (busy(cur.job) && cur.job.message && first) add('⏳ ' + cur.job.message);
  };
  refresh();
  try { chrome.runtime.sendMessage({ type: 'purchase_ping' }).catch(() => {}); } catch (_) {}
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.purchase_job) cur.job = ch.purchase_job.newValue || null;
    if (ch.purchase_status) cur.status = ch.purchase_status.newValue || null;
    if (ch.purchase_job || ch.purchase_status) render(cur.job, cur.status);
  });
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'purchase-log') add(m.text); });

  async function go(msg) {
    running = true; render(cur.job, cur.status);
    try {
      const res = await chrome.runtime.sendMessage(msg);
      if (!res || !res.ok) add('❌ ' + ((res && res.error) || '開始できませんでした'));
      return res;
    } finally { running = false; render(cur.job, cur.status); }
  }
  run.addEventListener('click', async () => {
    const sd = (await chrome.storage.local.get('sharedDates')).sharedDates || {};
    if (!sd.start || !sd.end) { add('❌ 上で開始日・終了日を入力してください'); return; }
    if (sd.start > sd.end) { add('❌ 開始日が終了日より後になっています'); return; }
    go({ type: 'purchase_days', startDate: sd.start, endDate: sd.end });
  });
  cancel.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'purchase_cancel' }));

  $('copylog').addEventListener('click', async () => {
    const logs = (await chrome.storage.local.get(LOG_KEY))[LOG_KEY] || [];
    const text = logs.map((l) => `${l.t} ${l.msg}`).join('\n') || st.textContent;
    try { await navigator.clipboard.writeText(text); add('📋 ログをコピーしました'); } catch (_) { add('コピーできませんでした'); }
  });
  $('clearlog').addEventListener('click', async () => {
    await chrome.storage.local.set({ [LOG_KEY]: [] });
    st.textContent = ''; first = false;
  });
})();

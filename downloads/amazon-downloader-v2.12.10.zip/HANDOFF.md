# amazon-downloader 引き継ぎ資料（2026-10-27 時点 / v2.12.10）

別のチャットでこの開発を続けるための要点メモ。このzipを添付し、「HANDOFF.md を読んで続きをやって」と伝えればOK。

---

## 0-purchase. v2.12.0〜v2.12.2 の変更（2026-10-26）④購入商品データ を追加（仕様書「購入商品データ_取得仕様書.md」第2版）
- 版の経緯（同日に3回お渡し）：v2.12.0＝過去30日まとめ＋期間指定・4種まとめてDL（仕様書 第1版）／
  v2.12.1＝1日1ファイルに変更・3種まとめてDL＋購入商品の別ボタン（第2版）／v2.12.2＝1日1ファイルのまま4種まとめてDLに戻す／
  v2.12.3＝作成待ち中に同じ日を頼まれたら✕でなく「⏳作成中」扱い（4種まとめてDLで購入が✕になっていた）／
  v2.12.4＝作成待ちの再開：拡張を更新・再読み込みすると chrome.alarms が消え、storage の `purchase_job`（waiting）が永久に待ち続けていた。
  → purchasejob.js / officialjob.js で起動時（トップレベル・onStartup・onInstalled）とポップアップ表示時（`purchase_ping`）に alarm を作り直して再開。
  あわせて、完成済みなら30分を過ぎていても保存（タイムアウトは未完成のときだけ）、保存したトークンが古ければ最新の捕捉トークンで再確認、
  4種まとめてDL は購入が作成中のとき「広告・出荷数・KW は完了／購入は作成中（閉じてOK）」と表示し、完成したらチップを ✓ に更新。／
  v2.12.5＝4種まとめてDL の完了通知を、購入商品の作成完了時に出す：購入が「作成中」で終わったら suite.js は通知を出さず、
  `purchase_bulk {bulk:{range, ok(購入以外の成功数), ngs[]}}` を background へ送る。purchasejob.js が job.bulk に預かり、
  保存完了（または失敗）時に「4種まとめてDL：完了」／「完了 n/4」を通知（purBulkNotify）。購入がすでに終わっていれば即通知。／
  v2.12.6＝4種まとめてDL の表示（チップ・メッセージ）を storage `bulk_state` に保存**し、ポップアップを開き直しても戻す。
  `{active, phase:'running'|'waiting-purchase', range, chips:{k:{cls,suffix}}, msg, finishedAt}`。購入の作成待ちは purBulkNotify が完成・失敗・中止時に最終表示へ更新。
  終わってから30分は結果を表示。3種の途中でポップアップが閉じられていた場合（phase running のまま）は、待機→「未実行」、実行中→「要確認」にして注意文を出す。／
  v2.12.7：①1回のレポートの期間上限が**121日**（超えると INVALID_METRIC_COMBINATION。保持期間外と同じエラー名）と判明 → 120日ずつ順番に作成（job.chunks/ci/allDays/savedCount）。
  ②起動時の再開とアラームが重なり二重処理（ログ二重・二重保存）→ メモリ上のロック purPolling。
  ③**中身が空のレポート（データ行0）を「0件の日」として保存しない**：2025-01（31日）で全日0行の列名だけファイルが保存されたが、①では同月の広告売上 ¥2,118,457 あり
  ＝購入商品データ側にその期間のデータが無い。複数日で空ならエラーにして保存せず、レポートは削除。1日だけの0件は従来どおり列名だけ保存。
  ④トークン取得失敗時、前回捕捉したトークンで予約一覧が読めればそれで続行。／
  v2.12.8＝購入商品データの開始日 `PUR_DATA_START = '2025-02-13'`**（実測：確認レポート 2025-01 は空、2025-02-01〜05-31 は 2/13 から、
  以降 2026-10-25 まで毎日あり。2026-01-05 だけ行なし）。これより前は取りに行かない（開始日を自動で繰り上げ／終了日も前ならエラー）。
  ※2026-10-26 時点で約20か月前。固定日か「直近◯か月」かは未確認。もし後者なら日が進むと最初の日がずれていく（空レポートのガードで検知はできる）。
  実測：2025-02 は 2/13 からなので半端。**全日そろっているのは 2025-03 から**（ユーザーには過去分は 2025-03-01 から取るよう案内）。／
  v2.12.9＝レイアウト：popup.html の各項目を `.card`（外枠・角丸・影）で囲み、すき間の背景を一段濃く（#ddd2b4）。区切り帯 `.sep` は廃止。
  項目ごとのテーマカラー：広告 #1f5fa8（青）／出荷数 #2e7d4f（緑）／KW #6b3fa0（紫）／購入 #b03a5b（赤紫）。各 html の `.heading` 背景と
  popup のカード枠（.t-ads/.t-ship/.t-kw/.t-pur）、4種まとめてDL のチップ左端の線に同じ色。日付・保存先／4種まとめてDL のカードは紺のまま。／
  **v2.12.10（現行）**：①「中止」で待機をやめたレポートが Amazon 側に残り、同じ日を取り直すと `NAME_ALREADY_EXISTS`（400）で作れなかった
  → レポート名に作成時刻（JST, `(MMDD-HHMM)`）を付けて毎回別名に。中止時は Amazon 側のレポートも削除。
  ※削除API（207）の直後は一覧にまだ出ることがある（数秒で消える）。
  ②2025-12-30 が0行なのは正しい：①の取得元でも同日は 費用¥102・クリック4・売上0。2026-01-05 も売上0（購入商品データに行が無い日と一致）。
  ③毎日の予約「Amacheck_購入商品データ_毎日」の初回は 2026-10-27 06:15 JST に COMPLETED（予約の動作確認済み）。
- 広告経由で**実際に買われた商品（ASIN）ごと**の広告売上を、**1日1ファイル（速報）**で取る。SP・SB。宣伝商品／Halo を区別。①〜③はそのまま。
- 運用（ユーザー決定 2026-10-26）：日別＝このツールで毎日（ざっくりの推計）。**月別の確定値は翌々月の頭に別ツール「Amazon月別-一括ダウンローダー」**が取る
  （`購入商品データ-月別-YYYY-MM.csv`）。このツールでは月別・期間まとめファイルは作らない。
- 出力：`購入商品データ-YYYY-MMDD.csv`（YYYY-MMDD＝データの日）。列 `広告タイプ,キャンペーン名,キャンペーンID,広告対象ASIN,購入ASIN,関連性,商品購入数,注文点数,売上`（**日付列なし**）。
  SP/SB 変換、`="…"`を外す、Promoted→宣伝商品 / Brand halo→Halo、SBの広告対象ASINは空欄、全部0の行は除外、広告タイプ→キャンペーン名→購入ASIN順、
  UTF-8 BOM・CRLF。**購入0件の日も列名だけのファイルを出す**（取り忘れと区別）。
- 取り元：統合レポート（adsApi/v1）。**日付つき**で取り、拡張側で日ごとに切り分ける（同じ日の値は日付なし1日レポートと同じ）。フィールド（purchase.js FIELDS）:
  `date.value, convertedProduct.id, convertedProductMarketplace.value, productRelevance.value, advertisedProduct.id,
   advertisedProductMarketplace.value, adProduct.value, campaign.name, campaign.id, budgetCurrency.value, metric.purchases, metric.sales, metric.unitsSold`
  - **マーケットプレイス2列＋予算の通貨を入れないと INVALID_METRIC_COMBINATION（400）**。画面が自動で足しているもの。
  - 広告費は同時に取れない（仕様書1-2）。①から取る。
- 取り方（purchasejob.js `purchaseDays`・メッセージ `purchase_days {startDate,endDate}` / `purchase_cancel`）:
  - 上の期間（終了日は昨日までに切る）を1日ずつ保存。
  - **速い道**：予約レポート **`Amacheck_購入商品データ_毎日`**（RECURRING_DAILY・毎朝6時台JST・過去30日間・日付つき・期限1年）の最新 COMPLETED 回を
    ダウンロードして、その範囲（実行日JSTの30日前〜前日）に入る日を保存。数秒。予約が無ければ作成（作成日は動かず翌朝から。2026-10-26 14:15 に作成済み、
    次回 2026-10-27 06:15 JST）。
  - **遅い道**：範囲外の日（初回／今朝の回がまだ／30日より前＝取り忘れ）は datePeriod の NOW レポートをその場で作り、alarms `purchase_poll` で待って保存→削除。
  - ストレージ：`purchase_job`（state waiting/done/error/cancelled, days[]）, `purchase_status`（running/pending/done/idle）, `purchase_logs`。
- 画面：purchase.html / purchase-ui.js（KWの下「🛒 購入商品データ」：「⏬ 1日ずつ購入商品データを取得」「中止」。取り忘れた日の取り直し用）。
- **4種まとめてDL**：広告 → KW → 購入商品 の順（出荷数は並行）。購入商品は background に `purchase_days` を直接送る。
  ふだんは予約から数秒で保存まで終わる。その場で作成が必要な日があれば裏で作成を始め、チップ「⏳作成中」で完了扱い（完了は通知・その分は閉じてOK）。
  ※途中で「3種＋別ボタン」に分けたが、ふだんは即ダウンロードできると分かり、ユーザー判断で4種に戻した。
- 実測（2026-10-26）：
  - 日付つき過去30日の実物：列名 `日付,変換された商品ID,コンバージョン後の商品マーケットプレイス,商品の関連性,広告対象商品ID,
    広告対象商品のマーケットプレイス-Advertised product marketplace,広告プロダクト,キャンペーン名,キャンペーンID,予算の通貨,商品購入数,売上,注文された商品点数`、
    日付は `2026/10/25`、9/26〜10/25 で497行（全部0が50行）。キー重複なし。30日合計 ¥3,110,319 は日付なし版と一致。
  - 日付なし版は1列目が「期間」（その行で購入があった最初〜最後の日）。transform は日付列が無いとエラーにする（位置での推定もしない）。
  - 1日分（datePeriod 2026-10-25〜10-25）の NOW レポートは作成から完了まで約5分半（30日分は約4分）。
  - 期間プリセット `YESTERDAY` は有効（作成可）。ただし本実装は使っていない（過去30日の予約から切り出す方が、取り忘れにも強いため）。
  - 遡れる範囲：レポート作成は開始日 2024-10-12 まで可（それより前は 400 `INVALID_METRIC_COMBINATION`）。ただし**中身が入っているのは 2025-02-13 から**（それより前は列名だけの空レポート）。
  - 削除API：reportConfigurationIds に**複数IDを入れると400**。1件ずつなら207（コードは1件ずつ）。
  - ①とのキャンペーン別売上の差（9/26〜10/25 の30日合計、①の取り元 campaign-manager vs ④）：
    kw ¥1,039,188 / ¥1,036,843（−2,345）、商品 ¥512,853 / ¥519,543（+6,690）、【SB】動画 ¥130,150 / ¥130,150（0）、
    【SB】商品コレ ¥1,428,019 / ¥1,423,783（−4,236）、合計 ¥3,110,210 / ¥3,110,319（+109）。一致しなくてよい（仕様書4-2）。
- 補足：広告グループ画面のURLは `/cm/sp/campaigns/{id}/ad-groups` → `/campaign-manager/sp/campaigns/{id}/ad-groups` へリダイレクトされるようになったが、
  `cm/dds/retrieveReport` は従来どおり飛ぶのでトークン取得（token.js）は変更不要。

## 0-official. v2.11.0 の変更（2026-10-08）公式日別キャンペーンレポートを「別ボタン・期間指定・バックグラウンド」で取得
- 経緯：Amacheck の照合で、従来の取得元 campaign-manager/retrieveReport が日によって費用が欠けると判明（実機再現：2025-07-11
  23-05-耐火バッグ-kw が 392.50＝正 9,348.64、2025-07-14 は SP 費用が全部0。取り直しても同じ）。統合レポート（/reporting）の日別キャンペーンレポートは正しい。
  いったん①を公式レポートに切り替えたが、作成に3〜10分かかり毎日の運用に重いとのユーザー判断で、**最終形は次のとおり**：
  - **①広告データ（毎日）は従来の65列版のまま**（campaign-manager・速い・状態で絞らない・SP/SB・ファイル名 広告データ-YYYY-MMDD.csv）。ads.js は v2.10.0 と同じ動作。
  - **別ボタン「📑 公式の日別キャンペーンレポート（照合で合わない月だけ）」**（広告データ欄の下）：上の期間で公式レポートを1件作成→完成待ち→
    `公式広告レポート-YYYY-MMDD_YYYY-MMDD.csv`（期間まとめて1ファイル・日付列あり。Amacheck v3.09 以降でそのまま取込可）を保存。
    background（officialjob.js）＋ chrome.alarms（30秒ごと）で待つので**ポップアップを閉じても進む**。完了/失敗は通知。「中止」は待機をやめるだけ（Amazon側のレポートは残る）。
  - 出力列：公式10列（日付,キャンペーン名,キャンペーンID,広告プロダクト,予算の通貨,合計費用,売上,クリック数,商品購入数,インプレッション）＋
    ターゲティングタイプ（campaign-manager の campaignTargetingType: AUTOMATIC→オート / MANUAL→マニュアル）＋状態（有効/一時停止/アーカイブ）。
    費用・売上・クリックがすべて0の行は除外。日付→キャンペーン名順。キャンペーンIDのセルは元の `="…"` のまま。
  - 照合：作成待ちの間に campaign-manager の日別値を取り、公式と日別合計を比較。¥100超かつ2%超の日をログに（差の大きいキャンペーン上位3件）。
- **統合レポート API（a9g-api-gateway/adsApi/v1/…）** ※ dds トークンのヘッダで動作確認済み（cm トークンは未検証 → token.js の latest/ensureFresh に {ddsOnly:true}）
  - 作成 `POST create/reportConfigurations` body: `{accessRequestedAccounts:[{advertiserAccountId}], reportConfigurations:[{name, format:'CSV', locale:'ja-JP',
    status:'ACTIVE', emailDeliveryMarketplace:'JP', linkedAccounts:[{advertiserAccountId}], linkedQuery:{reportingQuery:{fields:[…], filter:null}},
    period:{datePeriod:{startDate,endDate}}, scheduleType:'NOW', schedule:{nowSchedule:{timeZone:'ASIA_TOKYO'}}, timeZoneMode:'CAMPAIGN_TIMEZONE'}]}` → 207
    （status / emailDeliveryMarketplace / accessRequestedAccounts が無いと 400。deliverySettings 省略＝メール送信なし）
  - 状態 `POST query/scheduledReports {reportConfigurationIdFilter:{include:[cfgId]}, maxResults:50}` → SCHEDULED→COMPLETED（実測 3〜12分）
  - 削除 `POST delete/reportConfigurations {accessRequestedAccounts, reportConfigurationIds:[cfgId]}` → 207（ツールからは呼んでいない）
  - 列一覧 `POST query/reportingFields {}`（1155項目、maxResults は100以下）。キャンペーン単位の「オート/マニュアル」項目は無い。同期（即時）で数値を返すAPIは見つからなかった。
  - ダウンロード `GET /reporting/subscriptions/{cfgId}/download-report/{scheduledReportId}` → 302 → S3
    `decorated-reports-prod-pdx.s3.us-west-2.amazonaws.com`。S3 に CORS が無くページ文脈では読めない → **拡張(background)から fetch**
    （host_permissions に https://*.amazonaws.com/* を追加。permissions に alarms を追加）。
- 公式CSVの実物：ヘッダ上記10列、日付 `2025/07/12`、キャンペーンID `="451447082971855"`（= campaign-manager の campaignExternalId）、
  広告プロダクト `Sponsored Products` / `Sponsored Brands`。動きの無いキャンペーンは元々出ない。
- 検証：テスト用レポート（2025-07-11〜14）を実際に作成・ダウンロードし、日別合計 29,707.13 / 23,936.84 / 24,632.23 / 35,264.02（Amacheck の正解と一致）。
  officialjob.js を擬似Chrome（実CSV＋実際の campaign-manager 値）で通し、出力ファイル・照合の差額 ¥15,222 / ¥1,950 / ¥3,566 / ¥26,244（Amacheck の報告と一致）・通知・alarm解除を確認。
  テスト用レポートは削除済み。※ background からの実ダウンロード（cookie/host_permissions）はユーザー環境の初回実行で要確認。
- ③KW（kw.js）：保持期間外（今月を含め5か月前の月初より前、例 2026-10 → 2026-05-01 未満）の日は取得しない（⏭ ログ）。
  照合ルールを Amacheck の目安に：①≥¥100 かつ KW<①の5% / KW>①の3倍 かつ 差≥¥1,000 → 保存しない。差 >¥100 かつ >2% は保存して ⚠ 警告。

## 0-amacheck. v2.10.0 の変更（2026-10-08）状態による絞り込みを廃止（Amacheckからの依頼）
- 依頼要旨：state列は「その日」ではなく「ダウンロード時点」の状態。状態で絞ると、過去日に配信・費用発生していて
  今は停止/アーカイブのキャンペーンがファイルに入らず、分析側で取り戻せない。→ 全レポートで状態の絞り込みを外す。
  期間・列構成・ファイル名・保存先は不変。状態列は残す。停止中で動きのない行は 0 で入ってよい。
- 広告データ（ads.js）：FIXED_FILTER から state を削除（programType: SP/HSA/SB2/SBV のみ）。
  実機：state フィルタ無し = 28件（PAUSED 24 + ENABLED 4）。ARCHIVED のみ指定は 0件（現状アーカイブ無し）。
- KWデータ（kw.js）：サーバ側 targetState フィルタと isActive 絞り込みを削除し全行出力。キャンペーン名マップ(fetchCampaignInfo)も状態で絞らない。
  「ステータス」列（列名は不変）は現在の状態を日本語で：配信中 / 一時停止 / アーカイブ / キャンペーン一時停止 / 広告グループ一時停止。
- **KWの保持期間ガード（重要）**：SPAdGroupTargetsReport は KW 日別データを約5か月分（月単位）しか持たない。
  2026-10 時点で 2026-05-01〜 は日別がキャンペーン合計と完全一致。それより前は全行0、**月初日だけその月の合計が入る**
  （例 2026-03-01 KW合計 ¥1,648,973 = 3月の月計）。誤データ保存を防ぐため、各日でキャンペーン合計費用
  （campaign-manager/retrieveReport、ddsトークンで可）と KW 合計費用を照合し、差が max(¥1, 0.5%) を超えたら保存せず ❌ ログ。
- 検証（実アカウント・実コード）：
  - 広告データ 2025-10-04：28行/65列、今は停止中の「24-03-スピーカースタンド-KW」が state=PAUSED・spend 766.04・sales 2709・orders 1 で入ることを確認。
  - KWデータ 2026-05-15：233行/23列・費用合計 ¥42,036（キャンペーン合計と一致）。今は停止中のKW
    「【SB】耐火バッグ-商品コレ-KW / 耐火ケース / 完全一致」が 費用283.78・売上1527 で入ることを確認。
  - KWデータ 2026-03-01 / 2026-04-10 はガードで保存されないことを確認。

## 0-fix2. v2.9.2 の変更（2026-10-07）トークン取得を「広告グループ画面」方式に統一（token.js 新設）
- v2.9.1 でもユーザー環境で「トークン更新失敗」。実機調査で真因を特定：
  **キャンペーン一覧(all-campaigns)はタブが裏(visibility=hidden)だと requestAnimationFrame が止まり、表(=retrieveReport)が読み込まれない**。
  30秒以上待っても retrieveReport 0件・スケルトン表示のまま。ポップアップ操作中は広告タブが裏になるので毎回失敗しうる。
  （朝に成功していたのは広告タブが表に出ていたため）
- 一方、**広告グループ画面(/cm/sp/campaigns/{id}/ad-groups)は裏タブでも cm/dds/retrieveReport を投げる**。
  さらに **dds トークンは campaign-manager/retrieveReport にもそのまま通る**（内蔵65列ボディで HTTP 200・有効4キャンペーン、
  kw.js の19列簡易ボディでも 200・28件を確認）。※逆（cmトークン→dds）は 500（従来メモどおり）。
- 新設 token.js（ads.html / kw.html で読み込み）:
  - `latest()` … amzn_captured / amzn_cap_dds のうち新しい方を返す
  - `ensureFresh(tab)` … 3分以内の捕捉が無ければ、タブを広告グループ画面（`amzn_last_sp_campaign`、無ければ A07766381NLEGRFQQ1NRQ）へ移動して dds を捕捉
  - `restore(tab)` … 終了時にキャンペーン一覧へ戻す（読み込み完了まで待つ）
  - `remember(id)` … KW実行時の代表SPキャンペーンIDを記憶
- ads.js：getTemplate は latest() を使用（URLは常に campaign-manager、ボディは一覧の正規ボディ or 内蔵）。古ければ ensureFresh。
- kw.js：①も latest()/ensureFresh（キャンペーン一覧は使わない）。③は新しい dds があれば画面遷移を省略。
- 確認：token.js は擬似Chromeで単体テスト（取得/再利用/新しい方の選択/記憶ID/restore待ち）。拡張としての通し実行はユーザー環境で要確認。

## 0-fix. v2.9.1 の変更（2026-10-07）広告データの「トークン更新失敗」
- 症状：3種まとめてDLで 広告データ が「トークン更新失敗(ログイン切れの可能性)。実行中止」。ログイン自体は正常。
- 原因：KWデータは共有の広告タブを「広告グループ画面」(/cm/sp/campaigns/…/ad-groups) へ遷移させ、そのまま残していた。
  次の広告データは `tabs[0]` をそのまま F5 → 広告グループ画面は dds(`cm/dds/retrieveReport`) しか投げないため
  `amzn_captured`(campaign-manager) が更新されず、25秒待ってタイムアウト → 「ログイン切れ」と誤表示。
- 対策：
  - ads.js：タブは all-campaigns を優先して選ぶ。一覧以外に居る場合は reload ではなく all-campaigns へ `tabs.update` してトークン取得
    （トークンが新しくても一覧以外なら移動）。
  - kw.js：終了時（成功/失敗とも）に、広告グループ画面へ移動させたタブを all-campaigns へ戻す。

## 0-new. v2.9.0 の変更（2026-10-07）「3種まとめてDL」
- popup.html の上部（保存先の下・広告データの上）に「⏬ 3種まとめてDL」ボタン＋進捗チップ（広告/出荷数/KW）を追加。
- 実装は suite.js の bulkDownload()：各 iframe の `#run` ボタンを**そのまま click** し、
  ボタンが disabled→有効 に戻ったら終了、`*_status` が 'done' かつ開始後の ts なら成功と判定。
  - 広告 → KW は同じ広告タブを使う（KWはタブを遷移させる）ので**順番**、出荷数はバックグラウンドなので**並行**。
  - 実行中はボタンが「■ まとめて停止」になり、押すと各セクションの `#stop` を click、残りの段階はスキップ。
  - 開始前に日付・保存先(AMZ_FS)をチェック。終了時に通知と結果メッセージ（失敗はセクションのログ最終行を表示）。
  - 広告・KWはポップアップ上で動く処理なので、**実行中はポップアップを閉じない**こと（画面にも明記）。
- ads.js：成功以外で終わった時に ads_status が 'running' のまま残っていたのを 'idle' に戻すよう修正（判定とバッジのため）。
- 動作確認は headless Chromium で各セクションの run を擬似ハンドラに差し替えて実施（順序・並行・失敗表示・停止）。実Amazonでの通し実行は未確認。

## 0'''. v2.8.3 の変更（2026-10-07）
- ポップアップの3セクション(iframe)に個別の縦スクロールバーが出ていた（初期でも 出荷数 279>270px, KW 235>210px）。
  → suite.js で各 iframe の高さを中身(body)に自動で合わせる（ResizeObserver でログ欄のドラッグ拡大・上級設定の展開にも追従）。
  iframe は scrolling="no"、初期高さは 270 / 280 / 236px。スクロールはポップアップ全体の1本だけになる。
  ※ 同一オリジン(chrome-extension://)前提。file:// で直接開くと contentDocument が取れず効かない（テストは http で配信して確認）。
- ユーザー実行分（2026-10-05, v2.8.2）でキーワードの日本語表記・耐火バッグ/防火袋の分離を確認済み。

## 0''. v2.8.2 の変更（2026-10-07）
- 拡張から実行するとSPキーワードの `targetLocalized` が**英訳**で返り（耐火バッグ/防火袋→どちらも "fireproof bag" 等）、
  別KWが同名化した。キーワード表示は **`target`（登録文字列そのまま）を使う**よう修正。targetLocalized は使わない。
- ユーザー実行分（2026-10-05）の検証：39行・4キャンペーン、23-05-耐火バッグ-kw の合計費用 20,463.53 は画面と一致。

## 0'. v2.8.1 の変更（2026-10-07）
ユーザー確認：「SPの有効キャンペーン（23-05-耐火バッグ-商品 / 23-05-耐火バッグ-kw）と SBの有効キャンペーン
（【SB】耐火バッグ-商品コレ-KW / 【SB】耐火バッグ-動画-KW）が取れればOK」。
- v2.8.0 はキーワードだけに絞っていたため ASIN指定のみの「23-05-耐火バッグ-商品」が漏れていた → **全ターゲット種別を対象**に変更
  （キーワード / 商品(ASIN・カテゴリ) / オート）。「有効」の判定はそのまま。
- 列を追加：種別（キーワード/商品/オート）, 商品名（API の title。現状は空のことが多い）。「キーワード」列は「キーワード/ターゲット」に改名。
- 商品ターゲットの表示は target（asin="…" / asin-expanded="…"）から ASIN を取り出す。targetLocalized は
  'asin-expanded= B0…”' のように崩れるので使わない。マッチタイプ列は ASIN / ASIN(拡張) / カテゴリ。
- ライブ検証（2026-10-05、拡張と同じ手順＝キャンペーン一覧→広告グループ画面でddsトークン→取得）：
  有効ターゲット 39件 / 4キャンペーン（SP kw 16, SP 商品 9, SB 商品コレ 8, SB 動画 6）。ユーザーの言う4つと一致。
  キャンペーン一覧は画面がSB絞り込み中でも、固定filterで28件すべて取得できることも確認。

## 0. v2.8.0 の変更（2026-10-07）
ユーザー要望：「KWデータは、各広告グループの『ターゲティング』タブに出る**現在有効なキーワード**だけが欲しい」
（例: 23-05-耐火バッグ-kw → ターゲティング → 合計31件のうち配信中のKW）。

- 取得するのは**キーワード（EXACT / PHRASE / BROAD）のみ**。ASIN指定・カテゴリ・オート（TARGETING_EXPRESSION系）は除外。
- **現在有効なものだけ**：以下をすべて満たす行だけを出力
  - `targetState == ENABLED`（サーバ側filterでも絞る）
  - `calculatedStatusName` に PAUSED/ARCHIVED を含まない（SPは `TARGETING_CLAUSE_STATUS_LIVE` / `CAMPAIGN_PAUSED` 等が入る。SBは常に `UNKNOWN`）
  - 広告グループ：`SPAdGroupReport` の `adGroupState == ENABLED` かつ `statusName` にPAUSED/ARCHIVEDなし
  - キャンペーン：キャンペーン一覧(campaign-manager)の `state == ENABLED`（SBはここで判定）
- 画面と同じ列＋α：日付, 広告タイプ, キャンペーン名, 広告グループ名, キーワード, マッチタイプ, ステータス, 入札額,
  インプレッション, クリック, CTR(%), CPC, 合計費用, 商品購入数, 売上, ROAS, ACOS(%), 検索結果上部のインプレッションシェア(%), 各ID
- **広告グループ名は解決済み**：`SPAdGroupReport` は filter 無し（`{and:[]}`）で全広告グループ（SP・SB両方）を返す。
  使える列: adGroupId, adGroupName, adGroupState, adGroupExternalId, campaignId, statusName（campaignName/programType は不可=400）。
- `SPAdGroupTargetsReport` で追加確認済みの列: calculatedStatusName, calculatedStatusReasons, targetBid, clicks, ctr, cpc, acos。
  filter に `targetState IN [ENABLED]`, `matchType IN [EXACT,PHRASE,BROAD]` も使える（列をfieldsに入れること）。
- ctr / acos / topOfSearchImpressionShare は**既に%単位**の値（0.39 = 0.39%）。
- ライブ検証（2026-10-05）：有効KW 30件 = SP 23-05-耐火バッグ-kw 16件 + SB 2キャンペーン 14件。画面の数値と一致。
- 推奨入札額は別API（/sp/targets/bid/recommendations）なので未対応。
- 併せて：ads.js の cleanHeaders も大小無視の重複除去に統一／日付変更時に KW の「取得済み」表示もリセット／kw.html の説明文更新。

---

## 1. このツールは何か
Chrome拡張（Manifest V3）。Amazon広告・セラーのデータを**日別CSV**で、選んだフォルダ（File System Access API）に直接保存する。
ポップアップ上部で日付・保存先を共有し、3セクションを切替：
- **広告データ**（キャンペーン全体 / `advertising-japan.amazon.com`）… `広告データ-YYYY-MMDD.csv`
- **KWデータ(SP・SB)**（キーワード/ターゲット単位）… `KWデータ-YYYY-MMDD.csv`
- **出荷数データ**（注文 / `sellercentral-japan.amazon.com`）… `出荷数データ-YYYY-MMDD.csv`

ファイル名にバージョン名は付けない（ユーザー指示）。KWのファイル名は `KWデータ-YYYY-MMDD.csv`（v2.8.4で先頭に③を付けたが、v2.8.5でユーザー指示により元に戻した）。バージョンは manifest.json のみ。
出力zipは常に `amazon-downloader.zip`（版数サフィックス無し）。

## 2. 【最重要】これまでの全失敗の真因（v2.7.0で解決済み）
KWデータが延々 HTTP 400（Tomcatの "HTTP Status 400 – Bad Request" HTMLページ）になっていた原因は
**ヘッダの大文字小文字重複**だった。
`Content-Type` と `content-type` を両方オブジェクトに入れてfetchすると、重複ヘッダとして送られ
Amazon側のTomcatがコンテナレベルで400を返す。エンドポイント・フィルタ・ボディ形式は正しかった。
→ 対策：ヘッダは**大小無視で1つに統一**してから送る（`cleanHeaders()` と各注入関数のH構築で実装済み）。

## 3. KWデータの正しいAPI仕様（ライブ検証済み・KAIRYアカウント）
- エンドポイント: `POST https://advertising-japan.amazon.com/a9g-api-gateway/cm/dds/retrieveReport`
- ボディは `{ reportConfig: {...} }` でラップ（←以前はこのラップが無く失敗していた）：
  ```json
  {"reportConfig":{
    "reportId":"SPAdGroupTargetsReport",
    "fields":[... "marketplaceId" を必ず含める ...],
    "filter":{"and":[{"field":"marketplaceId","comparisonOperator":"EQUALS","value":"A1VC38T7YXB528","not":false}]},
    "startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD",
    "timeUnits":["SUMMARY","DAILY"],
    "offsetPagination":{"size":100,"offset":0},
    "columnsByTimeUnit":{"SUMMARY":["impressions","spend","orders","sales","roas"],"DAILY":["spend","sales","roas","impressions"]}
  }}
  ```
- 重要ルール: **filterで使う列は必ず fields にも入れる**（無いと「cannot filter on column that isn't being fetched」で400）。
- レスポンス: `j.report.data`（行配列, フラット） / `j.report.numberOfRecords`（総件数）。
  ページングは offset を +size しながら `collected >= numberOfRecords` まで。
- **marketplace単位の1回のsweepで全キャンペーン横断・SPとSB2(スポンサーブランド)両方**のターゲットが取れる
  （検証時: 233件 / 28キャンペーン / programType=["SP","SB2"]）。

### トークンのコンテキスト依存（重要）
- `cm/dds/retrieveReport` は **ddsコンテキストで発行されたCSRFトークン**でないと通らない（campaign-managerのトークンだと500）。
- ddsトークンは「広告グループ画面」= `https://advertising-japan.amazon.com/cm/sp/campaigns/{campaignId}/ad-groups?entityId={ENTITY}`
  をブラウザで開くとページが `SPAdGroupReport`(dds) を投げる → hook.js が捕捉できる。
  このページは **campaignId だけ**あれば開ける（adGroupId不要）。そのトークンでmarketplace sweepが通る（検証済み）。

### 現在の実装フロー（kw.js run）
1. 保存先フォルダ確認
2. campaign-managerトークン確保（無ければ all-campaigns を開いて hook捕捉）
3. 注入①`fetchCampaignInfo`：**捕捉済みのキャンペーンボディ**をそのまま使い（列を削ると UnifiedCampaignReportSyncAPI は500）、日付とページングだけ差し替えて有効キャンペーンを1件取得＋キャンペーン名マップ作成
4. 代表キャンペーンの ad-groups 画面へ遷移 → hook が dds トークンを `amzn_cap_dds` に保存
5. 注入②`kwDownloader`：ddsトークンで marketplace sweep を日別に実行しCSV保存

## 4. キー/ストレージ
- `amzn_captured` … campaign-manager系の最新リクエスト（広告データ用トークン）
- `amzn_cap_dds` … dds系の最新リクエスト（KW用トークン）← bridge.js でURLにより振り分け
- `amzn_working_req` … 広告データ実行時に保存される「通るリクエスト」(url/headers/body)
- `sharedDates` {start,end} / `kw_stop` / `kw_status`

## 5. アカウント定数（フォールバック用。ハードコード箇所あり）
- entityId: `ENTITY15N4IW58E6FGF`
- accountId: `amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m`
- marketplaceId(JP): `A1VC38T7YXB528`
- clientId: `amzn.advertising.789c1d8b...`（ads.js の DEFAULT_TEMPLATE 参照）

## 6. 残タスク / 既知の制限
- ~~広告グループ名の列が未対応~~ → v2.8.0で対応済み（下記は旧メモ）。KW(SPAdGroupTargetsReport)にはadGroupId/adGroupExternalIdはあるが名前が無い。
  `SPAdGroupReport` はmarketplaceId列を持たず marketplace横断不可（`campaignExternalId`でのフィルタのみ）。
  → 名前を付けるなら、キャンペーン毎に `SPAdGroupReport`(filter: campaignExternalId) を1回ずつ呼び
    `adGroupExternalId → adGroupName` マップを作る必要がある（起動時に1回）。campaignExternalIdは
    キャンペーンレポートから取得可能。
- 300超のキャンペーン数ではキャンペーン一覧のページングが必要（現状 size300 の1ページのみ）。

## 7. ファイル構成
- manifest.json / popup.html / suite.js
- ads.js, ads.html … 広告データ（+ DEFAULT_TEMPLATE に正規の列定義）
- kw.js, kw.html … KWデータ（本体。注入関数 fetchCampaignInfo / kwDownloader）
- ship.js … 出荷数データ
- hook.js（MAINワールド, fetch/XHR傍受）, bridge.js（ISOLATED, storageへ振り分け保存）
- background.js（amz_save_data 保存ハンドラ 等）, fsstore.js（AMZ_FS 保存先管理）, folder.js/folder.html
- token.js（AMZ_TOKEN：広告データ/KW共通のトークン確保。v2.9.2〜）
- official.js（OFFICIAL：統合レポートAPIの作成/状態/削除・照合用データ取得・CSVユーティリティ。v2.11.0〜）
- officialjob.js（background：公式レポートの作成→alarmsで待機→保存→照合→通知。v2.11.0〜）
- purchase.js（PURCHASE：④購入商品データのフィールド・予約の検索/作成・実行履歴・日ごとのCSV整形。v2.12.0〜）
- purchasejob.js（background：④を上の期間の1日ずつ保存。予約30日分から切り出し／足りない日はその場作成→alarmsで待機。officialjob.js の findAdsTab/inTab/cleanH/offDays を使う。v2.12.0〜）
- purchase.html / purchase-ui.js（④の画面。v2.12.0〜）

## 8. 検証方法メモ（次セッション用）
Claude in Chrome で実アカウントにログイン中のタブを使い、XHRフックで retrieveReport を採取→
`fetch(...)` で変種を叩いて200/件数を確認する手法が有効。トークン値は画面に出さず（自動redactされる）、
ボディ構造とヘッダ名・ステータス・件数だけ見れば仕様は確定できる。

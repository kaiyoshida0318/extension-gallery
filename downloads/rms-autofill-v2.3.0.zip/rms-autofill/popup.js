// ========== ユーティリティ ==========
function formatDate(ts) {
  const d = new Date(ts);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ========== ID表示 ==========
async function renderId() {
  const el = document.getElementById('idValue');
  const data = await chrome.storage.local.get(['loginId']);
  if (data.loginId) {
    el.textContent = data.loginId;
    el.classList.remove('empty');
  } else {
    el.textContent = '(未登録)';
    el.classList.add('empty');
  }
}

// ========== ログ描画 ==========
async function renderLog() {
  const data = await chrome.storage.local.get(['passLog']);
  const log = data.passLog || [];
  const list = document.getElementById('logList');
  const count = document.getElementById('logCount');

  count.textContent = log.length > 0 ? `${log.length}件` : '';

  if (log.length === 0) {
    list.innerHTML = '<div class="empty">変更ログはまだありません</div>';
    return;
  }

  list.innerHTML = '';
  log.forEach((entry) => {
    const item = document.createElement('div');
    item.className = 'log-item';

    const date = document.createElement('div');
    date.className = 'log-date';
    date.textContent = formatDate(entry.ts);

    const row = document.createElement('div');
    row.className = 'log-row';

    const pass = document.createElement('div');
    pass.className = 'log-pass';
    pass.textContent = entry.pass;

    const copyBtn = document.createElement('button');
    copyBtn.textContent = 'コピー';
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(entry.pass);
        copyBtn.textContent = '✓';
        setTimeout(() => (copyBtn.textContent = 'コピー'), 1200);
      } catch (e) {
        copyBtn.textContent = '失敗';
      }
    });

    row.appendChild(pass);
    row.appendChild(copyBtn);
    item.appendChild(date);
    item.appendChild(row);
    list.appendChild(item);
  });
}

// ========== イベント ==========
document.getElementById('openRmsBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://glogin.rms.rakuten.co.jp/?sp_id=1' });
  window.close();
});

document.getElementById('openOptionsBtn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

// トグル
document.getElementById('toggleHeader').addEventListener('click', () => {
  const section = document.getElementById('toggleSection');
  section.classList.toggle('expanded');
});

// 初期化
renderId();
renderLog();

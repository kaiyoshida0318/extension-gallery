// ====== Service Worker (background) ======
// popupを閉じても動き続けるよう、DLの実体はすべてここで走らせる。
// 状態は chrome.storage.local に直列化して書き込む。

var LOG_KEY = 'yh_dl_logs';
var HISTORY_KEY = 'yh_dl_history';
var JOB_KEY = 'yh_active_job';
var CANCEL_KEY = 'yh_cancel_flag';
var DONE_KEY = 'yh_done_flags';         // 区分A(期間指定DL)用: 日付変更でリセット
var DONE_SNAP_KEY = 'yh_done_flags_snap'; // 区分B(スナップショット)用: 日付と無関係
var CAMIDS_KEY = 'yh_cam_ids';

var KIND_LABEL = {
  ad: '① 広告詳細レポート',
  item: '② 商品分析',
  overall: '③ 全体分析',
  itemmgr: '④ 商品データ(最新)',
  bidcsv: '⑤ 入札商品データ(最新)'
};

// 区分B(最新状態スナップショット)
var SNAP_KINDS = ['itemmgr', 'bidcsv'];
function isSnapKind(k) { return SNAP_KINDS.indexOf(k) >= 0; }

// ---------- storage ヘルパ(直列化してレース回避) ----------
var _chain = Promise.resolve();
function serialize(fn) {
  _chain = _chain.then(fn).catch(function () {});
  return _chain;
}

function log(cat, text) {
  return serialize(async function () {
    var s = await chrome.storage.local.get([LOG_KEY]);
    var logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), cat: cat, msg: String(text) });
    if (logs.length > 2000) logs.splice(0, logs.length - 2000);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  });
}

function recordHistory(entry) {
  return serialize(async function () {
    var s = await chrome.storage.local.get([HISTORY_KEY]);
    var list = s[HISTORY_KEY] || [];
    list.unshift(Object.assign({ t: new Date().toISOString() }, entry));
    if (list.length > 200) list.length = 200;
    await chrome.storage.local.set({ [HISTORY_KEY]: list });
  });
}

function setDoneFlag(kind) {
  var key = isSnapKind(kind) ? DONE_SNAP_KEY : DONE_KEY;
  return serialize(async function () {
    var s = await chrome.storage.local.get([key]);
    var flags = s[key] || {};
    flags[kind] = true;
    await chrome.storage.local.set({ [key]: flags });
  });
}

async function isCancelled() {
  var s = await chrome.storage.local.get([CANCEL_KEY]);
  return !!s[CANCEL_KEY];
}

function setJob(job) { return chrome.storage.local.set({ [JOB_KEY]: job }); }
function clearJob() { return chrome.storage.local.remove([JOB_KEY]); }

// ---------- URL ----------
function urlFor(kind, seller) {
  if (kind === 'ad') return 'https://cam.yahoo.co.jp/' + seller + '/report/adDetail';
  if (kind === 'item') return 'https://pro.store.yahoo.co.jp/pro.' + seller + '/sales_manage/item_report';
  if (kind === 'itemmgr') return 'https://editor.store.yahoo.co.jp/RT/' + seller + '/ItemMgr/';
  return 'https://pro.store.yahoo.co.jp/pro.' + seller + '/sales_manage/overall';
}
function matchFor(kind, seller) {
  if (kind === 'ad') return '/' + seller + '/report/adDetail';
  if (kind === 'item') return '/sales_manage/item_report';
  if (kind === 'itemmgr') return '/RT/' + seller + '/ItemMgr/';
  if (kind === 'bidcsv') return '/' + seller + '/itemad/csv';
  return '/sales_manage/overall';
}

// ⑤ に必要な campaignId / adGroupId を ①のページから拾う(取れたらキャッシュ)
async function getCamIds(seller) {
  try {
    var tab = await getOrCreateTab(matchFor('ad', seller), urlFor('ad', seller));
    if (tab) {
      var ids = await callFn(tab.id, 'yhReadCamIds', {});
      if (ids && ids.ok) {
        await chrome.storage.local.set({ [CAMIDS_KEY]: ids });
        return ids;
      }
    }
  } catch (e) {}
  var s = await chrome.storage.local.get([CAMIDS_KEY]);
  return s[CAMIDS_KEY] || null;
}

// タブが目的のURLでなければ移動して読み込みを待つ
async function ensureTabUrl(tab, url, mustContain) {
  try {
    var t = await chrome.tabs.get(tab.id);
    if (t.url && t.url.indexOf(mustContain) >= 0) return t;
  } catch (e) { return tab; }
  await chrome.tabs.update(tab.id, { url: url });
  var start = Date.now();
  while (Date.now() - start < 30000) {
    await sleep(600);
    try {
      var t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete' && t2.url && t2.url.indexOf(mustContain) >= 0) {
        await sleep(1200);
        return t2;
      }
    } catch (e) {}
  }
  return tab;
}

// ---------- タブ ----------
async function getOrCreateTab(urlMatch, ensureUrl) {
  var tabs = await chrome.tabs.query({});
  var tab = tabs.filter(function (t) { return t.url && t.url.indexOf(urlMatch) >= 0; })[0];
  if (tab) return tab;
  await log('bg', 'タブが無いので新規オープン: ' + ensureUrl);
  tab = await chrome.tabs.create({ url: ensureUrl, active: false });
  var start = Date.now();
  while (Date.now() - start < 25000) {
    await sleep(200);
    try {
      var t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete') { await sleep(500); return t2; }
    } catch (e) {
      var re = (await chrome.tabs.query({})).filter(function (t) { return t.url && t.url.indexOf(urlMatch) >= 0; })[0];
      if (re) return re;
    }
  }
  return tab;
}

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

// ---------- MAIN world 実行 ----------
async function injectFile(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    files: ['injected.js']
  });
}

async function callFn(tabId, name, params) {
  await injectFile(tabId);
  var res = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: async function (n, p) {
      var f = window[n];
      if (typeof f !== 'function') return { ok: false, status: 'error', error: '関数が未注入: ' + n };
      try { return await f(p); }
      catch (e) { return { ok: false, status: 'error', error: e && e.message ? e.message : String(e) }; }
    },
    args: [name, params]
  });
  return res && res[0] ? res[0].result : null;
}

async function overlay(tabId, text) {
  try {
    await injectFile(tabId);
    await chrome.scripting.executeScript({
      target: { tabId: tabId }, world: 'MAIN',
      func: function (t) { if (typeof yhInstallOverlay === 'function') yhInstallOverlay(t); },
      args: [text]
    });
  } catch (e) {}
}
async function overlayOff(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId }, world: 'MAIN',
      func: function () { if (typeof yhRemoveOverlay === 'function') yhRemoveOverlay(); }
    });
  } catch (e) {}
}

// ---------- 1件のDL ----------
async function downloadOne(kind, day, settings) {
  var seller = settings.seller;

  // ---- 区分B: 最新状態スナップショット(日付は使わない) ----
  if (kind === 'itemmgr') {
    var t1 = await getOrCreateTab(matchFor(kind, seller), urlFor(kind, seller));
    if (!t1) return { ok: false, status: 'error', error: 'タブ取得失敗' };
    await overlay(t1.id, '📥 ' + KIND_LABEL[kind] + ' 取得中…');
    try { return await callFn(t1.id, 'yahooItemMgrSnapshot', { seller: seller }); }
    finally { await overlayOff(t1.id); }
  }
  if (kind === 'bidcsv') {
    var ids = await getCamIds(seller);
    if (!ids || !ids.campaignId) {
      return { ok: false, status: 'error', error: 'campaignId/adGroupId が取得できません(①広告詳細レポートのページを一度開いてください)' };
    }
    var camUrl = 'https://cam.yahoo.co.jp/' + seller + '/itemad/csv?campaignId=' +
      encodeURIComponent(ids.campaignId) + '&adGroupId=' + encodeURIComponent(ids.adGroupId);
    var t2 = await getOrCreateTab(matchFor(kind, seller), camUrl);
    if (!t2) return { ok: false, status: 'error', error: 'タブ取得失敗' };
    t2 = await ensureTabUrl(t2, camUrl, 'campaignId=' + ids.campaignId);
    await overlay(t2.id, '📥 ' + KIND_LABEL[kind] + ' 取得中…');
    try { return await callFn(t2.id, 'yahooBidCsvSnapshot', { seller: seller }); }
    finally { await overlayOff(t2.id); }
  }

  // ---- 区分A: 期間指定DL ----
  var tab = await getOrCreateTab(matchFor(kind, seller), urlFor(kind, seller));
  if (!tab) return { ok: false, status: 'error', error: 'タブ取得失敗' };

  await overlay(tab.id, '📥 ' + KIND_LABEL[kind] + ' ' + day + ' 取得中…');

  try {
    if (kind === 'ad') {
      return await callFn(tab.id, 'yahooAdDetailDownloader', {
        day: day, reportType: settings.reportType || 'product', seller: seller, timeout: 60
      });
    }

    // ②③: 日付セット → 遷移 → CSV取得
    var a = await callFn(tab.id, 'yahooProSetDate', { kind: kind, day: day });
    if (!a || !a.ok) return { ok: false, status: 'error', error: (a && a.error) || '日付セット失敗' };

    var ready = null;
    var t0 = Date.now();
    await sleep(1200);
    while (Date.now() - t0 < 45000) {
      try {
        var t = await chrome.tabs.get(tab.id);
        if (t.status === 'complete') {
          ready = await callFn(tab.id, 'yahooProCheckReady', { kind: kind, day: day });
          if (ready && ready.navigated && ready.match && ready.btn) break;
        }
      } catch (e) { /* 遷移中はエラーになるので無視 */ }
      await sleep(700);
    }
    if (!ready || !ready.navigated || !ready.match) {
      return { ok: false, status: 'error', error: 'ページ遷移待ちタイムアウト' + (ready ? ' (' + ready.from + '〜' + ready.to + ')' : '') };
    }
    await sleep(600); // 表の描画待ち
    return await callFn(tab.id, 'yahooProGrabCsv', { kind: kind, day: day, seller: seller, timeout: 60 });
  } finally {
    await overlayOff(tab.id);
  }
}

// ---------- リトライ付き ----------
async function downloadWithRetry(kind, day, settings) {
  var last = null;
  for (var i = 0; i < 3; i++) {
    if (await isCancelled()) return { ok: false, status: 'cancelled', error: '中止されました' };
    try {
      last = await downloadOne(kind, day, settings);
    } catch (e) {
      last = { ok: false, status: 'error', error: e && e.message ? e.message : String(e) };
    }
    if (last && (last.status === 'ok' || last.status === 'nodata' || last.status === 'notready')) return last;
    if (i < 2) {
      await log('bg', '  ⚠ ' + KIND_LABEL[kind] + ' ' + day + ' 失敗 → ' + (i + 2) + '回目を試行: ' + (last && last.error));
      await sleep(6000);
    }
  }
  return last || { ok: false, status: 'error', error: '不明なエラー' };
}

// ---------- ジョブ実行 ----------
async function runTasks(title, tasks, settings) {
  await chrome.storage.local.remove([CANCEL_KEY]);
  await log('bg', '▶ ' + title + ' 開始 (' + tasks.length + '件)');

  var job = {
    title: title,
    startedAt: Date.now(),
    tasks: tasks.map(function (t) { return { kind: t.kind, day: t.day, state: 'pending' }; })
  };
  await setJob(job);

  var ok = 0, ng = 0, nd = 0, nr = 0;
  var doneKinds = {};

  for (var i = 0; i < job.tasks.length; i++) {
    if (await isCancelled()) {
      await log('bg', '⏹ 中止フラグ検出 → 残り ' + (job.tasks.length - i) + ' 件をスキップ');
      break;
    }
    var t = job.tasks[i];
    t.state = 'processing';
    await setJob(job);

    var r = await downloadWithRetry(t.kind, t.day, settings);
    var status = (r && r.status) || 'error';

    if (status === 'ok') { ok++; t.state = 'ok'; doneKinds[t.kind] = true; }
    else if (status === 'nodata') { nd++; t.state = 'nodata'; doneKinds[t.kind] = true; }
    else if (status === 'notready') { nr++; t.state = 'notready'; }
    else if (status === 'cancelled') { t.state = 'pending'; }
    else { ng++; t.state = 'ng'; }

    await setJob(job);
    await recordHistory({
      kind: t.kind,
      type: KIND_LABEL[t.kind],
      day: t.day,
      result: t.state,
      file: r && r.file,
      bytes: r && r.bytes,
      msg: (r && r.error) || ''
    });
    await log('dl',
      (t.state === 'ok' ? '✅' : t.state === 'nodata' ? '⚪' : t.state === 'notready' ? '⏰' : '❌') + ' ' +
      KIND_LABEL[t.kind] + ' ' + (t.day === 'snapshot' ? 'スナップショット' : t.day) +
      (r && r.file ? ' → ' + r.file + ' (' + r.bytes + 'B)' : '') +
      (r && r.error ? ' : ' + r.error : ''));

    await sleep(1200); // サーバ負荷を避けるための間隔
  }

  Object.keys(doneKinds).forEach(function (k) { setDoneFlag(k); });
  await log('bg', '🎉 ' + title + ' 完了: ✅' + ok + ' ⚪' + nd + ' ⏰' + nr + ' ❌' + ng);
  await chrome.storage.local.remove([CANCEL_KEY]);
  await clearJob();
  return { ok: true, success: ok, nodata: nd, fail: ng };
}

// ---------- タスク生成 ----------
function daysBetween(startIso, endIso) {
  var out = [];
  var d = new Date(startIso + 'T00:00:00');
  var end = new Date(endIso + 'T00:00:00');
  while (d <= end) {
    out.push(d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0'));
    d.setDate(d.getDate() + 1);
  }
  return out;
}

// 種別ごとにまとめる(タブ移動を減らす)
function buildTasks(kinds, days) {
  var tasks = [];
  kinds.forEach(function (k) {
    days.forEach(function (d) { tasks.push({ kind: k, day: d }); });
  });
  return tasks;
}

// ---------- メッセージ ----------
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === 'run') {
    var kinds = msg.kinds || ['ad', 'item', 'overall'];
    var days = msg.days || daysBetween(msg.startDate, msg.endDate);
    var title = msg.title || 'DL';
    runTasks(title, buildTasks(kinds, days), msg.settings || {})
      .then(function (r) { try { sendResponse(r); } catch (e) {} })
      .catch(function (e) { try { sendResponse({ ok: false, error: e.message }); } catch (_) {} });
    return true;
  }
  if (msg && msg.type === 'run-tasks') {
    runTasks(msg.title || '♻ 失敗分の再取得', msg.tasks || [], msg.settings || {})
      .then(function (r) { try { sendResponse(r); } catch (e) {} })
      .catch(function (e) { try { sendResponse({ ok: false, error: e.message }); } catch (_) {} });
    return true;
  }
  if (msg && msg.type === 'open-tabs') {
    // 読み込み完了を待たず、足りないタブを一斉に開く(待つのは実際のDL時でよい)
    (async function () {
      var seller = (msg.settings && msg.settings.seller) || 'yukaiya';
      var kinds = msg.kinds || ['ad', 'item', 'overall'];
      var tabs = await chrome.tabs.query({});
      var created = 0;
      var jobs = kinds.map(function (k) {
        var m = matchFor(k, seller);
        var exists = tabs.some(function (t) { return t.url && t.url.indexOf(m) >= 0; });
        if (exists) return null;
        created++;
        return chrome.tabs.create({ url: urlFor(k, seller), active: false });
      }).filter(Boolean);
      await Promise.all(jobs);
      await log('bg', '🔗 一括オープン: ' + created + '件を新規オープン(' + (kinds.length - created) + '件は既に開いていました)');
      return { ok: true, created: created };
    })().then(function (r) { try { sendResponse(r); } catch (e) {} });
    return true;
  }
  return false;
});

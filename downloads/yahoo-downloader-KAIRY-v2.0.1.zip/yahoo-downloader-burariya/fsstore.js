// ============================================================================
// fsstore.js — File System Access API で「選んだフォルダ」に直接書く
//   ・ハンドルは IndexedDB に入れて次回以降も使う
//   ・書き込みは3回までやり直し、書いた後にサイズを確認する
//   ・途中で失敗したら、新しく作った空ファイルは消す(0バイトを残さない)
// このファイルは folder.html(通常のページ)で動く。Service Worker では動かない。
// ============================================================================

var YHFS = (function () {
  var DB_NAME = 'yh_fs';
  var STORE = 'handles';
  var KEY = 'root';

  function openDb() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function () {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
    });
  }

  function idb(mode, fn) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, mode);
        var req = fn(tx.objectStore(STORE));
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function saveRoot(handle) { return idb('readwrite', function (s) { return s.put(handle, KEY); }); }
  function loadRoot() { return idb('readonly', function (s) { return s.get(KEY); }); }
  function clearRoot() { return idb('readwrite', function (s) { return s.delete(KEY); }); }

  // --- 許可の状態 ---
  // 'none'(未設定) / 'granted' / 'prompt' / 'denied'
  async function status() {
    var root = null;
    try { root = await loadRoot(); } catch (e) {}
    if (!root) return { state: 'none', name: '' };
    var perm = 'prompt';
    try { perm = await root.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    return { state: perm, name: root.name || '' };
  }

  // ユーザー操作の中からだけ呼べる
  async function pick() {
    var h = await window.showDirectoryPicker({ mode: 'readwrite', startIn: 'documents' });
    await h.requestPermission({ mode: 'readwrite' });
    await saveRoot(h);
    return h;
  }

  async function requestGrant() {
    var root = await loadRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');
    var p = await root.requestPermission({ mode: 'readwrite' });
    return p;
  }

  function byteLength(data) {
    if (data == null) return null;
    if (typeof data === 'string') return new TextEncoder().encode(data).length;
    if (data instanceof Blob) return data.size;
    if (data.byteLength != null) return data.byteLength;
    return null;
  }

  // subdir は '' か 'a' か 'a/b'。無ければ作る。
  async function writeFile(subdir, filename, data) {
    var root = await loadRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');

    var perm = 'prompt';
    try { perm = await root.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    if (perm !== 'granted') throw new Error('保存先フォルダへの書き込み許可が切れています');

    var parts = String(subdir || '').split('/').map(function (s) { return s.trim(); })
                  .filter(Boolean);
    var dir = root, made = [];
    for (var i = 0; i < parts.length; i++) {
      dir = await dir.getDirectoryHandle(parts[i], { create: true });
      made.push(parts[i]);
    }

    var expected = byteLength(data);
    // 既にあるファイルか(途中で失敗したとき消してよいかの判断に使う)
    var existed = false;
    try { await dir.getFileHandle(filename, { create: false }); existed = true; } catch (e) {}

    var fh = await dir.getFileHandle(filename, { create: true });
    var lastErr = null;

    for (var attempt = 1; attempt <= 3; attempt++) {
      var w = null;
      try {
        w = await fh.createWritable();
        await w.write(data);
        await w.close();
        w = null;
        var size = (await fh.getFile()).size;
        if (expected != null && size !== expected) {
          throw new Error('サイズ不一致(書いた=' + size + ' / 期待=' + expected + ')');
        }
        return (root.name || '') + '/' + (made.length ? made.join('/') + '/' : '') + filename;
      } catch (e) {
        if (w) { try { await w.abort(); } catch (_) {} }
        lastErr = e;
        if (attempt < 3) await new Promise(function (r) { setTimeout(r, 500 * attempt); });
      }
    }

    // 最後まで失敗。今回新しく作ったファイルなら、0バイトを残さないように消す
    if (!existed) { try { await dir.removeEntry(filename); } catch (_) {} }
    throw new Error('書き込みに失敗(3回試行): ' +
      ((lastErr && lastErr.name ? lastErr.name + ' ' : '') + (lastErr && lastErr.message || '')));
  }

  return {
    status: status, pick: pick, requestGrant: requestGrant,
    writeFile: writeFile, clearRoot: clearRoot, byteLength: byteLength
  };
})();

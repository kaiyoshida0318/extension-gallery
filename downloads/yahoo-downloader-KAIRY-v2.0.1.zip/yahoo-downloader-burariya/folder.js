// ============================================================================
// folder.js — 保存先タブ。
//   ・ユーザーがフォルダを選ぶ／許可し直す
//   ・background からの「このバイト列をここに書いて」を受けて書く
// 書き込みを Service Worker ではなくこのページで行うのは、
// File System Access の許可が「ページが開いている間」に紐づくため。
// (だからこのタブは取得中に閉じられない。仕様書もそう書いてある)
// ============================================================================

var $ = function (id) { return document.getElementById(id); };
var logLines = [];

function putLog(s) {
  var t = new Date();
  var hh = String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0')
         + ':' + String(t.getSeconds()).padStart(2, '0');
  logLines.unshift('[' + hh + '] ' + s);
  if (logLines.length > 200) logLines.length = 200;
  $('log').textContent = logLines.join('\n');
}

var STATE_TEXT = {
  none:    ['保存先フォルダが未設定です', 'ng'],
  prompt:  ['書き込み許可が切れています', 'ng'],
  denied:  ['書き込みが拒否されています', 'ng'],
  granted: ['保存できます', 'ok']
};

async function render() {
  var st = await YHFS.status();
  var v = STATE_TEXT[st.state] || ['不明な状態: ' + st.state, 'ng'];
  $('state').textContent = v[0];
  $('state').className = 'state ' + v[1];
  $('path').textContent = st.name ? st.name + ' /' : '(未設定)';
  $('grant').hidden = (st.state === 'granted' || st.state === 'none');
  // popup 側で状態を出せるように控えておく
  try { chrome.storage.local.set({ yh_fs_state: { state: st.state, name: st.name, t: Date.now() } }); } catch (e) {}
  return st;
}

$('pick').addEventListener('click', async function () {
  try {
    var h = await YHFS.pick();
    putLog('保存先を設定: ' + h.name);
    await render();
  } catch (e) {
    if (e && e.name === 'AbortError') return;   // 選択をキャンセルしただけ
    putLog('✗ 保存先の設定に失敗: ' + (e && e.message));
  }
});

$('grant').addEventListener('click', async function () {
  try {
    var p = await YHFS.requestGrant();
    putLog(p === 'granted' ? '書き込みを許可しました' : '許可されませんでした (' + p + ')');
    await render();
  } catch (e) { putLog('✗ 許可の取得に失敗: ' + (e && e.message)); }
});

$('test').addEventListener('click', async function () {
  try {
    var name = '_書き込みテスト.txt';
    var body = 'Yahoo一括ダウンローダー 書き込みテスト ' + new Date().toString() + '\n';
    var where = await YHFS.writeFile('', name, new TextEncoder().encode(body));
    putLog('✓ テスト成功: ' + where + '(このファイルは消して構いません)');
  } catch (e) { putLog('✗ テスト失敗: ' + (e && e.message)); }
});


// data: URL -> バイト列。fetch が使えない環境のために手動復号も用意しておく。
async function toBytes(dataUrl) {
  try {
    var buf = await (await fetch(dataUrl)).arrayBuffer();
    return new Uint8Array(buf);
  } catch (e) {
    var i = String(dataUrl).indexOf(',');
    if (i < 0) throw new Error('データが壊れています');
    var head = dataUrl.slice(0, i), body = dataUrl.slice(i + 1);
    if (head.indexOf(';base64') >= 0) {
      var bin = atob(body);
      var out = new Uint8Array(bin.length);
      for (var k = 0; k < bin.length; k++) out[k] = bin.charCodeAt(k);
      return out;
    }
    return new TextEncoder().encode(decodeURIComponent(body));
  }
}

// --- background からの依頼を受ける ---
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.target !== 'folder') return false;

  if (msg.type === 'fs-status') {
    YHFS.status().then(function (st) { sendResponse(st); });
    return true;
  }

  if (msg.type === 'fs-write') {
    (async function () {
      try {
        // data: URL をそのまま受け取り、ここでバイト列に戻す。
        // 文字コードの変換も BOM の追加もしない(Yahoo から届いたまま書く)。
        var bytes = await toBytes(msg.dataUrl);
        var where = await YHFS.writeFile(msg.subdir || '', msg.filename, bytes);
        putLog('✓ ' + where + '  (' + bytes.length + ' B)');
        sendResponse({ ok: true, path: where, size: bytes.length });
      } catch (e) {
        putLog('✗ ' + (msg.subdir ? msg.subdir + '/' : '') + msg.filename + ' : ' + (e && e.message));
        sendResponse({ ok: false, error: (e && e.message) || String(e) });
      }
    })();
    return true;
  }

  return false;
});

render();
setInterval(render, 5000);

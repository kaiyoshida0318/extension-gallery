// ====== Service Worker (background) ======
// popupを閉じても動き続けるよう、DLの実体はすべてここで走らせる。
// 状態は chrome.storage.local に直列化して書き込む。

var LOG_KEY = 'yh_dl_logs';
var HISTORY_KEY = 'yh_dl_history';
var JOB_KEY = 'yh_active_job';
var CANCEL_KEY = 'yh_cancel_flag';
var DONE_KEY = 'yh_done_flags';         // 区分A(期間指定DL)用: 日付変更でリセット
var DONE_SNAP_KEY = 'yh_done_flags_snap'; // 区分B(スナップショット)用: 日付と無関係
var CAMIDS_KEY = 'yh_cam_ids';

var KIND_LABEL = {
  ad: '① 広告詳細レポート',
  item: '② 商品分析',
  overall: '③ 全体分析',
  pr: '④ PRオプション',
  itemmgr: '⑤ 商品データ(最新)',
  bidcsv: '⑥ 入札商品データ(最新)'
};

// 区分B(最新状態スナップショット)
var SNAP_KINDS = ['itemmgr', 'bidcsv'];
function isSnapKind(k) { return SNAP_KINDS.indexOf(k) >= 0; }

// ---------- storage ヘルパ(直列化してレース回避) ----------
var _chain = Promise.resolve();
function serialize(fn) {
  _chain = _chain.then(fn).catch(function () {});
  return _chain;
}

function log(cat, text) {
  return serialize(async function () {
    var s = await chrome.storage.local.get([LOG_KEY]);
    var logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), cat: cat, msg: String(text) });
    if (logs.length > 2000) logs.splice(0, logs.length - 2000);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  });
}

function recordHistory(entry) {
  return serialize(async function () {
    var s = await chrome.storage.local.get([HISTORY_KEY]);
    var list = s[HISTORY_KEY] || [];
    list.unshift(Object.assign({ t: new Date().toISOString() }, entry));
    if (list.length > 200) list.length = 200;
    await chrome.storage.local.set({ [HISTORY_KEY]: list });
  });
}

function todayIso() {
  var d = new Date();
  return d.getFullYear() + '-' +
    String(d.getMonth() + 1).padStart(2, '0') + '-' +
    String(d.getDate()).padStart(2, '0');
}

function setDoneFlag(kind) {
  var snap = isSnapKind(kind);
  var key = snap ? DONE_SNAP_KEY : DONE_KEY;
  return serialize(async function () {
    var s = await chrome.storage.local.get([key]);
    var flags = s[key] || {};
    // 区分Bは「今日その最新状態を取ったか」なので、実行日を入れておく。
    // 日付が変われば自動的にチェックが外れる。
    flags[kind] = snap ? todayIso() : true;
    await chrome.storage.local.set({ [key]: flags });
  });
}

async function isCancelled() {
  var s = await chrome.storage.local.get([CANCEL_KEY]);
  return !!s[CANCEL_KEY];
}

function setJob(job) {
  job.updatedAt = Date.now();   // popup側で「固まっていないか」を判定するため
  return chrome.storage.local.set({ [JOB_KEY]: job });
}

// 1件が応答しなくなっても、ジョブ全体が無音で止まらないようにする番人。
// executeScript はタブが遷移/破棄されると解決しないまま残ることがある。
function withTimeout(promise, ms, label) {
  return new Promise(function (resolve) {
    var done = false;
    var timer = setTimeout(function () {
      if (done) return;
      done = true;
      resolve({ ok: false, status: 'error', error: (label || '処理') + 'が' + Math.round(ms / 1000) + '秒応答しませんでした(タイムアウト)' });
    }, ms);
    Promise.resolve(promise).then(
      function (v) { if (!done) { done = true; clearTimeout(timer); resolve(v); } },
      function (e) { if (!done) { done = true; clearTimeout(timer); resolve({ ok: false, status: 'error', error: (e && e.message) ? e.message : String(e) }); } }
    );
  });
}
function clearJob() { return chrome.storage.local.remove([JOB_KEY]); }

// ---------- URL ----------
function urlFor(kind, seller) {
  if (kind === 'ad') return 'https://cam.yahoo.co.jp/' + seller + '/report/adDetail';
  if (kind === 'item') return 'https://pro.store.yahoo.co.jp/pro.' + seller + '/sales_manage/item_report';
  if (kind === 'pr') return 'https://pro.store.yahoo.co.jp/pro.' + seller + '/sales_manage/report/prreport';
  if (kind === 'itemmgr') return 'https://editor.store.yahoo.co.jp/RT/' + seller + '/ItemMgr/';
  // ⑥はcampaignId/adGroupIdが要るので、実際のURLは downloadOne 側で組み立てる
  if (kind === 'bidcsv') return 'https://cam.yahoo.co.jp/' + seller + '/itemad/csv';
  return 'https://pro.store.yahoo.co.jp/pro.' + seller + '/sales_manage/overall';
}
function matchFor(kind, seller) {
  if (kind === 'ad') return '/' + seller + '/report/adDetail';
  if (kind === 'item') return '/sales_manage/item_report';
  if (kind === 'pr') return '/sales_manage/report/prreport';
  if (kind === 'itemmgr') return '/RT/' + seller + '/ItemMgr/';
  if (kind === 'bidcsv') return '/' + seller + '/itemad/csv';
  return '/sales_manage/overall';
}

// ⑥ に必要な campaignId / adGroupId を ①のページから拾う(取れたらキャッシュ)
async function getCamIds(seller) {
  try {
    var tab = await getOrCreateTab(matchFor('ad', seller), urlFor('ad', seller));
    if (tab) {
      var ids = await callFn(tab.id, 'yhReadCamIds', {});
      if (ids && ids.ok) {
        await chrome.storage.local.set({ [CAMIDS_KEY]: ids });
        return ids;
      }
    }
  } catch (e) {}
  var s = await chrome.storage.local.get([CAMIDS_KEY]);
  return s[CAMIDS_KEY] || null;
}

// タブが目的のURLでなければ移動して読み込みを待つ
async function ensureTabUrl(tab, url, mustContain) {
  try {
    var t = await chrome.tabs.get(tab.id);
    if (t.url && t.url.indexOf(mustContain) >= 0) return t;
  } catch (e) { return tab; }
  await chrome.tabs.update(tab.id, { url: url });
  var start = Date.now();
  while (Date.now() - start < 30000) {
    await sleep(600);
    try {
      var t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete' && t2.url && t2.url.indexOf(mustContain) >= 0) {
        await sleep(1200);
        return t2;
      }
    } catch (e) {}
  }
  return tab;
}

// ---------- タブ ----------
async function getOrCreateTab(urlMatch, ensureUrl) {
  var tabs = await chrome.tabs.query({});
  var tab = tabs.filter(function (t) { return t.url && t.url.indexOf(urlMatch) >= 0; })[0];
  if (tab) return tab;
  await log('bg', 'タブが無いので新規オープン: ' + ensureUrl);
  tab = await chrome.tabs.create({ url: ensureUrl, active: false });
  var start = Date.now();
  while (Date.now() - start < 25000) {
    await sleep(200);
    try {
      var t2 = await chrome.tabs.get(tab.id);
      if (t2.status === 'complete') { await sleep(500); return t2; }
    } catch (e) {
      var re = (await chrome.tabs.query({})).filter(function (t) { return t.url && t.url.indexOf(urlMatch) >= 0; })[0];
      if (re) return re;
    }
  }
  return tab;
}

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

// ---------- MAIN world 実行 ----------
async function injectFile(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    files: ['injected.js']
  });
}

async function callFn(tabId, name, params) {
  await injectFile(tabId);
  var res = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: async function (n, p) {
      var f = window[n];
      if (typeof f !== 'function') return { ok: false, status: 'error', error: '関数が未注入: ' + n };
      try { return await f(p); }
      catch (e) { return { ok: false, status: 'error', error: e && e.message ? e.message : String(e) }; }
    },
    args: [name, params]
  });
  return res && res[0] ? res[0].result : null;
}

async function overlay(tabId, text) {
  try {
    await injectFile(tabId);
    await chrome.scripting.executeScript({
      target: { tabId: tabId }, world: 'MAIN',
      func: function (t) { if (typeof yhInstallOverlay === 'function') yhInstallOverlay(t); },
      args: [text]
    });
  } catch (e) {}
}
async function overlayOff(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId }, world: 'MAIN',
      func: function () { if (typeof yhRemoveOverlay === 'function') yhRemoveOverlay(); }
    });
  } catch (e) {}
}

// ---------- 1件のDL ----------
async function downloadOne(kind, day, settings) {
  var seller = settings.seller;

  // ---- 区分B: 最新状態スナップショット(日付は使わない) ----
  if (kind === 'itemmgr') {
    var t1 = await getOrCreateTab(matchFor(kind, seller), urlFor(kind, seller));
    if (!t1) return { ok: false, status: 'error', error: 'タブ取得失敗' };
    await overlay(t1.id, '📥 ' + KIND_LABEL[kind] + ' 取得中…');
    try { return await callFnWatched(t1.id, KIND_LABEL[kind], 'yahooItemMgrSnapshot', { seller: seller }); }
    finally { await overlayOff(t1.id); }
  }
  if (kind === 'bidcsv') {
    var ids = await getCamIds(seller);
    if (!ids || !ids.campaignId) {
      return { ok: false, status: 'error', error: 'campaignId/adGroupId が取得できません(①広告詳細レポートのページを一度開いてください)' };
    }
    var camUrl = 'https://cam.yahoo.co.jp/' + seller + '/itemad/csv?campaignId=' +
      encodeURIComponent(ids.campaignId) + '&adGroupId=' + encodeURIComponent(ids.adGroupId);
    var t2 = await getOrCreateTab(matchFor(kind, seller), camUrl);
    if (!t2) return { ok: false, status: 'error', error: 'タブ取得失敗' };
    t2 = await ensureTabUrl(t2, camUrl, 'campaignId=' + ids.campaignId);
    await overlay(t2.id, '📥 ' + KIND_LABEL[kind] + ' 取得中…');
    try { return await callFnWatched(t2.id, KIND_LABEL[kind], 'yahooBidCsvSnapshot', { seller: seller }); }
    finally { await overlayOff(t2.id); }
  }

  // ---- 区分A: 期間指定DL ----
  var tab = await getOrCreateTab(matchFor(kind, seller), urlFor(kind, seller));
  if (!tab) return { ok: false, status: 'error', error: 'タブ取得失敗' };

  await overlay(tab.id, '📥 ' + KIND_LABEL[kind] + ' ' + day + ' 取得中…');

  try {
    if (kind === 'ad') {
      return await callFnWatched(tab.id, KIND_LABEL[kind] + ' ' + day, 'yahooAdDetailDownloader', {
        day: day, reportType: settings.reportType || 'product', seller: seller, timeout: 60
      });
    }

    // ②③: 日付セット → 遷移 → CSV取得
    var a = await callFnWatched(tab.id, KIND_LABEL[kind] + ' ' + day, 'yahooProSetDate', { kind: kind, day: day });
    if (!a || !a.ok) return { ok: false, status: 'error', error: (a && a.error) || '日付セット失敗' };

    var ready = null;
    var t0 = Date.now();
    await sleep(1200);
    while (Date.now() - t0 < 45000) {
      try {
        var t = await chrome.tabs.get(tab.id);
        if (t.status === 'complete') {
          ready = await callFn(tab.id, 'yahooProCheckReady', { kind: kind, day: day });
          if (ready && ready.navigated && ready.match && ready.btn) break;
        }
      } catch (e) { /* 遷移中はエラーになるので無視 */ }
      await sleep(700);
    }
    if (!ready || !ready.navigated || !ready.match) {
      return { ok: false, status: 'error', error: 'ページ遷移待ちタイムアウト' + (ready ? ' (' + ready.from + '〜' + ready.to + ')' : '') };
    }
    await sleep(600); // 表の描画待ち
    return await callFnWatched(tab.id, KIND_LABEL[kind] + ' ' + day, 'yahooProGrabCsv', { kind: kind, day: day, seller: seller, timeout: 60 });
  } finally {
    await overlayOff(tab.id);
  }
}

// ============================================================================
// 保存: chrome.downloads ではなく「選んだフォルダ」に直接書く(folder.html 経由)
//   月別フォルダ: YYYY-MM-{IR|ITEM|STORE|PR} に _get なしで上書き
//   取り込み用  : Ycheck取り込み用/ に _getYYYYMMDD-HHMM 付きで全部残す
//   ⑤⑥(最新値)は取り込み用にだけ保存する
// ============================================================================

var IMPORT_DIR = 'Ycheck取り込み用';

function pad2(n) { return String(n).padStart(2, '0'); }

// 取得日時 YYYYMMDD-HHMM (PCの時刻。toISOString は UTC なので使わない)
function getStamp(d) {
  d = d || new Date();
  return '' + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate())
       + '-' + pad2(d.getHours()) + pad2(d.getMinutes());
}

// 日次①〜④のベース名(拡張子なし)
function baseNameFor(kind, seller, day) {
  var mid = { ad: 'item-reach', item: 'item_report', overall: 'store-overall', pr: 'total-report' }[kind];
  if (!mid) return null;
  return seller + '-' + mid + '-' + String(day).replace(/-/g, '');
}

// ⑤⑥(最新値)の名前。サイトが付けた名前を土台にする。
//   data202611120945.csv -> yukaiya-data202611120945
//   BID_ITEM (59).csv    -> yukaiya-BID_ITEM
function snapBaseFor(kind, seller, siteName) {
  var n = String(siteName || '');
  var i = n.lastIndexOf('.');
  var stem = i > 0 ? n.slice(0, i) : n;
  stem = stem.replace(/\s*\(\d+\)\s*$/, '').trim();      // 「 (59)」を外す
  if (kind === 'bidcsv' && !stem) stem = 'BID_ITEM';
  if (kind === 'itemmgr' && !stem) stem = 'data';
  return seller + '-' + stem;
}

function extOf(siteName) {
  var n = String(siteName || '');
  var i = n.lastIndexOf('.');
  return i > 0 ? n.slice(i) : '.csv';
}

// 'foo.csv' + '20261112-0945' -> 'foo_get20261112-0945.csv'
function withGet(base, ext, stamp) { return base + '_get' + stamp + ext; }

// ---- 保存先タブ(folder.html) ----
function folderUrl() { return chrome.runtime.getURL('folder.html'); }

async function findFolderTab() {
  try {
    var tabs = await chrome.tabs.query({ url: folderUrl() });
    return (tabs && tabs[0]) || null;
  } catch (e) { return null; }
}

// 無ければ開く。ピン留めして、うっかり閉じにくくする。
async function ensureFolderTab() {
  var t = await findFolderTab();
  if (t) return t;
  try {
    t = await chrome.tabs.create({ url: folderUrl(), active: false, pinned: true });
    await sleep(1200);   // ページが onMessage を張るまで少し待つ
    return t;
  } catch (e) { return null; }
}

function askFolder(msg) {
  return new Promise(function (resolve) {
    try {
      chrome.runtime.sendMessage(Object.assign({ target: 'folder' }, msg), function (r) {
        void chrome.runtime.lastError;
        resolve(r || null);
      });
    } catch (e) { resolve(null); }
  });
}

async function fsStatus() {
  await ensureFolderTab();
  var r = await askFolder({ type: 'fs-status' });
  return r || { state: 'none', name: '' };
}

// 許可が切れていたら、保存先タブを前面に出して最大4分待つ
async function waitForGrant() {
  var t = await ensureFolderTab();
  try { if (t) await chrome.tabs.update(t.id, { active: true }); } catch (e) {}
  notify('🔑 書き込み許可が必要です', '保存先タブで「🔑 書き込みを許可する」を押してください');
  await log('bg', '⏸ 書き込み許可が切れています。保存先タブで許可してください(最大4分待ちます)');
  for (var i = 0; i < 48; i++) {
    if (await isCancelled()) break;
    await sleep(5000);
    var st = await askFolder({ type: 'fs-status' });
    if (st && st.state === 'granted') {
      await log('bg', '▶ 許可されたので再開します');
      return st;
    }
  }
  return await fsStatus();
}

// data: URL のまま渡し、バイト列への変換は保存先タブ側で行う。
// 配列にして送ると数十MBの JSON になり、メッセージが詰まるため。
async function fsWrite(subdir, filename, dataUrl) {
  await ensureFolderTab();
  var r = await askFolder({ type: 'fs-write', subdir: subdir, filename: filename, dataUrl: dataUrl });
  if (!r) return { ok: false, error: '保存先タブが応答しません(閉じられた可能性)' };
  return r;
}

// ---------- 1件分の保存(月別 + 取り込み用。両方成功で成功) ----------
async function saveResult(r, ctx) {
  if (!r || !r.dataUrl) return r;
  if (r.status !== 'ok' && r.status !== 'nodata') return r;

  var dataUrl = r.dataUrl;
  delete r.dataUrl;   // ログ・履歴に巨大な文字列を残さない

  var st = await fsStatus();
  if (st.state === 'none') {
    return { ok: false, status: 'error',
             error: '保存先フォルダが未設定です。保存先タブで「📁 保存先フォルダを選ぶ」を押してください' };
  }
  if (st.state !== 'granted') {
    st = await waitForGrant();
    if (st.state !== 'granted') {
      return { ok: false, status: 'error',
               error: '保存先フォルダへの書き込み許可がありません(state=' + st.state + ')' };
    }
  }

  var stamp = getStamp();
  var ext = extOf(r.file);
  var snap = isSnapKind(ctx.kind);
  var base = snap ? snapBaseFor(ctx.kind, ctx.seller, r.file)
                  : baseNameFor(ctx.kind, ctx.seller, ctx.day);
  if (!base) return { ok: false, status: 'error', error: 'ファイル名を決められませんでした' };

  var failed = [];

  // (1) バックアップ: _get なしで上書き
  //     ①〜④ … YYYY-MM/ の月別フォルダにまとめて入れる(種別では分けない)
  //     ⑤⑥   … 月を持たないので、選んだフォルダの直下に置く。
  //              ⑥は名前に日付が入らないため毎回上書きになり、常に最新の1つだけ残る。
  var backupDir = snap ? '' : String(ctx.day).slice(0, 7);
  var w1 = await fsWrite(backupDir, base + ext, dataUrl);
  if (!w1.ok) failed.push((snap ? '直下: ' : '月別: ') + w1.error);

  // (2) 取り込み用: 全種類。_get 付きで残す
  var w2 = await fsWrite(IMPORT_DIR, withGet(base, ext, stamp), dataUrl);
  if (!w2.ok) failed.push('取り込み用: ' + w2.error);

  if (failed.length) {
    return { ok: false, status: 'error', error: '保存に失敗: ' + failed.join(' / ') };
  }

  r.file = withGet(base, ext, stamp);
  if (w2.size != null) r.bytes = w2.size;
  return r;
}

// ---------- リトライ付き ----------
async function downloadWithRetry(kind, day, settings) {
  var last = null;
  for (var i = 0; i < 3; i++) {
    if (await isCancelled()) return { ok: false, status: 'cancelled', error: '中止されました' };
    try {
      last = await saveResult(
        await withTimeout(downloadOne(kind, day, settings), 150000, KIND_LABEL[kind] + ' ' + day),
        { kind: kind, day: day, seller: settings.seller || 'yukaiya' }
      );
    } catch (e) {
      last = { ok: false, status: 'error', error: e && e.message ? e.message : String(e) };
    }
    if (last && (last.status === 'ok' || last.status === 'nodata' || last.status === 'notready')) return last;
    if (i < 2) {
      await log('bg', '  ⚠ ' + KIND_LABEL[kind] + ' ' + day + ' 失敗 → ' + (i + 2) + '回目を試行: ' + (last && last.error));
      await sleep(6000);
    }
  }
  return last || { ok: false, status: 'error', error: '不明なエラー' };
}

// ---------- 必要なページをまとめて開く(読み込み完了は待たない) ----------
// ⑥は campaignId/adGroupId が必要なのでここでは開かない(downloadOne が面倒を見る)
async function openTabsFor(kinds, seller) {
  try {
    var targets = kinds.filter(function (k) { return k !== 'bidcsv' && urlFor(k, seller); });
    if (!targets.length) return 0;
    var tabs = await chrome.tabs.query({});
    var created = 0;
    var jobs = targets.map(function (k) {
      var m = matchFor(k, seller);
      if (tabs.some(function (t) { return t.url && t.url.indexOf(m) >= 0; })) return null;
      created++;
      return chrome.tabs.create({ url: urlFor(k, seller), active: false });
    }).filter(Boolean);
    if (!jobs.length) return 0;
    await Promise.all(jobs);
    await log('bg', '🔗 必要なページを ' + created + '件 オープン(' + (targets.length - created) + '件は既に開いていました)');
    await sleep(1500);   // 少しだけ読み込みの猶予を与える
    return created;
  } catch (e) {
    await log('bg', '⚠ ページのオープンに失敗: ' + (e && e.message));
    return 0;
  }
}

// ---------- 完了のお知らせ ----------
// ① デスクトップ通知 ② 拡張アイコンのバッジ ③ popup上の「最後の結果」
// OS側で通知がブロックされていても ②③ で気づけるようにしてある。

// 通知アイコンは manifest から引く。パスを直書きすると、アイコンのファイル名を
// 変えたときに「Unable to download all specified images」で通知が出なくなる。
function notifyIconUrl() {
  try {
    var ic = chrome.runtime.getManifest().icons || {};
    var p = ic['128'] || ic['48'] || ic['16'];
    return p ? chrome.runtime.getURL(p) : '';
  } catch (e) { return ''; }
}

function notify(title, message) {
  try {
    chrome.notifications.create('yh_' + Date.now(), {
      type: 'basic',
      iconUrl: notifyIconUrl(),
      title: title,
      message: message,
      priority: 2
    }, function (id) {
      if (chrome.runtime.lastError) {
        log('bg', '⚠ 通知を出せませんでした: ' + chrome.runtime.lastError.message);
      } else if (!id) {
        log('bg', '⚠ 通知が表示されませんでした(Windowsの通知設定でChromeがブロックされている可能性)');
      }
    });
  } catch (e) {
    log('bg', '⚠ 通知の呼び出しに失敗: ' + (e && e.message));
  }
}

// 拡張アイコンのバッジ(OSの通知設定に左右されない)
function setBadge(state) {
  try {
    if (state === 'running') {
      chrome.action.setBadgeText({ text: '…' });
      chrome.action.setBadgeBackgroundColor({ color: '#c25a00' });
    } else if (state === 'ok') {
      chrome.action.setBadgeText({ text: '✓' });
      chrome.action.setBadgeBackgroundColor({ color: '#1e7a3a' });
    } else if (state === 'ng') {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#c00000' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {}
}

// ---------- ジョブ実行 ----------
async function runTasks(title, tasks, settings) {
  await chrome.storage.local.remove([CANCEL_KEY]);
  var __ver = '?';
  try { __ver = chrome.runtime.getManifest().version; } catch (e) {}
  var __acct = (settings && settings.seller) || 'yukaiya';
  var __shop = (settings && settings.shopName) || '';
  await log('bg', '▶ ' + title + ' 開始 (' + tasks.length + '件) / 🏪 ' +
    (__shop ? __shop + ' [' + __acct + ']' : __acct) + ' / 拡張バージョン v' + __ver);

  var job = {
    title: title,
    startedAt: Date.now(),
    tasks: tasks.map(function (t) { return { kind: t.kind, day: t.day, state: 'pending' }; })
  };
  await setJob(job);
  setBadge('running');

  // このジョブで使うページを最初にまとめて開いておく。
  // 種別ごとに順番処理するので、開くのを実処理まで待つと
  // 「④のページがなかなか出てこない」ように見えるため。
  await openTabsFor(
    tasks.map(function (t) { return t.kind; }).filter(function (k, i, a) { return a.indexOf(k) === i; }),
    settings.seller || 'yukaiya'
  );

  var ok = 0, ng = 0, nd = 0, nr = 0;
  var cancelled = false;
  var doneKinds = {};

  for (var i = 0; i < job.tasks.length; i++) {
    if (await isCancelled()) {
      cancelled = true;
      await log('bg', '⏹ 中止フラグ検出 → 残り ' + (job.tasks.length - i) + ' 件をスキップ');
      break;
    }
    var t = job.tasks[i];
    t.state = 'processing';
    await setJob(job);

    var r = await downloadWithRetry(t.kind, t.day, settings);
    var status = (r && r.status) || 'error';

    if (status === 'ok') { ok++; t.state = 'ok'; doneKinds[t.kind] = true; }
    else if (status === 'nodata') { nd++; t.state = 'nodata'; doneKinds[t.kind] = true; }
    else if (status === 'notready') { nr++; t.state = 'notready'; }
    else if (status === 'cancelled') { t.state = 'pending'; }
    else { ng++; t.state = 'ng'; }

    await setJob(job);
    await recordHistory({
      kind: t.kind,
      type: KIND_LABEL[t.kind],
      day: t.day,
      result: t.state,
      file: r && r.file,
      bytes: r && r.bytes,
      msg: (r && r.error) || ''
    });
    await log('dl',
      (t.state === 'ok' ? '✅' : t.state === 'nodata' ? '⚪' : t.state === 'notready' ? '⏰' : '❌') + ' ' +
      KIND_LABEL[t.kind] + ' ' + (t.day === 'snapshot' ? 'スナップショット' : t.day) +
      (r && r.file ? ' → ' + r.file + ' (' + r.bytes + 'B)' : '') +
      (r && r.error ? ' : ' + r.error : ''));

    await sleep(1200); // サーバ負荷を避けるための間隔
  }

  Object.keys(doneKinds).forEach(function (k) { setDoneFlag(k); });
  await log('bg', '🎉 ' + title + ' 完了: ✅' + ok + ' ⚪' + nd + ' ⏰' + nr + ' ❌' + ng);

  // 完了をデスクトップ通知(このジョブの全件が終わったタイミング)
  var parts = [];
  if (ok) parts.push('✅ 保存 ' + ok + '件');
  if (nd) parts.push('⚪ データなし ' + nd + '件');
  if (nr) parts.push('⏰ 準備中 ' + nr + '件');
  if (ng) parts.push('❌ 失敗 ' + ng + '件');
  if (!parts.length) parts.push('対象がありませんでした');
  var sec = Math.max(1, Math.round((Date.now() - job.startedAt) / 1000));
  var head = cancelled ? '⏹ 中止しました' : (ng ? '⚠ 完了(失敗あり)' : '✅ ダウンロード完了');
  var detail = parts.join(' / ') + ' (' + sec + '秒)';
  notify(head, title + '\n' + detail);
  setBadge(ng ? 'ng' : 'ok');
  await chrome.storage.local.set({
    yh_last_result: { t: Date.now(), head: head, title: title, detail: detail, fail: ng }
  });

  // 中止・タイムアウトなどで手つかずのまま残った分は「残りから再開」用に取っておく
  var remaining = job.tasks
    .filter(function (t) { return t.state === 'pending'; })
    .map(function (t) { return { kind: t.kind, day: t.day }; });
  if (remaining.length) {
    await chrome.storage.local.set({ yh_resume: { title: title, tasks: remaining, t: Date.now() } });
    await log('bg', '↩ 未実行 ' + remaining.length + '件を「残りから再開」用に保存しました');
  } else {
    await chrome.storage.local.remove(['yh_resume']);
  }

  await chrome.storage.local.remove([CANCEL_KEY]);
  await clearJob();
  return { ok: true, success: ok, nodata: nd, fail: ng };
}

// ---------- タスク生成 ----------
function daysBetween(startIso, endIso) {
  var out = [];
  var d = new Date(startIso + 'T00:00:00');
  var end = new Date(endIso + 'T00:00:00');
  while (d <= end) {
    out.push(d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0'));
    d.setDate(d.getDate() + 1);
  }
  return out;
}

// 種別ごとにまとめる(タブ移動を減らす)
function buildTasks(kinds, days) {
  var tasks = [];
  kinds.forEach(function (k) {
    days.forEach(function (d) { tasks.push({ kind: k, day: d }); });
  });
  return tasks;
}

// ---------- メッセージ ----------

// ============================================================================
// 安全装置
//   1. タブ閉じ検知   : 取得中のタブが閉じたら、残りを続けずに中断する
//   2. 二重起動防止   : 同じ取得が動いている間は2本目を始めない
//   3. 片付け         : 拡張の更新・再読み込みで、実行中のまま残ったジョブを畳む
// ============================================================================
var runningTabs = new Map();   // tabId -> 表示名
var closedTabs = new Set();

chrome.tabs.onRemoved.addListener(function (tabId) {
  if (!runningTabs.has(tabId)) return;
  var label = runningTabs.get(tabId);
  runningTabs.delete(tabId);
  closedTabs.add(tabId);
  log('bg', '❌ 取得中のタブ(tabId=' + tabId + ')が閉じられたため「' + label + '」を中断しました');
  chrome.storage.local.set({ [CANCEL_KEY]: true });
  notify('❌ 中断されました', label + '\nタブが閉じられました。もう一度ボタンを押してください');
});

// 取得中のタブを覚えておく(閉じられたか判定するため)
async function callFnWatched(tabId, label, name, params) {
  runningTabs.set(tabId, label);
  try {
    return await callFn(tabId, name, params);
  } catch (e) {
    var gone = closedTabs.has(tabId);
    if (!gone) { try { await chrome.tabs.get(tabId); } catch (_) { gone = true; } }
    return { ok: false, status: 'error', tabClosed: gone,
             error: (gone ? 'タブが閉じられました: ' : '') + (e && e.message ? e.message : String(e)) };
  } finally {
    runningTabs.delete(tabId);
  }
}

var activeRuns = new Map();   // msg.type -> 開始時刻
function busyReason(type) {
  if (activeRuns.has(type)) return '同じ取得がすでに実行中です';
  if (activeRuns.size > 0) return 'ほかの取得が実行中です。終わってから実行してください';
  return null;
}

chrome.runtime.onInstalled.addListener(async function () {
  try {
    var s = await chrome.storage.local.get([JOB_KEY]);
    if (s[JOB_KEY]) {
      await chrome.storage.local.remove([JOB_KEY]);
      await log('bg', '🧹 拡張の更新・再読み込みで、実行中のまま残っていたジョブを片付けました');
    }
    await chrome.storage.local.remove([CANCEL_KEY]);
  } catch (e) {}
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.target === 'folder') return false;   // 保存先タブ宛は素通し

  // 二重起動防止: run系は1本ずつしか動かさない
  if (msg && typeof msg.type === 'string' && msg.type.indexOf('run') === 0) {
    var busy = busyReason(msg.type);
    if (busy) {
      try { sendResponse({ ok: false, busy: true, error: busy }); } catch (e) {}
      return false;
    }
    activeRuns.set(msg.type, Date.now());
    var origSend = sendResponse;
    sendResponse = function (res) { activeRuns.delete(msg.type); try { origSend(res); } catch (e) {} };
    ensureFolderTab();   // 保存先タブを先に用意しておく
  }

  if (msg && msg.type === 'run') {
    var kinds = msg.kinds || ['ad', 'item', 'overall', 'pr'];
    var days = msg.days || daysBetween(msg.startDate, msg.endDate);
    var title = msg.title || 'DL';
    runTasks(title, buildTasks(kinds, days), msg.settings || {})
      .then(function (r) { try { sendResponse(r); } catch (e) {} })
      .catch(function (e) { try { sendResponse({ ok: false, error: e.message }); } catch (_) {} });
    return true;
  }
  if (msg && msg.type === 'run-tasks') {
    runTasks(msg.title || '♻ 失敗分の再取得', msg.tasks || [], msg.settings || {})
      .then(function (r) { try { sendResponse(r); } catch (e) {} })
      .catch(function (e) { try { sendResponse({ ok: false, error: e.message }); } catch (_) {} });
    return true;
  }
  if (msg && msg.type === 'open-tabs') {
    var seller0 = (msg.settings && msg.settings.seller) || 'yukaiya';
    openTabsFor(msg.kinds || ['ad', 'item', 'overall', 'pr'], seller0)
      .then(function (created) { try { sendResponse({ ok: true, created: created }); } catch (e) {} });
    return true;
  }
  return false;
});

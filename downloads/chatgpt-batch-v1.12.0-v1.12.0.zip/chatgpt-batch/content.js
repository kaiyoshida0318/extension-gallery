// ChatGPT 画像一括送信 — content script (v1.2)
// ChatGPTを開いたときだけ右上にボタンを出し、パネルから画像＋指示文を設定間隔で1枚ずつ送信する。
(() => {
  if (window.__cgbLoaded) return;
  window.__cgbLoaded = true;

  const HOST_ID = 'cgb-host';
  const PUSH_ID = 'cgb-push-style';
  const DRY_RUN = !!window.__CGB_DRYRUN; // テスト用：送信ボタンを押す直前で止める
  const MIN_W = 320, WIDE_AT = 680;
  const defW = () => Math.max(MIN_W, Math.round(window.innerWidth * 0.49));
  const VERSION = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return '1.12.0'; } })();
  // ChatGPTは前に開いたチャットを見えない<main>として残すことがある。いま表示中のmainを選ぶ
  function chatMain() {
    const mains = [...document.querySelectorAll('main')];
    if (mains.length <= 1) return mains[0] || document;
    const area = m => { const r = m.getBoundingClientRect(); return r.width * r.height; };
    const shown = mains.filter(m => area(m) > 0 && !m.closest('[hidden], [inert], [aria-hidden="true"]'));
    return shown.sort((x, y) => area(y) - area(x))[0] || mains[mains.length - 1];
  }
  const CHANGELOG = [
    ['1.12.0', '画像DL：「全件選択／全件解除」の行を追加。DLボタンを「保存先へDL」と「デスクトップにDL」の2つに'],
    ['1.11.2', 'ChatGPTが前のチャットを見えない状態で残すようになり、画像DLが0枚・送信先がずれる問題を修正（表示中の画面だけを対象に）'],
    ['1.11.1', '2枚以上の生成（右側にサムネイルが並ぶ表示）で全部の画像を取得。チャット移動・読み込み直し時に一覧が更新されない問題を修正'],
    ['1.11.0', '画像DLの名称：初期値は薄い見本（x-01, x-02…）。空のまま保存するとその名前、連番は「ベース名-01」形式'],
    ['1.10.2', 'バージョン番号のみ更新（中身は1.10.1と同じ）'],
    ['1.10.1', '2枚まとめて生成したときに片方を取りこぼす問題を修正（画面外の画像・遅れて出る画像にも対応、DL一覧を自動更新）'],
    ['1.10.0', '保存先フォルダを選べるように（一番下の「保存先」で選択・切り替え・記憶）'],
    ['1.9.0', '「⬇ 画像DL」を追加：開いているチャットの画像を一覧表示し、名前を付けてダウンロード'],
    ['1.8.0', '「＋ 画像を追加」欄を縦に広げてドロップしやすく'],
    ['1.7.0', '生成画像をツールからダウンロード（自動DL・1枚ずつ・まとめてDL）'],
    ['1.6.0', '画像一覧に「一括でテンプレ」バー（全部に追加／置き換え／空欄だけ／全消し）'],
    ['1.5.0', '左に指示・設定、右に画像の2列レイアウト。開いたときの幅を画面の約半分に'],
    ['1.4.0', 'バージョン表示と更新履歴を追加'],
    ['1.3.0', 'OKを押すと進捗画面に切り替え（カウントダウン・経過時間・終了予定）'],
    ['1.2.0', '送信先の選択（最近の項目／URL入力）、指示テンプレ、パネル幅の調整'],
    ['1.1.0', 'ChatGPTを開いたときだけ右上にボタンを表示'],
    ['1.0.0', '初版'],
  ];

  // ---------- ドロップ・キー入力をChatGPT本体に奪われないようにする（最優先で登録） ----------
  const inPanel = e => e.composedPath().some(n => n && n.id === HOST_ID);
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(type => {
    window.addEventListener(type, e => {
      if (!inPanel(e)) return;
      e.stopImmediatePropagation();
      e.preventDefault();
      if (type === 'drop') panelApi?.onDrop(e);
      else if (type === 'dragleave') panelApi?.onDragLeave(e);
      else panelApi?.onDragOver(e);
    }, true);
  });
  ['keydown', 'keyup', 'keypress', 'paste'].forEach(type => {
    window.addEventListener(type, e => { if (inPanel(e)) e.stopImmediatePropagation(); }, true);
  });

  let panelApi = null;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const collator = new Intl.Collator('ja', { numeric: true, sensitivity: 'base' });

  // ---------- 設定の保存（拡張のストレージ。なければ localStorage） ----------
  const hasCS = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const cache = {};
  const store = {
    async load() {
      if (hasCS) {
        try { Object.assign(cache, await chrome.storage.local.get(null)); return; } catch (e) {}
      }
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k.startsWith('cgb_')) cache[k.slice(4)] = JSON.parse(localStorage.getItem(k));
        }
      } catch (e) {}
    },
    get(k, d) { return k in cache ? cache[k] : d; },
    set(k, v) {
      cache[k] = v;
      if (hasCS) { try { chrome.storage.local.set({ [k]: v }); return; } catch (e) {} }
      try { localStorage.setItem('cgb_' + k, JSON.stringify(v)); } catch (e) {}
    },
  };

  // ---------- ChatGPT画面の操作 ----------
  const cg = {
    composer() { const m = chatMain(); return m.querySelector('.ProseMirror[contenteditable="true"]') || m.querySelector('#prompt-textarea') || document.querySelector('.ProseMirror[contenteditable="true"]') || document.querySelector('#prompt-textarea'); },
    form() { return this.composer()?.closest('form') || null; },
    submitBtn() {
      const f = this.form(); if (!f) return null;
      return f.querySelector('button[type="submit"]') ||
        f.querySelector('[data-testid="send-button"], #composer-submit-button') ||
        [...f.querySelectorAll('button')].find(b => /^(送信|Send)/i.test(b.getAttribute('aria-label') || ''));
    },
    isGenerating() {
      const scope = this.form() || document;
      return !![...scope.querySelectorAll('button')].find(b => /停止|stop/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.dataset.testid || '')));
    },
    imageInput() {
      const f = this.form();
      const ins = [...(f || document).querySelectorAll('input[type="file"]')].concat(f ? [...document.querySelectorAll('input[type="file"]')] : []);
      return ins.find(i => i.accept === 'image/*') || ins.find(i => /image/.test(i.accept)) || ins[0] || null;
    },
    newChatBtn() {
      return document.querySelector('[data-testid="create-new-chat-button"]') ||
        [...document.querySelectorAll('button, a')].find(e => /^(新しいチャット|New chat)$/i.test((e.getAttribute('aria-label') || e.innerText || '').trim())) ||
        document.querySelector('a[href="/"]');
    },
    // サイドバーの「最近の項目」などから、開けるチャット/プロジェクト/GPTの一覧を集める
    recentLinks() {
      const seen = new Set(), out = [];
      document.querySelectorAll('nav a[href], aside a[href], a[href^="/c/"], a[href^="/g/"]').forEach(a => {
        const href = a.getAttribute('href');
        if (!/^\/(c|g)\//.test(href) || seen.has(href) || a.closest('#' + HOST_ID)) return;
        const title = (a.innerText || a.getAttribute('aria-label') || '').trim().split('\n')[0];
        if (!title) return;
        seen.add(href); out.push({ href, title });
      });
      return out;
    },
    async waitFor(fn, timeout, label) {
      const t0 = Date.now();
      while (Date.now() - t0 < timeout) {
        try { const v = fn(); if (v) return v; } catch (e) {}
        await sleep(300);
      }
      throw new Error(`${label}（${Math.round(timeout / 1000)}秒待っても変化なし）`);
    },
    async openNewChat() {
      const b = this.newChatBtn();
      if (!b) { log('「新しいチャット」ボタンが見つからないため、今のチャットに送ります'); return; }
      b.click();
      await sleep(1500);
      await this.waitFor(() => this.composer(), 15000, '入力欄が見つかりません');
    },
    // ページを再読み込みせずに指定URLへ移動（再読み込みすると一覧が消えるため）
    async openUrl(raw) {
      let u;
      try { u = new URL(raw, location.origin); } catch (e) { throw new Error('送信先URLの形式が正しくありません'); }
      if (u.origin !== location.origin) throw new Error('送信先は chatgpt.com のURLにしてください');
      const path = u.pathname + u.search;
      if (location.pathname + location.search !== path) {
        const link = [...document.querySelectorAll('a[href]')].find(a => a.getAttribute('href') === path && !a.closest('#' + HOST_ID));
        if (link) link.click();
        else {
          history.pushState({}, '', path);
          window.dispatchEvent(new PopStateEvent('popstate', { state: history.state }));
        }
        await this.waitFor(() => location.pathname + location.search === path, 10000, '送信先のページに移動できません');
        await sleep(2000);
      }
      await this.waitFor(() => this.composer(), 15000, '送信先に入力欄が見つかりません');
    },
    async attach(file) {
      const count = () => this.form()?.querySelectorAll('img').length || 0;
      const before = count();
      const inp = this.imageInput();
      let ok = false;
      if (inp) {
        const dt = new DataTransfer(); dt.items.add(file);
        inp.files = dt.files;
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        ok = await this.waitFor(() => count() > before, 15000, '').catch(() => false);
      }
      if (!ok) { // 予備：貼り付けで添付
        const c = this.composer(); c.focus();
        const dt = new DataTransfer(); dt.items.add(file);
        c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        await this.waitFor(() => count() > before, 15000, '画像を添付できませんでした');
      }
    },
    typeText(text) {
      const c = this.composer(); c.focus();
      text.split('\n').forEach((line, i) => {
        if (i > 0) c.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', shiftKey: true, bubbles: true, cancelable: true }));
        if (line) document.execCommand('insertText', false, line);
      });
    },
    // 生成画像（ChatGPTの画像ギャラリー内のimg）
    // 複数枚生成のとき右側に並ぶサムネイル（「生成画像2を表示」ボタン）
    thumbImgs(scope) {
      return [...(scope || document).querySelectorAll('button img, [role="button"] img, [role="tab"] img')].filter(i => {
        const b = i.closest('button, [role="button"], [role="tab"]');
        const label = (b?.getAttribute('aria-label') || b?.title || '');
        return /生成画像\s*\d+\s*を表示|(show|view)\s+generated\s+image|generated\s+image\s*\d+/i.test(label);
      });
    },
    generatedImgs() {
      const main = chatMain();
      const thumbs = this.thumbImgs(main);
      const thumbSrc = new Set(thumbs.map(i => i.currentSrc || i.src));
      const set = new Set(main.querySelectorAll('[data-testid="generated-image-gallery"] img, [data-testid="generated-image-preview"] img, img[alt^="生成画像"], img[alt^="Generated image"]'));
      thumbs.forEach(i => set.add(i));
      // 予備：ギャラリー外でも「生成画像」らしい大きな画像（添付画像・アイコンは除く）
      main.querySelectorAll('img').forEach(i => {
        if (set.has(i) || i.closest('form')) return;
        if (/添付|Uploaded|avatar|アイコン|icon/i.test(i.alt || '')) return;
        const big = i.naturalWidth >= 512 && i.naturalHeight >= 512;
        if (big && /画像|image/i.test(i.alt || '') && i.closest('[data-message-author-role="assistant"], [data-turn="assistant"], article, [data-content-search-turn-key]')) set.add(i);
      });
      // 画面の順番に並べる。サムネイル列がある返答は、大きい表示（マウスを乗せた1枚）ではなくサムネイルの順番を使う
      return [...set]
        .filter(i => !i.closest('#' + HOST_ID))
        .filter(i => thumbs.includes(i) || !thumbSrc.has(i.currentSrc || i.src))
        .sort((a, b) => a === b ? 0 : (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    },
    // 自分が送った添付画像（ギャラリー外のimgの最後）
    lastUserImg() {
      const main = chatMain();
      const gens = new Set(this.generatedImgs()), thumbs = new Set(this.thumbImgs(main));
      const all = [...main.querySelectorAll('img')].filter(i => !i.closest('[data-testid="generated-image-gallery"]') && !gens.has(i) && !thumbs.has(i) && !i.closest('#' + HOST_ID) && !i.closest('form'));
      return all[all.length - 1] || null;
    },
    async collectNew(before) {
      const pick = () => {
        const anchor = this.lastUserImg();
        const seen = new Set();
        return this.generatedImgs().filter(i => {
          const src = i.currentSrc || i.src;
          if (!src || before.has(src) || seen.has(src)) return false;
          if (anchor && !(anchor.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING)) return false;
          if (/^data:|^about:/.test(src)) return false; // 生成途中のぼかしプレビューなど
          seen.add(src); return true; // 画面外で未読み込み（lazy）の画像も取りこぼさない
        });
      };
      // 2枚目以降が遅れて出てくる・途中のぼかし画像が仕上がり画像に差し替わることがあるため、
      // 画像の枚数とURLが一定時間変わらなくなるまで待つ
      const t0 = Date.now(); let sig = '', stableSince = Date.now(), imgs = [];
      while (Date.now() - t0 < 120000) {
        imgs = pick();
        const now = imgs.map(i => i.currentSrc || i.src).join('|');
        if (now !== sig) { sig = now; stableSince = Date.now(); }
        if (imgs.length && Date.now() - stableSince > 8000) break;
        if (!imgs.length && Date.now() - t0 > 30000) break;
        await sleep(700);
      }
      const out = [], got = new Set();
      for (const i of imgs) {
        const src = i.currentSrc || i.src;
        if (got.has(src)) continue; got.add(src);
        try {
          const b = await (await fetch(src)).blob();
          if (b.size > 2048 && /^image\//.test(b.type || 'image/')) out.push(b);
        } catch (e) { log('生成画像の取得に失敗：' + e.message); }
      }
      if (imgs.length) log(`生成画像を${out.length}枚取得（画面上で${imgs.length}枚検出）`);
      return out;
    },
    async send(file, text, phase = () => {}) {
      await this.waitFor(() => this.composer(), 15000, '入力欄が見つかりません（ログイン切れ？）');
      await this.waitFor(() => !this.isGenerating(), 10 * 60000, '前の生成が終わりません');
      phase('attach');
      await this.attach(file);
      phase('type');
      if (text) this.typeText(text);
      phase('upload');
      const btn = await this.waitFor(() => { const b = this.submitBtn(); return b && !b.disabled && b.getAttribute('aria-disabled') !== 'true' ? b : null; }, 120000, '送信ボタンが押せる状態になりません');
      await sleep(1200);
      if (DRY_RUN) { phase('gen'); await sleep(1500); log('[テスト] 送信直前で停止'); return { url: location.href, images: [] }; }
      const before = new Set(this.generatedImgs().map(i => i.currentSrc || i.src));
      btn.click();
      phase('gen');
      await this.waitFor(() => this.isGenerating() || /\/c\//.test(location.pathname), 30000, '送信後に反応がありません').catch(e => log(e.message));
      const t0 = Date.now(); let quietSince = 0;
      while (Date.now() - t0 < 15 * 60000) {
        if (this.isGenerating()) quietSince = 0;
        else if (!quietSince) quietSince = Date.now();
        else if (Date.now() - quietSince > 4000 && Date.now() - t0 > 6000) break;
        await sleep(500);
      }
      phase('collect');
      const images = await this.collectNew(before);
      return { url: location.href, images };
    },
  };

  // ---------- 状態 ----------
  const state = { items: [], running: false, timer: null, nextAt: 0, busy: false, open: false, width: 0, runItems: [], mode: 'send', runView: false, current: null, phase: '', startedAt: 0, endedAt: 0, stopReason: '', destLabel: '' };
  let uid = 0, root = null;
  const $ = id => root.getElementById(id);

  function log(msg) {
    const t = new Date().toLocaleTimeString('ja-JP');
    console.log('[画像一括送信]', msg);
    const el = root?.getElementById('log'); if (el) el.textContent = `[${t}] ${msg}\n` + el.textContent;
  }
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---------- 見た目 ----------
  const CSS = `
  :host{all:initial}
  [hidden]{display:none !important}
  *{box-sizing:border-box;font-family:"Hiragino Sans","Noto Sans JP","Yu Gothic UI",Meiryo,sans-serif}
  .tabs{position:fixed;right:16px;top:64px;z-index:2147483646;display:flex;flex-direction:column;gap:6px;align-items:flex-end}
  .tab{background:#1f6f5c;color:#fff;border:0;border-radius:99px;
    padding:8px 14px;cursor:pointer;font-size:13px;font-weight:700;box-shadow:0 2px 10px rgba(0,0,0,.2);display:flex;align-items:center;gap:6px}
  .tab:hover{background:#185a4a}
  .tab.running{background:#b4541a}
  .tab.dl{background:#2f4f7a}
  .tab.dl:hover{background:#243d60}
  .modes{margin-left:10px;width:auto}
  .modes button{padding:4px 12px;flex:none;white-space:nowrap}
  .hd-l{display:flex;align-items:center;min-width:0}
  .dlbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
  .dlbar .bl{font-size:12px;font-weight:700}
  .dlbar input[type=text]{width:auto;flex:1;min-width:140px;padding:4px 8px;font-size:12px}
  .dlgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px}
  .dli{display:grid;grid-template-columns:20px 96px 1fr;gap:8px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
  .dli.off{opacity:.5}
  .dli img{width:96px;height:96px;object-fit:contain;background:var(--chip);border-radius:6px;cursor:zoom-in}
  .dli .nmrow{display:flex;gap:4px;align-items:center}
  .dli .nmrow input{flex:1;min-width:0;padding:5px 7px;font-size:12px}
  .dli .nmrow input::placeholder{color:var(--sub);opacity:.55}
  .dli .ext{font-size:11px;color:var(--sub)}
  .dli .sz{font-size:11px;color:var(--sub);margin-top:4px}
  .dli .acts{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:6px}
  .dli .acts .btn{padding:4px 4px;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dli .ok{display:block;margin-top:3px;min-height:14px}
  .dlsel{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .dlsel .cnt{font-size:12px;color:var(--sub)}
  .dlsel .desk{margin-left:auto;font-size:11px;color:var(--sub);display:flex;gap:6px;align-items:center}
  .dlbtns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .dlbtns .big{padding:10px 6px;font-size:13px}
  .dli .ok{font-size:11px;color:var(--accent)}
  .dli .kind{font-size:10px;padding:0 6px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .savebar{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .savebar .sl{font-size:12px;font-weight:700;white-space:nowrap}
  .savebar select{width:auto;flex:1;min-width:180px;max-width:420px;padding:5px 8px;font-size:12px}
  .zoom{position:fixed;inset:0;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;z-index:2147483647;cursor:zoom-out}
  .zoom img{max-width:92vw;max-height:92vh;border-radius:6px}
  .panel{position:fixed;right:0;top:0;bottom:0;max-width:100vw;z-index:2147483647;background:var(--bg);color:var(--ink);
    border-left:1px solid var(--line);display:flex;flex-direction:column;font-size:13px;line-height:1.5}
  .panel.light{--bg:#f7f6f2;--panel:#fff;--ink:#1d1d1b;--sub:#6b6a64;--line:#e3e1da;--accent:#1f6f5c;--accent-ink:#fff;--err:#b42318;--chip:#efeee8;--drop:#e6f2ec}
  .panel.dark{--bg:#18191b;--panel:#222326;--ink:#ecebe6;--sub:#9b9a94;--line:#35363c;--accent:#4fb393;--accent-ink:#0d1f19;--err:#f07a6e;--chip:#2b2c31;--drop:#1d2d27}
  .grip{position:absolute;left:-4px;top:0;bottom:0;width:8px;cursor:ew-resize;z-index:2}
  .grip::after{content:"";position:absolute;left:3px;top:50%;width:2px;height:40px;margin-top:-20px;border-radius:2px;background:var(--line)}
  .grip:hover::after,.grip.on::after{background:var(--accent)}
  .hd{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--line);background:var(--panel)}
  .hd b{font-size:14px}
  .ver{font-size:11px;font-weight:600;color:var(--sub);background:var(--chip);border:0;border-radius:99px;padding:1px 8px;margin-left:6px;cursor:pointer;vertical-align:1px}
  .ver:hover{color:var(--ink)}
  .clog{padding:8px 14px;border-bottom:1px solid var(--line);background:var(--panel);font-size:12px}
  .clog div{display:flex;gap:8px;margin:2px 0}
  .clog b{min-width:40px;color:var(--accent);font-variant-numeric:tabular-nums}
  .x{border:0;background:none;color:var(--sub);font-size:18px;cursor:pointer;line-height:1}
  .status{padding:6px 14px;font-size:12px;color:var(--sub);border-bottom:1px solid var(--line);font-variant-numeric:tabular-nums}
  .body{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column}
  .col{display:flex;flex-direction:column;gap:10px;padding:12px 14px}
  .stack{display:flex;flex-direction:column;gap:10px}
  .panel.wide .body{flex-direction:row;overflow:hidden}
  .panel.wide .col{overflow:auto;min-height:0}
  .panel.wide #colL{flex:0 0 42%;max-width:440px;border-right:1px solid var(--line)}
  .panel.wide #colR{flex:1;min-width:0}
  .drop.slim{min-height:84px;padding:14px 12px;display:flex;flex-direction:column;gap:2px;align-items:center;justify-content:center;text-align:center}
  .drop.slim strong{font-size:14px}
  .drop.slim .dsub{font-size:11px}
  .drop:hover{border-color:var(--accent)}
  .drop.over{border-style:solid;transform:scale(1.01)}
  .drop .dsub{display:block}
  .bulk{display:flex;gap:6px;align-items:center;flex-wrap:wrap;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
  .bulk .bl{font-size:12px;font-weight:700;color:var(--ink)}
  .bulk select{width:auto;flex:1;min-width:140px;max-width:260px;padding:4px 6px;font-size:12px}
  .irow{display:flex;gap:6px;align-items:center;margin-top:4px;flex-wrap:wrap}
  .irow .tsel{width:auto;max-width:180px;margin:0;flex:none}
  .irow .meta{margin:0}
  .drop{border:2px dashed var(--line);border-radius:10px;padding:16px 10px;text-align:center;color:var(--sub);cursor:pointer;background:var(--panel)}
  .drop.over{border-color:var(--accent);background:var(--drop);color:var(--ink)}
  .drop strong{display:block;color:var(--ink);font-size:14px}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .card > summary{cursor:pointer;font-size:13px;font-weight:700;color:var(--ink)}
  .lbl{font-size:11px;color:var(--sub);margin:8px 0 3px;display:block}
  .lbl:first-child{margin-top:0}
  .row{display:flex;gap:6px;align-items:center}
  .grow{flex:1;min-width:0}
  input[type=number],input[type=text],select,textarea{width:100%;padding:6px 8px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--ink);font-size:13px}
  textarea{resize:vertical;min-height:52px}
  .chk{display:flex;gap:6px;align-items:center;font-size:12px;margin-top:6px;color:var(--ink)}
  .chk input{margin:0}
  .seg{display:flex;border:1px solid var(--line);border-radius:6px;overflow:hidden}
  .seg button{flex:1;border:0;background:var(--bg);color:var(--sub);padding:6px;font-size:12px;cursor:pointer}
  .seg button.on{background:var(--accent);color:var(--accent-ink);font-weight:700}
  .btn{border:1px solid var(--line);background:var(--panel);color:var(--ink);padding:6px 10px;border-radius:6px;font-size:12px;cursor:pointer;white-space:nowrap}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-ink);font-weight:700}
  .btn.danger{color:var(--err)}
  .btn.sm{padding:3px 8px;font-size:11px}
  .big{width:100%;padding:10px;font-size:14px}
  .hint{font-size:11px;color:var(--sub);margin-top:3px}
  .lh{display:flex;justify-content:space-between;align-items:center}
  .lh b{font-size:13px}
  .item{display:grid;grid-template-columns:22px 64px 1fr;gap:8px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px}
  .num{font-weight:800;color:var(--accent);font-size:16px;text-align:center}
  .thumb{width:64px;height:64px;object-fit:contain;background:var(--chip);border-radius:6px}
  .fn{font-size:11px;color:var(--sub);display:flex;justify-content:space-between;gap:4px;word-break:break-all;margin-bottom:3px}
  .fn button{border:0;background:none;color:var(--sub);cursor:pointer;font-size:11px;padding:0;white-space:nowrap}
  .tsel{margin-top:4px;font-size:11px;padding:3px 6px;color:var(--sub)}
  .meta{display:flex;gap:6px;align-items:center;margin-top:4px;font-size:11px;flex-wrap:wrap}
  .badge{padding:1px 8px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .badge.run{background:var(--drop);color:var(--accent)}
  .badge.done{background:var(--accent);color:var(--accent-ink)}
  .badge.err{border:1px solid var(--err);color:var(--err);background:none}
  .meta a{color:var(--accent)}
  .meta .em{color:var(--err);flex-basis:100%}
  .meta button{border:0;background:none;color:var(--accent);cursor:pointer;font-size:11px;padding:0;text-decoration:underline}
  .empty{color:var(--sub);text-align:center;padding:24px 8px;border:1px dashed var(--line);border-radius:10px;font-size:12px}
  .tpl{border:1px solid var(--line);border-radius:8px;padding:6px 8px;margin-top:6px;background:var(--bg)}
  .tpl .tn{font-weight:700;font-size:12px;display:flex;justify-content:space-between;gap:6px;align-items:center}
  .tpl .tt{font-size:11px;color:var(--sub);white-space:pre-wrap;max-height:48px;overflow:hidden;margin-top:2px}
  .tpl .ta{display:flex;gap:4px;margin-top:4px;flex-wrap:wrap}
  .ft{padding:10px 14px;border-top:1px solid var(--line);background:var(--panel);display:flex;flex-direction:column;gap:6px}
  .hero{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px}
  .hero-top{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--sub);font-variant-numeric:tabular-nums}
  .hero-main{display:flex;gap:12px;align-items:center;margin:12px 0 10px}
  .hero-main img{width:64px;height:64px;object-fit:contain;background:var(--chip);border-radius:8px;flex:none}
  .hero-main img[src=""]{display:none}
  .now{font-size:13px;color:var(--sub)}
  .now b{color:var(--ink);font-size:15px}
  .big-num{font-size:34px;font-weight:800;letter-spacing:.02em;color:var(--accent);font-variant-numeric:tabular-nums;line-height:1.1}
  .big-num small{font-size:12px;font-weight:600;color:var(--sub);margin-left:6px;letter-spacing:0}
  .steps{display:flex;gap:4px;margin-top:2px;flex-wrap:wrap}
  .steps span{font-size:10px;padding:1px 6px;border-radius:99px;background:var(--chip);color:var(--sub)}
  .steps span.on{background:var(--accent);color:var(--accent-ink)}
  .steps span.ok{color:var(--accent)}
  .bar{height:8px;border-radius:99px;background:var(--chip);overflow:hidden;margin-top:6px}
  .bar div{height:100%;background:var(--accent);width:0;transition:width .4s}
  .stats{display:flex;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px;color:var(--sub);flex-wrap:wrap;font-variant-numeric:tabular-nums}
  .stats .e{color:var(--err)}
  .dest{font-size:11px;color:var(--sub);margin-top:8px;word-break:break-all}
  .rl{display:flex;flex-direction:column;gap:4px}
  .ri{display:grid;grid-template-columns:20px 40px 1fr auto;gap:8px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font-size:12px}
  .ri.cur{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .ri img{width:40px;height:40px;object-fit:contain;background:var(--chip);border-radius:4px}
  .ri .n{font-weight:800;color:var(--accent);text-align:center}
  .ri .nm{min-width:0}
  .ri .nm div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ri .nm .p{color:var(--sub);font-size:11px}
  .ri .st{text-align:right;font-size:11px;color:var(--sub);white-space:nowrap;font-variant-numeric:tabular-nums}
  .ri .st a{color:var(--accent);display:block}
  .ri{grid-template-columns:20px 40px 1fr auto auto}
  .gens{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
  .gens img{width:40px;height:40px;object-fit:cover;border-radius:4px;border:2px solid var(--accent);cursor:pointer;background:var(--chip)}
  .gens img:hover{opacity:.8}
  .gens .btn{padding:2px 8px;font-size:11px}
  .meta .gens img{width:34px;height:34px}
  details.log-box summary{cursor:pointer;font-size:12px;color:var(--sub)}
  .log{font-size:11px;color:var(--sub);max-height:100px;overflow:auto;white-space:pre-wrap;font-family:ui-monospace,Menlo,Consolas,monospace}
  `;

  const HTML = `
  <div class="tabs" id="tabs"><button class="tab" id="tab" title="画像一括送信パネルを開く (v__VER__)">📷 一括送信</button><button class="tab dl" id="tabDl" title="開いているチャットの画像を一覧でダウンロード">⬇ 画像DL</button></div>
  <div class="zoom" id="zoom" hidden><img id="zoomImg" alt=""></div>
  <div class="panel light" id="panel" hidden>
    <div class="grip" id="grip" title="ドラッグで幅を変更（ダブルクリックで元の幅）"></div>
    <div class="hd"><div class="hd-l"><b>ChatGPTツール<button class="ver" id="ver" title="押すと更新履歴"></button></b><div class="seg modes" id="modeSeg"><button data-mode="send" class="on">📷 一括送信</button><button data-mode="dl">⬇ 画像DL</button></div></div><button class="x" id="close" title="閉じる">×</button></div>
    <div class="clog" id="clog" hidden></div>
    <div class="status" id="status">待機中</div>
    <div class="body">
      <div class="col" id="colL">
        <div id="setupL" class="stack">
          <div class="card">
            <span class="lbl">送信先</span>
            <div class="seg" id="destSeg">
              <button data-dest="new" class="on">毎回新しいチャット</button>
              <button data-dest="url">指定したURL</button>
            </div>
            <div id="destUrlBox" hidden>
              <span class="lbl">最近の項目から選ぶ</span>
              <div class="row"><select id="recent" class="grow"><option value="">― 選択してください ―</option></select>
                <button class="btn sm" id="recentRefresh" title="一覧を読み込み直す">↻</button></div>
              <span class="lbl">またはURLを入力</span>
              <div class="row"><input type="text" id="destUrl" class="grow" placeholder="https://chatgpt.com/c/… やプロジェクトのURL">
                <button class="btn sm" id="useCurrent" title="今開いているページのURLを入れる">今のページ</button></div>
              <div class="hint">チャットのURL → そのチャットに続けて送信／プロジェクト・GPTのURL → その中で毎回新しいチャット</div>
            </div>
            <span class="lbl">送信間隔</span>
            <div class="row">
              <input type="number" id="ival" min="1" value="1" style="width:70px">
              <select id="iunit" style="width:110px"><option value="1">秒ごと</option><option value="60" selected>分ごと</option><option value="3600">時間ごと</option></select>
              <label class="chk" style="margin:0 0 0 4px"><input type="checkbox" id="firstNow" checked>1枚目はすぐ</label>
            </div>
            <div class="hint">前の生成が終わってから数え始めます</div>
            <label class="chk" style="margin-top:8px"><input type="checkbox" id="autoDl" checked>生成された画像を自動でダウンロード</label>
            <div class="hint">保存名：元のファイル名_gen.png ／ <span id="autoDlWhere">保存先：ダウンロードフォルダ</span>（一番下で変更）</div>
          </div>

          <div class="card">
            <span class="lbl">全画像に共通で付ける指示（任意）</span>
            <textarea id="common" rows="3" placeholder="例：この画像を元に、商品写真風の画像を生成して"></textarea>
            <select class="tsel" id="commonTpl"></select>
          </div>

          <div class="card" id="tplCard">
            <div class="lh"><span class="lbl" style="margin:0">指示テンプレ（<span id="tplCount">0</span>件）</span>
              <button class="btn sm" id="tplToggle">＋ 新規登録</button></div>
            <div id="tplForm" hidden style="margin-top:6px">
              <input type="text" id="tplName" placeholder="名前（例：背景を白に）">
              <textarea id="tplText" rows="3" placeholder="指示の文章" style="margin-top:4px"></textarea>
              <div class="row" style="margin-top:4px;justify-content:flex-end"><button class="btn sm" id="tplCancel">やめる</button><button class="btn primary sm" id="tplAdd">登録</button></div>
            </div>
            <div id="tplList"></div>
          </div>
        </div>

        <div id="runL" class="stack" hidden>
          <div class="hero">
            <div class="hero-top"><span class="badge run" id="rvState">実行中</span><span id="rvElapsed">経過 0:00</span></div>
            <div class="hero-main">
              <img id="rvThumb" src="" alt="">
              <div style="min-width:0;flex:1">
                <div class="now" id="rvNow">準備中…</div>
                <div class="big-num" id="rvBig">--:--</div>
                <div class="steps" id="rvSteps"></div>
              </div>
            </div>
            <div class="bar"><div id="rvBar"></div></div>
            <div class="stats"><span id="rvDone">0 / 0 完了</span><span id="rvErr"></span><span id="rvEta"></span></div>
            <div class="dest" id="rvDest"></div>
          </div>
        </div>

        <details class="card log-box"><summary>ログ</summary><div class="log" id="log"></div></details>
      </div>

      <div class="col" id="colR">
        <div id="setupR" class="stack">
          <div class="lh"><b id="count">画像一覧（0枚）</b><button class="btn danger sm" id="clear">全部クリア</button></div>
          <div class="drop" id="drop"><strong>ここに画像をドラッグ＆ドロップ</strong><span class="dsub">まとめてOK・ファイル名順に並びます（クリックで選択も可）</span>
            <input type="file" id="file" accept="image/*" multiple hidden></div>
          <div class="bulk" id="bulk" hidden>
            <span class="bl">一括でテンプレ</span>
            <select id="bulkTpl"></select>
            <button class="btn sm primary" id="bulkAdd" title="全部の画像の指示の後ろに追加">全部に追加</button>
            <button class="btn sm" id="bulkReplace" title="全部の画像の指示をこのテンプレで置き換え">全部置き換え</button>
            <button class="btn sm" id="bulkEmpty" title="指示が空の画像だけに入れる">空欄だけ</button>
            <button class="btn sm danger" id="bulkClear" title="全部の画像の指示を消す">指示を全消し</button>
          </div>
          <div id="items"></div>
        </div>
        <div id="runR" class="stack" hidden>
          <div class="lh"><b>送信の順番</b><button class="btn sm primary" id="dlAll" hidden>生成画像をまとめてDL</button></div>
          <div class="rl" id="rvList"></div>
        </div>
      </div>

      <div class="col" id="dlView" hidden style="flex:1;min-width:0">
        <div class="lh"><b id="dlTitle">このチャットの画像</b>
          <div class="row"><label class="chk" style="margin:0"><input type="checkbox" id="dlIncUser">添付した画像も表示</label>
          <button class="btn sm" id="dlRefresh">↻ 読み込み直す</button></div></div>
        <div class="dlbar">
          <span class="bl">名前をまとめて付ける</span>
          <input type="text" id="dlBase" placeholder="例：商品A">
          <button class="btn sm" id="dlNumber" title="ベース名_01, _02 … の連番を付ける">連番を付ける</button>

        </div>
        <div class="dlgrid" id="dlList"></div>
      </div>
    </div>
    <div class="ft">
      <div class="savebar">
        <span class="sl">保存先</span>
        <select id="saveDir"></select>
        <button class="btn sm" id="savePick" title="保存するフォルダを選ぶ">📁 フォルダを選ぶ</button>
        <button class="btn sm" id="saveForget" title="このフォルダを一覧から外す" hidden>外す</button>
      </div>
      <button class="btn primary big" id="start" disabled>OK（送信開始）</button>
      <button class="btn danger big" id="stop" hidden>停止</button>
      <button class="btn big" id="back" hidden>設定画面に戻る</button>
      <div id="dlFoot" hidden style="display:flex;flex-direction:column;gap:6px">
        <div class="dlsel">
          <button class="btn sm" id="dlAllOn">☑ 全件選択</button>
          <button class="btn sm" id="dlAllOff">☐ 全件解除</button>
          <span class="cnt" id="dlCount"></span>
          <span class="desk"><span id="deskName">🖥 デスクトップ：未設定（初回に場所を選びます）</span><button class="btn sm" id="deskPick">選び直す</button></span>
        </div>
        <div class="dlbtns">
          <button class="btn primary big" id="dlSelSave">⬇ 選択した画像を保存先へDL</button>
          <button class="btn big" id="dlSelDesk">🖥 選択した画像をデスクトップにDL</button>
        </div>
      </div>
    </div>
  </div>`;

  // ---------- ChatGPT本体を右側だけ狭くする ----------
  function applyLayout() {
    const maxW = Math.max(MIN_W, Math.round(window.innerWidth * 0.75));
    const w = Math.min(Math.max(state.width, MIN_W), maxW);
    $('panel').style.width = w + 'px';
    $('panel').classList.toggle('wide', w >= WIDE_AT);
    let st = document.getElementById(PUSH_ID);
    if (!st) { st = document.createElement('style'); st.id = PUSH_ID; (document.head || document.documentElement).appendChild(st); }
    st.textContent = state.open ? `
      html{margin-right:${w}px !important}
      #root > div{width:100% !important;max-width:100% !important}
      header.fixed{right:${w}px !important;width:auto !important;max-width:calc(100vw - ${w}px) !important}` : '';
  }

  function setOpen(o) {
    state.open = o;
    $('panel').hidden = !o; $('tabs').hidden = o;
    if (o) refreshRecent();
    applyLayout();
  }

  function initResize() {
    const grip = $('grip');
    let dragging = false;
    grip.addEventListener('pointerdown', e => {
      dragging = true; grip.classList.add('on'); grip.setPointerCapture(e.pointerId);
      document.documentElement.style.userSelect = 'none'; e.preventDefault();
    });
    grip.addEventListener('pointermove', e => {
      if (!dragging) return;
      state.width = Math.round(window.innerWidth - e.clientX);
      applyLayout();
    });
    const end = e => {
      if (!dragging) return;
      dragging = false; grip.classList.remove('on');
      try { grip.releasePointerCapture(e.pointerId); } catch (_) {}
      document.documentElement.style.userSelect = '';
      state.width = parseInt($('panel').style.width, 10) || defW();
      store.set('panelWidth', state.width);
    };
    grip.addEventListener('pointerup', end);
    grip.addEventListener('pointercancel', end);
    grip.addEventListener('dblclick', () => { state.width = defW(); store.set('panelWidth', null); applyLayout(); });
    window.addEventListener('resize', () => { if (!store.get('panelWidth', null)) state.width = defW(); if (state.open) applyLayout(); });
  }

  // ---------- 送信先 ----------
  function destMode() { return store.get('dest', 'new'); }
  function setDest(m) {
    store.set('dest', m);
    root.querySelectorAll('#destSeg button').forEach(b => b.classList.toggle('on', b.dataset.dest === m));
    $('destUrlBox').hidden = m !== 'url';
  }
  function refreshRecent() {
    const sel = $('recent'), keep = $('destUrl').value;
    const links = cg.recentLinks();
    sel.innerHTML = `<option value="">― ${links.length ? '選択してください' : 'サイドバーに項目が見つかりません'} ―</option>` +
      links.map(l => `<option value="${esc(location.origin + l.href)}">${esc(l.title)}</option>`).join('');
    if (keep) sel.value = [...sel.options].some(o => o.value === keep) ? keep : '';
  }

  // ---------- テンプレ ----------
  const tpls = () => store.get('templates', []);
  function saveTpls(list) { store.set('templates', list); renderTpls(); }
  function insertInto(ta, text) {
    ta.value = ta.value.trim() ? ta.value.replace(/\s+$/, '') + '\n' + text : text;
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function tplOptions() {
    return `<option value="">＋ テンプレを入れる…</option>` + tpls().map((t, i) => `<option value="${i}">${esc(t.name)}</option>`).join('');
  }
  function renderTpls() {
    const list = tpls();
    $('tplCount').textContent = list.length;
    $('tplList').innerHTML = list.length ? '' : '<div class="hint" style="margin-top:6px">まだありません。「＋ 新規登録」から作れます。</div>';
    list.forEach((t, i) => {
      const d = document.createElement('div'); d.className = 'tpl';
      d.innerHTML = `<div class="tn"><span>${esc(t.name)}</span></div><div class="tt">${esc(t.text)}</div>
        <div class="ta"><button class="btn sm" data-a="all" title="全部の画像の指示欄に入れる">全部に入れる</button><button class="btn sm" data-a="empty" title="指示が空の画像だけに入れる">空欄だけ</button>
        <button class="btn sm" data-a="edit">編集</button><button class="btn sm danger" data-a="del">削除</button></div>`;
      d.querySelector('[data-a=all]').onclick = () => applyTplToItems(t.text, 'add');
      d.querySelector('[data-a=empty]').onclick = () => applyTplToItems(t.text, 'empty');
      d.querySelector('[data-a=edit]').onclick = () => {
        state.tplForm(true);
        $('tplName').value = t.name; $('tplText').value = t.text; $('tplAdd').textContent = '上書き保存';
        $('tplAdd').dataset.edit = i;
      };
      d.querySelector('[data-a=del]').onclick = () => {
        const b = d.querySelector('[data-a=del]');
        if (b.dataset.armed) { const l = tpls(); l.splice(i, 1); saveTpls(l); }
        else { b.dataset.armed = 1; b.textContent = 'もう一度押すと削除'; setTimeout(() => { b.dataset.armed = ''; b.textContent = '削除'; }, 3000); }
      };
      $('tplList').appendChild(d);
    });
    root.querySelectorAll('select.tsel').forEach(s => { s.innerHTML = tplOptions(); });
    const bs = $('bulkTpl'), keep = bs.value;
    bs.innerHTML = list.length ? list.map((t, i) => `<option value="${i}">${esc(t.name)}</option>`).join('') : '<option value="">（テンプレ未登録）</option>';
    if (keep && list[+keep]) bs.value = keep;
    ['bulkAdd', 'bulkReplace', 'bulkEmpty'].forEach(id => { $(id).disabled = !list.length; });
  }
  function applyTplToItems(text, mode) {
    if (mode === true) mode = 'empty'; else if (mode === false) mode = 'add';
    let n = 0;
    state.items.forEach(it => {
      if (it.status !== 'wait') return;
      const has = !!it.prompt.trim();
      if (mode === 'empty' && has) return;
      if (mode === 'clear') { if (has) { it.prompt = ''; n++; } return; }
      it.prompt = mode === 'replace' || !has ? text : it.prompt.replace(/\s+$/, '') + '\n' + text; n++;
    });
    root.querySelectorAll('.item').forEach(el => {
      const it = state.items.find(x => x.id === +el.dataset.id); if (it) el.querySelector('textarea.pr').value = it.prompt;
    });
    log(mode === 'clear' ? `${n}枚の指示を消しました` : `テンプレを${n}枚に入れました`);
    return n;
  }

  // ---------- 組み立て ----------
  function build() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement('div'); host.id = HOST_ID;
    document.documentElement.appendChild(host);
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>${HTML}`;

    const dark = matchMedia('(prefers-color-scheme: dark)').matches || document.documentElement.classList.contains('dark');
    $('panel').classList.replace('light', dark ? 'dark' : 'light');

    $('ver').textContent = 'v' + VERSION;
    $('tab').title = $('tab').title.replace('__VER__', VERSION);
    $('clog').innerHTML = CHANGELOG.map(([v, t]) => `<div><b>v${v}</b><span>${esc(t)}</span></div>`).join('');
    $('ver').onclick = () => { $('clog').hidden = !$('clog').hidden; };
    log('ChatGPT 画像一括送信 v' + VERSION + ' を読み込みました');
    state.width = store.get('panelWidth', null) || defW();
    $('tab').onclick = () => { setOpen(true); setMode('send'); };
    $('tabDl').onclick = () => { setOpen(true); setMode('dl'); };
    root.querySelectorAll('#modeSeg button').forEach(b => b.onclick = () => setMode(b.dataset.mode));
    initDl();
    initSaveBar();
    $('close').onclick = () => setOpen(false);
    initResize();
    setOpen(false); // 最初はボタンだけ

    [['ival', 'value'], ['iunit', 'value'], ['firstNow', 'checked'], ['autoDl', 'checked'], ['common', 'value'], ['destUrl', 'value']].forEach(([id, prop]) => {
      const v = store.get(id, null); if (v !== null) $(id)[prop] = v;
      $(id).addEventListener('change', () => store.set(id, $(id)[prop]));
    });

    // 送信先
    root.querySelectorAll('#destSeg button').forEach(b => b.onclick = () => { if (!state.running) setDest(b.dataset.dest); });
    setDest(destMode());
    $('recent').onchange = () => { if ($('recent').value) { $('destUrl').value = $('recent').value; store.set('destUrl', $('destUrl').value); } };
    $('recentRefresh').onclick = refreshRecent;
    $('useCurrent').onclick = () => { $('destUrl').value = location.href; store.set('destUrl', location.href); refreshRecent(); };

    // テンプレ
    const tplForm = o => { $('tplForm').hidden = !o; $('tplToggle').hidden = o; if (!o) { $('tplName').value = ''; $('tplText').value = ''; $('tplAdd').textContent = '登録'; $('tplAdd').dataset.edit = ''; } else $('tplName').focus(); };
    state.tplForm = tplForm;
    $('tplToggle').onclick = () => tplForm(true);
    $('tplCancel').onclick = () => tplForm(false);
    $('tplAdd').onclick = () => {
      const name = $('tplName').value.trim(), text = $('tplText').value.trim();
      if (!name || !text) return log('テンプレの名前と文章を入れてください');
      const list = tpls();
      const ei = $('tplAdd').dataset.edit;
      if (ei !== undefined && ei !== '') list[+ei] = { name, text }; else list.push({ name, text });
      $('tplName').value = ''; $('tplText').value = ''; $('tplAdd').textContent = '登録'; $('tplAdd').dataset.edit = '';
      saveTpls(list); log(`テンプレ「${name}」を保存`); tplForm(false);
    };
    const bulkTpl = () => tpls()[+$('bulkTpl').value];
    const flash = (id, msg) => { const b = $(id), t = b.textContent; b.textContent = msg; setTimeout(() => b.textContent = t, 1200); };
    $('bulkAdd').onclick = () => { const t = bulkTpl(); if (t) flash('bulkAdd', `✓ ${applyTplToItems(t.text, 'add')}枚`); };
    $('bulkReplace').onclick = () => { const t = bulkTpl(); if (t) flash('bulkReplace', `✓ ${applyTplToItems(t.text, 'replace')}枚`); };
    $('bulkEmpty').onclick = () => { const t = bulkTpl(); if (t) flash('bulkEmpty', `✓ ${applyTplToItems(t.text, 'empty')}枚`); };
    let clearArmed = 0;
    $('bulkClear').onclick = () => {
      if (Date.now() - clearArmed > 3000) { clearArmed = Date.now(); $('bulkClear').textContent = 'もう一度押すと消去'; setTimeout(() => $('bulkClear').textContent = '指示を全消し', 3000); return; }
      clearArmed = 0; $('bulkClear').textContent = '指示を全消し'; applyTplToItems('', 'clear');
    };
    $('commonTpl').onchange = e => {
      const t = tpls()[+e.target.value]; if (t) insertInto($('common'), t.text); e.target.value = '';
    };

    // ドロップ
    $('drop').onclick = () => $('file').click();
    $('file').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
    panelApi = {
      onDragOver() { $('drop').classList.add('over'); },
      onDragLeave(e) { if (!e.relatedTarget || !inPanel({ composedPath: () => [e.relatedTarget, ...ancestors(e.relatedTarget)] })) $('drop').classList.remove('over'); },
      onDrop(e) { $('drop').classList.remove('over'); if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files); },
    };

    let armed = 0;
    $('clear').onclick = () => {
      if (state.running) return log('停止してからクリアしてください');
      if (Date.now() - armed > 3000) { armed = Date.now(); $('clear').textContent = 'もう一度押すとクリア'; setTimeout(() => $('clear').textContent = '全部クリア', 3000); return; }
      state.items.forEach(it => URL.revokeObjectURL(it.url));
      state.items = []; render(); $('clear').textContent = '全部クリア';
    };

    $('start').onclick = start;
    $('stop').onclick = () => stop('停止しました');
    $('back').onclick = () => { showView(false); render(); };
    $('dlAll').onclick = async () => { const n = await downloadAll(state.runItems); log(`まとめて${n}枚ダウンロード`); };
    window.addEventListener('beforeunload', e => { if (state.running) { e.preventDefault(); e.returnValue = ''; } });

    renderTpls();
    render();
  }

  function ancestors(n) { const a = []; while (n) { n = n.parentNode || n.host; if (n) a.push(n); } return a; }

  function addFiles(list) {
    const files = [...list].filter(f => f.type.startsWith('image/'));
    if (!files.length) return log('画像ファイルが見つかりませんでした');
    for (const f of files) {
      const ex = state.items.find(it => it.file.name === f.name);
      if (ex) { URL.revokeObjectURL(ex.url); ex.file = f; ex.url = URL.createObjectURL(f); continue; }
      state.items.push({ id: ++uid, file: f, url: URL.createObjectURL(f), prompt: '', status: 'wait' });
    }
    state.items.sort((a, b) => collator.compare(a.file.name, b.file.name));
    render();
    log(`${files.length}枚追加（合計${state.items.length}枚）`);
  }

  function render() {
    const box = $('items');
    $('count').textContent = `画像一覧（${state.items.length}枚）`;
    $('drop').classList.toggle('slim', state.items.length > 0);
    $('bulk').hidden = !state.items.length;
    $('drop').querySelector('strong').textContent = state.items.length ? '＋ 画像を追加' : 'ここに画像をドラッグ＆ドロップ';
    $('drop').querySelector('.dsub').textContent = state.items.length ? 'ドロップ／クリックで追加（名前順に並び替え）' : 'まとめてOK・ファイル名順に並びます（クリックで選択も可）';
    $('start').disabled = state.running || !state.items.some(it => it.status === 'wait');
    if (!state.items.length) { box.innerHTML = '<div class="empty">画像をドロップすると、ここに 1番・2番・3番… と並びます。<br>それぞれに指示を書いて「OK」を押してください。</div>'; return; }
    box.querySelectorAll('.empty').forEach(e => e.remove());
    box.style.cssText = 'display:flex;flex-direction:column;gap:8px';
    const existing = new Map([...box.querySelectorAll('.item')].map(el => [+el.dataset.id, el]));
    state.items.forEach((it, i) => {
      const el = existing.get(it.id) || buildRow(it);
      existing.delete(it.id);
      el.querySelector('.num').textContent = i + 1;
      el.querySelector('.thumb').src = it.url;
      el.querySelector('.fn span').textContent = it.file.name;
      const locked = state.running && it.status !== 'wait';
      el.querySelector('textarea.pr').disabled = locked;
      el.querySelector('select.tsel').disabled = locked;
      el.querySelector('.fn button').style.visibility = state.running ? 'hidden' : '';
      renderMeta(el, it);
      box.appendChild(el);
    });
    existing.forEach(el => el.remove());
  }

  function buildRow(it) {
    const el = document.createElement('div');
    el.className = 'item'; el.dataset.id = it.id;
    el.innerHTML = `<div class="num"></div><img class="thumb" alt="">
      <div><div class="fn"><span></span><button>✕ 外す</button></div>
      <textarea class="pr" rows="2" placeholder="この画像への指示（例：背景を夕焼けの海辺に変えて）"></textarea>
      <div class="irow"><select class="tsel">${tplOptions()}</select><div class="meta"></div></div></div>`;
    const ta = el.querySelector('textarea.pr');
    ta.value = it.prompt;
    ta.addEventListener('input', () => { it.prompt = ta.value; });
    el.querySelector('select.tsel').onchange = e => {
      const t = tpls()[+e.target.value]; if (t) insertInto(ta, t.text); e.target.value = '';
    };
    el.querySelector('.fn button').onclick = () => { URL.revokeObjectURL(it.url); state.items = state.items.filter(x => x !== it); render(); };
    return el;
  }

  function renderMeta(el, it) {
    const m = el.querySelector('.meta');
    const label = { wait: '未送信', run: '送信・生成中…', done: '完了', err: 'エラー' }[it.status];
    m.innerHTML = `<span class="badge ${it.status}">${label}</span>`;
    if (it.results?.length) { const g = document.createElement('span'); g.innerHTML = gensHtml(it); m.appendChild(g.firstChild); bindGens(m, it); }
    if (it.chatUrl) { const a = document.createElement('a'); a.href = it.chatUrl; a.textContent = 'チャットを開く'; a.target = '_blank'; m.appendChild(a); }
    if ((it.status === 'done' || it.status === 'err') && !state.running) {
      const b = document.createElement('button'); b.textContent = 'もう一度送る';
      b.onclick = () => { setResults(it, []); Object.assign(it, { status: 'wait', error: null, chatUrl: null }); render(); };
      m.appendChild(b);
    }
    if (it.status === 'err') { const d = document.createElement('div'); d.className = 'em'; d.textContent = it.error; m.appendChild(d); }
  }

  // ---------- 保存先フォルダ ----------
  // 選んだフォルダはこのブラウザ内（IndexedDB）に覚えておき、次回からプルダウンで切り替えられる
  const idb = {
    open() {
      return new Promise((ok, ng) => {
        const r = indexedDB.open('cgb-save', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('kv');
        r.onsuccess = () => ok(r.result); r.onerror = () => ng(r.error);
      });
    },
    async get(k) { const db = await this.open(); return new Promise(ok => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => ok(q.result); q.onerror = () => ok(undefined); }); },
    async set(k, v) { const db = await this.open(); return new Promise(ok => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = () => ok(); t.onerror = () => ok(); }); },
  };
  const save = { dirs: [], idx: -1 };
  const canPickDir = typeof window.showDirectoryPicker === 'function';
  const curDir = () => save.idx >= 0 ? save.dirs[save.idx] : null;

  async function loadSaveDirs() {
    try { save.dirs = (await idb.get('dirs')) || []; } catch (e) { save.dirs = []; }
    save.idx = Math.min(store.get('saveIdx', -1), save.dirs.length - 1);
    renderSaveBar();
  }
  async function persistDirs() { try { await idb.set('dirs', save.dirs); } catch (e) {} store.set('saveIdx', save.idx); }

  function renderSaveBar() {
    const sel = $('saveDir'); if (!sel) return;
    sel.innerHTML = `<option value="-1">📥 ダウンロードフォルダ（いつもの場所）</option>` +
      save.dirs.map((d, i) => `<option value="${i}">📁 ${esc(d.name)}</option>`).join('') +
      (canPickDir ? `<option value="pick">＋ 別のフォルダを選ぶ…</option>` : '');
    sel.value = String(save.idx);
    $('savePick').hidden = !canPickDir;
    $('saveForget').hidden = save.idx < 0;
    $('autoDlWhere').textContent = curDir() ? `保存先：📁 ${curDir().name}` : '保存先：ダウンロードフォルダ';
  }

  async function pickDir() {
    try {
      const h = await window.showDirectoryPicker({ id: 'cgb-save', mode: 'readwrite', startIn: curDir()?.handle || 'downloads' });
      let i = -1;
      for (let k = 0; k < save.dirs.length; k++) { try { if (await save.dirs[k].handle.isSameEntry(h)) { i = k; break; } } catch (e) {} }
      const entry = i >= 0 ? save.dirs.splice(i, 1)[0] : { name: h.name, handle: h };
      save.dirs.unshift(entry); save.dirs = save.dirs.slice(0, 8); save.idx = 0;
      await persistDirs(); log(`保存先を「${h.name}」にしました`);
    } catch (e) { if (e.name !== 'AbortError') log('フォルダを選べませんでした：' + e.message); }
    renderSaveBar();
  }

  // ---------- デスクトップ ----------
  // ブラウザからは決まった場所へ直接書けないため、最初の1回だけデスクトップを選んでもらい、その場所を覚えておく
  const desk = { handle: null };
  async function loadDesktop() { try { desk.handle = (await idb.get('desktop')) || null; } catch (e) { desk.handle = null; } renderDeskName(); }
  function renderDeskName() {
    const el = root?.getElementById('deskName'); if (!el) return;
    el.textContent = !canPickDir ? '🖥 このブラウザでは直接保存できないため、ダウンロードフォルダに保存します'
      : desk.handle ? `🖥 デスクトップ：「${desk.handle.name}」に保存` : '🖥 デスクトップ：未設定（初回に場所を選びます）';
    $('deskPick').hidden = !canPickDir || !desk.handle;
  }
  async function pickDesktop() {
    try {
      const h = await window.showDirectoryPicker({ id: 'cgb-desktop', mode: 'readwrite', startIn: 'desktop' });
      desk.handle = h; await idb.set('desktop', h);
      log(`デスクトップの保存場所を「${h.name}」にしました`);
    } catch (e) { if (e.name !== 'AbortError') log('デスクトップを選べませんでした：' + e.message); }
    renderDeskName();
    return desk.handle;
  }
  // ユーザー操作の直後に呼ぶ：未設定なら選択画面、設定済みなら書き込み許可を確認
  async function ensureDesktop() {
    if (!canPickDir) return false;
    if (!desk.handle) return !!(await pickDesktop());
    return ensureHandlePermission(desk.handle, true);
  }
  async function ensureHandlePermission(handle, interactive) {
    try {
      if (await handle.queryPermission({ mode: 'readwrite' }) === 'granted') return true;
      if (!interactive) return false;
      return (await handle.requestPermission({ mode: 'readwrite' })) === 'granted';
    } catch (e) { return false; }
  }

  // ユーザー操作の直後に呼ぶと、必要ならフォルダへの書き込み許可を確認する
  async function ensureDirPermission(interactive) {
    const d = curDir(); if (!d) return true;
    try {
      if (await d.handle.queryPermission({ mode: 'readwrite' }) === 'granted') return true;
      if (!interactive) return false;
      return (await d.handle.requestPermission({ mode: 'readwrite' })) === 'granted';
    } catch (e) { return false; }
  }

  async function uniqueName(dir, name) {
    const dot = name.lastIndexOf('.'), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : '';
    for (let n = 1; n < 1000; n++) {
      const cand = n === 1 ? name : `${base} (${n})${ext}`;
      try { await dir.getFileHandle(cand); } catch (e) { return cand; } // 存在しなければ使う
    }
    return `${base}_${Date.now()}${ext}`;
  }

  // 保存先フォルダがあればそこへ、なければ通常のダウンロード
  // target: 'save'＝一番下の保存先 ／ 'desk'＝デスクトップ
  async function saveBlob(blob, filename, interactive = false, target = 'save') {
    const d = target === 'desk' ? (desk.handle ? { name: desk.handle.name, handle: desk.handle } : null) : curDir();
    if (target === 'desk' && !d) log('デスクトップが未設定のため、ダウンロードフォルダに保存しました');
    if (d) {
      try {
        if (await ensureHandlePermission(d.handle, interactive)) {
          const name = await uniqueName(d.handle, filename);
          const fh = await d.handle.getFileHandle(name, { create: true });
          const w = await fh.createWritable(); await w.write(blob); await w.close();
          return `${target === 'desk' ? '🖥' : '📁'} ${d.name}/${name}`;
        }
        log(`「${d.name}」への書き込み許可がないため、ダウンロードフォルダに保存しました（保存先の「許可」を押すと次から直接保存されます）`);
      } catch (e) { log(`「${d.name}」に保存できなかったため、ダウンロードフォルダに保存しました：${e.message}`); }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return `📥 ${filename}`;
  }

  function initSaveBar() {
    $('saveDir').onchange = async e => {
      if (e.target.value === 'pick') { e.target.value = String(save.idx); await pickDir(); return; }
      save.idx = +e.target.value; await persistDirs(); renderSaveBar();
      if (curDir()) await ensureDirPermission(true);
      log(curDir() ? `保存先を「${curDir().name}」に切り替え` : '保存先をダウンロードフォルダに切り替え');
    };
    $('savePick').onclick = pickDir;
    $('saveForget').onclick = async () => {
      const d = curDir(); if (!d) return;
      save.dirs.splice(save.idx, 1); save.idx = -1; await persistDirs(); renderSaveBar();
      log(`「${d.name}」を保存先の一覧から外しました`);
    };
    loadSaveDirs();
  }

  // ---------- 生成画像のダウンロード ----------
  function setResults(it, blobs) {
    (it.results || []).forEach(r => URL.revokeObjectURL(r.url));
    it.results = (blobs || []).map(b => ({ blob: b, url: URL.createObjectURL(b) }));
  }
  function dlName(it, k) {
    const base = it.file.name.replace(/\.[^.]+$/, '');
    const r = it.results[k];
    const ext = (r.blob.type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '');
    return `${base}_gen${it.results.length > 1 ? k + 1 : ''}.${ext}`;
  }
  async function downloadOne(it, k, interactive = false) {
    const where = await saveBlob(it.results[k].blob, dlName(it, k), interactive);
    log('保存：' + where);
  }
  async function downloadItem(it, interactive = false) {
    if (interactive) await ensureDirPermission(true);
    for (let k = 0; k < (it.results || []).length; k++) { await downloadOne(it, k); await sleep(300); }
    if (it.results?.length) log(`${it.file.name} の生成画像を${it.results.length}枚ダウンロード`);
  }
  async function downloadAll(list) {
    await ensureDirPermission(true);
    const targets = list.filter(it => it.results?.length);
    for (const it of targets) await downloadItem(it);
    return targets.reduce((n, it) => n + it.results.length, 0);
  }
  function gensHtml(it) {
    if (!it.results?.length) return '';
    return `<span class="gens">${it.results.map((r, k) => `<img src="${r.url}" data-k="${k}" title="クリックでダウンロード：${esc(dlName(it, k))}">`).join('')}<button class="btn" data-dl="1">DL</button></span>`;
  }
  function bindGens(scope, it) {
    scope.querySelectorAll('.gens img').forEach(img => img.onclick = () => downloadOne(it, +img.dataset.k, true));
    const b = scope.querySelector('.gens [data-dl]'); if (b) b.onclick = () => downloadItem(it, true);
  }

  // ---------- 画像DL（開いているチャットの画像一覧） ----------
  const dl = { list: [], names: new Map(), done: new Map(), off: new Set(), path: '', timer: null };
  const safeName = s => String(s).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120);
  // チャット名：サイドバーで今のURLを指している項目を優先（ページ名は切り替えが遅れることがある）
  const chatTitle = () => {
    const path = location.pathname;
    const a = [...document.querySelectorAll('nav a[href], aside a[href]')].find(x => x.getAttribute('href') === path && !x.closest('#' + HOST_ID));
    const t = (a?.innerText || '').trim().split('\n')[0] || (document.title || '').replace(/\s*[-|]\s*ChatGPT\s*$/i, '');
    return safeName(t) || 'ChatGPT';
  };
  const extOf = type => ((type || '').split('/')[1] || 'png').replace('jpeg', 'jpg').replace(/[^a-z0-9]/g, '') || 'png';

  // 名前が空のときの見本・保存名：x-01, x-02 …
  const defaultDlName = i => `x-${String(Math.max(0, i) + 1).padStart(2, '0')}`;

  function setMode(m) {
    state.mode = m;
    root.querySelectorAll('#modeSeg button').forEach(b => b.classList.toggle('on', b.dataset.mode === m));
    const isDl = m === 'dl';
    $('colL').hidden = isDl; $('colR').hidden = isDl; $('dlView').hidden = !isDl;
    $('dlFoot').hidden = !isDl;
    if (isDl) {
      $('start').hidden = true; $('stop').hidden = true; $('back').hidden = true;
      refreshDl();
      clearInterval(dl.timer);
      dl.timer = setInterval(dlWatch, 700);
    } else {
      clearInterval(dl.timer); dl.timer = null;
      showView(!!state.runView);
    }
  }

  function scanChatImages() {
    const main = chatMain();
    const genList = cg.generatedImgs();
    const gens = new Set(genList);
    const thumbSrc = new Set(cg.thumbImgs(main).map(i => i.currentSrc || i.src));
    const incUser = $('dlIncUser').checked;
    const seen = new Set(), out = [];
    // 生成画像はサムネイル順に並べた一覧を基準に、添付画像は画面の順番で差し込む
    const ordered = [...new Set([...main.querySelectorAll('img'), ...genList])]
      .sort((a, b) => a === b ? 0 : (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
    ordered.forEach(i => {
      if (!gens.has(i) && thumbSrc.has(i.currentSrc || i.src)) return; // 大きい表示はサムネイル側で数える
      if (i.closest('#' + HOST_ID) || i.closest('form')) return;
      const src = i.currentSrc || i.src;
      if (!src || seen.has(src) || /^data:image\/svg/.test(src)) return;
      const isGen = gens.has(i);
      const isUser = !isGen && (/添付|Uploaded/i.test(i.alt || '') || (i.naturalWidth >= 200 && i.naturalHeight >= 200));
      if (/^data:|^about:/.test(src)) return;
      if (!isGen && !(incUser && isUser)) return;
      if (dl.prevSrcs && dl.prevSrcs.has(src)) return;
      seen.add(src);
      out.push({ src, kind: isGen ? 'gen' : 'user', w: i.naturalWidth, h: i.naturalHeight });
    });
    return out;
  }

  // 画面の監視：チャットを移ったら、新しいチャットの画像が出そろうまで数秒間取り直し続ける
  function dlSig() { return location.pathname + '|' + scanChatImages().map(e => e.src).join('|'); }
  function dlWatch() {
    if (!state.open || state.mode !== 'dl') return;
    try {
      if (location.pathname !== dl.path) {
        dl.prevSrcs = new Set(dl.list.map(e => e.src)); // 移動直後に残っている前のチャットの画像は出さない
        dl.settleUntil = Date.now() + 8000; dl.loading = true; refreshDl(); return;
      }
      const sig = dlSig();
      if (sig !== dl.sig) { refreshDl(); if (dl.loading) dl.settleUntil = Math.max(dl.settleUntil, Date.now() + 4000); }
      else if (dl.loading && Date.now() > dl.settleUntil) { dl.loading = false; dl.prevSrcs = null; refreshDl(); }
    } catch (e) { log('画像一覧の更新でエラー：' + e.message); }
  }
  function renderDlTitle() {
    $('dlTitle').textContent = `「${chatTitle()}」の画像（${dl.list.length}枚）${dl.loading ? ' 読み込み中…' : ''}`;
  }
  function refreshDl(manual) {
    if (manual) { dl.loading = true; dl.settleUntil = Date.now() + 6000; }
    dl.path = location.pathname;
    const title = chatTitle();
    dl.list = scanChatImages();
    dl.sig = location.pathname + '|' + dl.list.map(e => e.src).join('|');
    dl.renderedSig = dl.sig;
    renderDlTitle();
    $('dlBase').placeholder = '例：商品A（空のまま押すと x-01, x-02…）';
    renderDl();
  }

  function renderDl() {
    const box = $('dlList');
    if (!dl.list.length) {
      box.innerHTML = dl.loading
        ? '<div class="empty" style="grid-column:1/-1">画像を探しています…</div>'
        : '<div class="empty" style="grid-column:1/-1">このチャットに生成画像が見つかりません。<br>自分が添付した画像は「添付した画像も表示」にチェックすると出ます。</div>';
      updateDlBtn(); return;
    }
    box.innerHTML = dl.list.map((e, i) => `
      <div class="dli${dl.off.has(e.src) ? ' off' : ''}" data-i="${i}">
        <input type="checkbox" class="ck" ${dl.off.has(e.src) ? '' : 'checked'}>
        <img src="${esc(e.src)}" alt="">
        <div style="min-width:0">
          <div class="nmrow"><input type="text" class="nm" value="${esc(dl.names.get(e.src) || '')}" placeholder="${esc(defaultDlName(i))}"><span class="ext">.png</span></div>
          <div class="sz"><span class="kind">${e.kind === 'gen' ? '生成' : '添付'}</span> ${e.w && e.h ? `${e.w}×${e.h}` : ''}</div>
          <div class="acts"><button class="btn sm primary dlb" data-t="save" title="一番下の「保存先」に保存">⬇ 保存先へDL</button><button class="btn sm dlb" data-t="desk" title="デスクトップに保存">🖥 デスクトップにDL</button></div>
          <span class="ok">${esc(dl.done.get(e.src) || '')}</span>
        </div>
      </div>`).join('');
    box.querySelectorAll('.dli').forEach(row => {
      const e = dl.list[+row.dataset.i];
      row.querySelector('.nm').addEventListener('input', ev => dl.names.set(e.src, ev.target.value));
      row.querySelector('.ck').onchange = ev => { ev.target.checked ? dl.off.delete(e.src) : dl.off.add(e.src); row.classList.toggle('off', !ev.target.checked); updateDlBtn(); };
      row.querySelector('img').onclick = () => { $('zoomImg').src = e.src; $('zoom').hidden = false; };
      row.querySelectorAll('.dlb').forEach(b => b.onclick = async () => {
        const t = b.dataset.t;
        if (t === 'desk') await ensureDesktop(); else await ensureDirPermission(true);
        dlOne(e, row, t);
      });
    });
    updateDlBtn();
  }

  function updateDlBtn() {
    const n = dl.list.filter(e => !dl.off.has(e.src)).length;
    $('dlCount').textContent = `${n} / ${dl.list.length}枚 選択中`;
    $('dlSelSave').textContent = `⬇ 選択した画像を保存先へDL（${n}枚）`;
    $('dlSelDesk').textContent = `🖥 選択した画像をデスクトップにDL（${n}枚）`;
    $('dlSelSave').disabled = $('dlSelDesk').disabled = !n;
    $('dlAllOn').disabled = n === dl.list.length; $('dlAllOff').disabled = !n;
  }

  async function dlOne(e, row, target = 'save') {
    const ok = row?.querySelector('.ok');
    try {
      if (ok) ok.textContent = '取得中…';
      const blob = await (await fetch(e.src)).blob();
      const ext = extOf(blob.type);
      if (row) row.querySelector('.ext').textContent = '.' + ext;
      const name = safeName(dl.names.get(e.src) || '') || defaultDlName(dl.list.indexOf(e));
      const where = await saveBlob(blob, `${name}.${ext}`, false, target);
      const label = (where.startsWith('🖥') ? '✓ デスクトップに保存' : where.startsWith('📁') ? '✓ 保存先に保存' : '✓ ダウンロードに保存');
      dl.done.set(e.src, label);
      if (ok) { ok.textContent = label; ok.title = where; }
      log('保存：' + where);
    } catch (err) {
      if (ok) ok.textContent = '失敗しました';
      log('画像のダウンロードに失敗：' + err.message);
    }
  }

  function initDl() {
    $('dlRefresh').onclick = () => refreshDl(true);
    $('dlIncUser').onchange = () => { store.set('dlIncUser', $('dlIncUser').checked); refreshDl(); };
    $('dlIncUser').checked = !!store.get('dlIncUser', false);
    $('dlNumber').onclick = () => {
      const base = safeName($('dlBase').value) || 'x';
      dl.list.forEach((e, i) => dl.names.set(e.src, `${base}-${String(i + 1).padStart(2, '0')}`));
      renderDl();
    };
    $('dlAllOn').onclick = () => { dl.list.forEach(e => dl.off.delete(e.src)); renderDl(); };
    $('dlAllOff').onclick = () => { dl.list.forEach(e => dl.off.add(e.src)); renderDl(); };
    const dlSelected = async target => {
      if (target === 'desk') await ensureDesktop(); else await ensureDirPermission(true);
      const rows = [...$('dlList').querySelectorAll('.dli')];
      for (const row of rows) {
        const e = dl.list[+row.dataset.i];
        if (dl.off.has(e.src)) continue;
        await dlOne(e, row, target); await sleep(350);
      }
    };
    $('dlSelSave').onclick = () => dlSelected('save');
    $('dlSelDesk').onclick = () => dlSelected('desk');
    $('deskPick').onclick = pickDesktop;
    loadDesktop();
    $('zoom').onclick = () => { $('zoom').hidden = true; };
  }

  // ---------- 実行 ----------
  const PHASES = [['nav', '送信先を開く'], ['attach', '画像を添付'], ['type', '指示を入力'], ['upload', 'アップロード'], ['gen', '生成待ち'], ['collect', '画像を取得']];
  const PHASE_TEXT = { nav: '送信先を開いています', attach: '画像を添付しています', type: '指示を入力しています', upload: 'アップロード完了を待っています', gen: 'ChatGPTの生成を待っています', collect: '生成画像を取り込んでいます' };
  const intervalMs = () => Math.max(1, +$('ival').value || 1) * (+$('iunit').value) * 1000;
  const fmt = ms => {
    const s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
  };
  const clock = t => new Date(t).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });

  function setStatus(t) {
    $('status').textContent = t;
    const tab = $('tab');
    tab.classList.toggle('running', state.running);
    const m = state.running && t.match(/(\d+)\/(\d+)/);
    tab.textContent = m ? `📷 実行中 ${m[1]}/${m[2]}` : '📷 一括送信';
  }

  function showView(run) {
    state.runView = run;
    if (state.mode === 'dl') return;
    $('setupL').hidden = run; $('setupR').hidden = run; $('runL').hidden = !run; $('runR').hidden = !run;
    $('start').hidden = run; $('stop').hidden = !(run && state.running); $('back').hidden = !(run && !state.running);
  }

  // 進捗画面の描画
  function renderRun() {
    if ($('runL').hidden) return;
    const now = Date.now();
    const total = state.runItems.length;
    const done = state.runItems.filter(i => i.status === 'done').length;
    const err = state.runItems.filter(i => i.status === 'err').length;
    const waiting = state.runItems.filter(i => i.status === 'wait');
    const cur = state.current;
    const end = state.endedAt || now;

    $('rvElapsed').textContent = `経過 ${fmt(end - state.startedAt)}　（開始 ${clock(state.startedAt)}）`;
    $('rvBar').style.width = total ? `${Math.round((done + err) / total * 100)}%` : '0%';
    $('rvDone').textContent = `${done + err} / ${total} 処理済み`;
    $('rvErr').textContent = err ? `エラー ${err}件` : '';
    $('rvErr').className = err ? 'e' : '';

    // 1枚あたりの所要時間（完了分の平均）から終了予定を出す
    const durs = state.runItems.filter(i => i.status === 'done' && i.endedAt).map(i => i.endedAt - i.startedAt);
    const avg = durs.length ? durs.reduce((a, b) => a + b, 0) / durs.length : 0;

    const st = $('rvState');
    if (!state.running) {
      st.className = 'badge ' + (state.stopReason === 'done' ? 'done' : 'err');
      st.textContent = state.stopReason === 'done' ? '完了' : '停止';
      $('rvThumb').src = '';
      $('rvNow').innerHTML = state.stopReason === 'done' ? '<b>すべて終わりました</b>' : '<b>停止しました</b>';
      $('rvBig').innerHTML = `${fmt(end - state.startedAt)}<small>かかりました</small>`;
      $('rvSteps').innerHTML = '';
      $('rvEta').textContent = avg ? `1枚あたり平均 ${fmt(avg)}` : '';
    } else if (cur) {
      st.className = 'badge run'; st.textContent = '送信中';
      const n = state.items.indexOf(cur) + 1;
      $('rvThumb').src = cur.url;
      $('rvNow').innerHTML = `<b>${n}番</b>「${esc(cur.file.name)}」— ${PHASE_TEXT[state.phase] || '処理中'}`;
      $('rvBig').innerHTML = `${fmt(now - cur.startedAt)}<small>経過</small>`;
      const idx = PHASES.findIndex(p => p[0] === state.phase);
      $('rvSteps').innerHTML = PHASES.map(([k, l], i) => `<span class="${i < idx ? 'ok' : i === idx ? 'on' : ''}">${i < idx ? '✓ ' : ''}${l}</span>`).join('');
      const est = avg ? Math.max(0, avg - (now - cur.startedAt)) + waiting.length * (intervalMs() + avg) : 0;
      $('rvEta').textContent = est ? `終了予定 ${clock(now + est)}ごろ（あと約${fmt(est)}）` : '';
    } else {
      const next = waiting[0];
      st.className = 'badge'; st.textContent = '待機中';
      if (next) {
        const n = state.items.indexOf(next) + 1;
        $('rvThumb').src = next.url;
        $('rvNow').innerHTML = `次は <b>${n}番</b>「${esc(next.file.name)}」を送信`;
        $('rvBig').innerHTML = `${fmt(state.nextAt - now)}<small>後に送信</small>`;
        $('rvSteps').innerHTML = `<span>送信予定 ${new Date(state.nextAt).toLocaleTimeString('ja-JP')}</span>`;
        const est = avg ? Math.max(0, state.nextAt - now) + waiting.length * avg + (waiting.length - 1) * intervalMs() : 0;
        $('rvEta').textContent = est ? `終了予定 ${clock(now + est)}ごろ（あと約${fmt(est)}）` : (done ? '' : '1枚目が終わると終了予定を表示します');
      }
    }
    $('rvDest').textContent = '送信先：' + (state.destLabel || '');

    // 一覧
    const list = $('rvList');
    if (list.childElementCount !== total) {
      list.innerHTML = state.runItems.map(it => `<div class="ri" data-id="${it.id}"><div class="n"></div><img alt=""><div class="nm"><div></div><div class="p"></div></div><div class="gc"></div><div class="st"></div></div>`).join('');
    }
    state.runItems.forEach((it, i) => {
      const el = list.children[i];
      el.classList.toggle('cur', it === cur);
      el.querySelector('.n').textContent = state.items.indexOf(it) + 1;
      if (el.querySelector('img').src !== it.url) el.querySelector('img').src = it.url;
      el.querySelector('.nm div').textContent = it.file.name;
      el.querySelector('.nm .p').textContent = it.sentText || it.prompt || '（指示なし）';
      let s;
      if (it.status === 'done') s = `<span style="color:var(--accent)">✓ 完了 ${fmt(it.endedAt - it.startedAt)}</span>`;
      else if (it.status === 'err') s = `<span style="color:var(--err)" title="${esc(it.error || '')}">✕ エラー</span>`;
      else if (it.status === 'run') s = `<span style="color:var(--accent)">● ${fmt(now - it.startedAt)}</span>`;
      else s = it === waiting[0] && !cur && state.running ? `あと ${fmt(state.nextAt - now)}` : '待機';
      if (it.chatUrl) s += `<a href="${esc(it.chatUrl)}" target="_blank">開く</a>`;
      const stEl = el.querySelector('.st'); if (stEl.innerHTML !== s) stEl.innerHTML = s;
      const gc = el.querySelector('.gc'), key = (it.results || []).map(r => r.url).join('|');
      if (gc.dataset.key !== key) { gc.dataset.key = key; gc.innerHTML = gensHtml(it); bindGens(gc, it); }
    });
    const nImgs = state.runItems.reduce((n, it) => n + (it.results?.length || 0), 0);
    $('dlAll').hidden = !nImgs;
    $('dlAll').textContent = `生成画像をまとめてDL（${nImgs}枚）`;
  }

  function start() {
    if (!state.items.some(it => it.status === 'wait')) return;
    if (!cg.composer()) return setStatus('ChatGPTの入力欄が見つかりません。ログインしているか確認してください');
    if (destMode() === 'url') {
      const u = $('destUrl').value.trim();
      if (!u) return setStatus('送信先のURLを選ぶか入力してください');
      try { if (new URL(u, location.origin).origin !== location.origin) throw 0; } catch (e) { return setStatus('送信先は chatgpt.com のURLにしてください'); }
    }
    state.running = true;
    state.startedAt = Date.now(); state.endedAt = 0; state.current = null; state.phase = ''; state.stopReason = '';
    state.runItems = state.items.filter(it => it.status === 'wait');
    state.destLabel = destMode() === 'url'
      ? (($('recent').selectedOptions[0]?.value === $('destUrl').value.trim() && $('recent').selectedOptions[0].textContent) || $('destUrl').value.trim())
      : '毎回新しいチャット';
    $('rvList').innerHTML = '';
    showView(true);
    render();
    state.nextAt = $('firstNow').checked ? Date.now() : Date.now() + intervalMs();
    state.timer = setInterval(tick, 500);
    log(`開始：${state.runItems.length}枚 → ${state.destLabel}`);
    tick();
  }
  function stop(msg, reason = 'stop') {
    state.running = false; clearInterval(state.timer); state.timer = null;
    state.endedAt = Date.now(); state.stopReason = reason;
    setStatus(msg); log(msg);
    showView(true); render(); renderRun();
  }
  async function tick() {
    if (!state.running) return;
    if (state.busy) { renderRun(); return; }
    const it = state.items.find(i => i.status === 'wait');
    const doneN = state.runItems.filter(i => i.status === 'done' || i.status === 'err').length;
    if (!it) {
      const ok = state.runItems.filter(i => i.status === 'done').length;
      return stop(`すべて完了（成功 ${ok} / エラー ${doneN - ok}）`, 'done');
    }
    if (!state.runItems.includes(it)) state.runItems.push(it);
    const left = state.nextAt - Date.now();
    if (left > 0) {
      setStatus(`実行中 ${doneN}/${state.runItems.length} ・ 次の送信まで ${fmt(left)}`);
      renderRun();
      return;
    }
    state.busy = true;
    const n = state.items.indexOf(it) + 1;
    setStatus(`実行中 ${doneN}/${state.runItems.length} ・ ${n}番を送信・生成中…`);
    it.status = 'run'; it.startedAt = Date.now(); state.current = it;
    const phase = p => { state.phase = p; renderRun(); };
    render(); phase('nav');
    log(`${n}番「${it.file.name}」を送信`);
    try {
      if (destMode() === 'url') await cg.openUrl($('destUrl').value.trim());
      else await cg.openNewChat();
      const text = [$('common').value.trim(), it.prompt.trim()].filter(Boolean).join('\n\n');
      it.sentText = text;
      const res = await cg.send(it.file, text, phase);
      it.chatUrl = res.url;
      setResults(it, res.images);
      it.status = 'done'; log(`${n}番 完了（${fmt(Date.now() - it.startedAt)}）${it.results.length ? `・生成画像 ${it.results.length}枚` : '・生成画像なし'}`);
      if (it.results.length && $('autoDl').checked) await downloadItem(it);
    } catch (e) {
      it.status = 'err'; it.error = e.message; log(`${n}番 エラー：${e.message}`);
    }
    it.endedAt = Date.now();
    state.current = null; state.phase = '';
    state.busy = false;
    state.nextAt = Date.now() + intervalMs();
    render(); renderRun();
    if (state.running) tick();
  }

  // ---------- 起動 ----------
  const boot = async () => { await store.load(); build(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();

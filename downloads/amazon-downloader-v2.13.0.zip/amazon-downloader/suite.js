// 最上部：共通の開始日/終了日 と「必要ページを開く」
const $ = (id) => document.getElementById(id);
function jstToday(off = 0) {
  return new Date(Date.now() + 9 * 3600 * 1000 + off * 86400000).toISOString().slice(0, 10);
}
const openTab = (url, active = true) => AMZ_openTab(url, active);
const DATE_LOCK_KEY = 'amazon_dl_date_lock';

async function initTop() {
  const store = await chrome.storage.local.get([DATE_LOCK_KEY, 'sharedDates']);
  const lock = store[DATE_LOCK_KEY];
  const sd = store.sharedDates;
  let s, e;
  if (lock) {                       // 固定されていれば固定値を優先
    s = lock.startDate || jstToday(-1);
    e = lock.endDate || jstToday(-1);
  } else {                          // それ以外は前回値、なければ昨日
    s = sd && sd.start ? sd.start : jstToday(-1);
    e = sd && sd.end ? sd.end : jstToday(-1);
  }
  $('top-start').value = s;
  $('top-end').value = e;
  await chrome.storage.local.set({ sharedDates: { start: s, end: e } });
  updateDateLockUI(!!lock);
}

function setDateHint(msg, isError) {
  const el = $('date-hint'); if (!el) return;
  el.textContent = msg || '';
  el.style.color = isError ? '#a01010' : '#806000';
}

function updateDateLockUI(locked) {
  const badge = $('date-lock-badge'); if (badge) badge.style.display = locked ? 'inline-block' : 'none';
  ['top-start', 'top-end'].forEach((id) => {
    const el = $(id); if (!el) return;
    el.classList.toggle('date-locked', locked);
  });
  const sb = $('date-save');
  if (sb) { sb.textContent = locked ? '✅ 保存中(再保存で更新)' : '💾 日付を保存(固定)'; sb.classList.toggle('locked', locked); }
}

$('date-save').addEventListener('click', async () => {
  const startDate = $('top-start').value, endDate = $('top-end').value;
  if (!startDate && !endDate) { setDateHint('❌ 保存する日付を入力してください', true); return; }
  await chrome.storage.local.set({ [DATE_LOCK_KEY]: { startDate, endDate } });
  updateDateLockUI(true);
  setDateHint(`✅ 保存しました (${startDate || '(空)'} 〜 ${endDate || '(空)'})`);
});

// 前日〜N日前を自動セット（v2.13.0〜）。広告の売上はクリック日に計上され、SB は14日後まで増え続ける。
// 毎日 前日〜18日前（14日＋1日＋反映の遅れ3日）を取り直せば、一番古い日は数字が出そろった値で上書きされる（Amacheck v5.19 の依頼）
const PRESET_DAYS_BACK = 18;
$('date-preset').textContent = `📅 前日〜${PRESET_DAYS_BACK}日前を自動セット`;
$('date-preset').addEventListener('click', async () => {
  const s = jstToday(-PRESET_DAYS_BACK), e = jstToday(-1);
  $('top-start').value = s; $('top-end').value = e;
  await save();
  setDateHint(`📅 期間をセットしました：${s} 〜 ${e}（${PRESET_DAYS_BACK}日分）`);
});

$('date-clear').addEventListener('click', async () => {
  await chrome.storage.local.remove([DATE_LOCK_KEY]);
  updateDateLockUI(false);
  setDateHint('🔓 日付の固定を解除しました');
});
async function save() {
  const now = Date.now();
  const startDate = $('top-start').value, endDate = $('top-end').value;
  const patch = {
    sharedDates: { start: startDate, end: endDate },
    // 日付(月)を変えたら「取得済み」表示をリセット
    ads_status: { state: 'idle', ts: now },
    ship_status: { state: 'idle', ts: now },
    kw_status: { state: 'idle', ts: now },
    purchase_status: { state: 'idle', ts: now }
  };
  // 固定中に日付を変えたら、固定値も追従して更新
  const store = await chrome.storage.local.get([DATE_LOCK_KEY]);
  if (store[DATE_LOCK_KEY]) patch[DATE_LOCK_KEY] = { startDate, endDate };
  chrome.storage.local.set(patch);
}
$('top-start').addEventListener('change', save);
$('top-end').addEventListener('change', save);

$('top-open').addEventListener('click', async () => {
  const urls = [
    'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
    'https://sellercentral-japan.amazon.com/orders-v3?page=1'
  ];
  for (const u of urls) await openTab(u, false);
  const b = $('top-open'); b.textContent = '✅ 開きました（各タブを一度表示してください）';
  setTimeout(() => (b.textContent = '🗂️ 必要ページを開く'), 2500);
});

initTop();

// ===== 保存先(File System Access API)の状態表示 =====
async function renderFs() {
  const st = await AMZ_FS.status();
  const nameEl = $('fs-name'), setBtn = $('fs-set');
  if (st.state === 'granted') {
    nameEl.textContent = st.name; nameEl.style.color = '#1a7f37';
    setBtn.textContent = '変更'; setBtn.style.background = '#888';
  } else if (st.state === 'none') {
    nameEl.textContent = '未設定（要設定）'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '設定'; setBtn.style.background = '#c25a00';
  } else {
    nameEl.textContent = (st.name || '') + '：要許可'; nameEl.style.color = '#c25a00';
    setBtn.textContent = '許可'; setBtn.style.background = '#c25a00';
  }
}
$('fs-set').addEventListener('click', () => {
  openTab(chrome.runtime.getURL('folder.html'));
});
chrome.storage.onChanged.addListener((ch) => { if (ch.amz_fs_state || ch.amz_fs_name || ch.amz_fs_ts) renderFs(); });
// 拡張のウィンドウは開いたまま使い回すので、前に出てきたときにも保存先を読み直す（v2.12.17）
window.addEventListener('focus', () => renderFs());
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') renderFs(); });
renderFs();

// ===== 各セクション(iframe)の高さを中身に自動で合わせる =====
// iframe 内に個別の縦スクロールバーが出ないようにする。
// ログ欄をドラッグで広げた時や表示内容が増えた時も ResizeObserver で追従する。
(function autoFitFrames() {
  const fit = (f) => {
    try {
      const b = f.contentDocument && f.contentDocument.body;
      if (!b) return;
      const h = Math.ceil(b.getBoundingClientRect().height);
      if (h > 0 && f.style.height !== h + 'px') f.style.height = h + 'px';
    } catch (_) {}
  };
  const hook = (f) => {
    fit(f);
    try {
      if (f.__amzRO) f.__amzRO.disconnect();
      const RO = (f.contentWindow && f.contentWindow.ResizeObserver) || ResizeObserver;
      f.__amzRO = new RO(() => fit(f));
      f.__amzRO.observe(f.contentDocument.body);
    } catch (_) {}
  };
  document.querySelectorAll('iframe.frame').forEach((f) => {
    f.addEventListener('load', () => hook(f));
    try { if (f.contentDocument && f.contentDocument.readyState === 'complete' && f.contentDocument.body) hook(f); } catch (_) {}
  });
})();

// ===== 4種まとめてDL =====（v2.12.0 で ④購入商品データ を追加）
// 各セクション(iframe)の「実行」ボタンをそのまま押して完了を待つ。
//  ・広告 → KW は同じAmazon広告タブを使う(KWはタブを遷移させる)ので順番に実行
//  ・出荷数はバックグラウンド(セラーセントラル)で動くので並行して実行
// 完了判定: ボタンが disabled(実行中) → 再び有効 になったら終了。
//           成功は各 *_status が 'done' かつ開始後に更新されていること。
(function bulkDownload() {
  const btn = $('all-run'); if (!btn) return;
  const msg = $('all-msg');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const STEPS = {
    ads:  { frame: 'f-ads',  statusKey: 'ads_status',  chip: 'st-ads',  label: '① 広告' },
    ship: { frame: 'f-ship', statusKey: 'ship_status', chip: 'st-ship', label: '② 出荷数' },
    kw:   { frame: 'f-kw',   statusKey: 'kw_status',   chip: 'st-kw',   label: '③ KW' },
    pur:  { frame: 'f-pur',  statusKey: 'purchase_status', chip: 'st-pur', label: '④ 購入' }
  };
  let running = false, stopReq = false;

  // 表示（チップ・メッセージ）は storage の bulk_state にも保存し、ポップアップを開き直しても同じ表示に戻す（v2.12.6）
  //   bulk_state = { active, phase:'running'|'waiting-purchase', range, chips:{k:{cls,suffix}}, msg, ts, finishedAt }
  //   購入商品の作成待ち（waiting-purchase）は background（purchasejob.js purBulkNotify）が完成時に最終表示へ更新する。
  const BULK_KEY = 'bulk_state';
  let state = null;
  const saveState = () => { if (state) { state.ts = Date.now(); chrome.storage.local.set({ [BULK_KEY]: state }).catch(() => {}); } };
  const paintChip = (k, cls, suffix) => {
    const el = $(STEPS[k].chip); if (!el) return;
    el.className = 'step ' + cls;
    el.textContent = STEPS[k].label + (suffix ? ' ' + suffix : '');
  };
  const setChip = (k, cls, suffix) => {
    paintChip(k, cls, suffix);
    if (state) { state.chips[k] = { cls, suffix }; saveState(); }
  };
  const setMsg = (html) => { if (msg) msg.innerHTML = html; if (state) { state.msg = html; saveState(); } };
  const paint = (st) => {
    for (const k of Object.keys(STEPS)) { const c = (st.chips || {})[k]; if (c) paintChip(k, c.cls, c.suffix); }
    if (msg && st.msg) msg.innerHTML = st.msg;
  };
  // 開いたときに前回の表示を戻す
  (async () => {
    const st = (await chrome.storage.local.get(BULK_KEY))[BULK_KEY];
    if (!st || running) return;
    if (st.active && st.phase === 'waiting-purchase') { paint(st); return; }
    if (st.active && st.phase === 'running') {
      // 3種の途中でポップアップが閉じられた（続きは動いていない）
      st.active = false; st.finishedAt = Date.now();
      for (const k of Object.keys(STEPS)) {
        const c = (st.chips || {})[k];
        if (c && c.cls === 'wait') st.chips[k] = { cls: 'skip', suffix: '未実行' };
        else if (c && c.cls === 'run') st.chips[k] = { cls: 'skip', suffix: '要確認' };
      }
      st.msg = (st.msg || '') + '<br>⚠ 途中でウィンドウが閉じられたため、「未実行」の分は取得していません。「要確認」は下の各欄のログで結果を確認してください。';
      await chrome.storage.local.set({ [BULK_KEY]: st });
      paint(st); return;
    }
    if (!st.active && st.finishedAt && Date.now() - st.finishedAt < 30 * 60 * 1000) paint(st);   // 終わってから30分は結果を表示
  })();
  // background が作成待ちの結果を書き込んだら表示を更新
  chrome.storage.onChanged.addListener((ch) => {
    if (!ch[BULK_KEY] || running) return;
    const st = ch[BULK_KEY].newValue; if (st) paint(st);
  });
  const frameDoc = (k) => { try { return document.getElementById(STEPS[k].frame).contentDocument; } catch (_) { return null; } };
  const lastLine = (doc) => {
    try {
      const el = doc.getElementById('status');
      const t = (el && (el.value || el.textContent) || '').trim().split('\n').filter(Boolean);
      return t.length ? t[t.length - 1].trim().slice(0, 80) : '';
    } catch (_) { return ''; }
  };

  // 1セクションを実行して終わるまで待つ
  async function runStep(k) {
    if (stopReq) { setChip(k, 'skip', '中止'); return { ok: false, skipped: true }; }
    const doc = frameDoc(k);
    const b = doc && doc.getElementById('run');
    if (!b) { setChip(k, 'ng', '✕'); return { ok: false, error: '画面が読み込まれていません' }; }
    if (b.disabled) { setChip(k, 'ng', '✕'); return { ok: false, error: 'すでに実行中です' }; }
    const t0 = Date.now();
    setChip(k, 'run', '⏳');
    b.click();
    // 開始待ち(ボタンが disabled になる)。ならなければ開始前エラー
    let started = false;
    for (let i = 0; i < 40; i++) { await sleep(200); if (b.disabled) { started = true; break; } }
    if (!started) {
      setChip(k, 'ng', '✕');
      return { ok: false, error: lastLine(doc) || '開始できませんでした' };
    }
    // 終了待ち
    while (b.disabled) await sleep(1000);
    await sleep(300);
    const st = (await chrome.storage.local.get([STEPS[k].statusKey]))[STEPS[k].statusKey] || {};
    const ok = st.state === 'done' && (st.ts || 0) >= t0;
    if (ok) setChip(k, 'ok', '✓');
    else if (stopReq) setChip(k, 'skip', '停止');
    else setChip(k, 'ng', '✕');
    return { ok, error: ok ? '' : (lastLine(doc) || '失敗') };
  }

  // ④購入商品データ：background に直接頼む（purchasejob.js purchaseDays）。
  //   ふだんは毎朝の予約レポートから切り出して数秒で保存まで終わる。
  //   その場で作成が必要な日（朝6時半ごろより前・予約の初回前・30日より前）は裏で作成を始め、「⏳作成中」で完了扱い（完了は通知）。
  async function runPurchase(startDate, endDate) {
    if (stopReq) { setChip('pur', 'skip', '中止'); return { ok: false, skipped: true }; }
    setChip('pur', 'run', '⏳');
    let res;
    try { res = await chrome.runtime.sendMessage({ type: 'purchase_days', startDate, endDate }); }
    catch (e) { res = { ok: false, error: String(e && e.message || e) }; }
    if (!res || !res.ok) { setChip('pur', 'ng', '✕'); return { ok: false, error: (res && res.error) || '失敗' }; }
    if (res.mode === 'pending') { setChip('pur', 'ok', '⏳作成中'); return { ok: true, pending: true }; }
    setChip('pur', 'ok', '✓'); return { ok: true };
  }

  function requestStopAll() {
    stopReq = true;
    for (const k of Object.keys(STEPS)) {
      try { const s = frameDoc(k).getElementById('stop'); if (s) s.click(); } catch (_) {}
    }
    btn.disabled = true; btn.textContent = '停止処理中…';
    setMsg('■ 停止を要求しました（現在の日の処理が終わり次第止まります）');
  }

  btn.addEventListener('click', async () => {
    if (running) { requestStopAll(); return; }

    const startDate = $('top-start').value, endDate = $('top-end').value;
    if (!startDate || !endDate) { setMsg('❌ 上で開始日・終了日を入力してください'); return; }
    if (startDate > endDate) { setMsg('❌ 開始日が終了日より後になっています'); return; }
    try {
      const fs = await AMZ_FS.status();
      if (fs.state !== 'granted') {
        setMsg('❌ 保存先フォルダが未設定／要許可です。「保存先」から設定してください');
        openTab(chrome.runtime.getURL('folder.html'));
        return;
      }
    } catch (_) {}

    running = true; stopReq = false;
    state = { active: true, phase: 'running', range: `${startDate} 〜 ${endDate}`, chips: {}, msg: '', ts: Date.now() };
    btn.classList.add('running'); btn.textContent = '■ まとめて停止';
    for (const k of Object.keys(STEPS)) setChip(k, 'wait', '待機');
    setMsg(`▶ ${startDate} 〜 ${endDate} を取得中…<br><b>実行中はこのウィンドウを閉じないでください。</b>`);

    const results = {};
    try {
      // 出荷数は並行、広告 → KW は順番
      const shipP = runStep('ship').then((r) => (results.ship = r));
      results.ads = await runStep('ads');
      results.kw = await runStep('kw');
      results.pur = await runPurchase(startDate, endDate);
      await shipP;
    } catch (e) {
      setMsg('❌ ' + (e && e.message || e));
    }

    const okN = Object.values(results).filter((r) => r && r.ok).length;
    const name = { ads: '①広告', ship: '②出荷数', kw: '③KW', pur: '④購入商品' };
    const pend = results.pur && results.pur.pending ? '<br>④購入商品データはAmazon側で作成中です（あと数分・<b>ウィンドウを閉じてOK</b>・できたら「4種まとめてDL：完了」を通知）' : '';
    const ngs = Object.entries(results).filter(([, r]) => r && !r.ok && !r.skipped)
      .map(([k, r]) => `${name[k]}：${r.error}`);
    if (stopReq) setMsg(`■ 停止しました（完了 ${okN}/4）`);
    else if (okN === 4 && results.pur.pending) setMsg(`✅ ①広告・②出荷数・③KW は完了しました（${startDate} 〜 ${endDate}）` + pend);
    else if (okN === 4) setMsg(`🎉 4種すべて完了しました（${startDate} 〜 ${endDate}）`);
    else setMsg(`⚠ 完了 ${okN}/4<br>` + ngs.map((t) => '・' + t.replace(/</g, '&lt;')).join('<br>') + pend);
    if (!stopReq && results.pur && results.pur.pending) {
      // 購入商品の作成が終わったときに background から「4種まとめてDL：完了」を通知し、表示も更新する
      state.phase = 'waiting-purchase'; state.ts = Date.now();
      try { await chrome.storage.local.set({ [BULK_KEY]: state }); } catch (_) {}
      const others = ['ads', 'ship', 'kw'].map((k) => [k, results[k]]);
      try {
        await chrome.runtime.sendMessage({ type: 'purchase_bulk', bulk: {
          range: `${startDate} 〜 ${endDate}`,
          ok: others.filter(([, r]) => r && r.ok).length,
          ngs: others.filter(([, r]) => r && !r.ok && !r.skipped).map(([k, r]) => `${name[k]}：${String(r.error || '失敗').slice(0, 60)}`)
        } });
      } catch (_) {}
    } else {
      state.active = false; state.finishedAt = Date.now(); saveState();
      try {
        chrome.notifications.create('all-' + Date.now(), {
          type: 'basic', iconUrl: 'icons/icon128.png',
          title: '4種まとめてDL：' + (okN === 4 ? '完了' : `完了 ${okN}/4`),
          message: `${startDate} 〜 ${endDate}`, priority: 2
        }, (id) => setTimeout(() => chrome.notifications.clear(id), 8000));
      } catch (_) {}
    }

    running = false; state = null;
    btn.disabled = false; btn.classList.remove('running'); btn.textContent = '⏬ 4種まとめてDL';
  });
})();



// 保存先フォルダ(File System Access API)の管理。
// popup / 設定ページ(folder) / Service Worker(background) の全部から使う。
self.AMZ_FS = (() => {
  const DB = 'amz_suite_fs';
  const STORE = 'handles';
  const KEY = 'root';

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function getRoot() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const r = db.transaction(STORE).objectStore(STORE).get(KEY);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
  }
  async function setRoot(handle) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(handle, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  // { state: 'none' | 'granted' | 'prompt' | 'denied', name }
  async function status() {
    const h = await getRoot();
    if (!h) return { state: 'none' };
    let state = 'prompt';
    try { state = await h.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    return { state, name: h.name };
  }
  // ユーザー操作の中から呼ぶ(ページ側専用。Service Worker では使えない)
  async function requestPermission() {
    const h = await getRoot();
    if (!h) return 'none';
    return h.requestPermission({ mode: 'readwrite' });
  }
  // root/サブフォルダ(多階層可)/ファイル名 に書き込む(同名は上書き)
  async function writeFile(subdir, filename, data) {
    const root = await getRoot();
    if (!root) throw new Error('保存先フォルダが未設定です');
    let perm = 'prompt';
    try { perm = await root.queryPermission({ mode: 'readwrite' }); } catch (e) {}
    if (perm !== 'granted') throw new Error('保存先フォルダへの書き込み許可が切れています（保存先を選び直してください）');

    const parts = (subdir || '').split('/').map((s) => s.trim()).filter(Boolean);
    let dir = root, made = [];
    try {
      for (const p of parts) { dir = await dir.getDirectoryHandle(p, { create: true }); made.push(p); }
    } catch (e) {
      // サブフォルダ作成に失敗したら保存先直下に保存(データを失わない)
      dir = root; made = [];
    }
    // 書き込みのやり直しとサイズ確認（v2.13.0〜。Dropbox がファイルを一瞬つかむと InvalidStateError で失敗し、0バイトのファイルが残ることがある）
    const expected = byteLength(data);
    let existed = false;
    try { await dir.getFileHandle(filename, { create: false }); existed = true; } catch (_) {}
    let fh;
    try {
      fh = await dir.getFileHandle(filename, { create: true });
    } catch (e) {
      throw new Error(`ファイル作成に失敗(${e.name}: ${e.message})。保存先フォルダが移動/削除された可能性があります。保存先を選び直してください`);
    }
    let lastErr = null, ok = false;
    for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
      let w = null;
      try {
        w = await fh.createWritable();
        await w.write(data);
        await w.close(); w = null;
        const size = (await fh.getFile()).size;
        if (expected != null && size !== expected) throw new Error(`サイズ不一致（書いた=${size} / 期待=${expected}）`);
        ok = true;
      } catch (e) {
        if (w) { try { await w.abort(); } catch (_) {} }
        lastErr = e;
        if (attempt < 3) await new Promise((r) => setTimeout(r, 500 * attempt));
      }
    }
    if (!ok) {
      if (!existed) { try { await dir.removeEntry(filename); } catch (_) {} }   // 空のファイルを残さない
      throw new Error(`書き込みに失敗（3回試行: ${(lastErr && lastErr.name) || ''} ${(lastErr && lastErr.message) || ''}）`);
    }
    return `${root.name}/${made.length ? made.join('/') + '/' : ''}${filename}`;
  }
  function byteLength(data) {
    if (data == null) return null;
    if (typeof data === 'string') return new TextEncoder().encode(data).length;
    if (typeof Blob !== 'undefined' && data instanceof Blob) return data.size;
    if (data.byteLength != null) return data.byteLength;
    return null;
  }
  return { getRoot, setRoot, status, requestPermission, writeFile };
})();


// 拡張画面は別ウィンドウ（type:popup）で開くので、そこから開くタブはふだんのChromeウィンドウに開く（v2.12.13〜）
self.AMZ_openTab = async function (url, active = true) {
  let windowId;
  try {
    const ws = await chrome.windows.getAll({ windowTypes: ['normal'] });
    const w = ws.find((x) => x.focused) || ws[0];
    windowId = w ? w.id : undefined;
  } catch (_) {}
  try { return await chrome.tabs.create(windowId ? { url, active, windowId } : { url, active }); }
  catch (_) { const w = await chrome.windows.create({ url, focused: active }); return w && w.tabs && w.tabs[0]; }
};


// ============================================================
// 書き込み許可が切れたときの対策（v2.12.16〜）
//   Chrome は拡張のページ（拡張ウィンドウ・設定ページなど）が全部閉じてから約5秒で、保存先フォルダへの
//   書き込み許可を取り消すことがある（状態が prompt に戻る）。Service Worker は「開いているページ」に数えられない。
//   ① 作成待ちを裏で続ける処理（④購入商品・公式レポート）の間は、設定ページをピン留め・非アクティブで開いておく（keeper）
//   ② それでも保存時に許可が切れていたら、失敗にせず一時停止 → 通知＋設定ページを前に出す → 「許可」が押されたら続きから保存
// ============================================================
self.AMZ_FS_EXTRA = (() => {
  const FOLDER_URL = chrome.runtime.getURL('folder.html');
  const KEEPER_KEY = 'fs_keeper';            // { tabId, owners: ['purchase','official'] }
  const WAIT_MS = 4 * 60 * 1000;            // Service Worker の1イベントの上限（約5分）に掛からないよう最大4分待つ
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function findFolderTab() {
    try { return (await chrome.tabs.query({})).find((t) => (t.url || t.pendingUrl || '').startsWith(FOLDER_URL)) || null; }
    catch (_) { return null; }
  }
  async function normalWindowId() {
    try { const ws = await chrome.windows.getAll({ windowTypes: ['normal'] }); const w = ws.find((x) => x.focused) || ws[0]; return w ? w.id : undefined; }
    catch (_) { return undefined; }
  }
  // 設定ページを開く（無ければ作る）。active=true なら前に出す
  async function openFolderPage(active, extra = '') {
    const t = await findFolderTab();
    if (t) {
      if (active) { try { await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); } catch (_) {} }
      return t;
    }
    const windowId = await normalWindowId();
    const opt = { url: FOLDER_URL + extra, active: !!active, pinned: !active };
    if (windowId) opt.windowId = windowId;
    try { return await chrome.tabs.create(opt); } catch (_) { return null; }
  }

  // ① keeper：裏で続く処理の間、拡張のページを1つ開いておく
  async function ensureKeeper(owner) {
    const s = (await chrome.storage.local.get(KEEPER_KEY))[KEEPER_KEY] || { tabId: null, owners: [] };
    if (!s.owners.includes(owner)) s.owners.push(owner);
    let tab = null;
    if (s.tabId) { try { tab = await chrome.tabs.get(s.tabId); } catch (_) { tab = null; } }
    if (!tab) { tab = await findFolderTab(); s.mine = false; }   // ユーザーが開いた設定ページがあればそれを使う（閉じない）
    if (!tab) { tab = await openFolderPage(false, '?keeper=1'); s.mine = true; }
    s.tabId = tab ? tab.id : null;
    await chrome.storage.local.set({ [KEEPER_KEY]: s });
  }
  async function releaseKeeper(owner) {
    const s = (await chrome.storage.local.get(KEEPER_KEY))[KEEPER_KEY];
    if (!s) return;
    s.owners = (s.owners || []).filter((o) => o !== owner);
    if (s.owners.length) { await chrome.storage.local.set({ [KEEPER_KEY]: s }); return; }
    await chrome.storage.local.remove(KEEPER_KEY);
    // こちらで開いたピン留めタブだけ閉じる（ユーザーが自分で開いた設定ページは残す）
    if (s.mine && s.tabId) {
      try { const t = await chrome.tabs.get(s.tabId); if (t.pinned && (t.url || '').startsWith(FOLDER_URL)) await chrome.tabs.remove(t.id); } catch (_) {}
    }
  }

  // ② 許可が切れていたら一時停止して待つ。同時に何件来ても待つのは1回
  let waiting = null;
  async function waitForPermission(log) {
    if (waiting) return waiting;
    waiting = (async () => {
      try { log && await log('⏸ 保存先フォルダへの書き込み許可が切れています。設定ページの「このフォルダへの保存を許可」を押すと続きから保存します（最大4分待ちます）'); } catch (_) {}
      try {
        chrome.notifications.create('fs-perm-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', priority: 2, requireInteraction: true,
          title: '保存先フォルダの許可が必要です', message: '開いた設定ページで「このフォルダへの保存を許可」を押してください。押すと続きから保存します。' });
      } catch (_) {}
      await openFolderPage(true);
      const t0 = Date.now();
      while (Date.now() - t0 < WAIT_MS) {
        await sleep(2000);
        const st = await AMZ_FS.status();
        if (st.state === 'granted') { try { log && await log('▶ 許可されたので保存を続けます'); } catch (_) {} return true; }
        if (st.state === 'none') return false;
      }
      return false;
    })();
    try { return await waiting; } finally { waiting = null; }
  }

  // writeFile の代わりに使う（Service Worker 側の保存はすべてこれ）
  async function writeFileWait(subdir, filename, data, log) {
    const st = await AMZ_FS.status();
    if (st.state === 'none') throw new Error('保存先フォルダが未設定です');
    if (st.state !== 'granted') {
      const ok = await waitForPermission(log);
      if (!ok) throw new Error('保存先フォルダの許可が切れたまま4分たったため保存できませんでした。設定ページで「許可」を押してから、もう一度取得してください');
    }
    return AMZ_FS.writeFile(subdir, filename, data);
  }

  // ---- 日別データの保存（v2.13.0〜、Amacheck v5.19 の依頼）----
  //   「〇〇データ-YYYY-MMDD.csv」を2か所に書く。両方成功で成功扱い（片方でも失敗なら失敗）。
  //   (1) 月別フォルダ  YYYY-MM-〇〇データ/〇〇データ-YYYY-MMDD.csv  … _get なしで上書き（毎日取り直すと最新の数字になる）
  //   (2) Amacheck取り込み用/〇〇データ-YYYY-MMDD_getYYYYMMDD-HHMM.csv … 取得日時付きで全部残す（取り込んだら手で空にする）
  //       ※②出荷数データは Amacheck の依頼の対象外なので、取り込み用でも今までの名前のまま（_get なし・上書き）
  //   名前が日別の形でないファイル（公式広告レポート-期間.csv など）は保存先の直下に1つだけ書く。
  const IMPORT_DIR = 'Amacheck取り込み用';
  const NO_GET_KINDS = ['出荷数データ'];
  const DAILY_RE = /^(.+?)-(\d{4})-(\d{2})(\d{2})\.csv$/;
  const pad = (n) => String(n).padStart(2, '0');
  const getStamp = (d = new Date()) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;   // ローカル時刻
  const withGet = (fn, ts) => { const i = fn.lastIndexOf('.'); return i < 0 ? `${fn}_get${ts}` : `${fn.slice(0, i)}_get${ts}${fn.slice(i)}`; };
  async function saveDaily(filename, data, log) {
    const m = String(filename).match(DAILY_RE);
    if (!m) return writeFileWait('', filename, data, log);
    const [, kind, y, mo] = m;
    const st = await AMZ_FS.status();
    if (st.state === 'none') throw new Error('保存先フォルダが未設定です');
    if (st.state !== 'granted') {
      const ok = await waitForPermission(log);
      if (!ok) throw new Error('保存先フォルダの許可が切れたまま4分たったため保存できませんでした。設定ページで「許可」を押してから、もう一度取得してください');
    }
    const failed = [];
    let monthly = '';
    try { monthly = await AMZ_FS.writeFile(`${y}-${mo}-${kind}`, filename, data); } catch (e) { failed.push('月別: ' + e.message); }
    const importName = NO_GET_KINDS.includes(kind) ? filename : withGet(filename, getStamp());
    try { await AMZ_FS.writeFile(IMPORT_DIR, importName, data); } catch (e) { failed.push('取り込み用: ' + e.message); }
    if (failed.length) throw new Error('保存に失敗: ' + failed.join(' / '));
    return monthly;
  }

  return { FOLDER_URL, findFolderTab, openFolderPage, ensureKeeper, releaseKeeper, waitForPermission, writeFileWait, saveDaily, getStamp, withGet, IMPORT_DIR };
})();

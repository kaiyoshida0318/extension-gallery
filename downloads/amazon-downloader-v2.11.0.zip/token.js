// ============================================================
// token.js  広告データ / KWデータ 共通のトークン(CSRF)確保
//
// 背景（2026-10-07 実機で確認）:
//  ・キャンペーン一覧(campaign-manager/all-campaigns)は、タブが裏にあると
//    requestAnimationFrame が止まり表が読み込まれない → retrieveReport が飛ばず
//    トークンを捕捉できない（ポップアップ操作中は広告タブが裏になりがち）。
//  ・広告グループ画面(/cm/sp/campaigns/{id}/ad-groups)は裏タブでも
//    cm/dds/retrieveReport を投げる。
//  ・その dds トークンは campaign-manager/retrieveReport(広告データ)にもそのまま通る
//    （HTTP 200・全キャンペーン取得を確認）。
// → トークンは「新しい方」を使い、古ければ広告グループ画面を開いて取り直す。
// ============================================================
self.AMZ_TOKEN = (() => {
  const CAP = 'amzn_captured';            // campaign-manager 系の捕捉
  const DDS = 'amzn_cap_dds';             // dds 系の捕捉
  const LAST = 'amzn_last_sp_campaign';   // トークン取得に使うSPキャンペーンID
  const DEF_CAMPAIGN = 'A07766381NLEGRFQQ1NRQ';  // フォールバック（23-05-耐火バッグ-kw）
  const DEF_ENTITY = 'ENTITY15N4IW58E6FGF';
  const LIST_URL = 'https://advertising-japan.amazon.com/campaign-manager/all-campaigns';
  const MAX_AGE = 180000;                 // 3分以内なら新しいとみなす

  const hasCsrf = (h) => Object.keys(h || {}).some((k) => /csrf-token/i.test(k));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 捕捉済みのうち一番新しい有効なもの { headers, ts, src:'cm'|'dds', body }
  // opts.ddsOnly: 広告グループ画面(dds)で捕捉したものだけを対象にする（統合レポートAPIは dds トークンで動作確認済み）
  async function latest(opts = {}) {
    const s = await chrome.storage.local.get([CAP, DDS]);
    if (opts.ddsOnly) {
      return (s[DDS] && hasCsrf(s[DDS].headers)) ? { headers: s[DDS].headers, ts: s[DDS].ts || 0, src: 'dds', body: s[DDS].body || null } : null;
    }
    const c = [];
    if (s[CAP] && hasCsrf(s[CAP].headers)) c.push({ headers: s[CAP].headers, ts: s[CAP].ts || 0, src: 'cm', body: s[CAP].body || null });
    if (s[DDS] && hasCsrf(s[DDS].headers)) c.push({ headers: s[DDS].headers, ts: s[DDS].ts || 0, src: 'dds', body: s[DDS].body || null });
    c.sort((a, b) => b.ts - a.ts);
    return c[0] || null;
  }

  async function remember(campaignId) {
    if (campaignId) { try { await chrome.storage.local.set({ [LAST]: campaignId }); } catch (_) {} }
  }

  async function waitComplete(tabId, ms = 20000) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      await sleep(500);
      try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') return; } catch (_) {}
    }
  }

  // 新しいトークンを確保する。必要なら tab を広告グループ画面へ移動させる（裏タブでOK）。
  // 戻り値: { tok, moved }  tok=null なら取得失敗
  async function ensureFresh(tab, log = () => {}, opts = {}) {
    const cur = await latest(opts);
    if (cur && Date.now() - cur.ts < MAX_AGE) return { tok: cur, moved: false };
    const before = cur ? cur.ts : 0;
    const camp = (await chrome.storage.local.get([LAST]))[LAST] || DEF_CAMPAIGN;
    const url = `https://advertising-japan.amazon.com/cm/sp/campaigns/${encodeURIComponent(camp)}/ad-groups?entityId=${encodeURIComponent(DEF_ENTITY)}`;
    log('🔄 トークン取得のため広告グループ画面を読み込み中…');
    try { await chrome.tabs.update(tab.id, { url }); } catch (e) { log('タブ移動に失敗: ' + e.message); return { tok: null, moved: false }; }
    await waitComplete(tab.id);
    const t1 = Date.now();
    while (Date.now() - t1 < 25000) {
      await sleep(800);
      const t = await latest(opts);
      if (t && t.ts > before) return { tok: t, moved: true };
    }
    return { tok: null, moved: true };
  }

  // 作業後にタブをキャンペーン一覧へ戻す（見た目を元に戻すだけ。トークンには不要）
  //   読み込み完了まで待つ（直後に別の処理がこのタブへスクリプト注入しても途中で消えないように）
  async function restore(tab) {
    try { await chrome.tabs.update(tab.id, { url: LIST_URL }); } catch (_) { return; }
    await waitComplete(tab.id, 15000);
  }

  return { latest, ensureFresh, remember, restore, MAX_AGE, LIST_URL };
})();

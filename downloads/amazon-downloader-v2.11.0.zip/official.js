// ============================================================
// official.js  広告データ(①)を「公式の日別キャンペーンレポート」から作る（v2.11.0〜, Amacheckの依頼）
//
// 背景（2026-10-08 実機で確認）:
//  ・これまで①の元にしていた campaign-manager/retrieveReport（キャンペーン画面の表）は、
//    日によって費用が欠ける（例 2025-07-14 は SP の費用がすべて0）。取り直しても同じ値。
//  ・Amazon広告「レポート」画面（統合レポート）で作る日別キャンペーンレポートは正しい。
//    API: a9g-api-gateway/adsApi/v1/{create|query|retrieve}/...  （dds トークンのヘッダで通る）
//
// 流れ（ads.js から呼ぶ。ページ側で動く関数は chrome.scripting.executeScript で注入）:
//  1) OFFICIAL.create … 期間まとめて1件のレポートを作成（scheduleType NOW・メール送信なし）
//  2) OFFICIAL.poll   … 完了まで待つ（通常3〜5分）
//  3) OFFICIAL.download … CSV を取得（download-report → S3 へリダイレクト）
//  4) OFFICIAL.cmDaily … 照合用に、従来の取得元から日別のキャンペーン値（状態・ターゲティングタイプ含む）を取得
//  5) ads.js 側で日付ごとに分割して 広告データ-YYYY-MMDD.csv を保存＋照合
// ============================================================
self.OFFICIAL = (() => {
  const ACCOUNT = 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m';
  // 公式レポートの列（Amacheck が読む列名の元。順番も固定）
  const FIELDS = ['date.value', 'campaign.name', 'campaign.id', 'adProduct.value', 'budgetCurrency.value',
    'metric.totalCost', 'metric.sales', 'metric.clicks', 'metric.purchases', 'metric.impressions'];

  // ---- ページ(advertising-japan)で動く関数群（executeScript で注入するので自己完結にする） ----

  async function pageCreate({ headers, startDate, endDate, name, account, fields }) {
    const body = {
      accessRequestedAccounts: [{ advertiserAccountId: account }],
      reportConfigurations: [{
        name, format: 'CSV', locale: 'ja-JP', status: 'ACTIVE', emailDeliveryMarketplace: 'JP',
        linkedAccounts: [{ advertiserAccountId: account }],
        linkedQuery: { reportingQuery: { fields, filter: null } },   // filter 無し = SP/SB/SD すべて・状態で絞らない
        period: { datePeriod: { startDate, endDate } },
        scheduleType: 'NOW', schedule: { nowSchedule: { timeZone: 'ASIA_TOKYO' } }, timeZoneMode: 'CAMPAIGN_TIMEZONE'
      }]
    };
    try {
      const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/create/reportConfigurations',
        { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) });
      const t = await r.text();
      if (r.status !== 200 && r.status !== 207) return { ok: false, error: `HTTP ${r.status} ${t.slice(0, 200)}` };
      const j = JSON.parse(t);
      const rc = j.success && j.success[0] && j.success[0].reportConfiguration;
      if (!rc) return { ok: false, error: '作成に失敗: ' + t.slice(0, 200) };
      return { ok: true, cfgId: rc.reportConfigurationId, schedId: rc.latestScheduledReportId };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }

  async function pagePoll({ headers, cfgId }) {
    try {
      const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/query/scheduledReports',
        { method: 'POST', credentials: 'include', headers, body: JSON.stringify({ reportConfigurationIdFilter: { include: [cfgId] }, maxResults: 50 }) });
      if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
      const rep = ((await r.json()).scheduledReports || [])[0];
      if (!rep) return { ok: true, status: 'SCHEDULED' };
      return { ok: true, status: rep.status, schedId: rep.scheduledReportId, failure: rep.failureCode };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }

  async function pageDelete({ headers, cfgId, account }) {
    try {
      const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/adsApi/v1/delete/reportConfigurations',
        { method: 'POST', credentials: 'include', headers, body: JSON.stringify({ accessRequestedAccounts: [{ advertiserAccountId: account }], reportConfigurationIds: [cfgId] }) });
      return { ok: r.status === 200 || r.status === 207, status: r.status, text: (await r.text()).slice(0, 200) };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }

  // 照合用: 従来の取得元（campaign-manager）から日別・キャンペーン別の値を取る
  //   返り値: { [day]: { total, rows: [{ campaignId, campaignExternalId, campaignName, state, campaignTargetingType, programType, spend, sales, clicks }] } }
  async function pageCmDaily({ headers, days, account }) {
    const out = {};
    const FIELDS = ['campaignExternalId', 'campaignName', 'state', 'statusName', 'marketplaceId', 'programType', 'advertiserId',
      'campaignId', 'campaignType', 'campaignTargetingType', 'entityId', 'brandName', 'startDate', 'endDate', 'clicks', 'spend', 'orders', 'sales', 'roas'];
    for (const day of days) {
      const body = { reportConfig: {
        reportId: 'UnifiedCampaignReportSyncAPI', fields: FIELDS,
        filter: { and: [{ field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }] },
        startDate: day, endDate: day, timeUnits: ['SUMMARY', 'DAILY'], tokenPagination: { size: 300 }, currencyOfView: 'JPY',
        columnsByTimeUnit: { SUMMARY: ['clicks', 'spend', 'orders', 'sales', 'roas'], DAILY: ['spend', 'sales', 'orders', 'clicks'] }
      }, accessRequestedAccounts: [{ accountId: account }] };
      try {
        const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/campaign-manager/retrieveReport',
          { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) });
        if (!r.ok) { out[day] = { error: `HTTP ${r.status}` }; continue; }
        const j = await r.json();
        let rows = [];
        (function visit(v) { if (Array.isArray(v)) { if (v.length && v[0] && typeof v[0] === 'object' && 'campaignId' in v[0] && v.length > rows.length) rows = v; v.forEach(visit); } else if (v && typeof v === 'object') Object.values(v).forEach(visit); })(j);
        out[day] = {
          total: rows.reduce((a, x) => a + (Number(x.spend) || 0), 0),
          rows: rows.map((x) => ({ campaignId: x.campaignId, campaignExternalId: x.campaignExternalId, campaignName: x.campaignName, state: x.state,
            campaignTargetingType: x.campaignTargetingType, programType: x.programType, spend: Number(x.spend) || 0, sales: Number(x.sales) || 0, clicks: Number(x.clicks) || 0 }))
        };
      } catch (e) { out[day] = { error: String(e && e.message || e) }; }
      await new Promise((r) => setTimeout(r, 250));
    }
    return out;
  }

  // ---- CSV ユーティリティ（拡張ページ側） ----
  function parseCsv(text) {
    const s = text.replace(/^﻿/, '');
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (q) {
        if (ch === '"') { if (s[i + 1] === '"') { cell += '"'; i++; } else q = false; }
        else cell += ch;
      } else if (ch === '"') q = true;
      else if (ch === ',') { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && s[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.length > 1 || (r[0] || '').trim() !== '');
  }
  const csvCell = (v) => { if (v === null || v === undefined) return ''; let s = String(v); if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"'; return s; };
  const num = (v) => { const n = Number(String(v == null ? '' : v).replace(/[,¥￥\s]/g, '')); return isNaN(n) ? 0 : n; };
  // 日付文字列 → YYYY-MM-DD（"2025-07-11" / "2025/07/11" / "2025年7月11日" などに対応）
  function normDate(v) {
    const m = String(v || '').match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);
    return m ? `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}` : '';
  }

  // キャンペーンIDは ="451447082971855" の形（Excel対策）で入ってくるので、照合用に数字/IDだけにする
  const normId = (v) => String(v == null ? '' : v).trim().replace(/^=/, '').replace(/^"+|"+$/g, '').trim();

  return { ACCOUNT, FIELDS, pageCreate, pagePoll, pageDelete, pageCmDaily, parseCsv, csvCell, num, normDate, normId };
})();

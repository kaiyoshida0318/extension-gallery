// ===== KWデータ(SP/SB) ダウンローダー =====
// 仕組み:
//  1) 広告データ用トークン(campaign-manager)で、有効キャンペーンを1件取得
//     （キャンペーン名マップも同時に作る）
//  2) そのキャンペーンの「広告グループ」ページへ遷移させ、ページが自分で投げる
//     cm/dds/retrieveReport を hook.js が捕捉 → ddsコンテキストの正規トークンを入手
//  3) そのトークンで SPAdGroupTargetsReport を marketplace 単位で日別に一括取得
//     （SP だけでなく SB2 のターゲットも含まれる）
const $ = (id) => document.getElementById(id);
const LOG_KEY = 'kw_dl_logs';
const CAP_KEY = 'amzn_captured';     // campaign-manager トークン
const DDS_KEY = 'amzn_cap_dds';      // dds トークン
const WORK_KEY = 'amzn_working_req';  // 広告データが保存した通るリクエスト

// アカウント既定値(捕捉できなかった時のフォールバック)
const DEF_ENTITY = 'ENTITY15N4IW58E6FGF';
const DEF_ACCOUNT = 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m';
const DEF_MKT = 'A1VC38T7YXB528';

async function appendLog(text) {
  try {
    const s = await chrome.storage.local.get([LOG_KEY]);
    const logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), msg: String(text) });
    if (logs.length > 2000) logs.splice(0, logs.length - 2000);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  } catch (_) {}
}
function setStatus(msg, append = true) {
  const el = $('status');
  if (append) el.textContent += '\n' + msg; else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(p) { $('progress').style.width = p + '%'; }

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'kw-log') {
    appendLog(msg.text);
    setStatus(msg.text);
    if (typeof msg.extra?.progress === 'number') setProgress(msg.extra.progress);
  }
});

$('copylog').addEventListener('click', async () => {
  const s = await chrome.storage.local.get([LOG_KEY]);
  const logs = s[LOG_KEY] || [];
  const m = chrome.runtime.getManifest();
  const head = `=== ${m.name} KWログ v${m.version} ===\n${new Date().toISOString()}\n\n`;
  await navigator.clipboard.writeText(head + logs.map(l => `[${l.t.replace('T',' ').replace(/\..+/,'')}] ${l.msg}`).join('\n'));
  const b = $('copylog'); b.textContent = '✅ コピー済'; setTimeout(() => b.textContent = '📋 ログをコピー', 1500);
});
$('clearlog').addEventListener('click', async () => { await chrome.storage.local.remove([LOG_KEY]); setStatus('ログをクリアしました', false); });
$('stop').addEventListener('click', async () => { await chrome.storage.local.set({ kw_stop: true }); setStatus('■ 停止を要求しました（現在の処理後に停止）'); });

// ブラウザが拒否/上書きする禁止ヘッダを除去(トークン類は残す)
// ※ 大文字小文字違いの重複ヘッダ(Content-Type と content-type 等)は
//   Tomcatが HTTP 400 で弾くため、ここで大小無視で1つに統一する。
function cleanHeaders(headers) {
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  const out = {}; const seen = new Set();
  for (const [k, v] of Object.entries(headers || {})) {
    const lk = k.toLowerCase();
    if (!drop.test(k) && v != null && !seen.has(lk)) { out[k] = v; seen.add(lk); }
  }
  return out;
}
const hasCsrf = (h) => Object.keys(h || {}).some(k => /csrf-token/i.test(k));

// キャンペーン一覧の正規ボディ（UnifiedCampaignReportSyncAPI・50列以上）を探す。無ければ null（注入側の簡易版を使う）
async function getCampaignBody() {
  const s = await chrome.storage.local.get([WORK_KEY, CAP_KEY]);
  for (const r of [s[WORK_KEY], s[CAP_KEY]]) {
    const rc = r && r.body && r.body.reportConfig;
    if (rc && rc.reportId === 'UnifiedCampaignReportSyncAPI' && (rc.fields || []).length >= 50) return r.body;
  }
  return null;
}
// dds側のトークンを取得
async function getDdsHeaders() {
  const s = await chrome.storage.local.get([DDS_KEY]);
  const c = s[DDS_KEY];
  if (c && c.headers && hasCsrf(c.headers)) return { headers: cleanHeaders(c.headers), ts: c.ts || 0 };
  return null;
}

const waitTabComplete = async (tabId, ms = 20000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { await new Promise(r => setTimeout(r, 500)); try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') break; } catch (_) {} }
};

$('run').addEventListener('click', async () => {
  const sd = (await chrome.storage.local.get('sharedDates')).sharedDates || {};
  const startDate = sd.start, endDate = sd.end;
  if (!startDate || !endDate) { setStatus('❌ 上部で開始日・終了日を入力してください', false); return; }

  const btn = $('run'); btn.disabled = true;
  let tab = null, movedTab = false;   // 終了後にキャンペーン一覧へ戻すため
  setStatus('▶ 実行準備中...', false); setProgress(0);
  await chrome.storage.local.set({ kw_stop: false, kw_status: { state: 'running', ts: Date.now() } });

  try {
    const fs = await AMZ_FS.status();
    if (fs.state !== 'granted') {
      setStatus('保存先フォルダが未設定です。上部の「保存先」から設定してください', false);
      chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }

    // 広告タブを探す
    const tabs = await chrome.tabs.query({ url: ['https://advertising-japan.amazon.com/*', 'https://advertising.amazon.com/*'] });
    tab = (tabs || []).find(t => /campaign-manager\/all-campaigns/.test(t.url || ''))
             || (tabs || []).find(t => /advertising-japan\.amazon\.com/.test(t.url || ''))
             || (tabs || [])[0];
    if (!tab) { setStatus('❌ Amazon広告の画面のタブが見つかりません。上部「必要ページを開く」で開いてから実行してください', false); await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } }); btn.disabled = false; return; }

    // ── ① トークンを用意 ──
    // キャンペーン一覧は裏タブだと読み込まれないため使わない。新しい捕捉(cm/dds)が無ければ
    // 広告グループ画面(裏タブでも読み込まれる)を開いて取得する（token.js）。
    let tok = await AMZ_TOKEN.latest();
    if (!tok || Date.now() - tok.ts > AMZ_TOKEN.MAX_AGE) {
      const r = await AMZ_TOKEN.ensureFresh(tab, (t) => setStatus(t));
      if (r.moved) movedTab = true;
      tok = r.tok;
    }
    if (!tok) {
      setStatus('❌ トークンを取得できませんでした。Amazon広告にログインしているか確認して再実行してください', false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      return;
    }
    // キャンペーン一覧の正規ボディ(広告データ実行時に保存/捕捉されたもの)があれば使う。無ければ内蔵の簡易版
    const cm = { headers: cleanHeaders(tok.headers), body: await getCampaignBody() };

    // ── ② 有効キャンペーンを1件取得 + キャンペーン名マップ作成 ──
    setStatus('🔎 キャンペーン一覧を取得中…');
    const info = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fetchCampaignInfo,
      args: [{ headers: cm.headers, capBody: cm.body, defAccount: DEF_ACCOUNT, defEntity: DEF_ENTITY }]
    }))[0]?.result;

    if (!info || !info.ok || !info.campaignId) {
      setStatus(`❌ キャンペーン情報の取得に失敗: ${info?.error || '不明'}`, false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }
    setStatus(`  有効キャンペーン ${info.count}件 / 代表: ${info.campaignId}`);

    // ── ③ KW用(dds)トークン ──
    // ①で広告グループ画面から取った新しいトークンがあればそのまま使う。無ければ代表キャンペーンの広告グループ画面で取得
    if (info.pickType === 'SP') await AMZ_TOKEN.remember(info.campaignId);
    let dds = await getDdsHeaders();
    if (!dds || Date.now() - dds.ts > AMZ_TOKEN.MAX_AGE) {
      setStatus('🔑 KW用トークン(dds)を取得中…');
      const beforeDds = dds ? dds.ts : 0;
      const agUrl = `https://advertising-japan.amazon.com/cm/sp/campaigns/${encodeURIComponent(info.campaignId)}/ad-groups?entityId=${encodeURIComponent(info.entityId || DEF_ENTITY)}`;
      try { await chrome.tabs.update(tab.id, { url: agUrl }); movedTab = true; } catch (_) {}
      await waitTabComplete(tab.id);
      dds = null;
      const t2 = Date.now();
      while (Date.now() - t2 < 25000) { await new Promise(r => setTimeout(r, 800)); const d = await getDdsHeaders(); if (d && d.ts > beforeDds) { dds = d; break; } }
    }
    if (!dds) {
      setStatus('❌ KW用トークンを取得できませんでした。もう一度実行してみてください', false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      return;
    }

    // ── ④ marketplace単位で日別にKWを一括取得 ──
    const result = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: kwDownloader,
      args: [{ startDate, endDate, headers: dds.headers, mkt: info.mkt || DEF_MKT, campMap: info.campMap || {}, campState: info.campState || {}, account: DEF_ACCOUNT }]
    }))[0]?.result;

    if (result?.ok) {
      setStatus(`\n🎉 完了: 成功 ${result.success} / 失敗 ${result.fail}`);
      const b = $('done'); if (b) { b.textContent = '✓ 取得済み'; b.classList.add('done'); }
      await chrome.storage.local.set({ kw_status: { state: 'done', ts: Date.now() } });
      try { chrome.notifications.create('kw-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: 'KWデータ：ダウンロード完了', message: `成功 ${result.success}日 / 失敗 ${result.fail}日`, priority: 2 }, (id) => setTimeout(() => chrome.notifications.clear(id), 8000)); } catch (_) {}
    } else {
      setStatus(`\n❌ エラー: ${result?.error || '不明'}`);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
    }
  } catch (e) {
    setStatus(`\n❌ ${e.message}`); appendLog('error ' + e.message);
    await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
  } finally {
    // 広告グループ画面へ移動させたタブはキャンペーン一覧へ戻す（見た目を元に戻す）
    if (tab && movedTab) await AMZ_TOKEN.restore(tab);
    btn.disabled = false;
  }
});

// 状態バッジ
(async function initBadge() {
  const b = $('done'); if (!b) return;
  const setGreen = g => { b.textContent = g ? '✓ 取得済み' : '未取得'; b.classList.toggle('done', g); };
  try { const s = await chrome.storage.local.get(['kw_status']); setGreen((s.kw_status || {}).state === 'done'); } catch (_) { setGreen(false); }
  chrome.storage.onChanged.addListener((ch) => { if (ch.kw_status) setGreen((ch.kw_status.newValue || {}).state === 'done'); });
})();

// ============================================================
// ▼ 注入①: 有効キャンペーンを1件 + 名前マップを取得
//    campaign-manager トークンで UnifiedCampaignReportSyncAPI を叩く
// ============================================================
async function fetchCampaignInfo({ headers, capBody, defAccount, defEntity }) {
  try {
    const H = {}; const seenH = new Set();
    for (const [k, v] of Object.entries(headers || {})) { const lk = k.toLowerCase(); if (v != null && !seenH.has(lk)) { H[k] = v; seenH.add(lk); } }
    if (!seenH.has('content-type')) H['content-type'] = 'application/json';
    if (!seenH.has('accept')) H['accept'] = 'application/json';
    const account = headers['amazon-ads-account-id'] || headers['advertiserid'] || defAccount;
    const entity = headers['amazon-advertising-api-advertiserid'] || defEntity;
    const mkt = headers['amazon-advertising-api-marketplaceid'] || 'A1VC38T7YXB528';
    const today = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })();

    // UnifiedCampaignReportSyncAPI は列を省くと500になるため、ページが投げる
    // 正規ボディ(捕捉済み)をそのまま使い、日付とページングだけ差し替える。
    let body;
    const capN = (() => { try { return capBody.reportConfig.fields.length; } catch (_) { return 0; } })();
    if (capBody && capN >= 50 && capBody.reportConfig && capBody.reportConfig.reportId === 'UnifiedCampaignReportSyncAPI') {
      body = JSON.parse(JSON.stringify(capBody));
      body.reportConfig.startDate = today;
      body.reportConfig.endDate = today;
      // 画面の検索/絞り込みに左右されないよう filter は固定（state列は fields に含まれている前提）
      // 状態では絞らない（アーカイブ済みキャンペーンの名前も引けるように）
      body.reportConfig.filter = { and: [
        { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }
      ] };
      if (body.reportConfig.tokenPagination) body.reportConfig.tokenPagination = { size: 300 };
      else body.reportConfig.offsetPagination = { size: 300, offset: 0 };
    } else {
      body = { reportConfig: {
        reportId: 'UnifiedCampaignReportSyncAPI',
        fields: ['campaignExternalId','campaignName','state','statusName','marketplaceId','programType','advertiserId','campaignId','campaignType','campaignTargetingType','entityId','brandName','startDate','endDate','clicks','spend','orders','sales','roas'],
        filter: { and: [
          { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }
        ] },
        startDate: today, endDate: today,
        timeUnits: ['SUMMARY', 'DAILY'],
        tokenPagination: { size: 300 },
        currencyOfView: 'JPY',
        columnsByTimeUnit: { SUMMARY: ['clicks','spend','orders','sales','roas'], DAILY: ['spend','sales','orders','clicks'] }
      }, accessRequestedAccounts: [{ accountId: account }] };
    }

    const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/campaign-manager/retrieveReport', {
      method: 'POST', credentials: 'include', mode: 'cors', headers: H, body: JSON.stringify(body)
    });
    if (!r.ok) { const t = await r.text().catch(() => ''); return { ok: false, error: `HTTP ${r.status} ${t.slice(0,120)}` }; }
    const j = await r.json();

    // 行配列を探す
    let rows = [];
    const isRow = o => o && typeof o === 'object' && ('campaignId' in o);
    (function visit(v) { if (Array.isArray(v)) { if (v.length && isRow(v[0]) && v.length > rows.length) rows = v; v.forEach(visit); } else if (v && typeof v === 'object') Object.values(v).forEach(visit); })(j);

    const campMap = {}, campState = {};
    for (const row of rows) if (row.campaignId) { campMap[row.campaignId] = row.campaignName || ''; if (row.state) campState[row.campaignId] = row.state; }

    // 代表キャンペーン: 有効なSPを優先、無ければ有効な任意、無ければ先頭
    const enabledSP = rows.find(r => r.state === 'ENABLED' && r.programType === 'SP');
    const enabledAny = rows.find(r => r.state === 'ENABLED');
    const pick = enabledSP || enabledAny || rows[0];
    if (!pick) return { ok: false, error: 'キャンペーンが0件でした' };

    return { ok: true, campaignId: pick.campaignId, pickType: pick.programType, entityId: entity, mkt, count: rows.length, campMap, campState };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  }
}

// ============================================================
// ▼ 注入②: dds トークンで「ターゲティング」タブと同じデータを日別取得
//    ・キーワード＋商品ターゲティング(ASIN/カテゴリ)＋オートの全ターゲット
//    ・状態では絞り込まない（停止中・アーカイブも含め全件。ステータス列に現在の状態）
//    ・広告グループ名は SPAdGroupReport から（SP/SB両方入っている。起動時に1回）
// ============================================================
async function kwDownloader({ startDate, endDate, headers, mkt, campMap, campState, account }) {
  const writeLog = async (text) => {
    try { const KEY='kw_dl_logs'; const s=await chrome.storage.local.get([KEY]); const logs=s[KEY]||[]; logs.push({t:new Date().toISOString(),msg:String(text)}); if(logs.length>2000)logs.splice(0,logs.length-2000); await chrome.storage.local.set({[KEY]:logs}); } catch(_){}
  };
  const log = (text, progress) => { writeLog(text); try { chrome.runtime.sendMessage({ type: 'kw-log', text, extra: { progress } }); } catch (_) {} };

  const KW_URL = 'https://advertising-japan.amazon.com/a9g-api-gateway/cm/dds/retrieveReport';
  // filter に使う列(marketplaceId / targetState)は fields にも必須
  const KW_FIELDS = ['targetId','targetState','calculatedStatusName','programType','target','targetLocalized','matchType','targetBid','asin','title',
    'campaignId','marketplaceId','adGroupId','impressions','clicks','ctr','cpc','topOfSearchImpressionShare','spend','orders','sales','roas','acos','currencyCode'];

  // 禁止ヘッダのみ除去、トークン類はそのまま。
  // 大小違いの重複(Content-Type / content-type 等)はTomcatが400で弾くため統一。
  const dropH = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  const H = {}; const seenH = new Set();
  for (const [hk, hv] of Object.entries(headers || {})) { const lk = hk.toLowerCase(); if (!dropH.test(hk) && hv != null && !seenH.has(lk)) { H[hk] = hv; seenH.add(lk); } }
  if (!seenH.has('content-type')) H['content-type'] = 'application/json';
  if (!seenH.has('accept')) H['accept'] = 'application/json';

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const csvCell = v => { if (v === null || v === undefined) return ''; let s = typeof v === 'object' ? JSON.stringify(v) : String(v); if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"'; return s; };
  const toD = x => { const [y,m,d] = x.split('-').map(Number); return new Date(y, m-1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const r2 = v => (v === null || v === undefined || v === '' || isNaN(Number(v))) ? '' : Math.round(Number(v) * 100) / 100;

  // dds retrieveReport を offset ページングで全件取得
  const fetchAll = async (reportConfig) => {
    let offset = 0, out = [], total = Infinity, page = 0;
    while (offset < total) {
      page++;
      const body = { reportConfig: { ...reportConfig, offsetPagination: { size: 100, offset } } };
      const r = await fetch(KW_URL, { method:'POST', credentials:'include', mode:'cors', headers:H, body: JSON.stringify(body) });
      if (!r.ok) { const t = await r.text().catch(()=> ''); throw new Error(`HTTP ${r.status} ${t.slice(0,160)}`); }
      const j = await r.json();
      const rep = j.report || {};
      const rows = Array.isArray(rep.data) ? rep.data : [];
      total = (typeof rep.numberOfRecords === 'number') ? rep.numberOfRecords : rows.length;
      out = out.concat(rows);
      if (rows.length === 0 || page > 500) break;
      offset += 100; await sleep(200);
    }
    return out;
  };

  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate()+1)) days.push(fmt(d));
  log(`📅 ${days.length}日分 / SP・SBの全ターゲット（全状態）を取得`);

  // ── 広告グループ名・状態マップ（起動時に1回） ──
  const agMap = {};
  try {
    const ags = await fetchAll({
      reportId: 'SPAdGroupReport',
      fields: ['adGroupId','adGroupName','adGroupState','campaignId','statusName','spend'],
      filter: { and: [] },
      startDate: endDate, endDate: endDate,
      timeUnits: ['SUMMARY'],
      columnsByTimeUnit: { SUMMARY: ['spend'] }
    });
    for (const a of ags) if (a.adGroupId) agMap[a.adGroupId] = a;
    log(`  広告グループ ${ags.length}件を確認`);
  } catch (e) {
    log(`  ⚠ 広告グループ名を取得できませんでした（名前空欄・広告グループ状態の判定なしで続行）: ${e.message}`);
  }

  // ※ 状態（ターゲット/広告グループ/キャンペーン）では絞り込まない（v2.10.0〜, Amacheckからの依頼）。
  //   状態は「ダウンロード時点」のものなので、絞ると過去日に配信していた今は停止中のものが漏れる。
  //   全状態を出力し、ステータス列に現在の状態を入れる。
  // ステータス表示（現在の状態）: ターゲット → 広告グループ → キャンペーン の順で停止/アーカイブを判定
  const statusOf = (r) => {
    const st = (x) => /ARCHIVED/i.test(x || '') ? 'アーカイブ' : /PAUSED/i.test(x || '') ? '一時停止' : '';
    if (st(r.targetState)) return st(r.targetState);
    const ag = agMap[r.adGroupId] || {};
    const cs = campState && campState[r.campaignId];
    if (st(cs)) return 'キャンペーン' + st(cs);
    if (/CAMPAIGN/i.test(r.calculatedStatusName || '') && st(r.calculatedStatusName)) return 'キャンペーン' + st(r.calculatedStatusName);
    if (st(ag.adGroupState)) return '広告グループ' + st(ag.adGroupState);
    if (/AD_?GROUP/i.test(ag.statusName || '') && st(ag.statusName)) return '広告グループ' + st(ag.statusName);
    if (st(r.calculatedStatusName)) return st(r.calculatedStatusName);
    return '配信中';
  };

  const fetchDayKw = (day) => fetchAll({
    reportId: 'SPAdGroupTargetsReport',
    fields: KW_FIELDS,
    filter: { and: [
      { field: 'marketplaceId', comparisonOperator: 'EQUALS', value: mkt, not: false }
    ] },
    startDate: day, endDate: day,
    timeUnits: ['SUMMARY', 'DAILY'],
    columnsByTimeUnit: { SUMMARY: ['impressions','spend','orders','sales','roas'], DAILY: ['spend','sales','roas','impressions'] }
  });

  // ── 保持期間・照合チェック（Amacheck依頼 4・5） ──
  // Amazon は KW(ターゲット)単位の日別データを約5か月分（月単位）しか持っていない（2026-10 時点で 2026-05-01〜）。
  // それより前の日は全行0、さらに「月初日」だけはその月の合計が入って返ってくる（実機確認）。
  // → 保持期間外の日は取得しない。さらに各日のキャンペーン合計費用と照合し、
  //    ①≥¥100 なのに KW<①の5% / KW>①の3倍 かつ 差≥¥1,000 の日は保存しない。小さな差(>¥100かつ>2%)は警告のみ。
  const CM_URL = 'https://advertising-japan.amazon.com/a9g-api-gateway/campaign-manager/retrieveReport';
  const campaignSpendOfDay = async (day) => {
    const body = { reportConfig: {
      reportId: 'UnifiedCampaignReportSyncAPI',
      fields: ['campaignName','state','programType','campaignId','spend','sales','orders','clicks'],
      filter: { and: [ { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false } ] },
      startDate: day, endDate: day, timeUnits: ['SUMMARY', 'DAILY'], tokenPagination: { size: 300 }, currencyOfView: 'JPY',
      columnsByTimeUnit: { SUMMARY: ['clicks','spend','orders','sales','roas'], DAILY: ['spend','sales','orders','clicks'] }
    }, accessRequestedAccounts: [{ accountId: account || 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m' }] };
    const r = await fetch(CM_URL, { method: 'POST', credentials: 'include', mode: 'cors', headers: H, body: JSON.stringify(body) });
    if (!r.ok) throw new Error(`照合用キャンペーン合計の取得に失敗 HTTP ${r.status}`);
    const j = await r.json();
    let rows = [];
    (function visit(v) { if (Array.isArray(v)) { if (v.length && v[0] && typeof v[0] === 'object' && 'campaignId' in v[0] && v.length > rows.length) rows = v; v.forEach(visit); } else if (v && typeof v === 'object') Object.values(v).forEach(visit); })(j);
    return rows.reduce((a, x) => a + (Number(x.spend) || 0), 0);
  };
  const yen = (n) => '¥' + Math.round(n).toLocaleString();

  const TYPE_JA = { SP: 'SP', SB2: 'SB', HSA: 'SB', SBV: 'SB動画' };
  const MATCH_JA = { EXACT: '完全一致', PHRASE: 'フレーズ一致', BROAD: '部分一致' };
  const MATCH_ORDER = { BROAD: 0, PHRASE: 1, EXACT: 2, TARGETING_EXPRESSION: 3, TARGETING_EXPRESSION_PREDEFINED: 4 };
  const AUTO_JA = { 'close-match': 'ほぼ一致', 'loose-match': 'ゆるやかな一致', 'substitutes': '代替商品', 'complements': '補完商品' };
  // 種別: キーワード / 商品 / オート
  const kindJa = r => r.matchType === 'TARGETING_EXPRESSION' ? '商品' : r.matchType === 'TARGETING_EXPRESSION_PREDEFINED' ? 'オート' : 'キーワード';
  // マッチタイプ表示: KWは一致種別、商品は ASIN(拡張)/ASIN/カテゴリ、オートは一致グループ
  const matchJa = r => {
    if (MATCH_JA[r.matchType]) return MATCH_JA[r.matchType];
    const t = String(r.target || '');
    if (r.matchType === 'TARGETING_EXPRESSION_PREDEFINED') return AUTO_JA[t] || t;
    if (/^asin-expanded=/i.test(t)) return 'ASIN(拡張)';
    if (/^asin=/i.test(t)) return 'ASIN';
    if (/^category=/i.test(t)) return 'カテゴリ';
    return r.matchType || '';
  };
  // ターゲット表示: 商品ターゲティングは asin="B0..." → B0... に整形
  //   （targetLocalized は商品ターゲティングだと 'asin-expanded= B0…”' のように崩れるので target を優先）
  const targetJa = r => {
    const t = String(r.target || '');
    if (r.matchType === 'TARGETING_EXPRESSION_PREDEFINED') return AUTO_JA[t] || t;
    if (r.matchType === 'TARGETING_EXPRESSION') {
      const m = t.match(/^asin(?:-expanded)?="?([^"]+)"?$/i);
      if (m) return m[1];
      return r.targetLocalized || t;
    }
    // キーワードは target（登録した文字列そのまま）を使う。targetLocalized は環境によって英訳されて返り、
    // 「耐火バッグ」「防火袋」がどちらも "fireproof bag" になる等、別KWが同名化するため使わない。
    return t || r.targetLocalized || '';
  };

  const outHeader = ['日付','広告タイプ','キャンペーン名','広告グループ名','種別','キーワード/ターゲット','マッチタイプ','商品名','ステータス','入札額',
    'インプレッション','クリック','CTR(%)','CPC','合計費用','商品購入数','売上','ROAS','ACOS(%)','検索結果上部のインプレッションシェア(%)',
    'キャンペーンID','広告グループID','ターゲットID'];
  const toRow = (r, day) => [day, TYPE_JA[r.programType] || r.programType, (campMap && campMap[r.campaignId]) || '', (agMap[r.adGroupId] || {}).adGroupName || '',
    kindJa(r), targetJa(r), matchJa(r), r.title || '', statusOf(r), r.targetBid,
    r.impressions, r.clicks, r2(r.ctr), r2(r.cpc), r2(r.spend), r.orders, r2(r.sales), r2(r.roas), r2(r.acos), r2(r.topOfSearchImpressionShare),
    r.campaignId, r.adGroupId, r.targetId];
  const sortKey = (r) => [TYPE_JA[r.programType] || '', (campMap && campMap[r.campaignId]) || r.campaignId, (agMap[r.adGroupId] || {}).adGroupName || r.adGroupId, kindJa(r), targetJa(r)];
  const cmp = (a, b) => {
    const ka = sortKey(a), kb = sortKey(b);
    for (let i = 0; i < ka.length; i++) { const c = String(ka[i]).localeCompare(String(kb[i]), 'ja'); if (c) return c; }
    return (MATCH_ORDER[a.matchType] ?? 9) - (MATCH_ORDER[b.matchType] ?? 9);
  };

  // KW(ターゲット)日別データの保持期間: 今月を含めて約5か月前の月初から（2026-10 時点で 2026-05-01〜、実機確認）
  const cutoff = (() => { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 5); return fmt(d); })();
  let success = 0, fail = 0, skipped = 0;
  for (let di = 0; di < days.length; di++) {
    const day = days[di];
    try { if ((await chrome.storage.local.get('kw_stop')).kw_stop) { log('■ 停止しました'); break; } } catch (_) {}
    try {
      // ① 保持期間外の日は取得しない（Amacheck依頼 4）
      if (day < cutoff) {
        skipped++;
        log(`  ⏭ ${day} 保持期間外（KW日別データは ${cutoff} 以降のみ）のため取得しません`, Math.round(((di+1)/days.length)*100));
        continue;
      }
      const all = await fetchDayKw(day);
      // ② 広告データ（キャンペーン合計）との照合（Amacheck依頼 5）
      const kwSpend = all.reduce((a, x) => a + (Number(x.spend) || 0), 0);
      const campSpend = await campaignSpendOfDay(day);
      const tooLow = campSpend >= 100 && kwSpend < campSpend * 0.05;
      const tooHigh = kwSpend > campSpend * 3 && (kwSpend - campSpend) >= 1000;
      if (tooLow || tooHigh) {
        throw new Error(`KW合計${yen(kwSpend)}が広告データ合計${yen(campSpend)}と大きくずれているため保存しませんでした（${tooLow ? 'KWが5%未満' : 'KWが3倍超'}。保持期間外などでAmazonに正しいKW日別データが無い日です）`);
      }
      const diff = Math.abs(kwSpend - campSpend);
      if (diff > 100 && diff > campSpend * 0.02) {
        log(`  ⚠ ${day} KW合計${yen(kwSpend)}と広告データ合計${yen(campSpend)}に差があります（差${yen(diff)}）。保存はしますが確認してください`);
      }
      const rows = all.slice().sort(cmp);
      const lines = [outHeader.map(csvCell).join(',')];
      for (const r of rows) lines.push(toRow(r, day).map(csvCell).join(','));
      const csv = '﻿' + lines.join('\r\n') + '\r\n';
      const [yy, mm, dd] = day.split('-');
      const resp = await chrome.runtime.sendMessage({ type:'amz_save_data', subdir:'', filename:`KWデータ-${yy}-${mm}${dd}.csv`, dataUrl:'data:text/csv;charset=utf-8;base64,' + btoa(unescape(encodeURIComponent(csv))) });
      if (!resp || !resp.ok) throw new Error('保存に失敗: ' + ((resp && resp.error) || '保存先未設定/許可切れ'));
      success++;
      const nAg = new Set(rows.map(r => r.adGroupId)).size;
      log(`  ✅ ${day} → ターゲット ${rows.length}件（${nAg}広告グループ / ${new Set(rows.map(r => r.campaignId)).size}キャンペーン）保存`, Math.round(((di+1)/days.length)*100));
    } catch (e) {
      fail++;
      log(`  ❌ ${day} ${e.message}`, Math.round(((di+1)/days.length)*100));
    }
    await sleep(200);
  }
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}${skipped ? ` / 保持期間外でスキップ ${skipped}` : ''}`, 100);
  return { ok: true, success, fail, skipped };
}

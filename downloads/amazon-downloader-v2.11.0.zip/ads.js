// ============================================================
// Amazon広告 キャンペーン一括ダウンローダー v1.0.0
// 楽天版の構造を流用。retrieveReport を日付ループ + ページング + CSV化。
// ============================================================
const $ = id => document.getElementById(id);
const LOG_KEY = 'amzn_dl_logs';
const TMPL_KEY = 'amzn_dl_template';   // {raw, url, headers, body}
const LOG_MAX = 2000;

// ---- 初期テンプレ(ユーザーが採取した retrieveReport を流用) ----
const DEFAULT_TEMPLATE = {
  raw: '',
  url: 'https://advertising-japan.amazon.com/a9g-api-gateway/campaign-manager/retrieveReport',
  headers: {
    'accept': 'application/json',
    'advertiserid': 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m',
    'advertisertype': 'undefined',
    'amazon-ads-account-id': 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m',
    'amazon-advertising-api-advertiserid': 'ENTITY15N4IW58E6FGF',
    'amazon-advertising-api-clientid': 'amzn.advertising.789c1d8bc111003008c2560a5a6bdd7fb1aa1f2e9083171222846d7603376e52294ab285563eae55ae6a9edde7a2f30104c80e2f',
    'amazon-advertising-api-csrf-data': 'amzn.advertising.789c1d8bc111003008c2560a5a6bdd7fb1aa1f2e9083171222846d7603376e52294ab285563eae55ae6a9edde7a2f30104c80e2f',
    'amazon-advertising-api-csrf-token': 'REPLACE_WITH_FRESH_TOKEN',
    'amazon-advertising-api-isimpersonator': 'false',
    'amazon-advertising-api-isportalserver': 'false',
    'amazon-advertising-api-marketplaceid': 'A1VC38T7YXB528',
    'content-type': 'application/json',
    'prefer': 'return=representation',
    'x-ads-report-source-id': 'campaignOverviewAllCampaigns',
    'x-amz-isglobalcampaignenabled': 'true'
  },
  body: {"reportConfig":{"reportId":"UnifiedCampaignReportSyncAPI","fields":["campaignExternalId","campaignName","state","statusName","marketplaceId","programType","isDspCampaign","advertiserId","advertiserCfId","globalAccountId","campaignCostType","dateValue","budgetCurrency","currencyOfView","campaignFlightId","saStatusName","dspCampaignDeliveryStatus","globalCampaignId","internalProgramType","campaignId","bidAdjustmentPredicates","bidAdjustmentPercentages","statusReasons","isGlobalCampaign","campaignType","campaignTargetingType","entityId","campaign.autoManaged","siteRestrictions","campaign.country","countryCodes","brandName","sourceName","campaignRetailer","campaignBiddingStrategy","portfolioId","portfolioExternalId","portfolioName","currencyCode","advertiserName","startDate","endDate","timezone","campaignBudgetAmount","campaignBudgetAmountCoV","campaignBudgetType","campaignEffectiveBudget","campaignEffectiveBudgetCoV","campaignRuleBasedBudgetAmount","campaignRuleBasedBudgetAmountCoV","campaignApplicableBudgetRuleId","campaignApplicableBudgetRuleName","isAnyRuleAssociatedWithCampaign","bidType","clicks","ctr","cpc","cpcCoV","spend","spendCoV","orders","sales","salesCoV","roas","topOfSearchImpressionShare"],"filter":{"and":[{"field":"state","values":["ENABLED","PAUSED"],"comparisonOperator":"IN","not":false},{"field":"programType","values":["SP","HSA","SB2","SBV"],"comparisonOperator":"IN","not":false}]},"startDate":"2026-09-14","endDate":"2026-09-14","timeUnits":["SUMMARY","DAILY"],"tokenPagination":{"size":50},"currencyOfView":"JPY","columnsByTimeUnit":{"SUMMARY":["clicks","ctr","cpcCoV","spendCoV","orders","salesCoV","roas"],"DAILY":["spendCoV","salesCoV","orders","clicks"]}},"accessRequestedAccounts":[{"accountId":"amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m"}]}
};

// ---------- ログ ----------
async function appendLog(cat, text, extra = null) {
  try {
    const s = await chrome.storage.local.get([LOG_KEY]);
    const logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), cat, msg: String(text), extra });
    if (logs.length > LOG_MAX) logs.splice(0, logs.length - LOG_MAX);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  } catch (_) {}
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'amzn-log') {
    appendLog(msg.cat || 'page', msg.text, msg.extra || null);
    setStatus(msg.text);
    if (typeof msg.extra?.progress === 'number') setProgress(msg.extra.progress);
  }
});
function setStatus(msg, append = true) {
  const el = $('status');
  if (append) el.textContent += '\n' + msg; else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(pct) { $('progress').style.width = pct + '%'; }


// ---------- テンプレ管理 ----------
// 禁止ヘッダ(ブラウザが拒否/上書きする)を除去
function cleanHeaders(headers) {
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  // 大文字小文字違いの重複ヘッダ(Content-Type と content-type 等)はTomcatが400で弾くため1つに統一
  const out = {}; const seen = new Set();
  for (const [k, v] of Object.entries(headers || {})) {
    const lk = k.toLowerCase();
    if (!drop.test(k) && v != null && !seen.has(lk)) { out[k] = v; seen.add(lk); }
  }
  return out;
}

const CAP_KEY = 'amzn_captured';

// 検索欄の絞り込みに左右されないよう、filterを常に固定(名前検索などを除去)
// ※ キャンペーンの「状態」では絞り込まない（v2.10.0〜, Amacheckからの依頼）。
//   state列はその日ではなく「ダウンロード時点」の状態なので、絞ると過去日に配信していた
//   今は停止/アーカイブ中のキャンペーンが漏れる。画面の「すべて」と同じく全状態を出力する。
const FIXED_FILTER = { and: [
  { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }
] };
function sanitizeBody(body) {
  try {
    const b = JSON.parse(JSON.stringify(body));
    const rc = b && b.reportConfig;
    if (rc) {
      // 全広告種を横断するレポートに固定(SB等に絞られた状態を無効化)
      rc.reportId = 'UnifiedCampaignReportSyncAPI';
      // フィルタ・検索系のキーを全部除去してから固定条件に差し替え
      for (const k of Object.keys(rc)) {
        if (/filter|query|search|keyword/i.test(k)) delete rc[k];
      }
      rc.filter = JSON.parse(JSON.stringify(FIXED_FILTER));
    }
    // ボディ直下にある絞り込み系も除去
    for (const k of Object.keys(b)) {
      if (/^(filter|query|search|keyword)/i.test(k)) delete b[k];
    }
    return b;
  } catch (_) { return body; }
}
const CAP_MAX_AGE = 30 * 60 * 1000; // 30分以内の捕捉を「新鮮」とみなす

async function getTemplate() {
  const s = await chrome.storage.local.get([TMPL_KEY]);

  // ① 自動捕捉したトークンを最優先。キャンペーン一覧(cm)・広告グループ画面(dds)の
  //    どちらで捕捉したものでも campaign-manager/retrieveReport に通る（実機確認済み）ので新しい方を使う。
  const cap = await AMZ_TOKEN.latest();
  if (cap) {
    const headers = cleanHeaders(cap.headers);
    const capN = cap.body?.reportConfig?.reportId === 'UnifiedCampaignReportSyncAPI' ? (cap.body?.reportConfig?.fields?.length || 0) : 0;
    // ページは複数種類のretrieveReportを投げる。トークン(ヘッダ)だけ使い、
    // レポート設定はキャンペーン一覧の正規ボディ(50列以上)か内蔵版を使う。URLは常にcampaign-manager。
    const body = sanitizeBody(capN >= 50 ? cap.body : DEFAULT_TEMPLATE.body);
    return { url: DEFAULT_TEMPLATE.url, headers, body, _auto: true, ts: cap.ts, capN, src: cap.src };
  }

  // ② フォールバック: 手動で貼り付けたテンプレ(無ければ内蔵)
  const t = s[TMPL_KEY] || DEFAULT_TEMPLATE;
  const n = t.body?.reportConfig?.fields?.length || 0;
  if (n < 10) return { ...t, url: t.url || DEFAULT_TEMPLATE.url, body: sanitizeBody(DEFAULT_TEMPLATE.body), _auto: false };
  return { ...t, body: sanitizeBody(t.body), _auto: false };
}
(async function showTemplate() {
  const s = await chrome.storage.local.get([TMPL_KEY]);
  const saved = s[TMPL_KEY];
  if (saved?.raw) $('tmpl').value = saved.raw;
  // 自動トークンの状態表示
  const t = await getTemplate();
  const el = $('auto-status');
  if (!el) return;
  if (t._auto) {
    const ageMin = Math.round((Date.now() - (t.ts || 0)) / 60000);
    const fresh = (Date.now() - (t.ts || 0)) < CAP_MAX_AGE;
    el.textContent = fresh
      ? `🟢 トークン自動取得：有効（${ageMin}分前に更新）`
      : `🟡 トークン自動取得：${ageMin}分前（実行時に自動で取り直します）`;
    el.style.color = fresh ? '#1a7f37' : '#9a6700';
  } else {
    el.textContent = '⚪ トークン自動取得：未捕捉（実行時に自動で取得します）';
    el.style.color = '#888';
  }
})();

// "Copy as fetch" のテキストを {url, headers, body} に変換
function parseFetchSnippet(text) {
  const urlM = text.match(/fetch\(\s*["'`]([^"'`]+)["'`]/);
  if (!urlM) throw new Error('URLが見つかりません(fetch("...")の形式で貼ってください)');
  const url = urlM[1];

  const hM = text.match(/["']headers["']\s*:\s*(\{[\s\S]*?\})\s*,\s*\n?\s*["'](?:referrer|referrerPolicy|body|method|mode|credentials)["']/);
  let headers = {};
  if (hM) { try { headers = JSON.parse(hM[1]); } catch (e) { throw new Error('headersの解析に失敗: ' + e.message); } }

  const bM = text.match(/["']body["']\s*:\s*("(?:\\.|[^"\\])*")/);
  if (!bM) throw new Error('bodyが見つかりません');
  let body;
  try { body = JSON.parse(JSON.parse(bM[1])); }
  catch (e) { throw new Error('bodyの解析に失敗: ' + e.message); }

  // ブラウザが拒否する/上書きする禁止ヘッダを除去
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent)/i;
  const clean = {};
  for (const [k, v] of Object.entries(headers)) if (!drop.test(k)) clean[k] = v;

  return { raw: text, url, headers: clean, body };
}

$('savetmpl').addEventListener('click', async () => {
  try {
    const parsed = parseFetchSnippet($('tmpl').value);
    const n = parsed.body?.reportConfig?.fields?.length || 0;
    let note = '';
    if (n < 10) {
      // 別の(小さい)retrieveReportを貼った場合: トークンだけ使い、本体は内蔵設定に差し替え
      parsed.body = DEFAULT_TEMPLATE.body;
      parsed.url = parsed.url || DEFAULT_TEMPLATE.url;
      note = `（貼られたのは小さいリクエスト[${n}列]でしたが、トークンだけ採用し本体は内蔵の正しい設定[${DEFAULT_TEMPLATE.body.reportConfig.fields.length}列]を使います）`;
    }
    await chrome.storage.local.set({ [TMPL_KEY]: parsed });
    const cols = parsed.body?.reportConfig?.fields?.length ?? '?';
    $('tmpl-status').textContent = `✅ 保存しました(列 ${cols}個 / ${Object.keys(parsed.headers).length}ヘッダ)${note}`;
  } catch (e) {
    $('tmpl-status').textContent = '❌ ' + e.message;
  }
});

// ---------- ログのコピー/クリア ----------
$('copylog').addEventListener('click', async () => {
  const s = await chrome.storage.local.get([LOG_KEY]);
  const logs = s[LOG_KEY] || [];
  const m = chrome.runtime.getManifest();
  const head = `=== ${m.name} v${m.version} ログ ===\n${new Date().toISOString()}\nUA: ${navigator.userAgent}\n\n`;
  const body = logs.map(l => `[${l.t.replace('T',' ').replace(/\..+/,'')}] (${l.cat}) ${l.msg}` + (l.extra ? ` | ${JSON.stringify(l.extra)}` : '')).join('\n');
  await navigator.clipboard.writeText(head + body);
  const b = $('copylog'); b.textContent = '✅ コピー済'; setTimeout(() => b.textContent = '📋 ログをコピー', 1500);
});
$('clearlog').addEventListener('click', async () => {
  await chrome.storage.local.remove([LOG_KEY]); setStatus('ログをクリアしました', false);
});

// ---------- 実行 ----------
$('run').addEventListener('click', async () => {
  const sd = (await chrome.storage.local.get('sharedDates')).sharedDates || {};
  const startDate = sd.start, endDate = sd.end;
  const interval = 2;  // 固定2秒
  if (!startDate || !endDate) { setStatus('❌ 開始日・終了日を入力してください', false); return; }
  await chrome.storage.local.set({ ads_status: { state: 'running', ts: Date.now() } });
  try {
    const fs = await AMZ_FS.status();
    if (fs.state !== 'granted') {
      setStatus('保存先フォルダが未設定です。上部の「保存先」から設定してください', false);
      chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
      await chrome.storage.local.set({ ads_status: { state: 'idle', ts: Date.now() } });
      return;
    }
  } catch (_) {}
  await chrome.storage.local.set({ ads_stop: false });

  const btn = $('run'); btn.disabled = true;
  let movedTab = null;   // トークン取得で広告グループ画面へ移動させたタブ（終了時に一覧へ戻す）
  setStatus('▶ 実行準備中...', false); setProgress(0);

  try {
    // アクティブタブに依存せず、開いてあるAmazon広告のキャンペーン画面を自動で探す
    // キャンペーン一覧のタブを優先（KW取得後は広告グループ画面に居ることがあるため）
    let tabs = await chrome.tabs.query({ url: ['https://advertising-japan.amazon.com/*', 'https://advertising.amazon.com/*'] });
    let tab = (tabs || []).find(t => /campaign-manager\/all-campaigns/.test(t.url || ''))
           || (tabs || []).find(t => /advertising-japan\.amazon\.com/.test(t.url || ''))
           || (tabs || [])[0];
    if (!tab) {
      setStatus('❌ Amazon広告のキャンペーン画面のタブが見つかりません。上部「必要ページを開く」で開き、一度表示してから実行してください', false);
      btn.disabled = false; return;
    }

    // ── トークン自動更新 ──
    // キャンペーン一覧は裏タブだと表が読み込まれずトークンが取れないため、
    // 古い(3分超)/手動の場合は広告グループ画面(裏タブでも読み込まれる)を開いて取得する。
    let tmpl = await getTemplate();
    const ageMs = tmpl._auto ? (Date.now() - (tmpl.ts || 0)) : Infinity;
    if (ageMs > AMZ_TOKEN.MAX_AGE) {
      setStatus('🔄 トークン更新のため広告グループ画面を読み込み中…', false);
      await appendLog('run', 'トークンが古いため広告グループ画面で再取得');
      const r = await AMZ_TOKEN.ensureFresh(tab, (t) => appendLog('run', t));
      if (r.moved) movedTab = tab;
      tmpl = await getTemplate();
      if (!r.tok || !tmpl._auto || Date.now() - (tmpl.ts || 0) > AMZ_TOKEN.MAX_AGE) {
        setStatus('❌ トークンを更新できませんでした。\nAmazon広告にログインしているか確認してから再実行してください（長時間空くとログインが切れます）。', false);
        await appendLog('run', 'トークン更新失敗(ログイン切れの可能性)。実行中止');
        try { chrome.notifications.create('ads-authfail-' + Date.now(), {
          type: 'basic', iconUrl: 'icons/icon128.png',
          title: '広告データ：実行できませんでした',
          message: 'トークンを更新できません。Amazon広告のログイン状態を確認してください。',
          priority: 2
        }, (id) => setTimeout(() => chrome.notifications.clear(id), 10000)); } catch (_) {}
        await chrome.storage.local.set({ ads_status: { state: 'idle', ts: Date.now() } });
        return;
      }
    }

    const src = tmpl._auto ? `自動取得トークン(${Math.round((Date.now()-(tmpl.ts||0))/60000)}分前)` : '手動貼り付けトークン';
    await appendLog('run', `開始 ${startDate}〜${endDate} / ${src}`);
    setStatus(`トークン: ${src}`);

    // KW機能が流用できるよう、通るリクエスト(URL/ヘッダ/ボディ)を保存
    try { await chrome.storage.local.set({ amzn_working_req: { url: tmpl.url, headers: tmpl.headers, body: tmpl.body, ts: Date.now() } }); } catch (_) {}

    // ── 公式の日別キャンペーンレポートから作成（v2.11.0〜, official.js） ──
    // 統合レポートAPIは広告グループ画面(dds)のトークンで動作確認済みなので、それを使う（無ければ取得）
    const dr = await AMZ_TOKEN.ensureFresh(tab, (t) => appendLog('run', t), { ddsOnly: true });
    if (dr.moved) movedTab = tab;
    if (!dr.tok) { setStatus('\n❌ レポート用のトークンを取得できませんでした。Amazon広告にログインしているか確認して再実行してください'); return; }
    const result = await runOfficial({ tab, startDate, endDate, headers: cleanHeaders(dr.tok.headers) });

    if (result?.ok) {
      setStatus(`\n🎉 完了: 保存 ${result.success}日${result.warnDays ? ` / 照合で差あり ${result.warnDays}日（ログ参照）` : ''}`);
      // 完了バッジをその場で緑に(閉じている場合はバックグラウンドが反映)
      const b = document.getElementById('done');
      if (b) { b.textContent = '✓ 取得済み'; b.classList.add('done'); }
      try { await chrome.storage.local.set({ ads_status: { state: 'done', ts: Date.now() } }); } catch (_) {}
      try { chrome.notifications.create('ads-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '広告データ：ダウンロード完了',
        message: `保存 ${result.success}日` + (result.warnDays ? ` / 照合で差あり ${result.warnDays}日` : ''), priority: 2 }, (id) => setTimeout(() => chrome.notifications.clear(id), 8000)); } catch (_) {}
    } else setStatus(`\n❌ エラー: ${result?.error || '不明'}`);
  } catch (e) {
    setStatus(`\n❌ ${e.message}`); appendLog('error', e.message);
  } finally {
    if (movedTab) await AMZ_TOKEN.restore(movedTab);
    // 成功以外で終わった場合は 'running' のまま残さない（3種まとめてDL・バッジの判定用）
    try { const s = (await chrome.storage.local.get('ads_status')).ads_status || {}; if (s.state === 'running') await chrome.storage.local.set({ ads_status: { state: 'idle', ts: Date.now() } }); } catch (_) {}
    btn.disabled = false;
  }
});

// ============================================================
// ▼ 公式レポートで①を作る（v2.11.0〜）
//   1回の実行で期間まとめて1件のレポートを作成 → 完成を待つ → CSVを日付ごとに分けて保存
//   → 従来の取得元(キャンペーン画面の表)と日別合計を照合し、¥100超かつ2%超ずれた日は警告
// ============================================================
async function runOfficial({ tab, startDate, endDate, headers }) {
  const say = (t) => { setStatus(t); appendLog('run', t); };
  const inPage = async (func, arg) => (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args: [arg] }))[0]?.result;
  const stopped = async () => { try { return !!(await chrome.storage.local.get('ads_stop')).ads_stop; } catch (_) { return false; } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const yen = (n) => '¥' + Math.round(n).toLocaleString();
  const toD = (x) => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const days = []; for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));

  // 1) レポート作成（期間まとめて1件・メール送信なし）
  const stamp = new Date().toLocaleString('ja-JP', { hour12: false }).replace(/[^\d]/g, '').slice(2, 12);
  const name = `amazon-downloader 広告データ ${startDate}〜${endDate} (${stamp})`;
  say(`📝 公式レポートを作成中（${startDate}〜${endDate}・${days.length}日分）…`);
  const cr = await inPage(OFFICIAL.pageCreate, { headers, startDate, endDate, name, account: OFFICIAL.ACCOUNT, fields: OFFICIAL.FIELDS });
  if (!cr || !cr.ok) return { ok: false, error: '公式レポートを作成できませんでした: ' + (cr && cr.error || '不明') };
  appendLog('run', `レポート作成: ${name} / config=${cr.cfgId}`);

  // 2) 照合用の従来データ（キャンペーン画面の表）を先に取っておく（状態・ターゲティングタイプにも使う）
  say('🔎 照合用データ（キャンペーン画面の値）を取得中…');
  const cm = await inPage(OFFICIAL.pageCmDaily, { headers, days, account: OFFICIAL.ACCOUNT }) || {};

  // 3) 完成待ち（最大20分）
  say('⏳ Amazon側でレポートを作成中です（通常3〜10分）。このポップアップは閉じないでください…');
  const t0 = Date.now(); let st = null;
  while (Date.now() - t0 < 20 * 60 * 1000) {
    if (await stopped()) return { ok: false, error: '停止しました（作成中のレポートはAmazonの「レポート」画面に残ります）' };
    st = await inPage(OFFICIAL.pagePoll, { headers, cfgId: cr.cfgId });
    if (st && st.ok && st.status === 'COMPLETED') break;
    if (st && st.ok && /FAIL|CANCEL/i.test(st.status || '')) return { ok: false, error: `公式レポートの作成に失敗しました（${st.status} ${st.failure || ''}）` };
    setProgress(Math.min(60, Math.round((Date.now() - t0) / (10 * 60 * 1000) * 60)));
    await sleep(15000);
  }
  if (!st || st.status !== 'COMPLETED') return { ok: false, error: '公式レポートが20分以内に完成しませんでした。少し時間をおいて再実行してください' };
  say(`✅ 公式レポート完成（${Math.round((Date.now() - t0) / 1000)}秒）。ダウンロード中…`);

  // 4) ダウンロード（download-report → S3 へリダイレクト。拡張ページからは host_permissions で取得できる）
  let csvText;
  try {
    const url = `https://advertising-japan.amazon.com/reporting/subscriptions/${encodeURIComponent(cr.cfgId)}/download-report/${encodeURIComponent(st.schedId)}`;
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const u8 = new Uint8Array(await res.arrayBuffer());
    if (u8[0] === 0x1f && u8[1] === 0x8b) csvText = await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
    else csvText = new TextDecoder('utf-8').decode(u8);
  } catch (e) {
    return { ok: false, error: `公式レポートのダウンロードに失敗しました（${e.message}）。Amazonの「レポート」画面に「${name}」が完成しています` };
  }

  // 5) 解析・日付ごとに分割
  const table = OFFICIAL.parseCsv(csvText);
  if (!table.length) return { ok: false, error: '公式レポートが空でした' };
  const header = table[0];
  // 列は FIELDS の順で並ぶ: 0日付 1キャンペーン名 2キャンペーンID 3広告プロダクト 4予算の通貨 5合計費用 6売上 7クリック数 8商品購入数 9インプレッション
  const I = { date: 0, name: 1, id: 2, product: 3, cost: 5, sales: 6, clicks: 7 };
  if (header.length < OFFICIAL.FIELDS.length) return { ok: false, error: `公式レポートの列数が想定と違います（${header.length}列: ${header.join(',').slice(0, 120)}）` };
  appendLog('run', `公式レポート ${table.length - 1}行 / 列: ${header.join(',')}`);

  const byDay = {};
  for (const r of table.slice(1)) {
    const day = OFFICIAL.normDate(r[I.date]);
    if (!day) continue;
    (byDay[day] = byDay[day] || []).push(r);
  }

  // 状態・ターゲティングタイプ（キャンペーン画面の値から。IDまたは名前で引く）
  const meta = {};
  for (const d of Object.values(cm)) for (const x of (d && d.rows) || []) {
    const v = { state: x.state || '', tt: x.campaignTargetingType || '' };
    if (x.campaignId) meta['id:' + x.campaignId] = v;
    if (x.campaignExternalId) meta['id:' + x.campaignExternalId] = v;
    if (x.campaignName) meta['name:' + x.campaignName] = v;
  }
  const TT_JA = { AUTOMATIC: 'オート', AUTO: 'オート', MANUAL: 'マニュアル' };
  const ST_JA = { ENABLED: '有効', PAUSED: '一時停止', ARCHIVED: 'アーカイブ' };
  const metaOf = (r) => meta['id:' + OFFICIAL.normId(r[I.id])] || meta['name:' + r[I.name]] || { state: '', tt: '' };

  const outHeader = header.concat(['ターゲティングタイプ', '状態']);
  let success = 0, fail = 0, warnDays = 0;
  for (let i = 0; i < days.length; i++) {
    const day = days[i];
    const rowsAll = byDay[day] || [];
    // 費用・売上・クリックがすべて0の行は入れない（Amacheckの依頼）
    const rows = rowsAll.filter((r) => OFFICIAL.num(r[I.cost]) !== 0 || OFFICIAL.num(r[I.sales]) !== 0 || OFFICIAL.num(r[I.clicks]) !== 0);
    const lines = [outHeader.map(OFFICIAL.csvCell).join(',')];
    for (const r of rows) {
      const m = metaOf(r);
      const tt = TT_JA[m.tt] || m.tt || '';   // キャンペーン画面の campaignTargetingType（AUTO/MANUAL）
      lines.push(r.concat([tt, ST_JA[m.state] || m.state || '']).map(OFFICIAL.csvCell).join(','));
    }
    const csv = '﻿' + lines.join('\r\n') + '\r\n';
    const [yy, mm, dd] = day.split('-');
    const fname = `広告データ-${yy}-${mm}${dd}.csv`;
    const bytes = new TextEncoder().encode(csv); let bin = '';
    for (let k = 0; k < bytes.length; k += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(k, k + 0x8000));
    const resp = await chrome.runtime.sendMessage({ type: 'amz_save_data', subdir: '', filename: fname, dataUrl: 'data:text/csv;charset=utf-8;base64,' + btoa(bin) });
    const offTotal = rows.reduce((a, r) => a + OFFICIAL.num(r[I.cost]), 0);
    if (!resp || !resp.ok) { fail++; say(`  ❌ ${day} 保存に失敗: ${(resp && resp.error) || '保存先未設定/許可切れ'}`); continue; }
    success++;
    // 照合: 公式 vs キャンペーン画面の値（日別合計）。¥100超かつ2%超ずれたら警告（どのキャンペーンか）
    const c = cm[day];
    let note = '';
    if (c && !c.error) {
      const diff = offTotal - c.total;
      if (Math.abs(diff) > 100 && Math.abs(diff) > offTotal * 0.02) {
        warnDays++;
        const cmBy = {}; for (const x of c.rows) cmBy[x.campaignId] = cmBy[x.campaignExternalId] = cmBy['n:' + x.campaignName] = x;
        const camp = rows.map((r) => { const x = cmBy[OFFICIAL.normId(r[I.id])] || cmBy['n:' + r[I.name]]; const o = OFFICIAL.num(r[I.cost]); const v = x ? x.spend : 0; return { name: r[I.name], o, v, d: o - v }; })
          .filter((z) => Math.abs(z.d) > 100).sort((a, b) => Math.abs(b.d) - Math.abs(a.d)).slice(0, 5)
          .map((z) => `${z.name}（公式${yen(z.o)} / 画面${yen(z.v)}）`).join('、');
        note = `\n     ⚠ キャンペーン画面の値と差あり: 公式${yen(offTotal)} / 画面${yen(c.total)}（差${yen(diff)}）${camp ? '\n       ' + camp : ''}\n       → ファイルは公式レポートの数字で作成しました`;
      }
    } else if (c && c.error) note = `（照合用データ取得失敗: ${c.error}）`;
    say(`  ✅ ${day} → ${rows.length}件 合計費用${yen(offTotal)}${note}`);
    setProgress(60 + Math.round(((i + 1) / days.length) * 40));
  }
  return { ok: true, success, fail, warnDays, cfgId: cr.cfgId };
}

// ============================================================
// ▼ ページ(advertising-japan.amazon.com)に注入される本体
// ============================================================
async function amazonDownloader({ startDate, endDate, interval, tmpl }) {
  const writeLog = async (text, extra) => {
    try {
      const KEY = 'amzn_dl_logs';
      const s = await chrome.storage.local.get([KEY]);
      const logs = s[KEY] || [];
      logs.push({ t: new Date().toISOString(), cat: 'amzn', msg: String(text), extra: extra || null });
      if (logs.length > 2000) logs.splice(0, logs.length - 2000);
      await chrome.storage.local.set({ [KEY]: logs });
    } catch (_) {}
  };
  const log = (text, progress) => {
    writeLog(text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'amzn-log', cat: 'amzn', text, extra: { progress } }); } catch (_) {}
  };

  const fields = tmpl?.body?.reportConfig?.fields || [];
  if (!tmpl?.url || !fields.length) { log('❌ リクエストテンプレートが不正です'); return { ok: false, error: 'テンプレート不正' }; }

  // 日付リスト
  const toD = x => { const [y,m,d] = x.split('-').map(Number); return new Date(y, m-1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate()+1)) days.push(fmt(d));
  log(`📅 ${days.length}日分 / ${fields.length}列`);

  // レスポンスJSONからキャンペーン行の配列を探す
  const findRows = (obj) => {
    let best = [];
    const isRow = o => o && typeof o === 'object' && ('campaignId' in o || 'campaignName' in o || 'campaignExternalId' in o);
    const visit = v => {
      if (Array.isArray(v)) { if (v.length && isRow(v[0]) && v.length > best.length) best = v; v.forEach(visit); }
      else if (v && typeof v === 'object') Object.values(v).forEach(visit);
    };
    visit(obj);
    return best;
  };
  const csvCell = v => {
    if (v === null || v === undefined) return '';
    let s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let success = 0, fail = 0;

  const MAX_RETRY = 3;          // 1日あたり最大試行回数
  const failedDays = [];

  // レスポンスから次ページトークンを探す(キー名は環境で変わりうるので総当たり)
  const findNextToken = (obj) => {
    let found = null;
    const KEYS = /^(nexttoken|next_page_token|nextpagetoken|paginationtoken|pagetoken|token|cursor)$/i;
    const visit = (v) => {
      if (found) return;
      if (Array.isArray(v)) { v.forEach(visit); return; }
      if (v && typeof v === 'object') {
        for (const [k, val] of Object.entries(v)) {
          if (found) break;
          if (KEYS.test(k) && typeof val === 'string' && val.length > 0) { found = val; return; }
          visit(val);
        }
      }
    };
    visit(obj);
    return found;
  };

  // 1日分を取得してCSV保存(成功で件数を返す)。失敗時は例外を投げる。
  const fetchOneDay = async (day) => {
    const rc = tmpl.body.reportConfig || {};
    const useToken = !!rc.tokenPagination;               // 新API: tokenPagination
    const size = (rc.tokenPagination?.size) || (rc.offsetPagination?.size) || 50;
    let offset = 0, nextToken = null, allRows = [], page = 0;
    while (true) {
      page++;
      const body = JSON.parse(JSON.stringify(tmpl.body));
      body.reportConfig.startDate = day;
      body.reportConfig.endDate = day;
      if (useToken) {
        body.reportConfig.tokenPagination = nextToken ? { size, token: nextToken } : { size };
      } else {
        body.reportConfig.offsetPagination = { size, offset };
      }

      const res = await fetch(tmpl.url, {
        method: 'POST', credentials: 'include', mode: 'cors',
        headers: { ...tmpl.headers },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const t = await res.text().catch(() => '');
        const note = res.status === 429 ? '(リクエスト過多。間隔を空けて再試行)'
                   : (res.status === 401 || res.status === 403) ? '(セッション/トークン切れ。retrieveReportを再取得して貼り直し)'
                   : '';
        const err = new Error(`HTTP ${res.status}${note} ${t.slice(0,120)}`);
        err.status = res.status;
        throw err;
      }
      const json = await res.json();
      const rows = findRows(json);
      if (page === 1 && rows.length === 0) {
        log(`  ⚠️ ${day} 行が見つかりません。レスポンス構造: ${Object.keys(json).join(',').slice(0,120)}`);
      }
      allRows = allRows.concat(rows);
      if (page > 200) break;
      if (useToken) {
        nextToken = findNextToken(json);
        if (!nextToken || rows.length === 0) break;
      } else {
        if (rows.length < size) break;
        offset += size;
      }
      await sleep(300);
    }

    const header = fields.join(',');
    const lines = allRows.map(r => fields.map(f => csvCell(r[f])).join(','));
    const csv = '\uFEFF' + header + '\n' + lines.join('\n');
    const [yy, mm, dd] = day.split('-');
    const fname = `広告データ-${yy}-${mm}${dd}.csv`;   // 例: 2026-09-16 → 広告データ-2026-0916.csv
    // CSVをbase64のdata URLにしてService Workerへ渡し、選んだフォルダへ直接保存
    const bytes = new TextEncoder().encode(csv);
    let bin = '';
    for (let k = 0; k < bytes.length; k += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(k, k + 0x8000));
    const dataUrl = 'data:text/csv;charset=utf-8;base64,' + btoa(bin);
    const resp = await chrome.runtime.sendMessage({
      type: 'amz_save_data', subdir: '', filename: fname, dataUrl
    });
    if (!resp || !resp.ok) throw new Error('保存に失敗: ' + ((resp && resp.error) || '保存先未設定/許可切れ'));
    return allRows.length;
  };

  for (let i = 0; i < days.length; i++) {
    try { if ((await chrome.storage.local.get('ads_stop')).ads_stop) { log('■ 停止しました'); break; } } catch (_) {}
    const day = days[i];
    let done = false;
    for (let attempt = 1; attempt <= MAX_RETRY && !done; attempt++) {
      try {
        const n = await fetchOneDay(day);
        success++;
        log(`  ✅ ${day} → ${n}件${attempt > 1 ? `(${attempt}回目で成功)` : ''}`, Math.round(((i+1)/days.length)*100));
        done = true;
      } catch (e) {
        // 400/422(InvalidInput=日付がレポート提供期間外 等)はリトライ無意味→即打ち切り
        const noRetry = e.status === 400 || e.status === 422 || /InvalidInput/i.test(e.message || '');
        if (noRetry) {
          fail++; failedDays.push(day);
          log(`  ❌ ${day} 取得不可(リトライ対象外): ${e.message}\n     ※ Amazonのレポート提供期間(スポンサープロダクト約95日/ブランド・ディスプレイ約60日)を超えている可能性が高いです`, Math.round(((i+1)/days.length)*100));
          break;
        }
        if (attempt < MAX_RETRY) {
          // 429やサーバー混雑(504等)は待ち時間を増やしてリトライ(バックオフ)
          const wait = (e.status === 429 ? 5 : 2) * attempt;
          log(`  ↻ ${day} 失敗(${attempt}/${MAX_RETRY}): ${e.message} → ${wait}秒後に再試行`);
          await sleep(wait * 1000);
        } else {
          fail++; failedDays.push(day);
          log(`  ❌ ${day} ${MAX_RETRY}回試行して失敗: ${e.message}`, Math.round(((i+1)/days.length)*100));
        }
      }
    }
    if (i < days.length - 1) await sleep(interval * 1000);
  }

  if (failedDays.length) log(`⚠️ 取得できなかった日: ${failedDays.join(', ')}`);
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  try { chrome.runtime.sendMessage({ type: 'amz_ads_done', success, fail }); } catch (_) {}
  return { ok: true, success, fail, failedDays };
}

// ===== 「必要ページを一括で開く」ボタン(統合版で追加) =====
(function () {
  const btn = document.getElementById('open-pages');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    const urls = [
      'https://advertising-japan.amazon.com/campaign-manager/all-campaigns',
      'https://sellercentral-japan.amazon.com/orders-v3?page=1'
    ];
    for (const u of urls) {
      try { await chrome.tabs.create({ url: u, active: false }); } catch (_) {}
    }
    btn.textContent = '✅ 開きました（各タブを一度表示してください）';
    setTimeout(() => (btn.textContent = '🗂️ 必要ページを一括で開く'), 2500);
  });
})();

// ===== 停止ボタン(統合版で追加) =====
(function () {
  const sb = document.getElementById('stop');
  if (!sb) return;
  sb.addEventListener('click', async () => {
    try { await chrome.storage.local.set({ ads_stop: true }); } catch (_) {}
    setStatus('■ 停止を要求しました（現在の日付の処理後に停止）');
  });
})();


// ===== 状態バッジ(未取得 / ✓取得済み)=====
// ・閉じている間に完了したら、開いたとき一度だけ「取得済み」を表示
// ・一度表示したら次に開くと「未取得」に戻る
async function initDoneBadge(statusKey) {
  const b = document.getElementById('done');
  if (!b) return;
  const setGreen = (g) => { b.textContent = g ? '✓ 取得済み' : '未取得'; b.classList.toggle('done', g); };
  try {
    const s = await chrome.storage.local.get([statusKey]);
    setGreen((s[statusKey] || {}).state === 'done');   // done なら常に取得済み
  } catch (_) { setGreen(false); }
  chrome.storage.onChanged.addListener((ch) => {
    if (!ch[statusKey]) return;
    setGreen((ch[statusKey].newValue || {}).state === 'done');
  });
}
initDoneBadge('ads_status');

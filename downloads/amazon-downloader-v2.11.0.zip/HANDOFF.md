# amazon-downloader 引き継ぎ資料（2026-10-08 時点 / v2.11.0）

別のチャットでこの開発を続けるための要点メモ。このzipを添付し、「HANDOFF.md を読んで続きをやって」と伝えればOK。

---

## 0-official. v2.11.0 の変更（2026-10-08）①広告データを「公式の日別キャンペーンレポート」から作成（Amacheck依頼）
- 背景：従来の取得元 campaign-manager/retrieveReport は日によって費用が欠ける（実機で再現：2025-07-11 23-05-耐火バッグ-kw が 392.50＝正 9,348.64、
  2025-07-14 は SP 費用が全部0）。取り直しても同じ。統合レポート（Amazon広告「レポート」→ /reporting）の日別キャンペーンレポートは正しい。
- **統合レポート API（a9g-api-gateway/adsApi/v1/…）** ※ dds トークンのヘッダで通る（cm トークンは未検証のため ads.js は dds を必ず取り直して使う）
  - 作成 `POST create/reportConfigurations` body: `{accessRequestedAccounts:[{advertiserAccountId}], reportConfigurations:[{name, format:'CSV', locale:'ja-JP',
    status:'ACTIVE', emailDeliveryMarketplace:'JP', linkedAccounts:[{advertiserAccountId}], linkedQuery:{reportingQuery:{fields:[…], filter:null}},
    period:{datePeriod:{startDate,endDate}}, scheduleType:'NOW', schedule:{nowSchedule:{timeZone:'ASIA_TOKYO'}}, timeZoneMode:'CAMPAIGN_TIMEZONE'}]}` → 207
    （status / emailDeliveryMarketplace / accessRequestedAccounts が無いと 400。deliverySettings 省略＝メール送信なし）
  - 状態 `POST query/scheduledReports {reportConfigurationIdFilter:{include:[cfgId]}, maxResults:50}` → status SCHEDULED→COMPLETED（実測 3〜12分）
  - 削除 `POST delete/reportConfigurations {accessRequestedAccounts, reportConfigurationIds:[cfgId]}` → 207
  - 列一覧 `POST query/reportingFields {}`（1155項目）。キャンペーン単位の「オート/マニュアル」項目は無い。
  - ダウンロード `GET /reporting/subscriptions/{cfgId}/download-report/{scheduledReportId}` → 302 → S3
    `decorated-reports-prod-pdx.s3.us-west-2.amazonaws.com`。S3 に CORS が無くページ文脈では読めない →
    **拡張ページから fetch（host_permissions に https://*.amazonaws.com/* を追加）**。
- 公式CSVの形（実物で確認）：ヘッダ `日付,キャンペーン名,キャンペーンID,広告プロダクト,予算の通貨,合計費用,売上,クリック数,商品購入数,インプレッション`、
  日付 `2025/07/12`、キャンペーンID は `="451447082971855"`（数値の外部ID＝campaign-manager の campaignExternalId と一致）、
  広告プロダクト `Sponsored Products` / `Sponsored Brands`。0行は元々出ない。
- 実装（official.js 新設 + ads.js runOfficial）：
  1) 期間まとめて**1件**だけ作成（名前 `amazon-downloader 広告データ {start}〜{end} ({stamp})`、メール無し、本番は削除しない）
  2) 待っている間に照合用の campaign-manager 日別値を取得（状態・campaignTargetingType もここから）
  3) 完成待ち（15秒間隔・最大20分）→ ダウンロード → 日付ごとに分割して `広告データ-YYYY-MMDD.csv`
  4) 列＝公式の10列そのまま＋末尾に `ターゲティングタイプ`（AUTOMATIC→オート / MANUAL→マニュアル）と `状態`（有効/一時停止/アーカイブ）。
     費用・売上・クリックがすべて0の行は入れない。キャンペーンIDのセルは元の `="…"` のまま。
  5) 照合：公式の日別合計 vs campaign-manager 日別合計。差が ¥100 超かつ 2% 超ならログに警告（差の大きいキャンペーン上位5件）。ファイルは公式の数字。
- 検証：テスト用レポート（2025-07-11〜14）を実際に作成→実CSVで日別合計 29,707.13 / 23,936.84 / 24,632.23 / 35,264.02（Amacheck提示の正解と一致）。
  実CSV＋実際の campaign-manager 値で runOfficial を擬似Chromeで実行し、警告の差額 ¥15,222 / ¥1,950 / ¥3,566 / ¥26,244 が Amacheck の報告と一致。
  テスト用レポートは削除済み。※ 拡張ページからの S3 ダウンロード（host_permissions）はユーザー環境での初回実行で要確認。
- 旧 amazonDownloader（campaign-manager から65列で保存）は ads.js に残っているが呼ばれない。
- ③KW（kw.js）：保持期間外（今月を含め5か月前の月初より前、例 2026-10 → 2026-05-01 未満）の日は取得しない（⏭ ログ）。
  照合ルールを Amacheck の目安に変更：①≥¥100 かつ KW<①の5% / KW>①の3倍 かつ 差≥¥1,000 → 保存しない。差 >¥100 かつ >2% は保存して ⚠ 警告。

## 0-amacheck. v2.10.0 の変更（2026-10-08）状態による絞り込みを廃止（Amacheckからの依頼）
- 依頼要旨：state列は「その日」ではなく「ダウンロード時点」の状態。状態で絞ると、過去日に配信・費用発生していて
  今は停止/アーカイブのキャンペーンがファイルに入らず、分析側で取り戻せない。→ 全レポートで状態の絞り込みを外す。
  期間・列構成・ファイル名・保存先は不変。状態列は残す。停止中で動きのない行は 0 で入ってよい。
- 広告データ（ads.js）：FIXED_FILTER から state を削除（programType: SP/HSA/SB2/SBV のみ）。
  実機：state フィルタ無し = 28件（PAUSED 24 + ENABLED 4）。ARCHIVED のみ指定は 0件（現状アーカイブ無し）。
- KWデータ（kw.js）：サーバ側 targetState フィルタと isActive 絞り込みを削除し全行出力。キャンペーン名マップ(fetchCampaignInfo)も状態で絞らない。
  「ステータス」列（列名は不変）は現在の状態を日本語で：配信中 / 一時停止 / アーカイブ / キャンペーン一時停止 / 広告グループ一時停止。
- **KWの保持期間ガード（重要）**：SPAdGroupTargetsReport は KW 日別データを約5か月分（月単位）しか持たない。
  2026-10 時点で 2026-05-01〜 は日別がキャンペーン合計と完全一致。それより前は全行0、**月初日だけその月の合計が入る**
  （例 2026-03-01 KW合計 ¥1,648,973 = 3月の月計）。誤データ保存を防ぐため、各日でキャンペーン合計費用
  （campaign-manager/retrieveReport、ddsトークンで可）と KW 合計費用を照合し、差が max(¥1, 0.5%) を超えたら保存せず ❌ ログ。
- 検証（実アカウント・実コード）：
  - 広告データ 2025-10-04：28行/65列、今は停止中の「24-03-スピーカースタンド-KW」が state=PAUSED・spend 766.04・sales 2709・orders 1 で入ることを確認。
  - KWデータ 2026-05-15：233行/23列・費用合計 ¥42,036（キャンペーン合計と一致）。今は停止中のKW
    「【SB】耐火バッグ-商品コレ-KW / 耐火ケース / 完全一致」が 費用283.78・売上1527 で入ることを確認。
  - KWデータ 2026-03-01 / 2026-04-10 はガードで保存されないことを確認。

## 0-fix2. v2.9.2 の変更（2026-10-07）トークン取得を「広告グループ画面」方式に統一（token.js 新設）
- v2.9.1 でもユーザー環境で「トークン更新失敗」。実機調査で真因を特定：
  **キャンペーン一覧(all-campaigns)はタブが裏(visibility=hidden)だと requestAnimationFrame が止まり、表(=retrieveReport)が読み込まれない**。
  30秒以上待っても retrieveReport 0件・スケルトン表示のまま。ポップアップ操作中は広告タブが裏になるので毎回失敗しうる。
  （朝に成功していたのは広告タブが表に出ていたため）
- 一方、**広告グループ画面(/cm/sp/campaigns/{id}/ad-groups)は裏タブでも cm/dds/retrieveReport を投げる**。
  さらに **dds トークンは campaign-manager/retrieveReport にもそのまま通る**（内蔵65列ボディで HTTP 200・有効4キャンペーン、
  kw.js の19列簡易ボディでも 200・28件を確認）。※逆（cmトークン→dds）は 500（従来メモどおり）。
- 新設 token.js（ads.html / kw.html で読み込み）:
  - `latest()` … amzn_captured / amzn_cap_dds のうち新しい方を返す
  - `ensureFresh(tab)` … 3分以内の捕捉が無ければ、タブを広告グループ画面（`amzn_last_sp_campaign`、無ければ A07766381NLEGRFQQ1NRQ）へ移動して dds を捕捉
  - `restore(tab)` … 終了時にキャンペーン一覧へ戻す（読み込み完了まで待つ）
  - `remember(id)` … KW実行時の代表SPキャンペーンIDを記憶
- ads.js：getTemplate は latest() を使用（URLは常に campaign-manager、ボディは一覧の正規ボディ or 内蔵）。古ければ ensureFresh。
- kw.js：①も latest()/ensureFresh（キャンペーン一覧は使わない）。③は新しい dds があれば画面遷移を省略。
- 確認：token.js は擬似Chromeで単体テスト（取得/再利用/新しい方の選択/記憶ID/restore待ち）。拡張としての通し実行はユーザー環境で要確認。

## 0-fix. v2.9.1 の変更（2026-10-07）広告データの「トークン更新失敗」
- 症状：3種まとめてDLで 広告データ が「トークン更新失敗(ログイン切れの可能性)。実行中止」。ログイン自体は正常。
- 原因：KWデータは共有の広告タブを「広告グループ画面」(/cm/sp/campaigns/…/ad-groups) へ遷移させ、そのまま残していた。
  次の広告データは `tabs[0]` をそのまま F5 → 広告グループ画面は dds(`cm/dds/retrieveReport`) しか投げないため
  `amzn_captured`(campaign-manager) が更新されず、25秒待ってタイムアウト → 「ログイン切れ」と誤表示。
- 対策：
  - ads.js：タブは all-campaigns を優先して選ぶ。一覧以外に居る場合は reload ではなく all-campaigns へ `tabs.update` してトークン取得
    （トークンが新しくても一覧以外なら移動）。
  - kw.js：終了時（成功/失敗とも）に、広告グループ画面へ移動させたタブを all-campaigns へ戻す。

## 0-new. v2.9.0 の変更（2026-10-07）「3種まとめてDL」
- popup.html の上部（保存先の下・広告データの上）に「⏬ 3種まとめてDL」ボタン＋進捗チップ（広告/出荷数/KW）を追加。
- 実装は suite.js の bulkDownload()：各 iframe の `#run` ボタンを**そのまま click** し、
  ボタンが disabled→有効 に戻ったら終了、`*_status` が 'done' かつ開始後の ts なら成功と判定。
  - 広告 → KW は同じ広告タブを使う（KWはタブを遷移させる）ので**順番**、出荷数はバックグラウンドなので**並行**。
  - 実行中はボタンが「■ まとめて停止」になり、押すと各セクションの `#stop` を click、残りの段階はスキップ。
  - 開始前に日付・保存先(AMZ_FS)をチェック。終了時に通知と結果メッセージ（失敗はセクションのログ最終行を表示）。
  - 広告・KWはポップアップ上で動く処理なので、**実行中はポップアップを閉じない**こと（画面にも明記）。
- ads.js：成功以外で終わった時に ads_status が 'running' のまま残っていたのを 'idle' に戻すよう修正（判定とバッジのため）。
- 動作確認は headless Chromium で各セクションの run を擬似ハンドラに差し替えて実施（順序・並行・失敗表示・停止）。実Amazonでの通し実行は未確認。

## 0'''. v2.8.3 の変更（2026-10-07）
- ポップアップの3セクション(iframe)に個別の縦スクロールバーが出ていた（初期でも 出荷数 279>270px, KW 235>210px）。
  → suite.js で各 iframe の高さを中身(body)に自動で合わせる（ResizeObserver でログ欄のドラッグ拡大・上級設定の展開にも追従）。
  iframe は scrolling="no"、初期高さは 270 / 280 / 236px。スクロールはポップアップ全体の1本だけになる。
  ※ 同一オリジン(chrome-extension://)前提。file:// で直接開くと contentDocument が取れず効かない（テストは http で配信して確認）。
- ユーザー実行分（2026-10-05, v2.8.2）でキーワードの日本語表記・耐火バッグ/防火袋の分離を確認済み。

## 0''. v2.8.2 の変更（2026-10-07）
- 拡張から実行するとSPキーワードの `targetLocalized` が**英訳**で返り（耐火バッグ/防火袋→どちらも "fireproof bag" 等）、
  別KWが同名化した。キーワード表示は **`target`（登録文字列そのまま）を使う**よう修正。targetLocalized は使わない。
- ユーザー実行分（2026-10-05）の検証：39行・4キャンペーン、23-05-耐火バッグ-kw の合計費用 20,463.53 は画面と一致。

## 0'. v2.8.1 の変更（2026-10-07）
ユーザー確認：「SPの有効キャンペーン（23-05-耐火バッグ-商品 / 23-05-耐火バッグ-kw）と SBの有効キャンペーン
（【SB】耐火バッグ-商品コレ-KW / 【SB】耐火バッグ-動画-KW）が取れればOK」。
- v2.8.0 はキーワードだけに絞っていたため ASIN指定のみの「23-05-耐火バッグ-商品」が漏れていた → **全ターゲット種別を対象**に変更
  （キーワード / 商品(ASIN・カテゴリ) / オート）。「有効」の判定はそのまま。
- 列を追加：種別（キーワード/商品/オート）, 商品名（API の title。現状は空のことが多い）。「キーワード」列は「キーワード/ターゲット」に改名。
- 商品ターゲットの表示は target（asin="…" / asin-expanded="…"）から ASIN を取り出す。targetLocalized は
  'asin-expanded= B0…”' のように崩れるので使わない。マッチタイプ列は ASIN / ASIN(拡張) / カテゴリ。
- ライブ検証（2026-10-05、拡張と同じ手順＝キャンペーン一覧→広告グループ画面でddsトークン→取得）：
  有効ターゲット 39件 / 4キャンペーン（SP kw 16, SP 商品 9, SB 商品コレ 8, SB 動画 6）。ユーザーの言う4つと一致。
  キャンペーン一覧は画面がSB絞り込み中でも、固定filterで28件すべて取得できることも確認。

## 0. v2.8.0 の変更（2026-10-07）
ユーザー要望：「KWデータは、各広告グループの『ターゲティング』タブに出る**現在有効なキーワード**だけが欲しい」
（例: 23-05-耐火バッグ-kw → ターゲティング → 合計31件のうち配信中のKW）。

- 取得するのは**キーワード（EXACT / PHRASE / BROAD）のみ**。ASIN指定・カテゴリ・オート（TARGETING_EXPRESSION系）は除外。
- **現在有効なものだけ**：以下をすべて満たす行だけを出力
  - `targetState == ENABLED`（サーバ側filterでも絞る）
  - `calculatedStatusName` に PAUSED/ARCHIVED を含まない（SPは `TARGETING_CLAUSE_STATUS_LIVE` / `CAMPAIGN_PAUSED` 等が入る。SBは常に `UNKNOWN`）
  - 広告グループ：`SPAdGroupReport` の `adGroupState == ENABLED` かつ `statusName` にPAUSED/ARCHIVEDなし
  - キャンペーン：キャンペーン一覧(campaign-manager)の `state == ENABLED`（SBはここで判定）
- 画面と同じ列＋α：日付, 広告タイプ, キャンペーン名, 広告グループ名, キーワード, マッチタイプ, ステータス, 入札額,
  インプレッション, クリック, CTR(%), CPC, 合計費用, 商品購入数, 売上, ROAS, ACOS(%), 検索結果上部のインプレッションシェア(%), 各ID
- **広告グループ名は解決済み**：`SPAdGroupReport` は filter 無し（`{and:[]}`）で全広告グループ（SP・SB両方）を返す。
  使える列: adGroupId, adGroupName, adGroupState, adGroupExternalId, campaignId, statusName（campaignName/programType は不可=400）。
- `SPAdGroupTargetsReport` で追加確認済みの列: calculatedStatusName, calculatedStatusReasons, targetBid, clicks, ctr, cpc, acos。
  filter に `targetState IN [ENABLED]`, `matchType IN [EXACT,PHRASE,BROAD]` も使える（列をfieldsに入れること）。
- ctr / acos / topOfSearchImpressionShare は**既に%単位**の値（0.39 = 0.39%）。
- ライブ検証（2026-10-05）：有効KW 30件 = SP 23-05-耐火バッグ-kw 16件 + SB 2キャンペーン 14件。画面の数値と一致。
- 推奨入札額は別API（/sp/targets/bid/recommendations）なので未対応。
- 併せて：ads.js の cleanHeaders も大小無視の重複除去に統一／日付変更時に KW の「取得済み」表示もリセット／kw.html の説明文更新。

---

## 1. このツールは何か
Chrome拡張（Manifest V3）。Amazon広告・セラーのデータを**日別CSV**で、選んだフォルダ（File System Access API）に直接保存する。
ポップアップ上部で日付・保存先を共有し、3セクションを切替：
- **広告データ**（キャンペーン全体 / `advertising-japan.amazon.com`）… `広告データ-YYYY-MMDD.csv`
- **KWデータ(SP・SB)**（キーワード/ターゲット単位）… `KWデータ-YYYY-MMDD.csv`
- **出荷数データ**（注文 / `sellercentral-japan.amazon.com`）… `出荷数データ-YYYY-MMDD.csv`

ファイル名にバージョン名は付けない（ユーザー指示）。KWのファイル名は `KWデータ-YYYY-MMDD.csv`（v2.8.4で先頭に③を付けたが、v2.8.5でユーザー指示により元に戻した）。バージョンは manifest.json のみ。
出力zipは常に `amazon-downloader.zip`（版数サフィックス無し）。

## 2. 【最重要】これまでの全失敗の真因（v2.7.0で解決済み）
KWデータが延々 HTTP 400（Tomcatの "HTTP Status 400 – Bad Request" HTMLページ）になっていた原因は
**ヘッダの大文字小文字重複**だった。
`Content-Type` と `content-type` を両方オブジェクトに入れてfetchすると、重複ヘッダとして送られ
Amazon側のTomcatがコンテナレベルで400を返す。エンドポイント・フィルタ・ボディ形式は正しかった。
→ 対策：ヘッダは**大小無視で1つに統一**してから送る（`cleanHeaders()` と各注入関数のH構築で実装済み）。

## 3. KWデータの正しいAPI仕様（ライブ検証済み・KAIRYアカウント）
- エンドポイント: `POST https://advertising-japan.amazon.com/a9g-api-gateway/cm/dds/retrieveReport`
- ボディは `{ reportConfig: {...} }` でラップ（←以前はこのラップが無く失敗していた）：
  ```json
  {"reportConfig":{
    "reportId":"SPAdGroupTargetsReport",
    "fields":[... "marketplaceId" を必ず含める ...],
    "filter":{"and":[{"field":"marketplaceId","comparisonOperator":"EQUALS","value":"A1VC38T7YXB528","not":false}]},
    "startDate":"YYYY-MM-DD","endDate":"YYYY-MM-DD",
    "timeUnits":["SUMMARY","DAILY"],
    "offsetPagination":{"size":100,"offset":0},
    "columnsByTimeUnit":{"SUMMARY":["impressions","spend","orders","sales","roas"],"DAILY":["spend","sales","roas","impressions"]}
  }}
  ```
- 重要ルール: **filterで使う列は必ず fields にも入れる**（無いと「cannot filter on column that isn't being fetched」で400）。
- レスポンス: `j.report.data`（行配列, フラット） / `j.report.numberOfRecords`（総件数）。
  ページングは offset を +size しながら `collected >= numberOfRecords` まで。
- **marketplace単位の1回のsweepで全キャンペーン横断・SPとSB2(スポンサーブランド)両方**のターゲットが取れる
  （検証時: 233件 / 28キャンペーン / programType=["SP","SB2"]）。

### トークンのコンテキスト依存（重要）
- `cm/dds/retrieveReport` は **ddsコンテキストで発行されたCSRFトークン**でないと通らない（campaign-managerのトークンだと500）。
- ddsトークンは「広告グループ画面」= `https://advertising-japan.amazon.com/cm/sp/campaigns/{campaignId}/ad-groups?entityId={ENTITY}`
  をブラウザで開くとページが `SPAdGroupReport`(dds) を投げる → hook.js が捕捉できる。
  このページは **campaignId だけ**あれば開ける（adGroupId不要）。そのトークンでmarketplace sweepが通る（検証済み）。

### 現在の実装フロー（kw.js run）
1. 保存先フォルダ確認
2. campaign-managerトークン確保（無ければ all-campaigns を開いて hook捕捉）
3. 注入①`fetchCampaignInfo`：**捕捉済みのキャンペーンボディ**をそのまま使い（列を削ると UnifiedCampaignReportSyncAPI は500）、日付とページングだけ差し替えて有効キャンペーンを1件取得＋キャンペーン名マップ作成
4. 代表キャンペーンの ad-groups 画面へ遷移 → hook が dds トークンを `amzn_cap_dds` に保存
5. 注入②`kwDownloader`：ddsトークンで marketplace sweep を日別に実行しCSV保存

## 4. キー/ストレージ
- `amzn_captured` … campaign-manager系の最新リクエスト（広告データ用トークン）
- `amzn_cap_dds` … dds系の最新リクエスト（KW用トークン）← bridge.js でURLにより振り分け
- `amzn_working_req` … 広告データ実行時に保存される「通るリクエスト」(url/headers/body)
- `sharedDates` {start,end} / `kw_stop` / `kw_status`

## 5. アカウント定数（フォールバック用。ハードコード箇所あり）
- entityId: `ENTITY15N4IW58E6FGF`
- accountId: `amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m`
- marketplaceId(JP): `A1VC38T7YXB528`
- clientId: `amzn.advertising.789c1d8b...`（ads.js の DEFAULT_TEMPLATE 参照）

## 6. 残タスク / 既知の制限
- ~~広告グループ名の列が未対応~~ → v2.8.0で対応済み（下記は旧メモ）。KW(SPAdGroupTargetsReport)にはadGroupId/adGroupExternalIdはあるが名前が無い。
  `SPAdGroupReport` はmarketplaceId列を持たず marketplace横断不可（`campaignExternalId`でのフィルタのみ）。
  → 名前を付けるなら、キャンペーン毎に `SPAdGroupReport`(filter: campaignExternalId) を1回ずつ呼び
    `adGroupExternalId → adGroupName` マップを作る必要がある（起動時に1回）。campaignExternalIdは
    キャンペーンレポートから取得可能。
- 300超のキャンペーン数ではキャンペーン一覧のページングが必要（現状 size300 の1ページのみ）。

## 7. ファイル構成
- manifest.json / popup.html / suite.js
- ads.js, ads.html … 広告データ（+ DEFAULT_TEMPLATE に正規の列定義）
- kw.js, kw.html … KWデータ（本体。注入関数 fetchCampaignInfo / kwDownloader）
- ship.js … 出荷数データ
- hook.js（MAINワールド, fetch/XHR傍受）, bridge.js（ISOLATED, storageへ振り分け保存）
- background.js（amz_save_data 保存ハンドラ 等）, fsstore.js（AMZ_FS 保存先管理）, folder.js/folder.html
- token.js（AMZ_TOKEN：広告データ/KW共通のトークン確保。v2.9.2〜）
- official.js（OFFICIAL：統合レポートAPIの作成/状態/削除・照合用データ取得・CSVユーティリティ。v2.11.0〜）

## 8. 検証方法メモ（次セッション用）
Claude in Chrome で実アカウントにログイン中のタブを使い、XHRフックで retrieveReport を採取→
`fetch(...)` で変種を叩いて200/件数を確認する手法が有効。トークン値は画面に出さず（自動redactされる）、
ボディ構造とヘッダ名・ステータス・件数だけ見れば仕様は確定できる。

// 1日分のDLが終わるたびに呼ぶ簡易履歴記録(直列化)
function recordDailyHistory(entry) {
  window.__rmsHistoryChain = (window.__rmsHistoryChain || Promise.resolve()).then(async () => {
    try {
      const KEY = 'rms_dl_history';
      const s = await chrome.storage.local.get([KEY]);
      const list = s[KEY] || [];
      list.unshift({ t: new Date().toISOString(), ...entry });
      if (list.length > 200) list.length = 200;
      await chrome.storage.local.set({ [KEY]: list });
    } catch (_) {}
  });
  return window.__rmsHistoryChain;
}

// =============== ジョブのライフサイクル管理 (進行中ジョブ表示用) ===============
// 進行中の1ジョブだけを `rms_active_job` に保存し、popup側に表示・中止ボタンを出す。
// 同時実行は想定しない(連続実行のみ)。

async function startJob(type, days) {
  const jobId = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const job = {
    jobId,
    type,
    startedAt: new Date().toISOString(),
    days: days.map(d => ({ day: d, status: 'pending' })),
    status: 'running'
  };
  // 中止フラグはジョブ開始時に必ずクリア
  await chrome.storage.local.set({ rms_active_job: job });
  await chrome.storage.local.remove(['rms_cancel_flag']);
  return jobId;
}

// 各日のステータス更新を直列化
function _jobChain() {
  window.__rmsJobChain = (window.__rmsJobChain || Promise.resolve());
  return window.__rmsJobChain;
}

function markDay(jobId, day, status, extra) {
  window.__rmsJobChain = _jobChain().then(async () => {
    try {
      const s = await chrome.storage.local.get(['rms_active_job']);
      const job = s.rms_active_job;
      if (!job || job.jobId !== jobId) return;
      const d = job.days.find(x => x.day === day);
      if (d) {
        d.status = status;
        if (extra) Object.assign(d, extra);
      }
      await chrome.storage.local.set({ rms_active_job: job });
    } catch (_) {}
  });
  return window.__rmsJobChain;
}

function endJob(jobId, status) {
  window.__rmsJobChain = _jobChain().then(async () => {
    try {
      const s = await chrome.storage.local.get(['rms_active_job']);
      const job = s.rms_active_job;
      if (!job || job.jobId !== jobId) return;
      job.status = status;
      job.endedAt = new Date().toISOString();
      await chrome.storage.local.set({ rms_active_job: job });
    } catch (_) {}
  });
  return window.__rmsJobChain;
}

async function isJobCancelled(jobId) {
  try {
    const s = await chrome.storage.local.get(['rms_cancel_flag']);
    // 'all' なら任意のジョブをキャンセル、または jobId一致でキャンセル
    return s.rms_cancel_flag === 'all' || s.rms_cancel_flag === jobId;
  } catch (_) { return false; }
}

function installProgressOverlay(title) {
  if (window.__rmsDLOverlay?.el?.isConnected) {
    // 既存オーバーレイを再表示してタイトル更新
    window.__rmsDLOverlay.el.style.display = 'block';
    window.__rmsDLOverlay.setTitle(title);
    window.__rmsDLOverlay.clearLog();
    window.__rmsDLOverlay.setProgress(0);
    return;
  }

  const box = document.createElement('div');
  box.id = '__rms_dl_overlay';
  Object.assign(box.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '420px',
    maxHeight: '70vh',
    background: '#ffffff',
    border: '2px solid #bf0000',
    borderRadius: '8px',
    boxShadow: '0 8px 32px rgba(0,0,0,0.25)',
    zIndex: '2147483647',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#222',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    userSelect: 'none'
  });

  // ヘッダー(ドラッグハンドル + 閉じるボタン)
  const header = document.createElement('div');
  Object.assign(header.style, {
    padding: '8px 12px',
    background: '#bf0000',
    color: '#fff',
    fontWeight: 'bold',
    cursor: 'move',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  });
  const titleSpan = document.createElement('span');
  titleSpan.textContent = title || 'RMS一括DL 進捗';
  header.appendChild(titleSpan);

  const closeBtn = document.createElement('span');
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    cursor: 'pointer',
    padding: '0 4px',
    fontSize: '16px',
    lineHeight: '1'
  });
  closeBtn.title = '閉じる(処理は継続します)';
  closeBtn.onclick = (e) => { e.stopPropagation(); box.style.display = 'none'; };
  header.appendChild(closeBtn);

  box.appendChild(header);

  // プログレスバー
  const progTrack = document.createElement('div');
  Object.assign(progTrack.style, {
    width: '100%',
    height: '6px',
    background: '#eee',
    flexShrink: '0'
  });
  const progBar = document.createElement('div');
  Object.assign(progBar.style, {
    height: '100%',
    width: '0%',
    background: '#bf0000',
    transition: 'width 0.3s'
  });
  progTrack.appendChild(progBar);
  box.appendChild(progTrack);

  // ログ領域
  const logEl = document.createElement('div');
  Object.assign(logEl.style, {
    padding: '10px 14px',
    overflowY: 'auto',
    flex: '1',
    whiteSpace: 'pre-wrap',
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
    fontSize: '12px',
    lineHeight: '1.5',
    background: '#fafafa',
    userSelect: 'text'
  });
  logEl.textContent = '開始を待っています…';
  box.appendChild(logEl);

  document.documentElement.appendChild(box);

  // ドラッグ処理
  let dragging = false, offX = 0, offY = 0;
  header.addEventListener('mousedown', (e) => {
    dragging = true;
    const rect = box.getBoundingClientRect();
    offX = e.clientX - rect.left;
    offY = e.clientY - rect.top;
    box.style.transform = 'none';
    box.style.left = rect.left + 'px';
    box.style.top = rect.top + 'px';
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    box.style.left = (e.clientX - offX) + 'px';
    box.style.top = (e.clientY - offY) + 'px';
  });
  window.addEventListener('mouseup', () => { dragging = false; });

  window.__rmsDLOverlay = {
    el: box,
    setTitle: (t) => { titleSpan.textContent = t || 'RMS一括DL 進捗'; },
    log: (text) => {
      logEl.textContent += '\n' + text;
      logEl.scrollTop = logEl.scrollHeight;
    },
    clearLog: () => { logEl.textContent = '開始しました…'; },
    setProgress: (pct) => { progBar.style.width = Math.max(0, Math.min(100, pct)) + '%'; }
  };
}

// -------- 全ての広告(RPP) --------
async function rppAllDownloader({ startDate, endDate, interval, options }) {
  // chrome.storage.localに直接書き込むログ関数
  // (popupが閉じていても確実に記録される。chrome.runtime.sendMessageはpopup閉じると失敗するため)
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('rppAll', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'rppAll', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ rppAllDownloader 開始 (${startDate}〜${endDate}, interval=${interval}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    log(`❌ 日付フォーマット不正 (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付フォーマット不正' };
  }

  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) { log('❌ XSRF-TOKENが見つかりません'); return { ok: false, error: 'XSRF-TOKENが見つかりません' }; }

  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
  log(`📅 ${days.length}日分`);

  // 進行中ジョブを登録(中止ボタン/進捗マス表示用)
  const jobId = await startJob('② 全ての広告', days);

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let success = 0, fail = 0;
  for (let i = 0; i < days.length; i++) {
    // 中止チェック
    if (await isJobCancelled(jobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(jobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    markDay(jobId, day, 'processing');
    try {
      // 各リクエストのペイロード: 日付以外はUIで指定したoptionsを使う
      const payload = {
        page: 1,
        selectionType: 1,
        startDate: day,
        endDate: day,
        ...options
      };
      const r = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadPerfFile', {
        method: 'POST', credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const cd = r.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      // 楽天のオリジナル: rpp_reports_yukaiya_20260629101357177.csv
      // → 末尾のDL時刻タイムスタンプを対象日(YYYYMMDD)に置換
      const dayStr = day.replaceAll('-', '');
      let fn;
      if (mt) {
        // 末尾の数字列(10桁以上)を対象日に置換
        fn = mt[1].replace(/_\d{10,}(\.[A-Za-z]+)$/, `_${dayStr}$1`);
      } else {
        fn = `rpp_reports_${dayStr}.csv`;
      }
      const blob = await r.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = fn; document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(u);
      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: '② 全ての広告', day, ok: true, file: fn });
      markDay(jobId, day, 'ok', { file: fn });
    } catch (e) {
      fail++;
      log(`  ❌ ${day} ${e.message}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: '② 全ての広告', day, ok: false, error: e.message });
      markDay(jobId, day, 'ng', { error: e.message });
    }
    if (i < days.length - 1) await sleep(interval * 1000);
  }
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(jobId, 'done');
  return { ok: true, success, fail };
}

// -------- 商品別売上 --------
async function itemSalesDownloader({ startDate, endDate, period, device, tax, filter, filterBy, interval }) {
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('is', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'is', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ itemSalesDownloader 開始 (${startDate}〜${endDate}, period=${period}, device=${device}, tax=${tax})`);

  // 入力ガード(空文字列等を弾く)
  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    log(`❌ 日付フォーマット不正 (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付フォーマット不正' };
  }

  // YYYY-MM-DD → YYYYMMDD
  const yyyymmdd = s => s.replaceAll('-', '');
  // 月次の月初/月末
  const monthStart = s => s.slice(0, 8) + '01';
  const monthEnd = s => {
    const [y, m] = s.split('-').map(Number);
    const last = new Date(y, m, 0).getDate();
    return `${y}-${String(m).padStart(2, '0')}-${String(last).padStart(2, '0')}`;
  };

  // 分割リスト作成(日次=1日ずつ、月次=1ヶ月ずつ、range=1発)
  const ranges = [];
  if (period === 'daily') {
    const [y1, m1, d1] = startDate.split('-').map(Number);
    const [y2, m2, d2] = endDate.split('-').map(Number);
    for (let d = new Date(y1, m1 - 1, d1), e = new Date(y2, m2 - 1, d2); d <= e; d.setDate(d.getDate() + 1)) {
      const s = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      ranges.push({ s, e: s, label: s });
    }
  } else if (period === 'monthly') {
    const [y1, m1] = startDate.split('-').map(Number);
    const [y2, m2] = endDate.split('-').map(Number);
    let y = y1, m = m1;
    while (y < y2 || (y === y2 && m <= m2)) {
      const ms = `${y}-${String(m).padStart(2, '0')}-01`;
      const me = monthEnd(ms);
      ranges.push({ s: ms, e: me, label: `${y}-${String(m).padStart(2, '0')}` });
      m++; if (m > 12) { m = 1; y++; }
    }
  } else {
    ranges.push({ s: startDate, e: endDate, label: `${startDate}_${endDate}` });
  }

  log(`📅 ${ranges.length}件のDLを実行`);

  const BASE = 'https://datatool.rms.rakuten.co.jp/realtime';
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // API用のperiodパラメータ(range時もAPIはdailyでOKらしいが、一応monthlyに切り替え)
  const apiPeriod = (period === 'monthly') ? 'monthly' : 'daily';

  // 共通クエリビルダ
  const buildQuery = (s, e, extra = {}) => {
    const q = new URLSearchParams({
      period: apiPeriod,
      startDate: yyyymmdd(s),
      endDate: yyyymmdd(e),
      tax,
      device,
      filter: filter || '',
      filterBy,
      sortBy: 'sales',
      sort: 'desc',
      ...extra
    });
    return q.toString();
  };

  // 楽天の実CSVフォーマットに合わせたCSVビルダー
  // 文字列は必ず "..." で囲む、数値は囲まない、改行はCRLF
  const esc = v => {
    if (v === null || v === undefined) return '';
    const s = String(v);
    return '"' + s.replaceAll('"', '""') + '"';
  };
  const num = v => (v === null || v === undefined) ? '' : String(v);

  // YYYY-MM-DD → 「2026年04月01日」
  const jpDate = s => {
    const [y, m, d] = s.split('-');
    return `${y}年${m}月${d}日`;
  };
  // 端末ラベル
  const deviceLabel = { all: 'すべて', pc: 'PC', app: '楽天市場アプリ', sp: 'スマートフォン' }[device] || device;
  const taxLabel = tax === 'incl' ? '税込' : '税抜';

  // ファイル名: 楽天の実ファイル名パターンに合わせる
  // 例: 20260401_Item_SalesList.csv
  const fileNameFor = (s, e, label) => {
    if (period === 'daily') return `${s.replaceAll('-', '')}_Item_SalesList.csv`;
    if (period === 'monthly') return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
    return `${s.replaceAll('-', '')}-${e.replaceAll('-', '')}_Item_SalesList.csv`;
  };

  let success = 0, fail = 0;

  // 進行中ジョブを登録(中止ボタン/進捗マス表示用)
  const itemJobId = await startJob('① 商品別売上', ranges.map(r => r.label));

  for (let i = 0; i < ranges.length; i++) {
    if (await isJobCancelled(itemJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${ranges.length}完了)`);
      await endJob(itemJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const { s, e, label } = ranges[i];
    markDay(itemJobId, label, 'processing');
    try {
      // ① 検索(画面表示用のAPIを叩いてセッション整合を取る)
      const searchUrl = `${BASE}/get-shop-item-list?${buildQuery(s, e)}`;
      const sr = await fetch(searchUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
      if (!sr.ok) throw new Error('search HTTP ' + sr.status);
      await sr.json();

      // ② DL API を maxCycleNumber まで繰り返して全件取得
      let allRows = [];
      let cycle = 0, maxCycle = 0;
      do {
        const dlUrl = `${BASE}/get-shop-item-dl?${buildQuery(s, e, { size: '1000', cycleNumber: String(cycle) })}`;
        const dr = await fetch(dlUrl, { method: 'GET', credentials: 'include', cache: 'no-cache' });
        if (!dr.ok) throw new Error('dl HTTP ' + dr.status);
        const dj = await dr.json();
        if (Array.isArray(dj.data)) allRows = allRows.concat(dj.data);
        maxCycle = dj.maxCycleNumber || 0;
        cycle++;
        if (cycle <= maxCycle) await new Promise(r => setTimeout(r, 500));
      } while (cycle <= maxCycle);

      // ③ 楽天の実CSVと同じフォーマットで組み立て
      const lines = [];
      lines.push('※この情報は店舗様および楽天市場での重要な情報となります。データの取扱には十分にご注意ください。');
      lines.push('商品別売上');
      lines.push(`表示期間,${jpDate(s)}から${jpDate(e)}`);
      lines.push(`端末,${deviceLabel}`);
      lines.push(`消費税,${taxLabel}`);
      lines.push(filter ? `キーワード,${esc(filter)}` : 'キーワード');
      lines.push('商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数');
      for (const r of allRows) {
        // API: itemName/mngNumber/itemNumber/itemPrice/units/sales/orderCount
        // CSV順: 商品名,商品管理番号,商品番号,平均単価,売上個数,売上,売上件数
        lines.push([
          esc(r.itemName),
          esc(r.mngNumber),
          esc(r.itemNumber),
          num(r.itemPrice),
          num(r.units),
          num(r.sales),
          num(r.orderCount)
        ].join(','));
      }
      const csv = lines.join('\r\n') + '\r\n';

      // UTF-8 BOM付き(楽天オリジナルもBOM付きUTF-8)
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });

      const fn = fileNameFor(s, e, label);
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = fn; document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(u);

      success++;
      log(`  ✅ ${label} (${allRows.length}件) → ${fn}`, Math.round(((i + 1) / ranges.length) * 100));
      recordDailyHistory({ type: '① 商品別売上', day: label, ok: true, file: fn, rows: allRows.length });
      markDay(itemJobId, label, 'ok', { file: fn, rows: allRows.length });
    } catch (err) {
      fail++;
      log(`  ❌ ${label} ${err.message}`, Math.round(((i + 1) / ranges.length) * 100));
      recordDailyHistory({ type: '① 商品別売上', day: label, ok: false, error: err.message });
      markDay(itemJobId, label, 'ng', { error: err.message });
    }
    if (i < ranges.length - 1) await new Promise(r => setTimeout(r, interval * 1000));
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(itemJobId, 'done');
  return { ok: true, success, fail };
}

// -------- 商品別 / キーワード別(RPP 非同期ZIPダウンロード、1日ずつループ) --------
async function rppAsyncDownloader({ startDate, endDate, timeout, options, selectionType, reportType, panelPrefix, reportName }) {
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog(panelPrefix, text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: panelPrefix, text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };
  log(`▶ ${reportName} 開始 (${startDate}〜${endDate}, selectionType=${selectionType}, timeout=${timeout}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }

  const getCookie = n => {
    const m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  };
  const token = getCookie('XSRF-TOKEN');
  if (!token) { log('❌ XSRF-TOKENが見つかりません'); return { ok: false, error: 'XSRF-TOKENが見つかりません' }; }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // 日付リストを作成(startDate〜endDateを1日ずつ)
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));

  log(`📅 ${reportName} を ${days.length}日分 順番にダウンロードします`);

  // ====== 日ごとのループ ======
  let success = 0, fail = 0;
  const failedDays = [];

  const rppAsyncJobId = await startJob(`② ${reportName || 'RPP非同期'}`, days);

  for (let i = 0; i < days.length; i++) {
    if (await isJobCancelled(rppAsyncJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(rppAsyncJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    const dayNum = i + 1;
    const basePct = Math.round((i / days.length) * 100);

    log(`\n── [${dayNum}/${days.length}] ${day} ──`, basePct);
    markDay(rppAsyncJobId, day, 'processing');

    try {
      // ─ ① この日のジョブ投入前に、既存ジョブID一覧を取得 ─
      log('  🔍 既存ジョブを確認中…');
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const preJson = await pre.json();
          const list = preJson?.data?.userHistoryList || [];
          for (const j of list) existingIds.add(j.id);
        }
      } catch (_) { /* 失敗しても続行 */ }

      // ─ ② downloadAsyncでこの日のジョブ投入(startDate=endDate=day) ─
      log(`  📤 ${day}分のジョブを投入…`);
      const payload = {
        page: 1,
        selectionType,
        startDate: day,
        endDate: day,
        ...options
      };
      const asyncRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/reports/downloadAsync', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/plain, */*',
          'X-Request-ID': crypto.randomUUID(),
          'X-XSRF-TOKEN': token
        },
        body: JSON.stringify(payload)
      });
      if (!asyncRes.ok) throw new Error(`downloadAsync失敗 HTTP ${asyncRes.status}`);
      const asyncJson = await asyncRes.json();
      if (asyncJson?.status !== 'SUCCESS') {
        throw new Error(`downloadAsync応答が予期せぬ形式: ${JSON.stringify(asyncJson).slice(0, 80)}`);
      }

      // ─ ③ listポーリング、この日のジョブが完了するまで待つ ─
      const pollStart = Date.now();
      const pollInterval = 1000; // 1秒ごとにポーリング(短いtimeoutに対応)
      let myJob = null;
      while ((Date.now() - pollStart) / 1000 < timeout) {
        await sleep(pollInterval);
        const elapsed = Math.round((Date.now() - pollStart) / 1000);

        try {
          const listRes = await fetch('https://ad.rms.rakuten.co.jp/rpp/api/download/list', {
            method: 'GET', credentials: 'include',
            headers: { 'Accept': 'application/json' }
          });
          if (!listRes.ok) continue;
          const listJson = await listRes.json();
          const userList = listJson?.data?.userHistoryList || [];

          // 自分のジョブを特定する。
          // 楽天側で reportType の番号が変わる(以前 3/4 → 現在 13/14 等)ため、
          // reportType の固定値では照合しない。代わりに:
          //   - 投入前に存在しなかった新規ジョブ (existingIdsに無い)
          //   - startDate が対象日と一致
          // で特定し、ダウンロード時はジョブ自身の reportType を使う。
          const newJobs = userList.filter(j => {
            if (existingIds.has(j.id)) return false;
            // startDateは "YYYY-MM-DD" または "YYYY-MM-DD 00:00:00" 形式
            if (j.startDate && !j.startDate.startsWith(day)) return false;
            return true;
          });
          if (newJobs.length > 0) {
            // 最新(requestDate降順)を自分のジョブとみなす
            newJobs.sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || ''));
            // 完了(status 2/4) かつ reportTypeを持つジョブを最優先。
            // なければ完了ジョブ、それも無ければ最新ジョブを暫定保持。
            myJob = newJobs.find(j => (j.status === 2 || j.status === 4) && j.reportType != null)
                 || newJobs.find(j => j.status === 2 || j.status === 4)
                 || newJobs[0];
          }

          if (myJob) {
            if (myJob.status === 2 || myJob.status === 4) break;
            else if (myJob.status === 3) {
              // 失敗ジョブしか無い場合のみエラー。新しい候補がまだ出るかもしれないので
              // newJobsに完了/処理中が他に無いことを確認
              const hasPending = newJobs.some(j => j.status === 0 || j.status === 1);
              if (!hasPending) throw new Error(`ジョブが失敗 (id=${myJob.id}, status=3)`);
              else { myJob = null; log(`    ⏳ 生成中… (${elapsed}s経過)`); }
            }
            else log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
          } else {
            log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
          }
        } catch (e) {
          if (e.message.includes('ジョブが失敗')) throw e;
          log(`    ⚠ ポーリング一時エラー: ${e.message}`);
        }
      }

      if (!myJob || (myJob.status !== 2 && myJob.status !== 4)) {
        throw new Error(`タイムアウト(${timeout}秒)`);
      }

      // ─ ④ ZIPを取得して保存 ─
      // ダウンロードに使う reportType は、固定値ではなく
      // 見つかったジョブ自身の reportType を使う(楽天側の番号変更に追従)
      const dlReportType = (myJob.reportType != null) ? myJob.reportType : reportType;
      const storageType = myJob.storageType || 'STAAS';
      const dlUrl = `https://ad.rms.rakuten.co.jp/rpp/api/download/report?downloadId=${myJob.id}&reportType=${dlReportType}&storageType=${storageType}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      if (!zipRes.ok) throw new Error(`ZIP取得失敗 HTTP ${zipRes.status}`);

      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      // 楽天オリジナル: rpp_item_reports_yukaiya_20260629101404836.zip
      // → 末尾DL時刻を対象日に置換
      const dayStr = day.replaceAll('-', '');
      let fn;
      if (mt) {
        fn = mt[1].replace(/_\d{10,}(\.[A-Za-z]+)$/, `_${dayStr}$1`);
      } else {
        const kind = (selectionType === 3) ? 'item' : 'keyword';
        fn = `rpp_${kind}_reports_${dayStr}.zip`;
      }

      const blob = await zipRes.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u;
      a.download = fn;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(u);

      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: `② ${reportName || 'RPP'}`, day, ok: true, file: fn });
      markDay(rppAsyncJobId, day, 'ok', { file: fn });
    } catch (err) {
      fail++;
      failedDays.push(day);
      log(`  ❌ ${day}: ${err.message}`, Math.round(((i + 1) / days.length) * 100));
      recordDailyHistory({ type: `② ${reportName || 'RPP'}`, day, ok: false, error: err.message });
      markDay(rppAsyncJobId, day, 'ng', { error: err.message });
    }

    // 次の日のジョブに進む前に1秒だけ待つ(連続投入でサーバーに優しく)
    if (i < days.length - 1) await sleep(1000);
  }

  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  await endJob(rppAsyncJobId, 'done');

  if (fail === 0) {
    return { ok: true, success, fail, filename: `${success}件のZIPを保存しました` };
  } else {
    return {
      ok: false,
      success, fail,
      error: `成功 ${success} / 失敗 ${fail} (失敗日: ${failedDays.join(', ')})`
    };
  }
}

// -------- クーポンアドバンス広告(cpnadv) 商品別 / KW別 全件 (1日ずつループ) --------
async function cpnadvAsyncDownloader({ startDate, endDate, mode, interval, timeout }) {
  // chrome.storage.localに直接書き込むログ関数
  // 直列化: 同時書込で chrome.storage.local が上書きされログ消失するのを防ぐ
  const writeLog = (panel, text, extra) => {
    window.__rmsLogChain = (window.__rmsLogChain || Promise.resolve()).then(async () => {
      try {
        const KEY = 'rms_dl_logs';
        const s = await chrome.storage.local.get([KEY]);
        const logs = s[KEY] || [];
        logs.push({ t: new Date().toISOString(), cat: panel, msg: String(text), extra: extra || null });
        if (logs.length > 2000) logs.splice(0, logs.length - 2000);
        await chrome.storage.local.set({ [KEY]: logs });
      } catch (_) {}
    });
    return window.__rmsLogChain;
  };
  const log = (text, progress) => {
    writeLog('cpn', text, typeof progress === 'number' ? { progress } : null);
    try { chrome.runtime.sendMessage({ type: 'rms-log', panel: 'cpn', text, progress }); } catch (_) {}
    try {
      window.__rmsDLOverlay?.log(text);
      if (typeof progress === 'number') window.__rmsDLOverlay?.setProgress(progress);
    } catch (_) {}
  };

  const reportName = mode === 'keyword' ? 'クーポン広告 全KWレポート' : 'クーポン広告 商品別レポート';
  log(`▶ ${reportName} 開始 (${startDate}〜${endDate}, mode=${mode}, timeout=${timeout}s)`);

  if (!startDate || !endDate) {
    log(`❌ 日付が空です (startDate=${startDate}, endDate=${endDate})`);
    return { ok: false, error: '日付が指定されていません' };
  }

  // CSRFトークンを取得(metaタグ)
  const csrfMeta = document.querySelector("meta[name='_csrf']");
  const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : null;
  if (!csrfToken) {
    log(`❌ CSRFトークンが見つかりません(クーポン広告ページを開いているか確認)`);
    return { ok: false, error: 'CSRFトークン取得失敗(対象ページが開いていない可能性)' };
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const toD = x => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  // 日付範囲
  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) days.push(fmt(d));
  log(`📅 ${days.length}日分 順次ダウンロードします`);

  // 種別パラメータ
  const selectionType = mode === 'keyword' ? 4 : 3;
  const templateDiv = mode === 'keyword' ? 110 : 108;
  const keywordReportType = mode === 'keyword' ? 'ALL_KEYWORDS' : '';  // 空文字で null扱い

  // form-urlencoded ボディ生成(displayStatuses[]は234要素全true)
  function buildPayload(day) {
    const p = new URLSearchParams();
    p.append('selectionType', String(selectionType));
    p.append('periodType', '3');  // 指定期間
    p.append('searchStartDate', day);
    p.append('searchEndDate', day);
    p.append('templateDiv', String(templateDiv));
    for (let i = 0; i < 234; i++) p.append('displayStatuses[]', 'true');
    p.append('page', '0');
    if (keywordReportType) p.append('keywordReportType', keywordReportType);
    // campaignId / keywordToSearch は省略(全件)
    return p.toString();
  }

  // 共通fetchヘッダー
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/plain, */*',
    'X-CSRF-TOKEN': csrfToken
  };

  let success = 0, fail = 0;
  const failedDays = [];

  const cpnJobLabel = (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別';
  const cpnJobId = await startJob(cpnJobLabel, days);

  for (let i = 0; i < days.length; i++) {
    if (await isJobCancelled(cpnJobId)) {
      log(`⏹ ユーザーが中止しました (${i}/${days.length}完了)`);
      await endJob(cpnJobId, 'cancelled');
      return { ok: false, cancelled: true, success, fail, error: '中止されました' };
    }
    const day = days[i];
    const progBase = Math.round((i / days.length) * 100);
    log(`\n── [${i + 1}/${days.length}] ${day} ──`, progBase);
    markDay(cpnJobId, day, 'processing');

    try {
      // ─ ① 投入前のジョブIDを記録(自分のジョブを後で識別するため) ─
      log(`  🔍 既存ジョブを確認中…`);
      let existingIds = new Set();
      try {
        const pre = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/api/downloads?page=1', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (pre.ok) {
          const preJson = await pre.json();
          const list = preJson?.data?.jobs || [];
          for (const j of list) existingIds.add(j.jobId);
        }
      } catch (_) { /* 取れなくても進む */ }

      // ─ ② この日のジョブを投入 ─
      log(`  📤 ${day}分のジョブを投入…`);
      const submitRes = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/performance_reports/download', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: buildPayload(day)
      });
      if (!submitRes.ok) throw new Error(`投入失敗 HTTP ${submitRes.status}`);
      const submitText = await submitRes.text();
      if (!submitText.includes('Success')) {
        log(`  ⚠ 投入レスポンスが想定外: ${submitText.slice(0, 80)}`);
      }

      // ─ ③ ポーリングしてジョブ完了を待つ ─
      const tStart = Date.now();
      let myJob = null;
      while ((Date.now() - tStart) / 1000 < timeout) {
        await sleep(1000);
        const elapsed = Math.round((Date.now() - tStart) / 1000);
        const listRes = await fetch('https://ad.rms.rakuten.co.jp/cpnadv/api/downloads?page=1', {
          method: 'GET', credentials: 'include',
          headers: { 'Accept': 'application/json' }
        });
        if (!listRes.ok) { log(`    ⚠ list失敗 HTTP ${listRes.status}`); continue; }
        const listJson = await listRes.json();
        const allJobs = listJson?.data?.jobs || [];

        // 新規 + selectionType一致 + keywordReportType一致 で自分のジョブを特定
        const matchKwType = mode === 'keyword' ? 'ALL_KEYWORDS' : null;
        const newJobs = allJobs.filter(j => {
          if (existingIds.has(j.jobId)) return false;
          if (j.selectionType !== selectionType) return false;
          // keywordReportTypeチェック(商品別ならnull or undef、KW別ならALL_KEYWORDS)
          if (mode === 'keyword' && j.keywordReportType !== matchKwType) return false;
          if (mode === 'item' && j.keywordReportType && j.keywordReportType !== '') return false;
          return true;
        });
        if (newJobs.length > 0) {
          // sysCreateDatetime降順で最新
          newJobs.sort((a, b) => (b.sysCreateDatetime || '').localeCompare(a.sysCreateDatetime || ''));
          myJob = newJobs.find(j => j.status === 300) || newJobs[0];
        }

        if (myJob) {
          if (myJob.status === 300) break;  // 完了
          if (myJob.status >= 400) {
            // 400/500等はエラー扱い(楽天側でジョブが失敗)
            throw new Error(`ジョブ失敗 (status=${myJob.status}, jobId=${myJob.jobId})`);
          }
          // 100/200 は処理中
          log(`    ⏳ 生成中… (${elapsed}s経過, status=${myJob.status})`);
        } else {
          log(`    ⏳ ジョブ出現待ち… (${elapsed}s経過)`);
        }
      }

      if (!myJob || myJob.status !== 300) {
        throw new Error(`タイムアウト(${timeout}s)`);
      }

      // ─ ④ ZIPを取得して保存 ─
      const dlUrl = `https://ad.rms.rakuten.co.jp/cpnadv/api/downloads/report?jobId=${myJob.jobId}`;
      const zipRes = await fetch(dlUrl, { method: 'GET', credentials: 'include' });
      if (!zipRes.ok) throw new Error(`ZIP取得失敗 HTTP ${zipRes.status}`);

      // 楽天のレスポンスは商品別/KW別で同じファイル名パターンになるので、
      // こちら側で「item」or「kw」と「日付」を明示したファイル名を生成する。
      const cd = zipRes.headers.get('Content-Disposition') || '';
      const mt = cd.match(/filename="?([^";]+)"?/i);
      const original = mt ? mt[1] : '';
      // 元ファイル名からショップ名を抽出(例: ...__yukaiya_20260629... → yukaiya)
      let shopName = 'shop';
      const sm = original.match(/PerformanceReport_+([A-Za-z0-9_-]+?)_\d{10,}/);
      if (sm) shopName = sm[1];
      const dayStr = day.replaceAll('-', '');
      const modeLabel = (mode === 'keyword') ? 'kw' : 'item';
      const fn = `CouponAdvance_${shopName}_${modeLabel}_${dayStr}.zip`;

      const blob = await zipRes.blob();
      const u = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = u; a.download = fn;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(u);

      success++;
      log(`  ✅ ${day} → ${fn}`, Math.round(((i + 1) / days.length) * 100));
      const cpnLabel = (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別';
      recordDailyHistory({ type: cpnLabel, day, ok: true, file: fn });
      markDay(cpnJobId, day, 'ok', { file: fn });
    } catch (err) {
      fail++;
      failedDays.push(day);
      log(`  ❌ ${day}: ${err.message}`, Math.round(((i + 1) / days.length) * 100));
      const cpnLabel = (mode === 'keyword') ? '③ クーポンKW別' : '③ クーポン商品別';
      recordDailyHistory({ type: cpnLabel, day, ok: false, error: err.message });
      markDay(cpnJobId, day, 'ng', { error: err.message });
    }

    if (i < days.length - 1) await sleep((interval || 1) * 1000);
  }

  const finalMsg = `🎉 完了: 成功 ${success} / 失敗 ${fail}`;
  log(`\n${finalMsg}`, 100);
  await endJob(cpnJobId, 'done');

  if (fail === 0) return { ok: true, success, fail };
  return { ok: false, error: `成功 ${success} / 失敗 ${fail} (失敗日: ${failedDays.join(', ')})`, success, fail };
}

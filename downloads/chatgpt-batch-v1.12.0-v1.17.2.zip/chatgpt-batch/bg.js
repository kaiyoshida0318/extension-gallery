// ChatGPT 画像一括送信 — 裏側の処理（新しいタブを「今の画面のまま」裏で開く）
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'cgb-open-tab' && typeof msg.url === 'string' && /^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(msg.url)) {
    const opt = { url: msg.url, active: false };
    if (sender.tab) { opt.index = sender.tab.index + 1; opt.openerTabId = sender.tab.id; opt.windowId = sender.tab.windowId; }
    chrome.tabs.create(opt, () => reply({ ok: !chrome.runtime.lastError }));
    return true;
  }
});

/* ポップアップ → アクティブタブのcontent scriptへ指示を送る */
(() => {
  const dateInput = document.getElementById("date");
  const hint = document.getElementById("hint");

  const d = new Date();
  dateInput.value = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  function showHint(text) { hint.textContent = text; hint.style.display = "block"; }

  async function send(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) { showHint("アクティブなタブが見つかりません。"); return; }

    // tab.url は権限により取得できないことがある。取得できた時だけ軽くチェックし、
    // 取得できない時は content script へ送って応答可否で判断する。
    if (tab.url && !/^https:\/\/[^/]*next-engine\.com\//.test(tab.url)) {
      showHint("ネクストエンジン（main.next-engine.com）のタブで開いてください。");
      return;
    }
    try {
      await chrome.tabs.sendMessage(tab.id, message);
      window.close();
    } catch (e) {
      showHint("ネクストエンジンの画面で、ページを一度リロードしてからお試しください。");
    }
  }

  document.getElementById("run").addEventListener("click", () => send({ type: "measure", refDate: dateInput.value }));
  document.getElementById("diag").addEventListener("click", () => send({ type: "diagnose" }));
})();

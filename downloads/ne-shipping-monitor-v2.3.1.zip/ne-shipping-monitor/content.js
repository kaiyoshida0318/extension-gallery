/* =============================================================================
 * NE 出荷漏れ点検  (NE Shipping Monitor)  v2.0.0
 * -----------------------------------------------------------------------------
 * ・常時バーは廃止。Chromeツールアイコンのポップアップから「測定開始／診断ログ」。
 * ・各ステータスのページを隠しiframeで実際に開き、NEのJSが描画した受注一覧テーブルを
 *   読み取って【受注日別】【配送方法別】に集計する。
 * ・取得できない場合はサンプルを出さず「取得できませんでした」と表示（誤解防止）。
 * ========================================================================== */

(() => {
  "use strict";
  if (window.__neShippingMonitorLoaded) return;
  window.__neShippingMonitorLoaded = true;

  const PREFIX = "nesm";
  const VERSION = "2.0.0";

  const CONFIG = {
    listPath: "/Userjyuchu/index",
    searchParam: "search_condi",
    allowMockFallback: false,     // 実運用では false（サンプルを出さない）
    overdueDays: 2,               // 受注日が基準日の「何日以上前」なら ⚠ 強調するか
    iframeTimeoutMs: 9000,        // iframe内で結果テーブルを待つ最大時間
    statuses: [
      { key: "print",    label: "印刷待ち", icon: "🖨", searchCondi: 17, match: /印刷待/ },
      { key: "allocate", label: "引当待ち", icon: "📦", searchCondi: 14, match: /引当|引き?当て/ },
      { key: "confirm",  label: "確認待ち", icon: "🔍", searchCondi: 12, match: /確認待|確認まち/ },
      { key: "printed",  label: "印刷済",   icon: "✅", searchCondi: 18, match: /印刷済/ },
    ],
    headerMatch: {
      orderDate: /受注日|受付日|注文日/,
      delivery:  /配送方法|発送方法|配送区分|出荷方法|配送/,
      orderNo:   /受注番号|受注伝票番号|伝票番号/,
    },
    // 「配送方法選択ミス」チェック：楽-ゆ/Ya-ゆ の受注なのにヤマト系が選ばれている件
    mismatchCheck: {
      enabled: true,
      label: "配送方法選択ミス",
      statuses: ["print", "printed"],          // 印刷待ち・印刷済を対象
      expected: /楽-ゆ|Ya-ゆ/,                   // 本来こうあるべき（行内のどこかに出る想定）
      wrong: ["ヤマト(発払い)B2V6", "ヤマト(ネコポス)"], // 選ばれていたらミス（【自己発】は対象外）
    },
  };

  const Log = {
    lines: [],
    push(msg) { const t = new Date().toTimeString().slice(0, 8); this.lines.push(`${t}  ${msg}`); if (this.lines.length > 200) this.lines.shift(); },
  };

  /* ===========================================================================
   * ADAPTER
   * ========================================================================= */
  const Adapter = {
    statusUrl(st) { return `${location.origin}${CONFIG.listPath}?${CONFIG.searchParam}=${st.searchCondi}`; },

    async fetchByStatus(st) {
      // 1) 隠しiframeで実際に開いて、描画後の結果テーブルを読む
      try {
        const r = await loadStatusViaIframe(this.statusUrl(st), CONFIG.iframeTimeoutMs);
        if (r.rows.length) {
          Log.push(`${st.key}: iframe実データ ${r.rows.length}件 (全${r.total ?? "?"}件)`);
          return { rows: r.rows, source: "page", total: r.total };
        }
        Log.push(`${st.key}: iframeで結果テーブルを検出できず（見出し: ${JSON.stringify(r.headers || []).slice(0, 120)}）`);
      } catch (e) {
        Log.push(`${st.key}: iframe取得失敗 ${e && e.message || e}`);
      }
      // 2) いま開いている画面が当該ステータスの一覧なら、その表を読む
      if (detectVisibleStatus() === st.key) {
        const s = scrapeDoc(document);
        if (s.rows.length) { Log.push(`${st.key}: 表示中ページから ${s.rows.length}件`); return { rows: s.rows, source: "page", total: detectTotalCount(document) }; }
      }
      // 3) サンプル（既定オフ）
      if (CONFIG.allowMockFallback) {
        const rows = await MockData.byStatus(st.key);
        return { rows, source: "sample", total: null };
      }
      return { rows: [], source: "none", total: null };
    },
  };

  /** 隠しiframeでURLを開き、結果テーブルが描画されたら解析して返す */
  function loadStatusViaIframe(url, timeoutMs) {
    return new Promise((resolve, reject) => {
      const f = document.createElement("iframe");
      f.style.cssText = "position:fixed;left:-10000px;top:0;width:1280px;height:900px;opacity:0;pointer-events:none;border:0;";
      let settled = false;
      const cleanup = () => { try { f.remove(); } catch (e) {} };
      const done = (val) => { if (settled) return; settled = true; cleanup(); resolve(val); };
      const fail = (e) => { if (settled) return; settled = true; cleanup(); reject(e); };
      const getDoc = () => { try { return f.contentDocument; } catch (e) { return null; } };

      f.addEventListener("load", () => {
        const start = Date.now();
        const iv = setInterval(() => {
          const doc = getDoc();
          if (doc) {
            const s = scrapeDoc(doc);
            if (s.rows.length) { clearInterval(iv); done({ rows: s.rows, total: detectTotalCount(doc), tableInfo: s.tableInfo, headers: s.headers }); return; }
          }
          if (Date.now() - start > timeoutMs) {
            clearInterval(iv);
            const d = getDoc();
            done({ rows: [], total: d ? detectTotalCount(d) : null, tableInfo: null, headers: d ? allHeaderSets(d) : null, noResult: true });
          }
        }, 350);
      });
      f.addEventListener("error", () => fail(new Error("iframe load error")));
      setTimeout(() => fail(new Error("timeout")), timeoutMs + 3000);
      f.src = url;
      document.body.appendChild(f);
    });
  }

  function scrapeDoc(root) {
    const tables = [...root.querySelectorAll("table")];
    let best = null;
    for (const table of tables) {
      const headers = headerTexts(table);
      const odCol = headers.findIndex((h) => CONFIG.headerMatch.orderDate.test(h));
      const dCol  = headers.findIndex((h) => CONFIG.headerMatch.delivery.test(h));
      const nCol  = headers.findIndex((h) => CONFIG.headerMatch.orderNo.test(h));
      if (odCol < 0 || dCol < 0) continue;
      const rows = dataRows(table).map((tr) => {
        const cellEls = [...tr.querySelectorAll("td,th")];
        const cells = cellEls.map((c) => (c.textContent || "").trim());
        const orderDate = normalizeDate(cells[odCol] || "");
        const deliveryMethod = cells[dCol] || "未設定";
        const orderNo = nCol >= 0 ? (cells[nCol] || "") : "";
        return orderDate ? { orderDate, deliveryMethod, orderNo, cells } : null;
      }).filter(Boolean);
      if (rows.length && (!best || rows.length > best.rows.length)) best = { rows, tableInfo: tableInfo(table), odCol, dCol, headers };
    }
    return best || { rows: [], tableInfo: null, odCol: -1, dCol: -1, headers: [] };
  }

  function detectTotalCount(root) {
    const body = root.body || root;
    const text = (body.textContent || "").replace(/\s+/g, " ");
    const m = text.match(/全\s*([\d,]+)\s*件/) || text.match(/([\d,]+)\s*件中/) || text.match(/検索結果\s*([\d,]+)/);
    return m ? parseInt(m[1].replace(/,/g, ""), 10) : null;
  }

  function detectVisibleStatus() {
    const condi = (location.search.match(/search_condi=(\d+)/) || [])[1];
    if (condi != null) { const hit = CONFIG.statuses.find((s) => String(s.searchCondi) === condi); if (hit) return hit.key; }
    const actives = [...document.querySelectorAll("[class*='active'],[class*='selected'],[class*='current'],[aria-selected='true'],h1,h2,.tab")];
    for (const st of CONFIG.statuses) if (actives.some((e) => e.offsetParent !== null && st.match.test(e.textContent || ""))) return st.key;
    return null;
  }

  const MockData = {
    byStatus(statusKey) {
      const ref = new Date(); const d = (off) => { const x = new Date(ref); x.setDate(x.getDate() + off); return x.toISOString().slice(0, 10); };
      const methods = ["ヤマト宅急便", "ヤマトネコポス", "佐川急便", "日本郵便 ゆうパック", "メール便"];
      const rng = seededRandom(statusKey.length * 7 + 3);
      const buckets = statusKey === "print" ? [{ day: -3, n: 6 }, { day: -1, n: 9 }, { day: 0, n: 14 }] : [{ day: -5, n: 3 }, { day: -2, n: 5 }, { day: 0, n: 11 }];
      const out = []; buckets.forEach(({ day, n }) => { for (let i = 0; i < n; i++) out.push({ orderDate: d(day), deliveryMethod: methods[Math.floor(rng() * methods.length)] }); });
      return Promise.resolve(out);
    },
  };

  function aggregate(orders, refDate) {
    const byDate = new Map(), byMethod = new Map();
    orders.forEach((o) => { byDate.set(o.orderDate, (byDate.get(o.orderDate) || 0) + 1); byMethod.set(o.deliveryMethod, (byMethod.get(o.deliveryMethod) || 0) + 1); });
    const dateRows = [...byDate.entries()].map(([date, count]) => ({ date, count, overdue: daysBefore(refDate, date) >= CONFIG.overdueDays })).sort((a, b) => a.date.localeCompare(b.date));
    const methodRows = [...byMethod.entries()].map(([method, count]) => ({ method, count })).sort((a, b) => b.count - a.count);
    return { total: orders.length, dateRows, methodRows, overdue: dateRows.filter(r => r.overdue).reduce((s, r) => s + r.count, 0) };
  }

  /* ===========================================================================
   * 測定 → モーダル
   * ========================================================================= */
  async function runMeasure(refDate) {
    refDate = refDate || today();
    Log.push(`measure開始 refDate=${refDate}`);
    const overlay = showModal(loadingMarkup(refDate));
    try {
      const results = [];
      for (const st of CONFIG.statuses) {
        const { rows, source, total } = await Adapter.fetchByStatus(st);
        results.push({ ...st, source, total, rawRows: rows, agg: aggregate(rows, refDate) });
      }
      overlay.querySelector(`.${PREFIX}-modal`).innerHTML = resultMarkup(refDate, results);
      wireModalClose(overlay);
    } catch (e) {
      Log.push(`エラー: ${e && e.message || e}`);
      overlay.querySelector(`.${PREFIX}-modal`).innerHTML = errorMarkup(refDate, e);
      wireModalClose(overlay);
    }
  }

  function showModal(innerHTML, extraClass) {
    closeModal();
    const overlay = el("div", `${PREFIX}-overlay`);
    const modal = el("div", `${PREFIX}-modal${extraClass ? " " + extraClass : ""}`);
    modal.innerHTML = innerHTML; overlay.appendChild(modal);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });
    document.addEventListener("keydown", onEsc); document.body.appendChild(overlay);
    return overlay;
  }
  function wireModalClose(overlay) { overlay.querySelectorAll(`.${PREFIX}-close`).forEach((b) => b.addEventListener("click", closeModal)); }
  function onEsc(e) { if (e.key === "Escape") closeModal(); }
  function closeModal() { document.removeEventListener("keydown", onEsc); document.querySelectorAll(`.${PREFIX}-overlay`).forEach((o) => o.remove()); }

  function modalHeader(refDate) {
    return `<div class="${PREFIX}-modal__head"><div class="${PREFIX}-modal__heading">
      <span class="${PREFIX}-modal__kicker">出荷漏れ・対応漏れ点検</span>
      <span class="${PREFIX}-modal__ref">基準日 ${fmtJP(refDate)}</span></div>
      <button class="${PREFIX}-close" type="button" aria-label="閉じる">✕</button></div>`;
  }
  function loadingMarkup(refDate) { return `${modalHeader(refDate)}<div class="${PREFIX}-loading">各ステータスを開いて集計しています…<br><small>数秒かかります</small></div>`; }
  function errorMarkup(refDate, e) { return `${modalHeader(refDate)}<div class="${PREFIX}-error">集計できませんでした。<br>${escapeHtml(String(e && e.message || e))}</div>`; }

  function resultMarkup(refDate, results) {
    const cards = results.map(statusCard).join("");
    const grandTotal = results.reduce((s, r) => s + r.agg.total, 0);
    const grandOverdue = results.reduce((s, r) => s + r.agg.overdue, 0);
    const anyNone = results.some((r) => r.source === "none");
    const anyPartial = results.some((r) => r.total != null && r.total > r.agg.total);
    let banner = "";
    if (anyNone) banner = `<div class="${PREFIX}-banner">実データを取得できなかったステータスがあります。右下の「🛈 診断ログ」を Claude に渡すと修正できます。</div>`;
    else if (anyPartial) banner = `<div class="${PREFIX}-banner">取得件数が全件に届いていない可能性があります（ページ送り）。診断ログで構造を確認すると全件集計に対応できます。</div>`;
    return `${modalHeader(refDate)}
      <div class="${PREFIX}-summary">
        <span>残 合計 <b>${grandTotal}</b> 件</span>
        <span class="${grandOverdue ? PREFIX + "-summary__alert" : ""}">うち漏れ疑い <b>${grandOverdue}</b> 件</span>
        <span class="${PREFIX}-summary__note">※ 受注日が基準日の${CONFIG.overdueDays}日以上前のものを ⚠ で強調</span>
      </div>${banner}
      <div class="${PREFIX}-grid">${cards}</div>
      ${mismatchMarkup(results)}`;
  }

  /** 配送方法選択ミス（楽-ゆ/Ya-ゆ なのにヤマト系）を印刷待ち・印刷済から検出 */
  function computeMismatch(results) {
    const cfg = CONFIG.mismatchCheck;
    const nz = (s) => (s || "").replace(/\s/g, "").replace(/（/g, "(").replace(/）/g, ")").replace(/【/g, "【");
    const wrongN = cfg.wrong.map(nz);
    const targets = results.filter((r) => cfg.statuses.includes(r.key));
    const unavailable = targets.filter((r) => r.source !== "page").map((r) => r.label);
    const hits = [];
    targets.forEach((r) => {
      if (r.source !== "page") return;
      (r.rawRows || []).forEach((row) => {
        const isExpected = (row.cells || []).some((c) => cfg.expected.test(c));
        const dmN = nz(row.deliveryMethod);
        const isWrong = wrongN.some((w) => dmN.includes(w));
        if (isExpected && isWrong) hits.push({ status: r.label, orderNo: row.orderNo, orderDate: row.orderDate, deliveryMethod: row.deliveryMethod });
      });
    });
    return { hits, unavailable };
  }

  function mismatchMarkup(results) {
    const cfg = CONFIG.mismatchCheck;
    if (!cfg || !cfg.enabled) return "";
    const { hits, unavailable } = computeMismatch(results);
    const ng = hits.length > 0;
    const cls = ng ? `${PREFIX}-mismatch--ng` : `${PREFIX}-mismatch--ok`;
    const desc = `対象：<b>楽-ゆ / Ya-ゆ</b> の受注で、<b>${cfg.wrong.map(escapeHtml).join("</b> / <b>")}</b> が選ばれて 印刷待ち・印刷済 に残っているもの`;
    let body = "";
    if (ng) {
      const rows = hits.map((h) => `<tr>
        <td>${escapeHtml(h.status)}</td>
        <td>${escapeHtml(h.orderNo || "—")}</td>
        <td>${h.orderDate ? fmtMD(h.orderDate) : "—"}</td>
        <td>${escapeHtml(h.deliveryMethod)}</td></tr>`).join("");
      body = `<div class="${PREFIX}-mismatch__body"><table>
        <thead><tr><th>ステータス</th><th>受注番号</th><th>受注日</th><th>配送方法</th></tr></thead>
        <tbody>${rows}</tbody></table></div>`;
    }
    const warn = unavailable.length
      ? `<div class="${PREFIX}-mismatch__warn">※ ${escapeHtml(unavailable.join("・"))} を取得できていないため、その分は判定できていません</div>`
      : "";
    const countText = ng ? `${hits.length}<small>件 要確認</small>` : `0<small>件</small>`;
    return `<section class="${PREFIX}-mismatch ${cls}">
      <div class="${PREFIX}-mismatch__head">
        <span class="${PREFIX}-mismatch__title">⚠ ${escapeHtml(cfg.label)}</span>
        <span class="${PREFIX}-mismatch__count">${countText}</span>
      </div>
      <div class="${PREFIX}-mismatch__desc">${desc}</div>
      ${body}${warn}
    </section>`;
  }

  function sourceBadge(source) {
    if (source === "page") return `<span class="${PREFIX}-badge ${PREFIX}-badge--live">実データ</span>`;
    if (source === "sample") return `<span class="${PREFIX}-badge ${PREFIX}-badge--sample">サンプル</span>`;
    return `<span class="${PREFIX}-badge ${PREFIX}-badge--none">取得失敗</span>`;
  }

  function statusCard(r) {
    const { icon, label, agg, source, total } = r;
    if (source === "none") {
      return `<section class="${PREFIX}-card ${PREFIX}-card--${r.key}">
        <a class="${PREFIX}-card__head" href="${Adapter.statusUrl(r)}" target="_blank" rel="noopener" title="クリックで${escapeHtml(label)}の一覧を新しいタブで開く"><span class="${PREFIX}-card__icon">${icon}</span>
          <span class="${PREFIX}-card__label">${label}</span><span class="${PREFIX}-card__go">↗</span>${sourceBadge(source)}
          <span class="${PREFIX}-card__total"><b>—</b></span></a>
        <div class="${PREFIX}-card__fail">実データを取得できませんでした。<br>診断ログをご利用ください。</div></section>`;
    }
    const partial = total != null && total > agg.total;
    const partialNote = partial ? `<div class="${PREFIX}-card__note">全 ${total} 件中 ${agg.total} 件を集計（ページ送りの可能性）</div>` : "";
    const dateRows = agg.dateRows.length
      ? agg.dateRows.map((d) => `<tr class="${d.overdue ? PREFIX + "-row--overdue" : ""}"><td>${d.overdue ? "⚠ " : ""}${fmtMD(d.date)}</td><td class="${PREFIX}-num">${d.count}</td></tr>`).join("")
      : `<tr><td colspan="2" class="${PREFIX}-empty">残りなし</td></tr>`;
    const methodRows = agg.methodRows.length
      ? agg.methodRows.map((m) => `<tr><td>${escapeHtml(m.method)}</td><td class="${PREFIX}-num">${m.count}</td></tr>`).join("")
      : `<tr><td colspan="2" class="${PREFIX}-empty">残りなし</td></tr>`;
    return `<section class="${PREFIX}-card ${PREFIX}-card--${r.key}">
      <a class="${PREFIX}-card__head" href="${Adapter.statusUrl(r)}" target="_blank" rel="noopener" title="クリックで${escapeHtml(label)}の一覧を新しいタブで開く"><span class="${PREFIX}-card__icon">${icon}</span>
        <span class="${PREFIX}-card__label">${label}</span><span class="${PREFIX}-card__go">↗</span>${sourceBadge(source)}
        <span class="${PREFIX}-card__total"><b>${agg.total}</b><small>件</small></span></a>
      ${partialNote}
      <div class="${PREFIX}-card__body">
        <div class="${PREFIX}-block"><div class="${PREFIX}-block__title">受注日別</div><table class="${PREFIX}-table"><tbody>${dateRows}</tbody></table></div>
        <div class="${PREFIX}-block"><div class="${PREFIX}-block__title">配送方法別</div><table class="${PREFIX}-table"><tbody>${methodRows}</tbody></table></div>
      </div></section>`;
  }

  /* ===========================================================================
   * 診断ログ（iframeで描画後のテーブルを出力）
   * ========================================================================= */
  function openLogPanel() {
    const body = `${modalHeader2("診断ログ")}
      <div class="${PREFIX}-log">
        <p class="${PREFIX}-log__lead">各ステータスを実際に開いて、描画後のテーブル構造を出力します。下のテキストを Claude に貼ってください。（数秒かかります）</p>
        <label class="${PREFIX}-log__opt"><input type="checkbox" class="${PREFIX}-log__samples" />
          サンプル値（実セルの中身）も含める　<b>※顧客氏名・住所などが入る場合あり。確認してから共有</b></label>
        <textarea class="${PREFIX}-log__ta" readonly>取得中…（数秒）</textarea>
        <div class="${PREFIX}-log__actions">
          <button class="${PREFIX}-btn ${PREFIX}-copy" type="button">コピー</button>
          <button class="${PREFIX}-btn ${PREFIX}-dl" type="button">.txt保存</button>
          <span class="${PREFIX}-copied" hidden>コピーしました</span></div></div>`;
    const overlay = showModal(body, `${PREFIX}-modal--log`);
    wireModalClose(overlay);
    const ta = overlay.querySelector(`.${PREFIX}-log__ta`);
    const cb = overlay.querySelector(`.${PREFIX}-log__samples`);
    const render = async () => { ta.value = "取得中…（数秒）"; ta.value = await buildLogReport(cb.checked); };
    render(); cb.addEventListener("change", render);
    overlay.querySelector(`.${PREFIX}-copy`).addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(ta.value); } catch { ta.select(); document.execCommand("copy"); }
      const c = overlay.querySelector(`.${PREFIX}-copied`); c.hidden = false; setTimeout(() => (c.hidden = true), 1500);
    });
    overlay.querySelector(`.${PREFIX}-dl`).addEventListener("click", () => {
      const blob = new Blob([ta.value], { type: "text/plain" }); const a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = `ne-shipping-monitor_log_${today()}.txt`; a.click(); URL.revokeObjectURL(a.href);
    });
  }
  function modalHeader2(title) { return `<div class="${PREFIX}-modal__head"><div class="${PREFIX}-modal__heading"><span class="${PREFIX}-modal__kicker">${title}</span></div><button class="${PREFIX}-close" type="button" aria-label="閉じる">✕</button></div>`; }

  async function buildLogReport(includeSamples) {
    const L = [];
    L.push("=== NE 出荷漏れ点検 診断ログ ===");
    L.push(`生成: ${new Date().toLocaleString("ja-JP")}`);
    L.push(`拡張バージョン: ${VERSION}  / iframe方式`);
    L.push(`現在URL: ${location.href}  オリジン: ${location.origin}`);
    L.push("");
    for (const st of CONFIG.statuses) {
      L.push(`===== 「${st.label}」 (search_condi=${st.searchCondi}) =====`);
      L.push(`URL: ${Adapter.statusUrl(st)}`);
      try {
        const doc = await openDocViaIframe(Adapter.statusUrl(st), CONFIG.iframeTimeoutMs);
        if (!doc) { L.push("iframe内ドキュメントにアクセス不可（フレーム拒否の可能性）"); L.push(""); continue; }
        L.push(`総件数の表示: ${detectTotalCount(doc) ?? "拾えず"}`);
        const tables = [...doc.querySelectorAll("table")];
        L.push(`テーブル数: ${tables.length}`);
        tables.forEach((t, i) => {
          const headers = headerTexts(t), rows = dataRows(t);
          if (!headers.length && !rows.length) return;
          const odCol = headers.findIndex((h) => CONFIG.headerMatch.orderDate.test(h));
          const dCol = headers.findIndex((h) => CONFIG.headerMatch.delivery.test(h));
          L.push(`  [表#${i + 1}] ${tableInfo(t).selector}  行${rows.length} 列${headers.length}  受注日=${odCol < 0 ? "なし" : "col" + odCol} 配送=${dCol < 0 ? "なし" : "col" + dCol}`);
          if (headers.length) L.push(`     見出し: ${JSON.stringify(headers)}`);
          if (includeSamples && rows.length) rows.slice(0, 2).forEach((tr, ri) => {
            const cells = [...tr.querySelectorAll("td,th")].map((c) => (c.textContent || "").trim().replace(/\s+/g, " ").slice(0, 30));
            L.push(`     行${ri + 1}: ${JSON.stringify(cells)}`);
          });
        });
      } catch (e) { L.push(`取得失敗: ${e && e.message || e}`); }
      L.push("");
    }
    L.push("--- 実行ログ ---");
    (Log.lines.length ? Log.lines.slice(-30) : ["（まだ測定していません）"]).forEach((l) => L.push("  " + l));
    L.push("");
    L.push("--- 注意 ---");
    L.push("共有前に、顧客氏名・住所・電話番号などの個人情報が含まれていないか確認してください。");
    return L.join("\n");
  }

  /** iframeで開いて、テーブルが現れるまで待ってから Document を返す（診断用） */
  function openDocViaIframe(url, timeoutMs) {
    return new Promise((resolve) => {
      const f = document.createElement("iframe");
      f.style.cssText = "position:fixed;left:-10000px;top:0;width:1280px;height:900px;opacity:0;pointer-events:none;border:0;";
      let settled = false;
      const finish = (doc) => { if (settled) return; settled = true; const out = doc; setTimeout(() => { try { f.remove(); } catch (e) {} }, 50); resolve(out); };
      f.addEventListener("load", () => {
        const start = Date.now();
        const iv = setInterval(() => {
          let doc = null; try { doc = f.contentDocument; } catch (e) {}
          const hasData = doc && scrapeDoc(doc).rows.length;
          if (hasData || Date.now() - start > timeoutMs) { clearInterval(iv); finish(doc); }
        }, 350);
      });
      f.addEventListener("error", () => finish(null));
      setTimeout(() => finish(null), timeoutMs + 3000);
      f.src = url; document.body.appendChild(f);
    });
  }

  /* テーブル補助 */
  function headerTexts(table) {
    let cells = table.querySelectorAll("thead th, thead td");
    if (!cells.length) { const first = table.querySelector("tr"); cells = first ? first.querySelectorAll("th,td") : []; }
    return [...cells].map((c) => (c.textContent || "").trim().replace(/\s+/g, " "));
  }
  function dataRows(table) { let rows = table.querySelectorAll("tbody tr"); if (!rows.length) rows = [...table.querySelectorAll("tr")].slice(1); return [...rows].filter((tr) => tr.querySelector("td")); }
  function tableInfo(table) {
    const id = table.id ? "#" + table.id : (table.className ? "." + String(table.className).split(/\s+/)[0] : "(no-id)");
    let selector = "table";
    if (table.id) selector += "#" + table.id; else if (table.className) selector += "." + String(table.className).trim().split(/\s+/).join(".");
    return { id, selector };
  }
  function allHeaderSets(doc) { return [...doc.querySelectorAll("table")].map((t) => headerTexts(t)).filter((h) => h.length); }

  /* ユーティリティ */
  function el(tag, className) { const e = document.createElement(tag); if (className) e.className = className; return e; }
  function today() { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
  function fmtJP(iso) { const [y, m, d] = iso.split("-"); return `${y}/${m}/${d}`; }
  function fmtMD(iso) { const [, m, d] = iso.split("-"); return `${Number(m)}/${Number(d)}`; }
  function daysBefore(refIso, dateIso) { return Math.round((new Date(refIso + "T00:00:00") - new Date(dateIso + "T00:00:00")) / 86400000); }
  function normalizeDate(raw) { const m = raw.match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/); if (!m) return null; const [, y, mo, d] = m; return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`; }
  function escapeHtml(s) { return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
  function seededRandom(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

  /* ===========================================================================
   * ポップアップ等からの指示を受ける
   * ========================================================================= */
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg && msg.type === "measure") runMeasure(msg.refDate);
      else if (msg && msg.type === "diagnose") openLogPanel();
      if (sendResponse) sendResponse({ ok: true });
      return false;
    });
  }
  // テスト/手動起動用フック
  window.__nesm = { measure: runMeasure, diagnose: openLogPanel, version: VERSION, CONFIG, Adapter };
  Log.push(`起動 v${VERSION} @ ${location.href}`);
})();

// ===== KWデータ(SP/SB) ダウンローダー =====
// 仕組み:
//  1) 広告データ用トークン(campaign-manager)で、有効キャンペーンを1件取得
//     （キャンペーン名マップも同時に作る）
//  2) そのキャンペーンの「広告グループ」ページへ遷移させ、ページが自分で投げる
//     cm/dds/retrieveReport を hook.js が捕捉 → ddsコンテキストの正規トークンを入手
//  3) そのトークンで SPAdGroupTargetsReport を marketplace 単位で日別に一括取得
//     （SP だけでなく SB2 のターゲットも含まれる）
const $ = (id) => document.getElementById(id);
const LOG_KEY = 'kw_dl_logs';
const CAP_KEY = 'amzn_captured';     // campaign-manager トークン
const DDS_KEY = 'amzn_cap_dds';      // dds トークン
const WORK_KEY = 'amzn_working_req';  // 広告データが保存した通るリクエスト

// アカウント既定値(捕捉できなかった時のフォールバック)
const DEF_ENTITY = 'ENTITY15N4IW58E6FGF';
const DEF_ACCOUNT = 'amzn1.ads-account.g.cpphd5hyo0w3vxgllvgkngr6m';
const DEF_MKT = 'A1VC38T7YXB528';

async function appendLog(text) {
  try {
    const s = await chrome.storage.local.get([LOG_KEY]);
    const logs = s[LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), msg: String(text) });
    if (logs.length > 2000) logs.splice(0, logs.length - 2000);
    await chrome.storage.local.set({ [LOG_KEY]: logs });
  } catch (_) {}
}
function setStatus(msg, append = true) {
  const el = $('status');
  if (append) el.textContent += '\n' + msg; else el.textContent = msg;
  el.scrollTop = el.scrollHeight;
}
function setProgress(p) { $('progress').style.width = p + '%'; }

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'kw-log') {
    appendLog(msg.text);
    setStatus(msg.text);
    if (typeof msg.extra?.progress === 'number') setProgress(msg.extra.progress);
  }
});

$('copylog').addEventListener('click', async () => {
  const s = await chrome.storage.local.get([LOG_KEY]);
  const logs = s[LOG_KEY] || [];
  const m = chrome.runtime.getManifest();
  const head = `=== ${m.name} KWログ v${m.version} ===\n${new Date().toISOString()}\n\n`;
  await navigator.clipboard.writeText(head + logs.map(l => `[${l.t.replace('T',' ').replace(/\..+/,'')}] ${l.msg}`).join('\n'));
  const b = $('copylog'); b.textContent = '✅ コピー済'; setTimeout(() => b.textContent = '📋 ログをコピー', 1500);
});
$('clearlog').addEventListener('click', async () => { await chrome.storage.local.remove([LOG_KEY]); setStatus('ログをクリアしました', false); });
$('stop').addEventListener('click', async () => { await chrome.storage.local.set({ kw_stop: true }); setStatus('■ 停止を要求しました（現在の処理後に停止）'); });

// ブラウザが拒否/上書きする禁止ヘッダを除去(トークン類は残す)
// ※ 大文字小文字違いの重複ヘッダ(Content-Type と content-type 等)は
//   Tomcatが HTTP 400 で弾くため、ここで大小無視で1つに統一する。
function cleanHeaders(headers) {
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  const out = {}; const seen = new Set();
  for (const [k, v] of Object.entries(headers || {})) {
    const lk = k.toLowerCase();
    if (!drop.test(k) && v != null && !seen.has(lk)) { out[k] = v; seen.add(lk); }
  }
  return out;
}
const hasCsrf = (h) => Object.keys(h || {}).some(k => /csrf-token/i.test(k));

// campaign-manager(広告データ)側のトークン + 捕捉ボディを取得
function bodyFieldCount(b) { try { return b.reportConfig.fields.length; } catch (_) { return 0; } }
async function getCampaignHeaders() {
  const s = await chrome.storage.local.get([WORK_KEY, CAP_KEY]);
  const wr = s[WORK_KEY];
  if (wr && wr.headers && hasCsrf(wr.headers)) return { headers: cleanHeaders(wr.headers), body: wr.body || null, ts: wr.ts || 0 };
  const cap = s[CAP_KEY];
  if (cap && cap.headers && hasCsrf(cap.headers)) return { headers: cleanHeaders(cap.headers), body: cap.body || null, ts: cap.ts || 0 };
  return null;
}
// dds側のトークンを取得
async function getDdsHeaders() {
  const s = await chrome.storage.local.get([DDS_KEY]);
  const c = s[DDS_KEY];
  if (c && c.headers && hasCsrf(c.headers)) return { headers: cleanHeaders(c.headers), ts: c.ts || 0 };
  return null;
}

const waitTabComplete = async (tabId, ms = 20000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { await new Promise(r => setTimeout(r, 500)); try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') break; } catch (_) {} }
};

$('run').addEventListener('click', async () => {
  const sd = (await chrome.storage.local.get('sharedDates')).sharedDates || {};
  const startDate = sd.start, endDate = sd.end;
  if (!startDate || !endDate) { setStatus('❌ 上部で開始日・終了日を入力してください', false); return; }

  const btn = $('run'); btn.disabled = true;
  let tab = null, movedTab = false;   // 終了後にキャンペーン一覧へ戻すため
  setStatus('▶ 実行準備中...', false); setProgress(0);
  await chrome.storage.local.set({ kw_stop: false, kw_status: { state: 'running', ts: Date.now() } });

  try {
    const fs = await AMZ_FS.status();
    if (fs.state !== 'granted') {
      setStatus('保存先フォルダが未設定です。上部の「保存先」から設定してください', false);
      chrome.tabs.create({ url: chrome.runtime.getURL('folder.html') });
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }

    // 広告タブを探す
    const tabs = await chrome.tabs.query({ url: ['https://advertising-japan.amazon.com/*', 'https://advertising.amazon.com/*'] });
    tab = (tabs || []).find(t => /campaign-manager\/all-campaigns/.test(t.url || ''))
             || (tabs || []).find(t => /advertising-japan\.amazon\.com/.test(t.url || ''))
             || (tabs || [])[0];
    if (!tab) { setStatus('❌ Amazon広告の画面のタブが見つかりません。上部「必要ページを開く」で開いてから実行してください', false); await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } }); btn.disabled = false; return; }

    // ── ① campaign-manager トークンを用意(無ければ all-campaigns を開いて捕捉) ──
    let cm = await getCampaignHeaders();
    if (!cm || (Date.now() - cm.ts > 180000)) {
      setStatus('🔄 トークン取得のためキャンペーン画面を読み込み中…');
      try {
        if (!/campaign-manager\/all-campaigns/.test(tab.url || '')) {
          await chrome.tabs.update(tab.id, { url: 'https://advertising-japan.amazon.com/campaign-manager/all-campaigns' });
        } else {
          await chrome.tabs.reload(tab.id);
        }
      } catch (_) {}
      await waitTabComplete(tab.id);
      const t1 = Date.now();
      while (Date.now() - t1 < 25000) { await new Promise(r => setTimeout(r, 800)); cm = await getCampaignHeaders(); if (cm) break; }
    }
    if (!cm) {
      setStatus('❌ トークンを取得できませんでした。キャンペーン画面を開き、ログイン状態と表の表示を確認して再実行してください', false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }

    // ── ② 有効キャンペーンを1件取得 + キャンペーン名マップ作成 ──
    setStatus('🔎 キャンペーン一覧を取得中…');
    const info = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fetchCampaignInfo,
      args: [{ headers: cm.headers, capBody: cm.body, defAccount: DEF_ACCOUNT, defEntity: DEF_ENTITY }]
    }))[0]?.result;

    if (!info || !info.ok || !info.campaignId) {
      setStatus(`❌ キャンペーン情報の取得に失敗: ${info?.error || '不明'}`, false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }
    setStatus(`  有効キャンペーン ${info.count}件 / 代表: ${info.campaignId}`);

    // ── ③ 代表キャンペーンの広告グループ画面へ遷移 → dds トークンを捕捉 ──
    setStatus('🔑 KW用トークン(dds)を取得中…');
    const beforeDds = (await getDdsHeaders())?.ts || 0;
    const agUrl = `https://advertising-japan.amazon.com/cm/sp/campaigns/${encodeURIComponent(info.campaignId)}/ad-groups?entityId=${encodeURIComponent(info.entityId || DEF_ENTITY)}`;
    try { await chrome.tabs.update(tab.id, { url: agUrl }); movedTab = true; } catch (_) {}
    await waitTabComplete(tab.id);
    let dds = null;
    const t2 = Date.now();
    while (Date.now() - t2 < 25000) { await new Promise(r => setTimeout(r, 800)); dds = await getDdsHeaders(); if (dds && dds.ts > beforeDds) break; }
    if (!dds) {
      setStatus('❌ KW用トークンを取得できませんでした。もう一度実行してみてください（広告グループ画面の表示が必要です）', false);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
      btn.disabled = false; return;
    }

    // ── ④ marketplace単位で日別にKWを一括取得 ──
    const result = (await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: kwDownloader,
      args: [{ startDate, endDate, headers: dds.headers, mkt: info.mkt || DEF_MKT, campMap: info.campMap || {}, campState: info.campState || {} }]
    }))[0]?.result;

    if (result?.ok) {
      setStatus(`\n🎉 完了: 成功 ${result.success} / 失敗 ${result.fail}`);
      const b = $('done'); if (b) { b.textContent = '✓ 取得済み'; b.classList.add('done'); }
      await chrome.storage.local.set({ kw_status: { state: 'done', ts: Date.now() } });
      try { chrome.notifications.create('kw-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: 'KWデータ：ダウンロード完了', message: `成功 ${result.success}日 / 失敗 ${result.fail}日`, priority: 2 }, (id) => setTimeout(() => chrome.notifications.clear(id), 8000)); } catch (_) {}
    } else {
      setStatus(`\n❌ エラー: ${result?.error || '不明'}`);
      await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
    }
  } catch (e) {
    setStatus(`\n❌ ${e.message}`); appendLog('error ' + e.message);
    await chrome.storage.local.set({ kw_status: { state: 'idle', ts: Date.now() } });
  } finally {
    // 広告グループ画面のままだと次の「広告データ」がトークンを取れないので、キャンペーン一覧へ戻す
    if (tab && movedTab) { try { await chrome.tabs.update(tab.id, { url: 'https://advertising-japan.amazon.com/campaign-manager/all-campaigns' }); } catch (_) {} }
    btn.disabled = false;
  }
});

// 状態バッジ
(async function initBadge() {
  const b = $('done'); if (!b) return;
  const setGreen = g => { b.textContent = g ? '✓ 取得済み' : '未取得'; b.classList.toggle('done', g); };
  try { const s = await chrome.storage.local.get(['kw_status']); setGreen((s.kw_status || {}).state === 'done'); } catch (_) { setGreen(false); }
  chrome.storage.onChanged.addListener((ch) => { if (ch.kw_status) setGreen((ch.kw_status.newValue || {}).state === 'done'); });
})();

// ============================================================
// ▼ 注入①: 有効キャンペーンを1件 + 名前マップを取得
//    campaign-manager トークンで UnifiedCampaignReportSyncAPI を叩く
// ============================================================
async function fetchCampaignInfo({ headers, capBody, defAccount, defEntity }) {
  try {
    const H = {}; const seenH = new Set();
    for (const [k, v] of Object.entries(headers || {})) { const lk = k.toLowerCase(); if (v != null && !seenH.has(lk)) { H[k] = v; seenH.add(lk); } }
    if (!seenH.has('content-type')) H['content-type'] = 'application/json';
    if (!seenH.has('accept')) H['accept'] = 'application/json';
    const account = headers['amazon-ads-account-id'] || headers['advertiserid'] || defAccount;
    const entity = headers['amazon-advertising-api-advertiserid'] || defEntity;
    const mkt = headers['amazon-advertising-api-marketplaceid'] || 'A1VC38T7YXB528';
    const today = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })();

    // UnifiedCampaignReportSyncAPI は列を省くと500になるため、ページが投げる
    // 正規ボディ(捕捉済み)をそのまま使い、日付とページングだけ差し替える。
    let body;
    const capN = (() => { try { return capBody.reportConfig.fields.length; } catch (_) { return 0; } })();
    if (capBody && capN >= 50 && capBody.reportConfig && capBody.reportConfig.reportId === 'UnifiedCampaignReportSyncAPI') {
      body = JSON.parse(JSON.stringify(capBody));
      body.reportConfig.startDate = today;
      body.reportConfig.endDate = today;
      // 画面の検索/絞り込みに左右されないよう filter は固定（state列は fields に含まれている前提）
      body.reportConfig.filter = { and: [
        { field: 'state', values: ['ENABLED', 'PAUSED'], comparisonOperator: 'IN', not: false },
        { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }
      ] };
      if (body.reportConfig.tokenPagination) body.reportConfig.tokenPagination = { size: 300 };
      else body.reportConfig.offsetPagination = { size: 300, offset: 0 };
    } else {
      body = { reportConfig: {
        reportId: 'UnifiedCampaignReportSyncAPI',
        fields: ['campaignExternalId','campaignName','state','statusName','marketplaceId','programType','advertiserId','campaignId','campaignType','campaignTargetingType','entityId','brandName','startDate','endDate','clicks','spend','orders','sales','roas'],
        filter: { and: [
          { field: 'state', values: ['ENABLED', 'PAUSED'], comparisonOperator: 'IN', not: false },
          { field: 'programType', values: ['SP', 'HSA', 'SB2', 'SBV'], comparisonOperator: 'IN', not: false }
        ] },
        startDate: today, endDate: today,
        timeUnits: ['SUMMARY', 'DAILY'],
        tokenPagination: { size: 300 },
        currencyOfView: 'JPY',
        columnsByTimeUnit: { SUMMARY: ['clicks','spend','orders','sales','roas'], DAILY: ['spend','sales','orders','clicks'] }
      }, accessRequestedAccounts: [{ accountId: account }] };
    }

    const r = await fetch('https://advertising-japan.amazon.com/a9g-api-gateway/campaign-manager/retrieveReport', {
      method: 'POST', credentials: 'include', mode: 'cors', headers: H, body: JSON.stringify(body)
    });
    if (!r.ok) { const t = await r.text().catch(() => ''); return { ok: false, error: `HTTP ${r.status} ${t.slice(0,120)}` }; }
    const j = await r.json();

    // 行配列を探す
    let rows = [];
    const isRow = o => o && typeof o === 'object' && ('campaignId' in o);
    (function visit(v) { if (Array.isArray(v)) { if (v.length && isRow(v[0]) && v.length > rows.length) rows = v; v.forEach(visit); } else if (v && typeof v === 'object') Object.values(v).forEach(visit); })(j);

    const campMap = {}, campState = {};
    for (const row of rows) if (row.campaignId) { campMap[row.campaignId] = row.campaignName || ''; if (row.state) campState[row.campaignId] = row.state; }

    // 代表キャンペーン: 有効なSPを優先、無ければ有効な任意、無ければ先頭
    const enabledSP = rows.find(r => r.state === 'ENABLED' && r.programType === 'SP');
    const enabledAny = rows.find(r => r.state === 'ENABLED');
    const pick = enabledSP || enabledAny || rows[0];
    if (!pick) return { ok: false, error: 'キャンペーンが0件でした' };

    return { ok: true, campaignId: pick.campaignId, entityId: entity, mkt, count: rows.length, campMap, campState };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  }
}

// ============================================================
// ▼ 注入②: dds トークンで「ターゲティング」タブと同じデータを日別取得
//    ・キーワード＋商品ターゲティング(ASIN/カテゴリ)＋オートの全ターゲット
//    ・現在有効なものだけ（ターゲット・広告グループ・キャンペーンがすべて配信中）
//    ・広告グループ名は SPAdGroupReport から（SP/SB両方入っている。起動時に1回）
// ============================================================
async function kwDownloader({ startDate, endDate, headers, mkt, campMap, campState }) {
  const writeLog = async (text) => {
    try { const KEY='kw_dl_logs'; const s=await chrome.storage.local.get([KEY]); const logs=s[KEY]||[]; logs.push({t:new Date().toISOString(),msg:String(text)}); if(logs.length>2000)logs.splice(0,logs.length-2000); await chrome.storage.local.set({[KEY]:logs}); } catch(_){}
  };
  const log = (text, progress) => { writeLog(text); try { chrome.runtime.sendMessage({ type: 'kw-log', text, extra: { progress } }); } catch (_) {} };

  const KW_URL = 'https://advertising-japan.amazon.com/a9g-api-gateway/cm/dds/retrieveReport';
  // filter に使う列(marketplaceId / targetState)は fields にも必須
  const KW_FIELDS = ['targetId','targetState','calculatedStatusName','programType','target','targetLocalized','matchType','targetBid','asin','title',
    'campaignId','marketplaceId','adGroupId','impressions','clicks','ctr','cpc','topOfSearchImpressionShare','spend','orders','sales','roas','acos','currencyCode'];

  // 禁止ヘッダのみ除去、トークン類はそのまま。
  // 大小違いの重複(Content-Type / content-type 等)はTomcatが400で弾くため統一。
  const dropH = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  const H = {}; const seenH = new Set();
  for (const [hk, hv] of Object.entries(headers || {})) { const lk = hk.toLowerCase(); if (!dropH.test(hk) && hv != null && !seenH.has(lk)) { H[hk] = hv; seenH.add(lk); } }
  if (!seenH.has('content-type')) H['content-type'] = 'application/json';
  if (!seenH.has('accept')) H['accept'] = 'application/json';

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const csvCell = v => { if (v === null || v === undefined) return ''; let s = typeof v === 'object' ? JSON.stringify(v) : String(v); if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"'; return s; };
  const toD = x => { const [y,m,d] = x.split('-').map(Number); return new Date(y, m-1, d); };
  const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const r2 = v => (v === null || v === undefined || v === '' || isNaN(Number(v))) ? '' : Math.round(Number(v) * 100) / 100;

  // dds retrieveReport を offset ページングで全件取得
  const fetchAll = async (reportConfig) => {
    let offset = 0, out = [], total = Infinity, page = 0;
    while (offset < total) {
      page++;
      const body = { reportConfig: { ...reportConfig, offsetPagination: { size: 100, offset } } };
      const r = await fetch(KW_URL, { method:'POST', credentials:'include', mode:'cors', headers:H, body: JSON.stringify(body) });
      if (!r.ok) { const t = await r.text().catch(()=> ''); throw new Error(`HTTP ${r.status} ${t.slice(0,160)}`); }
      const j = await r.json();
      const rep = j.report || {};
      const rows = Array.isArray(rep.data) ? rep.data : [];
      total = (typeof rep.numberOfRecords === 'number') ? rep.numberOfRecords : rows.length;
      out = out.concat(rows);
      if (rows.length === 0 || page > 500) break;
      offset += 100; await sleep(200);
    }
    return out;
  };

  const days = [];
  for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate()+1)) days.push(fmt(d));
  log(`📅 ${days.length}日分 / 有効なターゲット(SP・SB)を取得`);

  // ── 広告グループ名・状態マップ（起動時に1回） ──
  const agMap = {};
  try {
    const ags = await fetchAll({
      reportId: 'SPAdGroupReport',
      fields: ['adGroupId','adGroupName','adGroupState','campaignId','statusName','spend'],
      filter: { and: [] },
      startDate: endDate, endDate: endDate,
      timeUnits: ['SUMMARY'],
      columnsByTimeUnit: { SUMMARY: ['spend'] }
    });
    for (const a of ags) if (a.adGroupId) agMap[a.adGroupId] = a;
    log(`  広告グループ ${ags.length}件を確認`);
  } catch (e) {
    log(`  ⚠ 広告グループ名を取得できませんでした（名前空欄・広告グループ状態の判定なしで続行）: ${e.message}`);
  }

  // 現在有効か: KW・広告グループ・キャンペーンのどこかが停止/アーカイブなら除外
  const OFF = /PAUSED|ARCHIVED|ENDED|TERMINATED/i;
  const isActive = (r) => {
    if (r.targetState !== 'ENABLED') return false;
    if (OFF.test(r.calculatedStatusName || '')) return false;
    const ag = agMap[r.adGroupId];
    if (ag && ag.adGroupState && ag.adGroupState !== 'ENABLED') return false;
    if (ag && OFF.test(ag.statusName || '')) return false;
    const cs = campState && campState[r.campaignId];
    if (cs && cs !== 'ENABLED') return false;
    return true;
  };

  const fetchDayKw = (day) => fetchAll({
    reportId: 'SPAdGroupTargetsReport',
    fields: KW_FIELDS,
    filter: { and: [
      { field: 'marketplaceId', comparisonOperator: 'EQUALS', value: mkt, not: false },
      { field: 'targetState', comparisonOperator: 'IN', values: ['ENABLED'], not: false }
    ] },
    startDate: day, endDate: day,
    timeUnits: ['SUMMARY', 'DAILY'],
    columnsByTimeUnit: { SUMMARY: ['impressions','spend','orders','sales','roas'], DAILY: ['spend','sales','roas','impressions'] }
  });

  const TYPE_JA = { SP: 'SP', SB2: 'SB', HSA: 'SB', SBV: 'SB動画' };
  const MATCH_JA = { EXACT: '完全一致', PHRASE: 'フレーズ一致', BROAD: '部分一致' };
  const MATCH_ORDER = { BROAD: 0, PHRASE: 1, EXACT: 2, TARGETING_EXPRESSION: 3, TARGETING_EXPRESSION_PREDEFINED: 4 };
  const AUTO_JA = { 'close-match': 'ほぼ一致', 'loose-match': 'ゆるやかな一致', 'substitutes': '代替商品', 'complements': '補完商品' };
  // 種別: キーワード / 商品 / オート
  const kindJa = r => r.matchType === 'TARGETING_EXPRESSION' ? '商品' : r.matchType === 'TARGETING_EXPRESSION_PREDEFINED' ? 'オート' : 'キーワード';
  // マッチタイプ表示: KWは一致種別、商品は ASIN(拡張)/ASIN/カテゴリ、オートは一致グループ
  const matchJa = r => {
    if (MATCH_JA[r.matchType]) return MATCH_JA[r.matchType];
    const t = String(r.target || '');
    if (r.matchType === 'TARGETING_EXPRESSION_PREDEFINED') return AUTO_JA[t] || t;
    if (/^asin-expanded=/i.test(t)) return 'ASIN(拡張)';
    if (/^asin=/i.test(t)) return 'ASIN';
    if (/^category=/i.test(t)) return 'カテゴリ';
    return r.matchType || '';
  };
  // ターゲット表示: 商品ターゲティングは asin="B0..." → B0... に整形
  //   （targetLocalized は商品ターゲティングだと 'asin-expanded= B0…”' のように崩れるので target を優先）
  const targetJa = r => {
    const t = String(r.target || '');
    if (r.matchType === 'TARGETING_EXPRESSION_PREDEFINED') return AUTO_JA[t] || t;
    if (r.matchType === 'TARGETING_EXPRESSION') {
      const m = t.match(/^asin(?:-expanded)?="?([^"]+)"?$/i);
      if (m) return m[1];
      return r.targetLocalized || t;
    }
    // キーワードは target（登録した文字列そのまま）を使う。targetLocalized は環境によって英訳されて返り、
    // 「耐火バッグ」「防火袋」がどちらも "fireproof bag" になる等、別KWが同名化するため使わない。
    return t || r.targetLocalized || '';
  };
  const statusJa = s => (!s || s === 'UNKNOWN' || s === 'TARGETING_CLAUSE_STATUS_LIVE') ? '配信中' : s;

  const outHeader = ['日付','広告タイプ','キャンペーン名','広告グループ名','種別','キーワード/ターゲット','マッチタイプ','商品名','ステータス','入札額',
    'インプレッション','クリック','CTR(%)','CPC','合計費用','商品購入数','売上','ROAS','ACOS(%)','検索結果上部のインプレッションシェア(%)',
    'キャンペーンID','広告グループID','ターゲットID'];
  const toRow = (r, day) => [day, TYPE_JA[r.programType] || r.programType, (campMap && campMap[r.campaignId]) || '', (agMap[r.adGroupId] || {}).adGroupName || '',
    kindJa(r), targetJa(r), matchJa(r), r.title || '', statusJa(r.calculatedStatusName), r.targetBid,
    r.impressions, r.clicks, r2(r.ctr), r2(r.cpc), r2(r.spend), r.orders, r2(r.sales), r2(r.roas), r2(r.acos), r2(r.topOfSearchImpressionShare),
    r.campaignId, r.adGroupId, r.targetId];
  const sortKey = (r) => [TYPE_JA[r.programType] || '', (campMap && campMap[r.campaignId]) || r.campaignId, (agMap[r.adGroupId] || {}).adGroupName || r.adGroupId, kindJa(r), targetJa(r)];
  const cmp = (a, b) => {
    const ka = sortKey(a), kb = sortKey(b);
    for (let i = 0; i < ka.length; i++) { const c = String(ka[i]).localeCompare(String(kb[i]), 'ja'); if (c) return c; }
    return (MATCH_ORDER[a.matchType] ?? 9) - (MATCH_ORDER[b.matchType] ?? 9);
  };

  let success = 0, fail = 0;
  for (let di = 0; di < days.length; di++) {
    const day = days[di];
    try { if ((await chrome.storage.local.get('kw_stop')).kw_stop) { log('■ 停止しました'); break; } } catch (_) {}
    try {
      const all = await fetchDayKw(day);
      const rows = all.filter(isActive).sort(cmp);
      const lines = [outHeader.map(csvCell).join(',')];
      for (const r of rows) lines.push(toRow(r, day).map(csvCell).join(','));
      const csv = '﻿' + lines.join('\r\n') + '\r\n';
      const [yy, mm, dd] = day.split('-');
      const resp = await chrome.runtime.sendMessage({ type:'amz_save_data', subdir:'', filename:`KWデータ-${yy}-${mm}${dd}.csv`, dataUrl:'data:text/csv;charset=utf-8;base64,' + btoa(unescape(encodeURIComponent(csv))) });
      if (!resp || !resp.ok) throw new Error('保存に失敗: ' + ((resp && resp.error) || '保存先未設定/許可切れ'));
      success++;
      const nAg = new Set(rows.map(r => r.adGroupId)).size;
      log(`  ✅ ${day} → 有効ターゲット ${rows.length}件（${nAg}広告グループ / ${new Set(rows.map(r => r.campaignId)).size}キャンペーン）保存`, Math.round(((di+1)/days.length)*100));
    } catch (e) {
      fail++;
      log(`  ❌ ${day} ${e.message}`, Math.round(((di+1)/days.length)*100));
    }
    await sleep(200);
  }
  log(`\n🎉 完了: 成功 ${success} / 失敗 ${fail}`, 100);
  return { ok: true, success, fail };
}

// ============================================================
// officialjob.js  （background.js から importScripts）
// 「公式の日別キャンペーンレポート（期間指定）」をバックグラウンドで作成・ダウンロードする（v2.11.0〜）
//
// ・毎日の①広告データ（65列版・速い）は従来どおり ads.js。こちらは Amacheck の照合で合わない月だけ使う。
// ・Amazon側の作成に3〜10分かかるので、ウィンドウを閉じても進むよう Service Worker + chrome.alarms で待つ。
// ・出力: 公式広告レポート-YYYY-MMDD_YYYY-MMDD.csv（期間まとめて1ファイル・「日付」列あり）
//   列 = 公式の10列（日付,キャンペーン名,キャンペーンID,広告プロダクト,予算の通貨,合計費用,売上,クリック数,商品購入数,インプレッション）
//        ＋ ターゲティングタイプ（オート/マニュアル）＋ 状態（有効/一時停止/アーカイブ）
//   費用・売上・クリックがすべて0の行は入れない。状態では絞らない。SP/SB とも入る。
// ・あわせて従来の取得元（キャンペーン画面）と日別合計を照合し、¥100超かつ2%超ずれた日をログに出す。
// ============================================================
const OFFICIAL_JOB_KEY = 'official_job';
const OFFICIAL_ALARM = 'official_poll';
const ADS_LOG_KEY = 'amzn_dl_logs';
const OFFICIAL_TIMEOUT_MS = 30 * 60 * 1000;

async function offLog(text) {
  try {
    const s = await chrome.storage.local.get([ADS_LOG_KEY]);
    const logs = s[ADS_LOG_KEY] || [];
    logs.push({ t: new Date().toISOString(), cat: 'official', msg: String(text), extra: null });
    if (logs.length > 2000) logs.splice(0, logs.length - 2000);
    await chrome.storage.local.set({ [ADS_LOG_KEY]: logs });
  } catch (_) {}
  try { chrome.runtime.sendMessage({ type: 'official-log', text: String(text) }).catch(() => {}); } catch (_) {}
}
async function getJob() { return (await chrome.storage.local.get(OFFICIAL_JOB_KEY))[OFFICIAL_JOB_KEY] || null; }
async function setJob(patch) {
  const cur = (await getJob()) || {};
  const job = { ...cur, ...patch, updatedAt: Date.now() };
  await chrome.storage.local.set({ [OFFICIAL_JOB_KEY]: job });
  return job;
}
async function findAdsTab() {
  const tabs = await chrome.tabs.query({ url: ['https://advertising-japan.amazon.com/*'] });
  return (tabs || []).find((t) => /campaign-manager\/all-campaigns/.test(t.url || '')) || (tabs || [])[0] || null;
}
async function inTab(tab, func, arg) {
  return (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args: [arg] }))[0]?.result;
}
const offYen = (n) => '¥' + Math.round(n).toLocaleString();
const offDays = (startDate, endDate) => {
  const toD = (x) => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const out = []; for (let d = toD(startDate), e = toD(endDate); d <= e; d.setDate(d.getDate() + 1)) out.push(fmt(d));
  return out;
};
const cleanH = (headers) => {
  const drop = /^(sec-|referer|referrer|host|origin|cookie|content-length|connection|accept-encoding|user-agent|x-amzn-trace-id)/i;
  const out = {}; const seen = new Set();
  for (const [k, v] of Object.entries(headers || {})) { const lk = k.toLowerCase(); if (!drop.test(k) && v != null && !seen.has(lk)) { out[k] = v; seen.add(lk); } }
  return out;
};

// ---- 開始（ポップアップのボタンから） ----
async function officialStart({ startDate, endDate }) {
  const cur = await getJob();
  if (cur && (cur.state === 'starting' || cur.state === 'waiting')) return { ok: false, error: 'すでに作成中のレポートがあります（完了までお待ちください）' };
  const fs = await AMZ_FS.status();
  if (fs.state !== 'granted') return { ok: false, error: '保存先フォルダが未設定／要許可です。上部の「保存先」から設定してください' };
  const tab = await findAdsTab();
  if (!tab) return { ok: false, error: 'Amazon広告のタブが見つかりません。上部「必要ページを開く」で開いてから実行してください' };
  const days = offDays(startDate, endDate);
  if (!days.length) return { ok: false, error: '期間が正しくありません' };
  await setJob({ state: 'starting', startDate, endDate, startedAt: Date.now(), message: '準備中…', fileName: null, error: null });
  // 開始処理は待たずに進める（ポップアップへはすぐ返す）
  officialKickoff(tab, startDate, endDate, days).catch(async (e) => {
    await setJob({ state: 'error', error: String(e && e.message || e), message: '❌ ' + String(e && e.message || e) });
    await offLog('❌ 公式レポート: ' + String(e && e.message || e));
  });
  return { ok: true };
}

async function officialKickoff(tab, startDate, endDate, days) {
  await offLog(`📑 公式日別キャンペーンレポート ${startDate}〜${endDate}（${days.length}日分）の作成を開始`);
  // トークン（統合レポートAPIは広告グループ画面の dds トークンで動作確認済み）
  const tr = await AMZ_TOKEN.ensureFresh(tab, (t) => offLog(t), { ddsOnly: true });
  if (!tr.tok) throw new Error('トークンを取得できませんでした。Amazon広告にログインしているか確認してください');
  const headers = cleanH(tr.tok.headers);
  // 作成（期間まとめて1件・メール無し）
  const stamp = new Date(Date.now() + 9 * 3600 * 1000).toISOString().replace(/[^\d]/g, '').slice(2, 12);
  const name = `amazon-downloader 公式 ${startDate}〜${endDate} (${stamp})`;
  const cr = await inTab(tab, OFFICIAL.pageCreate, { headers, startDate, endDate, name, account: OFFICIAL.ACCOUNT, fields: OFFICIAL.FIELDS });
  if (!cr || !cr.ok) { if (tr.moved) await AMZ_TOKEN.restore(tab); throw new Error('レポートを作成できませんでした: ' + (cr && cr.error || '不明')); }
  await offLog(`📝 Amazonの「レポート」画面に「${name}」を作成しました。完成まで3〜10分ほどかかります（ウィンドウを閉じても進みます）`);
  await setJob({ state: 'waiting', cfgId: cr.cfgId, schedId: cr.schedId, name, headers, message: 'Amazon側で作成中…（照合用データ取得中）' });
  chrome.alarms.create(OFFICIAL_ALARM, { periodInMinutes: 0.5 });
  // 待っている間に、照合・状態・ターゲティングタイプ用のキャンペーン画面の値を取る
  const cm = await inTab(tab, OFFICIAL.pageCmDaily, { headers, days, account: OFFICIAL.ACCOUNT }) || {};
  if (tr.moved) await AMZ_TOKEN.restore(tab);
  const meta = {}, totals = {};
  for (const [day, d] of Object.entries(cm)) {
    if (!d || d.error) { totals[day] = null; continue; }
    totals[day] = d.total;
    for (const x of d.rows || []) {
      const v = { s: x.state || '', t: x.campaignTargetingType || '' };
      if (x.campaignExternalId) meta['id:' + x.campaignExternalId] = v;
      if (x.campaignId) meta['id:' + x.campaignId] = v;
      if (x.campaignName) meta['name:' + x.campaignName] = v;
    }
  }
  // 日別・キャンペーン別（差の内訳表示用）
  const cmBy = {};
  for (const [day, d] of Object.entries(cm)) for (const x of (d && d.rows) || []) {
    const k = day + '|' + (x.campaignExternalId || x.campaignId);
    cmBy[k] = x.spend; if (x.campaignName) cmBy[day + '|n:' + x.campaignName] = x.spend;
  }
  await setJob({ meta, totals, cmBy, message: 'Amazon側で作成中…' });
  await officialPollOnce();
}

// ---- 待機（alarms から30秒ごと） ----
async function officialPollOnce() {
  const job = await getJob();
  if (!job || job.state !== 'waiting' || !job.cfgId) { chrome.alarms.clear(OFFICIAL_ALARM); return; }
  if (job.busy && Date.now() - job.busy < 120000) return;   // 前回の処理中
  if (Date.now() - job.startedAt > OFFICIAL_TIMEOUT_MS) {
    chrome.alarms.clear(OFFICIAL_ALARM);
    await setJob({ state: 'error', error: 'timeout', message: '❌ 30分以内に完成しませんでした。Amazonの「レポート」画面から直接ダウンロードしてください' });
    await offLog(`❌ 公式レポート「${job.name}」が30分以内に完成しませんでした。Amazonの「レポート」画面から直接ダウンロードできます`);
    return;
  }
  await setJob({ busy: Date.now() });
  try {
    // 状態確認: 広告タブがあればページ内で、無ければ拡張から直接
    let st = null;
    const tab = await findAdsTab();
    if (tab) { try { st = await inTab(tab, OFFICIAL.pagePoll, { headers: job.headers, cfgId: job.cfgId }); } catch (_) { st = null; } }
    if (!st || !st.ok) st = await OFFICIAL.pagePoll({ headers: job.headers, cfgId: job.cfgId });
    if (!st || !st.ok) { await setJob({ busy: 0, message: 'Amazon側で作成中…（状態確認に失敗。再試行します）' }); return; }
    if (/FAIL|CANCEL/i.test(st.status || '')) {
      chrome.alarms.clear(OFFICIAL_ALARM);
      await setJob({ state: 'error', busy: 0, error: st.status, message: `❌ Amazon側で作成に失敗しました（${st.status} ${st.failure || ''}）` });
      await offLog(`❌ 公式レポートの作成に失敗（${st.status} ${st.failure || ''}）`);
      return;
    }
    if (st.status !== 'COMPLETED') { await setJob({ busy: 0, message: `Amazon側で作成中…（${Math.round((Date.now() - job.startedAt) / 60000)}分経過）` }); return; }
    chrome.alarms.clear(OFFICIAL_ALARM);
    await setJob({ message: 'ダウンロード中…' });
    await officialFinish(job, st.schedId || job.schedId);
  } catch (e) {
    await setJob({ busy: 0, message: '状態確認でエラー（再試行します）: ' + String(e && e.message || e) });
  }
}

async function officialFinish(job, schedId) {
  // ダウンロード（download-report → S3 へリダイレクト。host_permissions で取得）
  let text;
  try {
    const url = `https://advertising-japan.amazon.com/reporting/subscriptions/${encodeURIComponent(job.cfgId)}/download-report/${encodeURIComponent(schedId)}`;
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const u8 = new Uint8Array(await res.arrayBuffer());
    text = (u8[0] === 0x1f && u8[1] === 0x8b)
      ? await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text()
      : new TextDecoder('utf-8').decode(u8);
  } catch (e) {
    await setJob({ state: 'error', busy: 0, error: 'download', message: `❌ ダウンロードに失敗しました（${e.message}）。Amazonの「レポート」画面の「${job.name}」から直接ダウンロードできます` });
    await offLog(`❌ 公式レポートのダウンロードに失敗（${e.message}）。Amazonの「レポート」画面の「${job.name}」から直接ダウンロードできます`);
    return;
  }
  const table = OFFICIAL.parseCsv(text);
  if (!table.length || table[0].length < OFFICIAL.FIELDS.length) {
    await setJob({ state: 'error', busy: 0, message: '❌ 公式レポートの形式が想定と違いました' });
    await offLog('❌ 公式レポートの形式が想定と違いました: ' + (table[0] || []).join(',').slice(0, 150));
    return;
  }
  // 列は FIELDS の順: 0日付 1キャンペーン名 2キャンペーンID 3広告プロダクト 4予算の通貨 5合計費用 6売上 7クリック数 8商品購入数 9インプレッション
  const I = { date: 0, name: 1, id: 2, cost: 5, sales: 6, clicks: 7 };
  const TT_JA = { AUTOMATIC: 'オート', AUTO: 'オート', MANUAL: 'マニュアル' };
  const ST_JA = { ENABLED: '有効', PAUSED: '一時停止', ARCHIVED: 'アーカイブ' };
  const meta = job.meta || {};
  const rows = table.slice(1).filter((r) => OFFICIAL.num(r[I.cost]) !== 0 || OFFICIAL.num(r[I.sales]) !== 0 || OFFICIAL.num(r[I.clicks]) !== 0);
  rows.sort((a, b) => (OFFICIAL.normDate(a[I.date]) + a[I.name]).localeCompare(OFFICIAL.normDate(b[I.date]) + b[I.name], 'ja'));
  const lines = [table[0].concat(['ターゲティングタイプ', '状態']).map(OFFICIAL.csvCell).join(',')];
  for (const r of rows) {
    const m = meta['id:' + OFFICIAL.normId(r[I.id])] || meta['name:' + r[I.name]] || { s: '', t: '' };
    lines.push(r.concat([TT_JA[m.t] || m.t || '', ST_JA[m.s] || m.s || '']).map(OFFICIAL.csvCell).join(','));
  }
  const csv = '﻿' + lines.join('\r\n') + '\r\n';
  const compact = (d) => { const [y, m, dd] = d.split('-'); return `${y}-${m}${dd}`; };
  const fileName = `公式広告レポート-${compact(job.startDate)}_${compact(job.endDate)}.csv`;
  try { await AMZ_FS.writeFile('', fileName, new TextEncoder().encode(csv)); }
  catch (e) {
    await setJob({ state: 'error', busy: 0, message: '❌ 保存に失敗: ' + e.message });
    await offLog('❌ 公式レポートの保存に失敗: ' + e.message);
    return;
  }
  // 照合（公式 vs キャンペーン画面の値・日別合計）
  const off = {};
  for (const r of rows) { const d = OFFICIAL.normDate(r[I.date]); (off[d] = off[d] || []).push(r); }
  const warns = [];
  for (const day of offDays(job.startDate, job.endDate)) {
    const o = (off[day] || []).reduce((a, r) => a + OFFICIAL.num(r[I.cost]), 0);
    const c = job.totals ? job.totals[day] : null;
    if (c == null) continue;
    const diff = o - c;
    if (Math.abs(diff) > 100 && Math.abs(diff) > o * 0.02) {
      const camp = (off[day] || []).map((r) => { const v = (job.cmBy || {})[day + '|' + OFFICIAL.normId(r[I.id])] ?? (job.cmBy || {})[day + '|n:' + r[I.name]] ?? 0; const ov = OFFICIAL.num(r[I.cost]); return { n: r[I.name], o: ov, v, d: ov - v }; })
        .filter((z) => Math.abs(z.d) > 100).sort((a, b) => Math.abs(b.d) - Math.abs(a.d)).slice(0, 3).map((z) => `${z.n}（公式${offYen(z.o)}/画面${offYen(z.v)}）`).join('、');
      warns.push(`  ⚠ ${day} 公式${offYen(o)} / 広告データ(画面)${offYen(c)}（差${offYen(diff)}）${camp ? ' ' + camp : ''}`);
    }
  }
  const total = rows.reduce((a, r) => a + OFFICIAL.num(r[I.cost]), 0);
  await offLog(`✅ 「${fileName}」を保存しました（${rows.length}行・合計費用${offYen(total)}）`);
  if (warns.length) await offLog(`⚠ 広告データ（毎日の65列版）と合わない日が ${warns.length}日あります:\n` + warns.join('\n'));
  else await offLog('  照合: 毎日の広告データ（65列版）と日別合計はすべて一致（差¥100以内または2%以内）');
  await setJob({ state: 'done', busy: 0, fileName, headers: null, meta: null, cmBy: null, message: `✅ ${fileName} を保存（${warns.length ? `合わない日 ${warns.length}日・ログ参照` : '照合OK'}）` });
  try {
    chrome.notifications.create('official-' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '公式レポート：保存しました',
      message: `${fileName}${warns.length ? `\n広告データと合わない日 ${warns.length}日（ログ参照）` : ''}`, priority: 2 }, (id) => setTimeout(() => chrome.notifications.clear(id), 15000));
  } catch (_) {}
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === OFFICIAL_ALARM) officialPollOnce(); });

// 拡張の更新・再読み込みで alarms は消える → 起動のたびに待機を再開する（v2.12.4）
async function officialResume() {
  try {
    const job = await getJob();
    if (!job || job.state !== 'waiting' || !job.cfgId) return;
    const a = await chrome.alarms.get(OFFICIAL_ALARM);
    if (!a) { chrome.alarms.create(OFFICIAL_ALARM, { periodInMinutes: 0.5 }); await setJob({ busy: 0 }); officialPollOnce(); }
  } catch (_) {}
}
officialResume();
chrome.runtime.onStartup.addListener(officialResume);
chrome.runtime.onInstalled.addListener(officialResume);

# Amazon広告 キャンペーン一括ダウンローダー v2.0.0

Amazon広告コンソール(advertising-japan.amazon.com)のキャンペーンデータを、
日付範囲で1日ずつCSVに一括ダウンロードするChrome拡張。

## v2.0.0 の新機能：トークン自動取得

これまでは毎回 retrieveReport を手動で貼り直す必要がありましたが、
v2.0.0 では**ページが自分で送る retrieveReport を拡張が傍受して、
新鮮なトークンを自動で保存**します。

- `hook.js`(MAINワールド) … ページの fetch/XHR をフックし retrieveReport を捕捉
- `bridge.js`(ISOLATED) … 捕捉した内容を chrome.storage に保存
- popup は保存済みトークンを自動で使用（手動貼り付けは保険として継続利用可）

### 使い方（基本）

1. キャンペーン画面 `advertising-japan.amazon.com/campaign-manager/all-campaigns`
   を**ログイン状態で開く**（または再読み込み）
   → この時点でトークンが自動捕捉される
2. 拡張を開く。「🟢 トークン自動取得：有効」と出ていればOK
3. 日付範囲・間隔を入れて実行

「⚪ 未捕捉」や「🟡 古い」と出たら、キャンペーン画面を再読み込みしてから実行。

### 手動貼り付け（保険）

自動取得がうまく働かない場合は、従来どおり「リクエスト設定(上級)」に
retrieveReport の Copy as fetch を貼り付けて使えます。

## 注意・制約

- トークンはAmazonのログインセッションごとにOFF。ページを開いていれば自動更新される。
- データ取得可能期間：スポンサープロダクト約95日／ブランド等約60日（Amazon側の制限）。
- 読み込んだフォルダは移動・削除しない（消すと拡張が消える）。

## ファイル

- manifest.json / popup.html / popup.js
- hook.js / bridge.js … トークン自動取得（v2.0.0で追加）
- icons/

## v2.1.0 の変更（Amazon仕様変更対応・2026-09）

Amazon側がキャンペーンレポートのAPIを変更したため追随:
- エンドポイント: `/cm/dds/retrieveReport` → `/campaign-manager/retrieveReport`
- レポートID: `CrossProgramCampaignFullFunnelReport` → `UnifiedCampaignReportSyncAPI`
- ページング: offsetPagination → tokenPagination（次ページトークン方式）
- 取得項目: 65列（新仕様のまま採用）
- hook.js の捕捉条件を `retrieveReport` 全般に緩和（新旧エンドポイント両対応）
